# The Hub local asset manifest

Everything below is downloaded by `INSTALL.bat` and pinned to an exact
version. After the install, only web search touches the internet.

## Thinking, hearing, seeing
| what | where from | file |
|---|---|---|
| language model | `mradermacher/Huihui-Qwen3-VL-4B-Thinking-abliterated-GGUF` | `...Q4_K_M.gguf` (2.33 GB) |
| vision projector | same repo | `...mmproj-Q8_0.gguf` (433 MB) |
| speech | `ggerganov/whisper.cpp` | `ggml-base.en.bin` |
| runtime | llama.cpp `b10456` | Windows CUDA 12.4 or CPU |
| runtime | whisper.cpp `v1.9.2` | `whisper-bin-x64.zip` |
| interpreter | python.org | Python 3.13.15 embedded |

## Generating
| what | where from | file | size |
|---|---|---|---|
| image + video runtime | stable-diffusion.cpp `master-709-92a3b73` | CUDA 12 / Vulkan / AVX2 | ~0.9 GB |
| image checkpoint | `offgrid-ai/dreamshaper-xl-v2-turbo-GGUF` | `...-Q4_K.gguf` | 2.8 GB |
| image fallback | `second-state/stable-diffusion-v1-5-GGUF` | `...-Q8_0.gguf` | 1.8 GB |
| video model | `samuelchristlie/Wan2.1-T2V-1.3B-GGUF` | `...-Q5_K_M.gguf` | 1.1 GB |
| video VAE | `Comfy-Org/Wan_2.1_ComfyUI_repackaged` | `wan_2.1_vae.safetensors` | 0.25 GB |
| video text encoder | `city96/umt5-xxl-encoder-gguf` | `...-Q3_K_M.gguf` | 3.1 GB |
| 3D runtime | trellis.cpp `v0.4.3` | CUDA or Vulkan, Windows | 0.7 GB |
| 3D weights (512 path) | `ilintar/trellis2-gguf` | 8 files | 11.3 GB |

Roughly **21 GB** for the generation half, on top of about 5 GB for the base.
`python install.py --generators` retries only this part.

The 1024-resolution TRELLIS weights are deliberately not downloaded: another
5 GB, and they will not run on a 4 GB card.

## Models are discovered, not whitelisted
`llm\gen\models` is scanned the same way `llm\models` is. Any Stable
Diffusion or Flux checkpoint put there - `.gguf` or `.safetensors` - is
offered to `generate_image`, and any Wan model is offered to
`generate_video`. The pinned downloads above are only what makes a fresh
install work. There is no allow-list, and no filter is applied to what a
generator produces.

## Verification
Model and projector SHA-256 values are checked before a file is accepted.
Vault files are never modified or deleted by model tools. Generated output
lands in the Playground; saving to the Vault is always a separate action.

## The language models

Chosen in use, not on paper. Three models have now been picked for their
specification and rejected for how they behaved, and each time the
specification was right about capability and silent about what mattered.

| | size | fetched | why |
|---|---|---|---|
| **Gemma 4 E2B abliterated** | 3.6 GB | yes — **default** | coherent and fast in use, uncensored, vision + tools |
| Qwen3.5-4B abliterated | 2.8 GB | no | all three capabilities; slower, and the family hallucinated here |

### Removed

**Qwen3.5-2B abliterated** was the default for one round. All three
prerequisites, 1.7 GB, and a measured 32768-token window — the best numbers
of anything tried. In use it was slow to arrive at anything and it
hallucinated: it invented a request from a previous day and acted on it.

**Qwen3-VL-4B-Thinking** before it repeated itself in a loop, re-reading its
own context instead of answering.

Both are gone from the catalogue rather than left unfetched. A model that
does not finish, or finishes with something invented, is not an option worth
keeping selectable.

### What the default costs

Gemma is 3.7 GB with its projector against the Qwen 2B's 1.9 GB, on a card
with 4 GB. That is paid for in the **context window**, and the window is what
decides whether Nova's own instructions fit in the prompt (ADR-71):

    Qwen3.5-2B    n_ctx 32768   whole character sheet, room to spare
    Gemma 4 E2B   smaller - measured at first launch and printed on screen

The launch banner reports the granted window and says outright when the sheet
had to be trimmed, naming the sections left out. The two rules that must
never be cut — *try again when told it is fixed*, and *saying it is not doing
it* — are pinned into the preamble, which is never trimmed.

Gemma 4 has no reasoning mode, so the `enable_thinking` flag The Hub sends
does nothing. Two of three, and two that work beat three where one arrives as
a loop.

### Trying something new

Nothing new is downloaded without asking first. Research a candidate, say
what it is and what it would cost, and wait for a yes.

### 3D on a 4 GB card — the honest position

Researched rather than assumed, because the answer changes what is worth
building:

| | VRAM |
|---|---|
| TRELLIS 2 | 16 GB, ~6.1 GB at Q4 |
| Hunyuan3D 2.1 | 16 GB |
| Stable Fast 3D | ~8 GB |
| TripoSR | ~6 GB |
| **this machine** | **4 GB** |

Nothing in the neural image-to-3D family fits on a GTX 1650. What makes it
possible anyway is that trellis.cpp's CLI carries an optional CPU fallback,
and this machine has 9.4 GB of system RAM free — so The Hub asks for
`--res 512` and deliberately does **not** pass `--require-gpu`, which is the
flag that would disable that path. Slow, and real.

**trellis.cpp ships a server, not a CLI.** Every prebuilt Windows archive
for v0.4.3 contains `trellis-server.exe` and nothing else — the 693 MB CUDA
download extracts to exactly one executable, and `trellis-cli` is
build-from-source only. The Hub therefore starts the server for one mesh and
stops it again:

    trellis-server --models DIR --port 8103
    GET  /health    -> ok
    POST /generate  -> multipart: image, seed, resolution, bg_removal
                    -> model/gltf-binary

That is not a workaround. Holding the weights resident instead of paying GPU
initialisation per request is the reason the server exists (ADR-94).

### Omni-modal

**MiniCPM-o 4.5** is the honest answer — vision, video, speech in *and* out
in one 9B model, with instruct and thinking modes and llama.cpp support. It
is 5.0 GB at Q4_K_M, so it does not fit beside a KV cache on a 4 GB card,
and its speech path needs more than llama-server provides. Right model,
wrong machine.

### Downloads

    Spellman66/Huihui-ai-Qwen3.5-2B-Abliterated
      Huihui-Qwen3.5-2B-abliterated.Q4_K_M.gguf
        974879b9e926b94e7153c402ebfe63fdc5af6c329b45b6b03514ad08cbf40e49
      Huihui-Qwen3.5-2B-abliterated.BF16-mmproj.gguf
        d377af603a2190e8ef5d7d042e1cb6e965a73dded8aec6143acbea643371456c

    mradermacher/Huihui-Qwen3.5-4B-abliterated-GGUF
      Huihui-Qwen3.5-4B-abliterated.Q4_K_M.gguf
        423f10b6ec2d99c3378143d7cd3b80eb4887b3ed92103103ac59173b404f4f7c
      Huihui-Qwen3.5-4B-abliterated.mmproj-Q8_0.gguf
        650e2af8754b8b10e21debdbaf352cab43cd2435ec8ed56b893b9b581ae4a95c

    mradermacher/Huihui-gemma-4-E2B-it-abliterated-GGUF
      Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf
        55044454df35c2e3b9f4ca7a52b27cc7b057b3b3547cd114183196c31f5062a8
      Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf
        030b1a496787c3ca9240552a3d5488db0ba50c6d6cdc878793513340d736765c

Every hash is the Git LFS object id the repository publishes. A file that
arrives with a different hash is deleted rather than loaded.
