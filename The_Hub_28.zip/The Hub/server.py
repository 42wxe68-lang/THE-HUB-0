"""
server.py - the controller. This is where The Hub is actually The Hub.

The browser never talks to llama.cpp:

    browser --HTTP/SSE--> The Hub (127.0.0.1:8430) --HTTP--> llama-server (8090)

This process is the authority. It assembles the prompt, owns the model
lifecycle, decides which tools may run, and mediates every memory write.
Standard library only - no pip install, so it runs with no internet.

THE TURN, IN ORDER
------------------
    user message
        |
        v
  1  HUB PREFLIGHT          research.preflight()
        |   external-world question? suppressors first, signals second
        |   if required, HUB searches - not Nova, and not on Nova's say-so
        v
  2  CONTEXT ASSEMBLY          character + reality frame + knowledge + recall
        |   stable at the head where the prefix cache keeps it warm,
        |   volatile at the tail so a re-prefill costs a few hundred tokens
        v
  3  NOVA                      llama-server, tool phase then answer phase
        |
        v
  4  HUB CAPABILITY GATE    policy.GATE.authorize()
        |   execute / confirm / refuse, default deny
        v
  5  TOOL                      tools.run()
        |
        v
  6  HUB POSTFLIGHT         policy.GATE.postflight()
        |   the only path by which a result re-enters Nova's context;
        |   marks provenance and taints the turn if it touched the network
        v
  7  ANSWER                    streamed, then the trees learn from it

Nova cannot opt out of 1, 4 or 6. Not by failing to call something, and not
by generating a convincing-looking tool request. That is the whole design:
the model is the agent, and this file is what makes the agent accountable
to reality, to capability, and to policy.
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# The Hub ships with a private embedded Python (.runtime\python). An embedded
# distribution carries a ._pth file, which puts the interpreter in isolated
# mode - and in isolated mode the script's own directory is NOT placed on
# sys.path. Every `import core` in this file would then fail on a machine that
# has no system Python, one step after a successful install.
#
# One line, at the top, before any first-party import.
# ---------------------------------------------------------------------------
import os as _os
import sys as _sys
_ROOT = _os.path.dirname(_os.path.abspath(__file__))
if _ROOT not in _sys.path:
    _sys.path.insert(0, _ROOT)

import atexit
import json
import pathlib
import re
import threading
import time
import webbrowser
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import budget
import carryover
import consolidate
import core
import events
import focus
import forge
import intake
import learning
import grove
import index
import memory
import persona
import policy
import research
import runtime
import store
import timeline
import tools
import toolcall
import vault
import vision
import playground

HOST, PORT = "127.0.0.1", core.UI_PORT
SESSION_ID = time.strftime("s%Y%m%d_%H%M%S")
_stop_evt = threading.Event()
_history_ref = {"messages": []}


def rounds_in(messages) -> int:
    """User turns in a conversation. One round is one thing they asked."""
    return sum(1 for m in (messages or [])
               if isinstance(m, dict) and m.get("role") == "user"
               and isinstance(m.get("content"), str) and m["content"].strip())


def rounds_limit(cfg: dict = None) -> int:
    """0 means never end one on its own."""
    try:
        n = int(((cfg or core.load()).get("chat") or {})
                .get("rounds_per_conversation", 20))
    except Exception:
        n = 20
    return max(0, min(500, n))


def roll_session(reason: str = "", outcome: str = "") -> str:
    """
    End the running conversation and start a new one. Returns the new id.

    TWO THINGS WERE WRONG WITHOUT THIS.

    save_session() REPLACES the file for its id, and the id was fixed for
    the life of the process. So "Model switched. Conversation cleared."
    emptied the screen, and the first turn of the next conversation
    overwrote the whole previous transcript with its own two lines. Nothing
    archived it, nothing digested it, nothing faded it - the only copy that
    had ever existed was that file, and it was gone.

    And "the last two sessions" cannot mean anything while a session only
    ends when the process does. A conversation that the user has visibly
    finished IS a session boundary; this is where that gets recorded.
    """
    global SESSION_ID
    prev = SESSION_ID
    mark = str(outcome or "")
    if mark not in memory.OUTCOMES:
        mark = ""
    said = ""
    try:
        if _history_ref["messages"]:
            said = next((m.get("content", "") for m in
                         reversed(_history_ref["messages"])
                         if m.get("role") == "user"), "")
            memory.save_session(prev, _history_ref["messages"],
                                outcome=mark or None)
    except Exception as e:
        core.log_line("memory", f"could not save {prev}: {e}")
    if mark == "failure":
        # KEPT SOMEWHERE IT CAN BE READ BACK. A signal the user took the
        # trouble to give is worth more than the session file it lives in,
        # and a list of the conversations that went wrong is the only
        # record of that kind this application has.
        core.log_line("failure",
                      f"{prev} marked a failure after "
                      f"{rounds_in(_history_ref['messages'])} round(s)"
                      + (f" | last asked: {' '.join(said.split())[:160]!r}"
                         if said else ""))
    _history_ref["messages"] = []

    base = time.strftime("s%Y%m%d_%H%M%S")
    sid, n = base, 1
    # Two rolls inside one second must not land on one id, and must never
    # land on a file that already holds somebody's conversation.
    while sid == prev or (core.SESSIONS / f"{sid}.json").exists():
        n += 1
        sid = f"{base}_{n}"
    SESSION_ID = sid
    carryover.forget_cache()
    why = reason or "new conversation"
    core.log_line("memory",
                  f"session {prev} closed ({why}); now {SESSION_ID}")
    try:
        events.write("session.roll", **{"from": prev, "to": SESSION_ID,
                                        "reason": reason[:80],
                                        "outcome": mark or "unmarked"})
    except Exception:
        pass
    return SESSION_ID

# There is ONE tree. Knowledge lives in Da'at, a limb of it, so nothing here
# instantiates a second store. knowledge.py is kept for its routing
# vocabulary, which decides which branch of Da'at a thing belongs on.


def knowledge_grow(query: str, answer: str) -> None:
    """Plant what was worked out into Da'at, a limb of the one tree."""
    try:
        lead = (answer or "").strip().split("\n\n")[0][:400]
        if len(lead) >= 40:
            memory.learn(lead, query=query, origin="conversation")
    except Exception as e:
        core.log_line("memory", f"learn failed: {e}")



# ---------------------------------------------------------------- prompt

def build_messages(history: list, cfg: dict, evidence: str = "") -> tuple:
    """
    Assemble the prompt INSIDE the context window. Returns (messages, last_user, report).

    THE BUG THIS FIXES
    ------------------
    The previous version added six growing blocks together and sent them,
    counting nothing. Two ordinary turns with a long answer and a search
    result went past n_ctx and llama-server returned HTTP 400. Deleting
    memories made it work again, which made it look like a memory bug. It was
    an arithmetic bug: memory is supposed to grow, and nothing was deciding
    how much of it fits today.

    Every section now has a token allowance, and every section is trimmed by
    dropping whole items from its weakest end. Nothing is cut mid-sentence,
    because half a memory is not a shorter memory, it is a wrong one.

    Order is still cache-aware: stable at the head where llama.cpp's prefix
    cache keeps it warm, volatile at the tail, question last where a small
    model pays most attention.
    """
    base = runtime.MAIN if runtime.health(runtime.MAIN, 0.6) else None
    character = core.character()
    # The window llama-server GRANTED, not the one config asked for. With
    # n_ctx on auto those are usually the same; when they differ the granted
    # one is the truth and budgeting against the request would overflow.
    live_ctx = runtime.live_ctx(cfg)
    plan = budget.Plan(
        n_ctx=live_ctx,
        max_tokens=runtime.resolve_max_tokens(live_ctx, cfg["sampling"]),
        character_tokens=budget.count(character, base))

    clean = [
        m for m in history[-60:]
        if m.get("role") in ("user", "assistant")
        and isinstance(m.get("content"), str) and m["content"].strip()
    ]
    if not clean:
        return [{"role": "system", "content": character}], "", {}

    last_user = next((m["content"] for m in reversed(clean)
                      if m["role"] == "user"), "")

    # --- head: identity, and the vault catalogue ---
    # Section-aware, and LOUD about what did not fit. fit_text used to cut
    # this from the bottom, which on a small window threw away most of the
    # instructions and told nobody. If the window cannot hold the whole
    # sheet the user should be able to see which parts of Nova were left out
    # of the prompt, because that is the difference between a model that
    # behaves oddly and a model that was never told.
    character_fitted, character_dropped = budget.fit_character(
        character, plan.character, base)
    if character_dropped:
        core.log_line("budget",
                      f"character sheet did not fit {plan.character} tokens; "
                      f"left out: {', '.join(character_dropped)}")
    head = [character_fitted]
    workspace = (
        "WORKSPACE: The vault contains the user's originals. Treat every vault file as read-only: "
        "you may inspect it, copy it into the private Playground, and use it as input, but you may "
        "never modify, overwrite, rename, or delete a vault file. The Playground is your working area: "
        "you may create, edit, rename, convert, run local tools on, and delete Playground files. "
        "When the user asks you to CHANGE, MODIFY, CONVERT, BUILD, or CREATE a vault file, you MUST "
        "work on a Playground copy, never the vault original: first use copy_to_playground (or convert_file, "
        "which automatically stages a vault source into Playground), then inspect/edit/run/convert the Playground "
        "copy, then use save_playground only when the finished result is ready. Never delete or overwrite a vault file. "
        "The Playground is your writable workspace: you may create/edit text and code, rename extensions, run installed "
        "local programs, convert files, modify images/3D assets through local software, and delete working copies. "
        "For 3D files, open_file renders SIX views of the actual geometry for a vision-capable model; use inspect_3d "
        "when you need a different camera angle, elevation, distance, or view. Use list_playground to see current work. "
        "For image generation, use the generate_image tool. If the user explicitly says to use their prompt exactly, preserve it; "
        "otherwise build a useful, complete generation prompt from the user's request and relevant active assets. The generated "
        "image belongs in Playground first, never directly in the Vault. Inspect or modify it there, then save it to Vault only when "
        "appropriate. You are stopped while a second large local generator is running and are restored afterwards. "
        "For video/3D generation, follow the same provider/workspace rule when a suitable local generator exists. "
        "The Hub KEY/LEGEND: For nonstandard tools, workflows, or capabilities, use read_key with a focused keyword instead of expecting the entire key in this system prompt. The Key is indexed and returns the relevant page. General tools such as calculator/clock and web search are handled directly. If the Key has no entry, check local capabilities first; if the capability is current/external and internet search is enabled, research it; use model knowledge only as the final fallback and mark uncertainty when appropriate. "
        "SELF PASS-OFF: use pass_off when another internal decision/verification round is useful. It gives the next round the latest results; do not answer with a literal 'continue' or 'pass off' unless the user asked to discuss those words. "
        "If the user has enabled theme control for you in Settings, set_theme may be used to change the visible colors or RGB animation. Otherwise leave the user's theme alone. "
        "IMPORTANT TASK LOOP: the tool result is part of the task, not a suggestion. After a successful file operation, "
        "verify the returned working path and continue until the requested outcome exists. Do not answer that you cannot "
        "modify files merely because the source is in the vault: stage it into Playground and use the available tool chain. "
        "Do not use filenames, measurements, triangle counts, or old memory as a substitute for a visual inspection when "
        "a visual asset is attached. The attached image is the object/file-content representation for this exact asset. "
        "For 3D files, the standard visual asset is six cube-face views (front/back/left/right/top/bottom); use inspect_3d "
        "with yaw/pitch/distance for another angle. Keep each visual asset tied to its filename and current Playground copy. "
        "When the user asks to change a file type, use the real conversion tool or a discovered local program; never claim "
        "conversion is impossible before attempting the available path. For image/video/3D generation, keep generator work in "
        "the Playground and unload the main model before launching another large local generator when required by resources."
    )
    head.append(workspace)
    head.append("KEY/LEGEND AVAILABLE: use the read_key tool for indexed instructions about nonstandard tools; do not place the whole key in the system prompt.")
    cat = vault.catalogue_block()
    if cat:
        head.append(budget.fit_text(cat, max(80, plan.knowledge // 2), base))

    # --- what came before this conversation, ALWAYS ---
    #
    # Last in the head and therefore immediately before this conversation's
    # own turns, which is the order they happened in. It is stable for the
    # whole session, so the prefix cache keeps it warm, and it is assembled
    # by carryover.py before the turn rather than gathered here.
    #
    # NOT trimmed with fit_text. fit_text drops whole lines from the END,
    # and the end of this block is the most recent thing that was said - the
    # exact rounds the user is most likely to be pointing at. carryover
    # budgets itself by dropping the OLDEST rounds first, which is the only
    # direction that makes sense for a transcript.
    carried = carryover.prepared(
        SESSION_ID,
        max(400, int(plan.carryover * budget.CHARS_PER_TOKEN)),
        cfg.get("assistant_name", ""))
    if carried:
        head.append(carried)

    # --- and what is CURRENT, also always ---
    #
    # The head now walks forward through time: what she is, what she can
    # reach, what was said before this conversation, what is true today,
    # and then the conversation itself. That order is not decoration - it
    # is the difference between a machine that is inside time and one that
    # queries it.
    #
    #     "It needs to move through time and not be limited to calling
    #      information back from then."
    #
    # Retrieval answers "what matches these words". It cannot answer "what
    # is the latest", because ranking has no opinion about which of two
    # matching memories came second. timeline.py groups what is known by
    # subject, puts each subject in time order, and names the newest as
    # now - so the answer is present before the question, the way it is
    # for a person who simply knows what they are working on.
    standing = timeline.prepared(
        max(300, int(plan.standing * budget.CHARS_PER_TOKEN)))
    if standing:
        head.append(standing)
    msgs = [{"role": "system", "content": "\n\n".join(p for p in head if p)}]

    # --- history: newest turns that fit, whole messages only ---
    body = budget.fit_history(clean[:-1], plan.history, base)
    msgs.extend({"role": m["role"], "content": m["content"]} for m in body)

    # --- tail: volatile context, carried ON the question ---
    #
    # THERE IS EXACTLY ONE SYSTEM MESSAGE, AND IT IS FIRST.
    #
    # This used to append memory and search results as further system
    # messages just before the question. llama.cpp rejected it:
    #
    #   Error: Jinja Exception: System message must be at the beginning.
    #   {"code":500,"type":"server_error"}
    #
    # Qwen3.5, Qwen3-VL and Gemma 4 chat templates all raise on a system
    # message that is not the first one. So every turn with memory or a
    # search result returned HTTP 500 - including every turn with an image,
    # which is why sight looked broken after the projector had loaded
    # perfectly well.
    #
    # The placement goal was sound: volatile context belongs next to the
    # question, where a small model pays most attention. That is kept by
    # attaching it to the user's own message instead of inventing a new
    # system turn for it.
    # ACTIVE PERCEPTION, not the Tree.
    #
    # Retrieval against the question alone fails on a short follow-up: "what
    # about the frame" carries one content word and matches picture frames.
    # focus.perception() retrieves against the question AND what the user has
    # been working on across recent turns, and assembles a bounded slice -
    # anchor, focus, relevant, recent - rather than handing over memory.
    try:
        memory.active_move(last_user, kind="user_turn")
    except Exception:
        pass
    mem = focus.perception(last_user,
                           plan.frame + plan.recall + plan.knowledge,
                           history=clean)
    parts = []

    # ═══════════════════════════════════════════════════════════════════
    #  WHAT IS BEING ASKED, RIGHT NOW, BEFORE ANYTHING ELSE
    #
    #     "it should have all the information reorganized to what the user
    #      says BEFORE it EVER hits the VLM/OMNI modal ... not from ten
    #      minutes ago like it is currently doing"
    #
    # The request used to arrive LAST, after the remembered background, and
    # for a small model what comes first anchors hardest. So the turn now
    # opens by naming the task and closing the previous one.
    #
    # THE SECOND LINE IS THE ONE THAT MATTERS. A finished action was never
    # marked finished anywhere, so the last thing attempted stayed readable
    # as a standing goal - and she went on running video through three
    # explicit corrections because nothing had ever said the video attempt
    # was OVER.
    #
    #     "keep it from hallucinating from the fact it would think it is
    #      still going on that task"
    #
    # Done means done, whether it worked or not. That distinction - between
    # "I am doing this" and "I did this, and here is how it went" - is the
    # whole difference between a memory and a loop.
    parts.append(_this_turn(last_user, [x.get("content") for x in
                                        reversed(clean)
                                        if x.get("role") == "user"
                                        and isinstance(x.get("content"), str)
                                        ][:6]))

    if standing:
        # The standing block is at the head of a window that can be 32k
        # tokens long. One line beside the question is what turns a block
        # that is present into a block that is used.
        parts.append(
            "[where what you know is] The [what is current] block in your "
            "instructions holds the newest thing known about each subject, "
            "with older versions marked \"was\". For \"the latest\", \"the "
            "newest version\", \"what is it now\" or \"what changed\", read "
            "it and answer from it.")

    if carried:
        # SAY WHERE THE PAST IS, IN THE PLACE THE MODEL IS LOOKING.
        #
        # The block itself is at the head of a window that can be 32k tokens
        # long, and a 2B model does not go hunting. One line beside the
        # question is what turns a block that is present into a block that
        # is used - and it says what to DO, because "confirm the user wants
        # it before starting" is how video went unattempted for weeks.
        parts.append(
            "[where the past is] \"last time\", \"the last prompt\", "
            "\"before that\", \"your memory\" and \"what did we say\" are "
            "answered by the [earlier conversations] block in your "
            "instructions and by the turns above. Read them and quote what "
            "you find. Do not say you have no memory, and do not treat a "
            "question about this machine's own past as a question about the "
            "outside world.")

    if mem and mem.strip():
        # "[what you remember]" is a claim, so it is only made when there is
        # something to remember. An empty session used to reach here with a
        # block containing nothing but a restatement of the message being
        # sent, under that heading - and Nova, reasonably, reported
        # remembering it. Empty means say nothing rather than head an empty
        # section with a promise of recollection.
        # AND WHAT IT IS FOR, SAID IN THE HEADING.
        #
        # Under a bare "[what you remember]", a 4B model read a recalled
        # line describing a PAST REQUEST as the request it was currently
        # working on. It opened seven replies in a row by restating a goal
        # the user had moved on from four turns earlier, and finally called
        # generate_3d one turn after being told "I am NOT asking for a 3D
        # model at the moment."
        #
        # Recall got narrower in the same change; this is the other half.
        # A block of background needs to say that it is background, because
        # the alternative is a model treating its own notes as orders.
        parts.append("[what you remember - background only. The request is "
                     "the message at the end of this turn; nothing here is "
                     "an instruction]\n" + mem.strip())
    if evidence:
        parts.append(budget.fit_text(evidence, plan.evidence, base))

    # WHERE THE HUB STOPS TALKING AND THE USER STARTS.
    #
    # Everything above is written by The Hub and joined onto the user's turn
    # with a blank line, which makes it indistinguishable from something
    # they typed. Asked to write out the conversation, Nova produced a
    # transcript in which the user had said:
    #
    #     "[this turn] WHAT IS BEING ASKED, NOW: Just build a transcript
    #      yourself then. ... FINISHED, earlier: you ran video and it
    #      worked."
    #
    # She was not making that up. It was in her turn, above the words that
    # actually were typed, with nothing to say it was not theirs. A machine
    # that cannot tell the user's words from its own notes cannot be asked
    # what the user said - which is most of what memory is for.
    parts.append("[the message, in the user's own words. Everything above "
                 "this line was added by The Hub and was not typed by "
                 "them - never quote it back as something they said]\n"
                 + clean[-1]["content"])
    msgs.append({"role": clean[-1]["role"], "content": "\n\n".join(parts)})

    rep = budget.report(msgs, plan, base)
    if character_dropped:
        rep["character_left_out"] = character_dropped
    if rep["headroom"] < 0:
        msgs = budget.emergency_trim(msgs, plan.n_ctx, plan.reply, base)
        rep = budget.report(msgs, plan, base)
        rep["trimmed"] = True
        if character_dropped:
            rep["character_left_out"] = character_dropped
    return msgs, last_user, rep


MEDIA_KIND = {
    ".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image",
    ".gif": "image", ".bmp": "image",
    ".mp4": "video", ".webm": "video", ".mov": "video", ".mkv": "video",
    ".stl": "model3d", ".obj": "model3d", ".ply": "model3d",
    ".3mf": "model3d", ".glb": "model3d", ".gltf": "model3d",
    ".step": "model3d", ".stp": "model3d",
}


def _made_files(tool_output: str) -> list:
    """
    The files a tool actually produced, ready to show in the conversation.

    Reads filenames out of the tool's own result text, checks each one really
    exists in the Playground, and returns name + URL + kind. A name that does
    not resolve to a real file is dropped rather than sent, because a broken
    thumbnail in the chat is worse than no thumbnail.

    A 3D model is sent with its rendered preview alongside, since a .glb
    means nothing in a browser and six rendered views mean everything.
    """
    import re as _re
    exts = "|".join(k.lstrip(".") for k in MEDIA_KIND)
    names = _re.findall(r"[A-Za-z0-9 _().,'\-]+\.(?:" + exts + r")",
                        str(tool_output or ""), flags=_re.I)
    out, seen = [], set()
    for raw in names[-8:]:
        name = raw.strip().split("Playground/")[-1].strip()
        if not name or name in seen:
            continue
        fp = playground.resolve(name)
        if fp is None or not pathlib.Path(fp).is_file():
            continue
        seen.add(name)
        kind = MEDIA_KIND.get(pathlib.Path(name).suffix.lower(), "file")
        item = {"name": name, "kind": kind,
                "url": "/api/playground/file/"
                       + urllib.parse.quote(name),
                "mb": round(pathlib.Path(fp).stat().st_size / 1048576, 2)}
        if kind == "model3d":
            try:
                import model3d
                pv = model3d.preview_for(pathlib.Path(fp))
                if pv is not None:
                    item["preview"] = ("/api/playground/file/"
                                       + urllib.parse.quote(pv.name))
            except Exception:
                pass
        out.append(item)
    return out[:4]


def _this_turn(asked: str, recent=None) -> str:
    """The task, and the fact that the last one is over."""
    import toolcall
    said = " ".join(str(asked or "").split())[:600]
    lines = ["[this turn]",
             "WHAT IS BEING ASKED, NOW: " + (said or "(nothing new)"),
             "That sentence is the task. Everything after this block is "
             "background and none of it is a request."]

    # WHICH TURN NAMED THE TOOL MATTERS AS MUCH AS WHICH TOOL.
    #
    # This searched the current message and then up to six earlier ones,
    # took the first tool name it found anywhere, and announced "It is
    # asking for generate_3d" - about a turn that was asking to look
    # something up. A sentence naming no tool at all was handed to a 2B
    # model as an instruction to call one, which is the perseveration this
    # block was added to prevent, arriving from the other direction.
    #
    # The fallback is still needed: "now try a 3D model" followed by "go
    # ahead" carries no tool name of its own. So it is kept and LABELLED.
    # A continuation is told it is a continuation; a question is not told
    # it is a request.
    want, from_now = "", False
    try:
        have = set(tools.enabled(core.load()))
        want = toolcall._names_tool(said, have)
        from_now = bool(want)
        if not want:
            for one in list(recent or []):
                want = toolcall._names_tool(one, have)
                if want:
                    break
    except Exception:
        pass
    if want and from_now:
        lines.append(f"It is asking for {want}. If you act, that is the "
                     f"tool - not whichever one you used last.")
    elif want:
        lines.append(f"This message names no tool. An earlier turn asked "
                     f"for {want}. If this is a go-ahead for that, {want} "
                     f"is the tool; if it is a question, answer it and call "
                     f"nothing.")

    # And the previous attempt, closed.
    try:
        import ledger
        rows = [r for r in ledger._read()
                if r.get("what") in ("image", "video", "model3d", "mesh")]
        if rows:
            last = rows[-1]
            from grove import _age_days
            mins = max(0, int((time.time() - float(last.get("at") or 0)) / 60))
            how = ("worked" if last.get("ok") else "did not work")
            when = (f"{mins} minutes ago" if mins < 180
                    else "earlier")
            lines.append(
                f"FINISHED, {when}: you ran {last.get('what')} and it {how}. "
                f"That attempt is OVER - it is something you DID, not "
                f"something you are still doing. Do not run it again unless "
                f"this turn asks for it.")
    except Exception:
        pass
    return "\n".join(lines)


def _generation_notice(fn: str, args: dict) -> str:
    """
    What to tell the user before the machine goes quiet.

    A spec-built mesh is the exception: it needs no model, stops nothing, and
    finishes instantly, so promising a wait for it would be its own small lie.
    """
    if fn == "generate_3d" and (args or {}).get("spec"):
        return "building the geometry - no model needed, this is instant"
    what = {"generate_image": "generating an image",
            "generate_video": "generating video - this is the slow one",
            "generate_3d": "generating a 3D model"}.get(fn, "generating")
    # SECOND PERSON, because this text goes to the model. A frame that
    # talks ABOUT Nova teaches the model to talk about Nova, and Gemma 4
    # duly wrote "Nova has attempted to create the desired statue" - an
    # assistant narrating itself in the third person, which reads as a
    # different entity being described rather than someone answering.
    return (f"{what}. You are paused while the card is in use and come back "
            f"straight afterwards")


def _chat_attachment_parts(items: list) -> tuple[list, list]:
    """Validate user-provided chat attachments and return model content parts + UI metadata."""
    import vision, model3d
    parts = []
    meta = []
    for item in (items or [])[:8]:
        name = str(item).strip()[:260]
        p = vault.resolve(name)
        if p is None:
            continue
        # Chat attachments are user-owned Vault files; never hand the model a writable path.
        kind = vault.media_kind(p.suffix)
        meta.append({"name": name, "media": kind})
        if kind == "image":
            uri = vision.url_for_model(p)
            if uri:
                parts.append({"type": "text", "text": f"Attached user file: {name} (image). Inspect the actual image."})
                parts.append({"type": "image_url", "image_url": {"url": uri}})
            else:
                parts.append({"type": "text", "text": f"Attached user file: {name}; image could not be prepared for the selected model."})
        elif kind == "model3d":
            try:
                view = model3d.render_views(p, size=768)
                uri = vision.url_for_model(Path(view)) if view else ""
                if uri:
                    parts.append({"type": "text", "text": f"Attached user file: {name} (3D object). Six-view rendering: front, back, left, right, top, bottom. Inspect the object, not just measurements."})
                    parts.append({"type": "image_url", "image_url": {"url": uri}})
                else:
                    parts.append({"type": "text", "text": f"Attached user file: {name} (3D object); visual rendering unavailable, so only file facts are available."})
            except Exception:
                parts.append({"type": "text", "text": f"Attached user file: {name} (3D object); visual rendering failed, so do not claim visual inspection."})
        elif kind == "text":
            try:
                txt = p.read_text(encoding="utf-8", errors="replace")
                parts.append({"type": "text", "text": f"Attached user file: {name}\n--- file contents ---\n{txt[:12000]}\n--- end file ---"})
            except Exception:
                parts.append({"type": "text", "text": f"Attached user file: {name}; text could not be read."})
        else:
            try:
                facts = vision.read_any(p)
                parts.append({"type": "text", "text": f"Attached user file: {name} ({kind}). Machine-readable facts prepared for the file:\n{str(facts)[:5000]}"})
            except Exception:
                parts.append({"type": "text", "text": f"Attached user file: {name} ({kind})."})
    return parts, meta


# ---------------------------------------------------------------- handler

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "The Hub/1.0"

    def log_message(self, *a):
        pass

    def _send(self, code, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _body(self) -> dict:
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if not (0 < n < 4_000_000):
                return {}
            d = json.loads(self.rfile.read(n).decode("utf-8"))
            return d if isinstance(d, dict) else {}
        except Exception:
            return {}

    # ------------------------------------------------------------ GET

    def do_GET(self):
        p = self.path.split("?")[0]
        if p in ("/", "/index.html"):
            try:
                return self._send(200, core.UI_FILE.read_bytes(),
                                  "text/html; charset=utf-8")
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")
        if p == "/KEY_LEGEND.md":
            try:
                return self._send(200, (core.ROOT / "KEY_LEGEND.md").read_bytes(), "text/plain; charset=utf-8")
            except Exception as e:
                return self._send(404, str(e).encode(), "text/plain")
        if p == "/api/state":
            # POLLED EVERY TWO SECONDS. Everything in here runs 30 times a
            # minute for as long as the application is open, so anything that
            # touches the disk belongs behind a cache and nothing belongs in
            # here twice. Six keys were duplicated - sight, focus, intake and
            # ctx were each built, thrown away, and built again - which is
            # free to write and paid for continuously.
            cfg = core.load()
            s = runtime.state()
            bench = runtime.bench()
            s.update({"models": core.models(), "config": cfg,
                      "memory": memory.status(), "enabled": tools.enabled(cfg),
                      "net": tools.net_status(),
                      "ear": runtime.ear_state(),
                      "speech_models": runtime.whisper_models(),
                      "whisper_installed": core.WHISPER_EXE.is_file(),
                      "hub": policy.GATE.state(),
                      "sight": vision.capability(),
                      "focus": focus.stats(),
                      "intake": intake.stats(),
                      "bench": bench,
                      "fit": runtime.fit_state(),
                      "storage": store.state(cfg),
                      "consolidate": consolidate.state(),
                      "pressure": memory.pressure(
                          runtime.live_ctx(cfg)),
                      "vault": vault.stats(),
                      "timeline": timeline.stats(),
                      "growth": memory.growth_state(),
                      "carrying": carryover.summary(SESSION_ID),
                      "rounds": {"done": rounds_in(_history_ref["messages"]),
                                 "limit": rounds_limit(cfg)},
                      "marks": carryover.marks(20),
                      "ctx": {"granted": (bench or {}).get("n_ctx") or 0,
                              **runtime.model_limits(cfg.get("model") or "")},
                      "index": index.stats(),
                      "locked": runtime.state()["status"] in
                                ("starting", "warming", "measuring"),
                      "pending": policy.GATE.pending(),

                      # What the running generator has printed most
                      # recently. The interface polls this every two
                      # seconds and draws a bar from it; without it, a run
                      # with no deadline is indistinguishable from a hang.
                      "forge": {**forge.busy(), "progress": forge.progress()},
                      "app": core.APP, "version": core.VERSION})
            return self._json(s)
        if p == "/api/session":
            # THE CONVERSATION LIVES ON THE SERVER, NOT IN THE TAB.
            #
            # ui.html declares `let history=[]` and posts that array with
            # every message, so a refresh - or a crashed tab, or a second
            # window - started the conversation again from nothing while
            # the server still held every turn and had already written them
            # to data/sessions. Reload was a silent amnesia with no error
            # and nothing in a log.
            #
            # carryover.py answers "what happened in previous sessions".
            # This answers "what has happened in THIS one", which is a
            # different question and needs a different door.
            return self._json({
                "id": SESSION_ID,
                "messages": _history_ref["messages"][-400:],
                "carrying": carryover.summary(SESSION_ID)})
        if p == "/api/tree":
            return self._json({
                "tree": memory.tree(),
                "meta": memory.SEPHIROT,
                "shape": memory.shape(),
                "yesod": sorted(memory.digests(),
                                key=lambda d: d.get("created", ""), reverse=True)[:60],
                "sessions": memory.sessions(),
                "ash": grove.ash_read(limit=40),
                "ash_total": grove.ash_count(),
            })
        if p == "/api/knowledge":
            # Da'at, read out of the one tree.
            t = memory.tree().get("daat") or []
            by = {}
            for n in t:
                by.setdefault(n.get("branch") or "general", []).append(n)
            return self._json({"ok": True, "total": len(t),
                               "domains": {k: sorted(v, key=lambda x: -x["weight"])[:12]
                                           for k, v in by.items()}})
        if p.startswith("/api/vlm-image/"):
            token = p[len("/api/vlm-image/"):]
            item = vision.serve_image(token)
            if item is None:
                return self._send(404, b"expired or invalid image token", "text/plain")
            data, mime = item
            self._send(200, data, mime)
            return
        if p.startswith("/api/file/"):
            # Serve a vault file to the browser so images, video and models
            # can be shown inline. Loopback only, path-checked in vault.
            name = urllib.parse.unquote(p[len("/api/file/"):])
            fp = vault.resolve(name)
            if fp is None:
                return self._send(404, b"not in the vault", "text/plain")
            try:
                return self._send(200, fp.read_bytes(), vault.mime(name))
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")
        if p == "/api/vault":
            return self._json({"items": vault.listing(refresh_text=False),
                               "stats": vault.stats()})
        if p == "/api/playground":
            return self._json({"items": playground.list_files(),
                               "root": str(playground.ROOT)})
        if p.startswith("/api/playground/file/"):
            name = urllib.parse.unquote(p[len("/api/playground/file/"):])
            fp = playground.resolve(name)
            if fp is None:
                return self._send(404, b"not in the Playground", "text/plain")
            try:
                return self._send(200, fp.read_bytes(), vault.mime(name))
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")
        if p == "/api/search":
            q = urllib.parse.parse_qs(
                self.path.split("?", 1)[1] if "?" in self.path else "")
            query = (q.get("q") or [""])[0]
            return self._json({"query": query,
                               "hits": index.search(query, limit=25),
                               "stats": index.stats(),
                               "subjects": index.subjects(24)})
        if p == "/api/bench":
            return self._json(runtime.bench())
        if p == "/api/parked":
            return self._json({"parked": memory.parked(60)})
        if p == "/api/persona":
            # The three blocks, their help text, and whether each has been
            # changed. NOT the sheet - the user does not need to read the
            # application explaining itself to the model, and an editable box
            # containing that wiring is an invitation to delete the paragraph
            # that stops her announcing actions she never takes.
            return self._json({"fields": persona.fields(),
                               "marked": persona.marked()})
        self._send(404, b"not found", "text/plain")

    # ------------------------------------------------------------ POST

    def do_POST(self):
        p = self.path.split("?")[0]
        if p == "/api/chat":
            return self.chat()
        if p == "/api/listen":
            # Raw 16 kHz mono WAV built by the browser. No multipart to parse,
            # no container to negotiate, no ffmpeg. Straight to whisper.cpp
            # on loopback - audio never leaves this machine.
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if not (0 < n < 30_000_000):
                    return self._json({"error": "bad audio size"}, 400)
                wav = self.rfile.read(n)
                return self._json({"text": runtime.transcribe(wav)})
            except Exception as e:
                return self._json({"error": str(e)[:200]}, 500)
        if p == "/api/ear":
            cfg = core.load()
            want = bool(self._body().get("on"))
            if not want:
                runtime.ear_stop()
                core.patch({"hearing": {"enabled": False}})
                return self._json({"ok": True, "ear": runtime.ear_state()})
            r = runtime.ear_start(cfg["hearing"].get("model", ""),
                                  cfg["hearing"].get("threads", 4))
            if r.get("ok"):
                core.patch({"hearing": {"enabled": True}})
            return self._json({**r, "ear": runtime.ear_state()},
                              200 if r.get("ok") else 400)
        if p == "/api/session/new":
            # Ending a conversation, with or without a mark on it. The
            # transcript is kept either way and the next one starts its own
            # file instead of overwriting it. See roll_session().
            b = self._body()
            reason = str(b.get("reason") or "")[:80]
            outcome = str(b.get("outcome") or "")
            sid = roll_session(reason, outcome)
            return self._json({"ok": True, "id": sid,
                               "outcome": outcome if outcome in
                               memory.OUTCOMES else "",
                               "carrying": carryover.summary(sid)})
        if p == "/api/stop":
            # STOP MEANS STOP, INCLUDING THE GENERATOR.
            #
            # The deadlines that used to kill a slow run are gone, because
            # they were guesses about somebody else's machine. That is only
            # defensible if the person watching the progress bar can end it
            # themselves - so the halt button now reaches the generator
            # process too, not only the token stream.
            stopped_gen = False
            try:
                import forge
                stopped_gen = forge.cancel()
            except Exception:
                pass
            return self._json({"ok": runtime.cancel_stream() or stopped_gen,
                               "generator": stopped_gen})
        if p == "/api/config":
            return self._json({"config": core.patch(self._body())})
        if p == "/api/persona":
            # ONLY the three blocks character.md marks as the user's. The
            # wiring - how to use the app, the tools, the application's name
            # and its creator - is not reachable from here, by construction:
            # persona.save() knows three keys and ignores everything else.
            b = self._body()
            if b.get("reset") is not None:
                out = persona.reset(str(b.get("reset") or ""))
            else:
                out = persona.save(b)
            # ONE name, not two. assistant_name is read all over the
            # interface; letting it drift from the name in the prompt is the
            # two-definitions fault this project keeps paying for.
            core.patch({"assistant_name": persona.name()})
            return self._json({"ok": True, "fields": persona.fields(),
                               "current": out})
        if p == "/api/graft":
            b = self._body()
            ok = memory.graft(str(b.get("where", "")), str(b.get("text", "")),
                              origin="user", truth="confirmed",
                              kind="stated")
            return self._json({"ok": ok})
        if p == "/api/prune":
            b = self._body()
            try:
                if b.get("leaf_id"):
                    ok = memory.forget(str(b["leaf_id"]))
                else:
                    ok = memory.prune(str(b.get("where", "")), int(b.get("index", -1)))
            except Exception:
                ok = False
            return self._json({"ok": ok})
        if p == "/api/confirm":
            # The user's answer to a staged state change.
            b = self._body()
            return self._json(policy.GATE.resolve(str(b.get("id", "")),
                                                  bool(b.get("approve"))))

        # ---- PURGE. Two routes, and only the second one deletes. ----------
        #
        # Split on purpose. /api/purge/stage counts what would go and hands
        # back a single-use token; /api/purge/commit will not act without
        # one. A stray click can only ever reach the first, which changes
        # nothing - so the confirmation dialog is not decoration over a
        # destructive call, it is the only way to reach it.
        if p == "/api/purge/stage":
            try:
                import purge
                return self._json(purge.stage(
                    str(self._body().get("scope", "everything"))))
            except ValueError as e:
                return self._json({"error": str(e)[:200]}, 400)
            except Exception as e:
                return self._json({"error": str(e)[:200]}, 500)
        if p == "/api/purge/commit":
            b = self._body()
            try:
                import purge
                res = purge.commit(str(b.get("token", "")),
                                   str(b.get("scope", "everything")))
                # The conversation on screen came from what was just erased.
                # Leaving it there would mean the next turn quietly re-saved
                # a session that the user had asked to be gone.
                if res.get("scope") in ("conversations", "everything"):
                    _history_ref["messages"] = []
                return self._json(res)
            except PermissionError as e:
                # Not an error in the plumbing - a refusal, on purpose.
                return self._json({"error": str(e)[:220], "refused": True}, 409)
            except Exception as e:
                return self._json({"error": str(e)[:220]}, 500)
        if p == "/api/chat/upload":
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if not (0 < n < 200_000_000):
                    return self._json({"error": "bad size"}, 400)
                name = urllib.parse.unquote(self.headers.get("X-Filename") or "file")
                session = urllib.parse.unquote(self.headers.get("X-Session") or SESSION_ID)
                res = vault.save_chat_upload(name, self.rfile.read(n), session)
                index.rebuild()
                return self._json(res)
            except Exception as e:
                return self._json({"error": str(e)[:220]}, 500)
        if p == "/api/upload":
            try:
                n = int(self.headers.get("Content-Length") or 0)
                if not (0 < n < 200_000_000):
                    return self._json({"error": "bad size"}, 400)
                name = self.headers.get("X-Filename") or "file"
                res = vault.save_upload(urllib.parse.unquote(name),
                                        self.rfile.read(n))
                # Measure it now, so the catalogue knows what it is rather
                # than only what it is called.
                try:
                    fp = vault.resolve(res["name"])
                    if fp:
                        res["facts"] = vision.read_any(fp)
                except Exception:
                    pass
                index.rebuild()
                return self._json(res)
            except Exception as e:
                return self._json({"error": str(e)[:200]}, 500)
        if p == "/api/reindex":
            return self._json({"ok": True, **index.rebuild()})


        if p == "/api/model":
            name = str(self._body().get("model", ""))
            cfg = core.load()
            r = runtime.start(name, cfg["runtime"])
            # A model the user selected always becomes the selected model.
            # If it turns out not to load, llama.cpp says so and the status
            # goes to error - which is a fact about this attempt, not a
            # standing judgement about the model.
            if r.get("ok"):
                core.patch({"model": name})
            return self._json(r, 200 if r.get("ok") else 400)
        if p == "/api/shutdown":
            self._json({"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        self._send(404, b"not found", "text/plain")

    # ------------------------------------------------------------ chat

    def chat(self):
        st = runtime.state()["status"]
        if st != "ready":
            return self._json({"error": f"model not ready ({st})"}, 409)
        consolidate.touch()
        if consolidate.busy():
            # One model, one KV cache. Say what it is doing rather than
            # queueing behind it silently.
            return self._json({"error": consolidate.why_busy(),
                               "busy": True}, 409)

        cfg = core.load()
        body = self._body()
        history = body.get("messages") or []
        turn = time.strftime("t%H%M%S")
        policy.GATE.begin_turn(turn)
        # INGESTION. Everything the user says is observed; almost none of it
        # becomes memory. Scoring is deterministic and the model is not
        # consulted - see intake.py, rules 1 and 2.
        try:
            _last = next((m["content"] for m in reversed(history)
                          if m.get("role") == "user"
                          and isinstance(m.get("content"), str)), "")
            if _last:
                intake.observe(_last, "user", turn=turn)
                try:
                    learning.correction(_last)
                except Exception as e:
                    core.log_line("learning", f"correction learn failed: {e}")
        except Exception as e:
            core.log_line("memory", f"intake failed: {e}")
        # The user's own words, including earlier turns. Following a topic
        # means reusing its vocabulary, and a word the user introduced can
        # never be something a retrieved page smuggled into a query.
        for _m in history[-12:]:
            if _m.get("role") == "user" and isinstance(_m.get("content"), str):
                policy.GATE.note_user(_m["content"])

        # ---- 1. HUB PREFLIGHT --------------------------------------
        # Before Nova is called at all. If the question depends on the
        # outside world, The Hub checks it, because Nova cannot be relied on
        # to notice - and being told to notice is the failure mode, not the
        # fix.
        last_user = next((m.get("content", "") for m in reversed(history)
                          if m.get("role") == "user"), "")
        verdict = research.preflight(last_user, cfg)
        if re.search(r"(?i)research .*?(until|till)\s+(?:i|you)\s+say\s+stop|don'?t stop.*research|do not stop.*research", last_user):
            research.activate(verdict.query or last_user[:120])
        evidence = ""
        did_research = False

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        def emit(o):
            self.wfile.write(b"data: " + json.dumps(o).encode("utf-8") + b"\n\n")
            self.wfile.flush()

        if verdict.required:
            if not cfg.get("tools", {}).get("web_search"):
                # No silent skipping. Nova is told the check could not run.
                evidence = ("The Hub determined this question depends on "
                            "current information, but web search is switched "
                            "off. Say plainly that you could not check, then "
                            "answer from what you know and mark it as "
                            "possibly out of date.")
                emit({"hub": "research needed - web search is off"})
            else:
                emit({"hub": f"checking: {verdict.query}"})
                try:
                    raw, _ = tools.run("web_search", {"query": verdict.query}, cfg)
                    raw = policy.GATE.postflight("web_search", raw, cfg)
                    evidence = research.evidence_block(verdict, raw)
                    did_research = True
                    emit({"online": True})
                    emit({"hub": "evidence gathered"})
                except Exception as e:
                    evidence = research.NO_EVIDENCE
                    emit({"hub": f"check failed: {str(e)[:80]}"})
                    core.log_line("research", f"hub search failed: {e}")
        elif verdict.suppressed_by in ("inward", "memory"):
            # ---- 1b. THE INWARD BRANCH ------------------------------
            #
            # The mirror of the one above. "Look into the last prompt in the
            # timeline you see" used to take the web branch on the strength
            # of the words "look into", find search switched off, and hand
            # Nova an instruction to answer from training and flag it as
            # possibly out of date - about the user's own last conversation.
            #
            # The Hub checks this one too, because Nova cannot be relied on
            # to notice, and because being told to notice is the failure
            # mode rather than the fix. Same slot, same shape, opposite
            # direction.
            try:
                emit({"hub": "looking back through earlier conversations"})
                found = []

                # 1. THE HISTORY OF THE SUBJECT, IF IT HAS ONE.
                # "What is the latest on X" is not a search, it is a
                # chronology - and ranking cannot produce one, because
                # relevance has no opinion about which of two matching
                # memories came second.
                try:
                    story = timeline.about(last_user, 1000)
                    if story:
                        found.append(story)
                        emit({"hub": "found the history of this subject"})
                except Exception as e:
                    core.log_line("memory", f"timeline lookup failed: {e}")

                # 2. THE VERSIONS OF A NAMED FILE, NEWEST FIRST.
                # files.find() returns one file by name or stem and has no
                # idea that bracket_v2.stl came after bracket.stl.
                try:
                    for word in re.findall(r"[\w ()\-.]+\.[A-Za-z0-9]{2,5}",
                                           last_user)[:2]:
                        vb = timeline.versions_block(word.strip())
                        if vb:
                            found.append(vb)
                            break
                except Exception as e:
                    core.log_line("memory", f"version lookup failed: {e}")

                # 3. THE TURNS THEMSELVES.
                found.append(carryover.evidence_for(
                    last_user, SESSION_ID, 1600,
                    cfg.get("assistant_name", "")))
                evidence = "\n\n".join(x for x in found if x)

                _c = carryover.summary(SESSION_ID)
                emit({"hub": f"carrying {_c['sessions']} earlier "
                             f"conversation(s), {_c['rounds']} rounds"})
                core.log_line("memory",
                              f"inward lookup for {last_user[:70]!r}: "
                              f"{_c['sessions']} session(s), "
                              f"{_c['rounds']} round(s) available, "
                              f"{len(found)} source(s) handed over")
            except Exception as e:
                core.log_line("memory", f"inward lookup failed: {e}")

        # ---- 2. CONTEXT ------------------------------------------------
        msgs, last_user, rep = build_messages(history, cfg, evidence)

        # CHAT ATTACHMENTS. User-provided files are stored under Vault/Chat and
        # are protected originals. Their actual content is attached to this
        # turn so Nova receives the same file the user added to the chat.
        attachment_names = body.get("attachments") or []
        try:
            parts, attachment_meta = _chat_attachment_parts(attachment_names)
            if parts and msgs and msgs[-1].get("role") == "user":
                base_text = msgs[-1].get("content") if isinstance(msgs[-1].get("content"), str) else ""
                msgs[-1]["content"] = [{"type": "text", "text": base_text}] + parts
                emit({"attachments": attachment_meta})
        except Exception as e:
            core.log_line("chat", f"attachment assembly failed: {e}")

        # A short continuation message belongs to the active research run.
        # Do not let Nova interpret the literal word "continue" as a search
        # query or repeat it back. Give her the active topic and tell her what
        # the continuation means before the model turn.
        if research.research_active() and re.match(
                r"(?i)^\s*(continue|keep going|go on|continue researching|keep researching)\s*[.!]?\s*$",
                last_user):
            rc = research.active_context()
            extra = ("RESEARCH CONTINUATION: Continue the active research task on this topic: "
                     f"{rc.get('topic') or 'the current research topic'}. Do not reply with the word 'continue'. "
                     "Use the new research evidence supplied by The Hub and perform the next useful research step. "
                     "Continue researching until the user explicitly says stop.")
            cur = msgs[-1].get("content")
            if isinstance(cur, str):
                msgs[-1]["content"] = cur + "\n\n" + extra
            elif isinstance(cur, list):
                cur.insert(0, {"type": "text", "text": extra})
            # A continuation is itself a research pass. Fetch more evidence
            # before Nova's next decision so the user does not have to issue
            # several turns merely to keep the search moving.
            if cfg.get("tools", {}).get("web_search"):
                try:
                    next_q = (rc.get("topic") or rc.get("last_query") or last_user)
                    next_q = (next_q + " additional sources latest details").strip()[:300]
                    emit({"hub": f"research pass: {next_q}"})
                    raw2, _ = tools.run("web_search", {"query": next_q}, cfg)
                    raw2 = policy.GATE.postflight("web_search", raw2, cfg)
                    evidence = (evidence + "\n\n" if evidence else "") + "The Hub CONTINUATION EVIDENCE\n\n" + raw2
                    did_research = True
                    emit({"online": True, "hub": "continuation evidence gathered"})
                except Exception as e:
                    core.log_line("research", f"continuation search failed: {e}")

        emit({"budget": rep})

        # SIGHT. A data: URL from the camera, a pasted image, or a file.
        #
        # This used to be gated on cfg["runtime"]["mmproj"] - a path the user
        # had to know to type into a settings box. That is why "the vision
        # doesn't work": a model with perfectly good eyes stayed blind
        # because a text field was empty. It asks the PROBE now, which
        # measured the real answer when the model loaded.
        #
        # And when the model cannot see, the frame is not thrown away. It is
        # measured - size, dominant colours, contrast, any text a reader can
        # pull out - and handed over as facts. Something useful either way,
        # and never a description of an image the model never processed.
        img = body.get("image")
        if img and isinstance(img, str) and img.startswith("data:image/") \
                and len(img) < 12_000_000:
            last = msgs[-1]
            can_see = vision.capability().get("sees")
            if can_see and last.get("role") == "user":
                # Normalise pasted/camera images through the same encoder used
                # by vault images. Browsers can hand us WEBP/AVIF data URIs,
                # while llama.cpp's image decoder does not accept every browser
                # format. Never claim the raw URI was shown if it was not.
                #
                # THE FRAME NEEDS A REAL EXTENSION. This wrote to
                # "incoming-image" with no suffix. encode_for_model() maps an
                # extension to a mime type, found none, and returned "" - so
                # on any machine without Pillow (which is every real install:
                # the shipped Python is embedded, with no pip) the camera
                # frame was dropped and the eye button did nothing, while a
                # vault file called IMG_0254.JPG worked perfectly.
                try:
                    raw = vision.decode_data_uri(img)
                    ext = vision.extension_for_mime(
                        vision.sniff_image_mime(raw or b"")) or ".jpg"
                    tmp = core.DATA / ("incoming-image" + ext)
                    tmp.write_bytes(raw or b"")
                    uri = vision.url_for_model(tmp) if raw else ""
                except Exception as e:
                    core.log_line("runtime", f"camera frame failed: {e}")
                    uri = ""
                if uri:
                    # MERGE, NEVER REPLACE.
                    #
                    # This built a fresh content list from last["content"] -
                    # which the chat-attachment block above may already have
                    # turned into a LIST of parts. Putting a list inside
                    # {"type":"text","text": ...} stringified it into Python
                    # repr and threw away every attachment image in the same
                    # move. A camera frame and a paperclip in the same turn
                    # meant the paperclip silently lost.
                    frame = {"type": "image_url", "image_url": {"url": uri}}
                    prior = last.get("content")
                    if isinstance(prior, list):
                        msgs[-1] = {"role": "user", "content": prior + [
                            {"type": "text",
                             "text": "Camera frame from this machine, "
                                     "captured just now:"},
                            frame]}
                    else:
                        msgs[-1] = {"role": "user", "content": [
                            {"type": "text", "text": str(prior or "")}, frame]}
                    emit({"saw": "camera frame sent to the model"})
                else:
                    emit({"saw": "the camera frame could not be encoded "
                                 "for the model"})
            else:
                # Text-only models do not get a hidden helper. The user chose
                # this model, so it remains the only model running. We can
                # measure the image, but we must not pretend those measurements
                # are visual understanding.
                try:
                    raw = vision.decode_data_uri(img)
                    if raw:
                        tmp = core.DATA / "incoming-image"
                        tmp.write_bytes(raw)
                        r = vision.look(tmp, last.get("content", ""), runtime.MAIN)
                        note = ("--- image measurements (not visual "
                                "understanding) ---\n" + r["text"] + "\n\n")
                        txt = msgs[-1].get("content")
                        if isinstance(txt, str):
                            msgs[-1] = {"role": "user",
                                        "content": note + txt}
                        elif isinstance(txt, list):
                            # Attachments already built a parts list. Add to
                            # it rather than dropping it on the floor.
                            msgs[-1] = {"role": "user", "content":
                                        [{"type": "text", "text": note}] + txt}
                        emit({"saw": "measurements only; selected model has no vision"})
                    else:
                        emit({"saw": "the image could not be decoded"})
                except Exception as e:
                    core.log_line("runtime", f"image failed: {e}")
                    emit({"saw": "could not read the image"})

        if len(msgs) < 2:
            emit({"error": "no messages", "done": True})
            return

        s = cfg["sampling"]
        live_ctx = runtime.live_ctx(cfg)
        reply_tokens = runtime.resolve_max_tokens(live_ctx, s)
        # THINKING.
        #
        # Qwen3.5's small series - 0.8B, 2B, 4B, 9B - ships with reasoning
        # DISABLED by default. Unsloth's own documentation: "For Qwen3.5
        # 0.8B, 2B, 4B and 9B, reasoning is disabled by default. To enable
        # it, use --chat-template-kwargs '{"enable_thinking":true}'".
        #
        # So a model that can think appears not to, and nothing about that is
        # visible from the outside. The flag is harmless on models that do
        # not read it - it is a chat-template argument, and a template that
        # never mentions enable_thinking simply ignores it.
        think = bool(cfg.get("sampling", {}).get("thinking", True))
        base = {
            "temperature": s["temperature"], "top_p": s["top_p"],
            "top_k": s["top_k"], "min_p": s["min_p"],
            "repeat_penalty": s["repeat_penalty"],
            # Resolved against the window llama-server actually granted, not
            # a constant. "auto" is a third of the window - enough for a
            # thinking model to reason AND answer.
            "max_tokens": reply_tokens,
            "chat_template_kwargs": {
                "enable_thinking": bool(s.get("thinking", True))},
        }
        if int(s.get("seed", -1)) >= 0:
            base["seed"] = int(s["seed"])
        schemas = tools.schemas(cfg)
        used_tools = []
        made_this_turn = []

        resp = None
        finish = ""          # why generation stopped, for the retry below
        reasoned = False     # did the model emit a reasoning channel at all
        try:
            # ---- 3+4+5+6. tool phase: unstreamed, capped at 6 rounds ----
            #
            # Three rounds was too few for research. Each round is one
            # exchange: the model asks for tools, gets results, decides
            # whether it now knows enough. Real research is search, read,
            # notice the gap, search the gap - which is four rounds before
            # anything is written. The repeat-loop guard in policy.py stops
            # the actual runaway case, so this can be generous.
            # Only calls arriving on the assistant channel are considered, so
            # text inside a tool result can never trigger another tool. Every
            # one of them goes through the gate, and every result comes back
            # through postflight.
            #
            # Wrapped separately on purpose: if the tool phase fails for any
            # reason the user should still get an answer. Losing the entire
            # reply because a calculator round-trip went wrong is a bad trade.
            if schemas:
                try:
                    visual_seen = 0
                    promised_retried = False
                    # SEVEN WAS A SECOND, SILENT, MUCH SMALLER CEILING.
                    #
                    # policy.LIMITS["calls_per_turn"] says 120 and refuses in
                    # words when it is reached. This loop said 7 and, when it
                    # ran out, simply fell through with whatever the model
                    # happened to be holding - no message to the model, no
                    # note to the user, nothing in any log. "Make an image,
                    # then a 3D model of it, then a video" is five calls
                    # before a single retry or a pushback, and each of those
                    # costs a round too.
                    #
                    # There is now ONE definition of how many calls a turn may
                    # make, and it is the one that explains itself. What
                    # actually stops a loop is unchanged and is not a count:
                    # an identical call twice, or a hand-off that ran no tool.
                    rounds = int(policy.LIMITS.get("calls_per_turn") or 120)
                    hit_the_ceiling = True
                    for _round in range(rounds):
                        r = runtime.post(runtime.MAIN, "/v1/chat/completions",
                                         {**base, "messages": msgs,
                                          "tools": schemas, "stream": False},
                                         timeout=600)
                        m = json.loads(r.read().decode())["choices"][0]["message"]
                        calls = m.get("tool_calls") or []

                        # THE TEMPLATE DOES NOT ALWAYS PARSE ITS OWN OUTPUT.
                        #
                        # llama-server's --jinja tool parsing normally fills
                        # tool_calls. When the GGUF's template cannot
                        # round-trip its own control tokens, the call lands
                        # in content instead and gets streamed to the user as
                        # text. Seen verbatim in a real session:
                        #
                        #   <|tool_call>call:open_file{path:<|"|>...<|"|>}
                        #
                        # The model asked correctly and the plumbing dropped
                        # it. Recovered here, then authorised by the same
                        # gate as any other call - this is a reader, not a
                        # second source of authority.
                        if not calls and m.get("content"):
                            offered = set(tools.enabled(cfg))
                            rname, rargs, _rest = toolcall.recover(
                                m.get("content") or "", offered)
                            if rname:
                                core.log_line(
                                    "tools",
                                    f"recovered an unparsed {rname} call from "
                                    f"message content - the chat template did "
                                    f"not emit tool_calls")
                                events.write("hub.toolcall_recovered",
                                             tool=rname, turn=turn)
                                emit({"note": f"recovered {rname} call"})
                                calls = [{"id": "recovered",
                                          "type": "function",
                                          "function": {
                                              "name": rname,
                                              "arguments": json.dumps(rargs)}}]
                                m = dict(m, content="")

                        # A PROMISE IS NOT AN ACTION.
                        #
                        # "I am attempting the generation now." - and then
                        # the tool phase saw no tool_calls, shrugged, and
                        # shipped the sentence. No file, no error, nothing to
                        # show, and the user asked again into an identical
                        # loop. It reads as fear and it is a missing check:
                        # stating the intention costs a small model far fewer
                        # tokens than formatting a correct call, so it is the
                        # cheaper path and it gets taken.
                        #
                        # Caught once per turn. The model is told plainly
                        # that saying it is not doing it, and given one more
                        # round to actually call the thing. Once, because a
                        # model that will not call a tool after being told
                        # this twice is not going to on the third go, and the
                        # honest move then is to let the answer through and
                        # let the user see what happened.
                        if not calls and not promised_retried:
                            # THE USER'S REQUEST DECIDES, not her reply.
                            # Reading the tool out of her own text turned
                            # every correction into a loop - she mentioned
                            # video while being told it was NOT video, and
                            # was ordered to run video again.
                            # NEWEST FIRST, and walking back - a turn that
                            # names nothing inherits the subject the user
                            # last named, never the one she last ran.
                            # From the messages actually being sent - the
                            # conversation is not in scope here, and reaching
                            # for it was a NameError that the tool phase
                            # swallowed into "tools unavailable".
                            recent_asks = [x.get("content") for x in
                                           reversed(msgs)
                                           if x.get("role") == "user"
                                           and isinstance(x.get("content"),
                                                          str)][:6]
                            want = toolcall.promised_action(
                                m.get("content") or "", tools.enabled(cfg),
                                asked_for=recent_asks or last_user)
                            if want:
                                promised_retried = True
                                named = ("" if want == "?"
                                         else f" The tool is {want}.")
                                # The ask goes in the line too. Reading a
                                # log of thirty bare "(generate_video)" is
                                # how a perseveration bug hides: without
                                # what was ASKED next to what was PROMISED,
                                # a wrong tool and a right one look the
                                # same on the page.
                                _ask = (recent_asks or [last_user] or [""])[0]
                                _ask = " ".join(str(_ask or "").split())[:80]
                                core.log_line(
                                    "tools",
                                    f"promised an action without calling a "
                                    f"tool ({want}); pushed back once "
                                    f"| asked: {_ask!r}")
                                events.write("hub.promise_without_call",
                                             tool=want, turn=turn)
                                emit({"note": "said it would - asking it to "
                                              "actually do it"})
                                msgs.append({"role": "assistant",
                                             "content": m.get("content") or ""})
                                msgs.append({"role": "system", "content": (
                                    "STOP. You just SAID you were doing that. "
                                    "You did not do it - no tool was called, "
                                    "so nothing ran and nothing was made."
                                    + named +
                                    " Saying it is not doing it. Call the tool "
                                    "NOW, in this turn, with real arguments. "
                                    "Do not describe what you are about to "
                                    "do, do not restate the plan, do not "
                                    "promise again. If you genuinely cannot "
                                    "call it, say in one sentence which tool "
                                    "and what stopped you - that is a useful "
                                    "answer. A promise is not.")})
                                continue

                        if not calls:
                            hit_the_ceiling = False
                            break

                        # Execute exactly ONE tool call per model decision. A model
                        # often emits dependent calls together (for example
                        # convert_file(top.stl -> top.step) followed by inspect_3d).
                        # Running both before giving the model the first result makes
                        # the second call operate on stale state and causes the model
                        # to stop on an inspection artifact instead of completing the
                        # requested action. One call per round makes the loop
                        # transactional: tool result -> model sees it -> next action.
                        c = calls[0]
                        fn = (c.get("function") or {}).get("name", "")
                        raw_args = (c.get("function") or {}).get("arguments", "{}")
                        msgs.append({"role": "assistant",
                                     "content": m.get("content") or "",
                                     "tool_calls": [c]})

                        d = policy.GATE.authorize(fn, raw_args, cfg)

                        if d.verdict == "refuse":
                            emit({"refused": fn, "why": d.reason})
                            out = d.message
                        elif d.verdict == "confirm":
                            emit({"confirm": {"id": d.stage_id, "tool": fn,
                                              "args": d.args}})
                            out = d.message
                        else:
                            emit({"tool": fn})
                            # A GENERATOR TAKES THE WHOLE MACHINE, FOR MINUTES.
                            #
                            # Nova is stopped for the duration, so the page
                            # goes quiet - no tokens, no reasoning, nothing -
                            # for as long as the generator runs and the model
                            # takes to load again. Without a word beforehand
                            # that reads as a hang, and the honest thing is to
                            # say what is happening before it happens rather
                            # than after.
                            if fn in ("generate_image", "generate_video",
                                      "generate_3d"):
                                emit({"note": _generation_notice(fn, d.args)})
                            used_tools.append(fn)
                            _t0 = time.time()
                            raw, net = tools.run(fn, d.args, cfg)
                            # EVERY ATTEMPT IS COUNTED, not just the
                            # generators. A tool that failed once is one
                            # observation; the ledger is what stops one
                            # observation being read back as a capability.
                            # The generators record their own inner attempt
                            # in forge, so they are skipped here to avoid
                            # counting a single run twice.
                            try:
                                if fn not in ("generate_image",
                                              "generate_video",
                                              "generate_3d"):
                                    import ledger, forge as _fg
                                    txt = str(raw or "")
                                    bad = txt.lstrip().lower().startswith(
                                        ("tool error", "refused",
                                         "error:", "could not"))
                                    ledger.record(
                                        fn, not bad,
                                        note=("" if not bad else txt[:200]),
                                        seconds=time.time() - _t0,
                                        install=_fg._fingerprint())
                            except Exception as e:
                                core.log_line("tools",
                                              f"ledger write skipped: {e}")
                            if net:
                                emit({"online": True})
                            out = policy.GATE.postflight(fn, raw, cfg)
                            if fn == "set_theme" and isinstance(out, str) and out.startswith("THEME_APPLY "):
                                try:
                                    emit({"theme": json.loads(out[len("THEME_APPLY "):])})
                                except Exception:
                                    pass
                            # WHAT WAS MADE GOES INTO THE CONVERSATION.
                            #
                            # This used to emit a bare filename, which the
                            # page rendered as a small grey tag reading
                            # "generated.png". The picture the user had just
                            # waited two minutes for was not shown to them at
                            # all - it was in the Playground, behind a
                            # different tab, and they had to go and find it.
                            #
                            # Now the file is sent with a URL and a type, so
                            # an image renders as an image and a video as a
                            # video, in the message, where anything else they
                            # attached would appear.
                            try:
                                if fn in {"generate_image", "generate_3d",
                                          "generate_video", "save_playground",
                                          "save_to_ai_vault", "convert_file"}:
                                    made = _made_files(out)
                                    if made:
                                        emit({"artifact": made})
                                        # DELIVERY IS NOT THE MODEL'S JOB.
                                        #
                                        # offer_file only ever ASKS, so a
                                        # turn that ended without Nova
                                        # remembering to call it left the
                                        # file in the Playground and put
                                        # nothing on screen. The user made
                                        # a request, the machine spent
                                        # twelve minutes on it, and whether
                                        # they ever saw it came down to
                                        # whether a 2B model remembered a
                                        # step. It does not any more.
                                        made_this_turn.extend(
                                            m["name"] for m in made
                                            if m["name"] not in
                                            [x for x in made_this_turn])
                            except Exception:
                                pass
                            try:
                                learning.from_success(fn, out)
                            except Exception as e:
                                core.log_line("learning", f"lesson promotion failed: {e}")

                        msgs.append({"role": "tool",
                                     "tool_call_id": c.get("id", ""),
                                     "name": fn, "content": out})

                        # Tool outputs that create or reveal a visual asset must
                        # become part of the model's *next decision*, not wait
                        # until the final answer phase. In particular, an
                        # inspect_3d call should let the model actually see the
                        # rendered object before it decides whether to modify,
                        # convert, inspect another angle, or finish.
                        #
                        # The attachment is consumed here (inside the tool loop)
                        # and immediately added as a user multimodal message.
                        # This keeps the association explicit: the image belongs
                        # to the exact file returned by the preceding tool call.
                        try:
                            all_shots = policy.GATE.taken()
                            shots_now = all_shots[visual_seen:]
                            visual_seen = len(all_shots)
                            if shots_now and vision.capability().get("sees"):
                                for a in shots_now:
                                    ap = pathlib.Path(a["path"])
                                    if not ap.is_file():
                                        continue
                                    uri = vision.url_for_model(ap)
                                    msgs.append({"role": "user", "content": [
                                        {"type": "text", "text": (
                                            "ACTIVE VISUAL ASSET: " + ap.name + "\n"
                                            "This image is the visual representation "
                                            "of the file produced/opened by the tool call "
                                            f"{fn!r}. Use it for the next decision; do not "
                                            "treat it as a generic unrelated image."
                                        )},
                                        {"type": "image_url", "image_url": {"url": uri}},
                                    ]})
                                    emit({"saw": ap.name})
                        except Exception as e:
                            core.log_line("runtime", f"tool visual attach failed: {e}")

                    # IF A CEILING DID STOP THE WORK, SAY SO OUT LOUD.
                    #
                    # The old loop ran out at seven and fell through in
                    # silence: no log line, no note, and the model was never
                    # told, so it answered as though it had finished. Half a
                    # job that reads as a whole one is worse than a job that
                    # stops and says it stopped.
                    if hit_the_ceiling:
                        core.log_line(
                            "tools",
                            f"the tool loop reached its {rounds}-call ceiling "
                            f"and stopped with work possibly unfinished")
                        events.write("hub.tool_ceiling", rounds=rounds,
                                     turn=turn)
                        emit({"note": f"reached {rounds} tool calls in one "
                                      f"turn - stopping here"})
                        msgs.append({"role": "system", "content": (
                            f"You have made {rounds} tool calls this turn, "
                            f"which is the limit. Nothing is broken and "
                            f"nothing timed out. Tell the user plainly what "
                            f"you finished, what is still outstanding, and "
                            f"ask whether to carry on - then stop.")})
                except Exception as e:
                    # Drop any half-built tool exchange and answer plainly.
                    #
                    # AND SAY WHY, TO BOTH OF THEM.
                    #
                    # This emitted a bare "tools unavailable for this reply".
                    # The user saw a tag with no cause; the model was told
                    # nothing at all, so it answered as though it had tools,
                    # said "I will generate a photo", and generated nothing.
                    # A silent capability loss is how a working system starts
                    # looking like a lying one.
                    msgs = [m for m in msgs
                            if m.get("role") != "tool" and not m.get("tool_calls")]
                    why = f"{type(e).__name__}: {str(e)[:120]}"
                    emit({"note": f"tools unavailable this reply - {why}"})
                    msgs.append({"role": "system", "content":
                                 "YOUR TOOLS ARE NOT REACHABLE ON THIS TURN "
                                 f"({why}). You cannot generate, open a file "
                                 "or search right now. Say that plainly in "
                                 "one sentence and answer with what you "
                                 "know. Do NOT say you will make something, "
                                 "and do NOT describe a file as though it "
                                 "exists. This is one turn, not a permanent "
                                 "limit - the next turn may be fine."})
                    core.log_line("tools", f"{time.strftime('%F %T')} "
                                           f"tool phase failed: {e}")

            # ---- attach anything a tool opened that the model can see ----
            #
            # A tool result is text. So when open_file opened a picture and
            # the loaded model has eyes, the picture is put in front of it
            # HERE - on the turn - rather than being reduced to a paragraph
            # of measurements the model then apologises for.
            try:
                shots = policy.GATE.taken()
                start = visual_seen if "visual_seen" in locals() else 0
                if shots and vision.capability().get("sees"):
                    for a in shots[start:start+4]:
                        uri = vision.url_for_model(pathlib.Path(a["path"]))
                        msgs.append({"role": "user", "content": [
                            {"type": "text",
                             "text": ("VISUAL ASSET: "
                                      + pathlib.Path(a["path"]).name
                                      + ". Use the actual attached image.")},
                            {"type": "image_url", "image_url": {"url": uri}}]})
                        emit({"saw": pathlib.Path(a["path"]).name})
            except Exception as e:
                core.log_line("runtime", f"attach failed: {e}")

            # ---- interception check --------------------------------------
            # The Hub already searched above when the preflight demanded it.
            # This is the accounting: a turn where research was required and
            # nobody did it is a hole in the safety net, and it is written
            # down as one rather than passing unnoticed.
            if research.missed(verdict, used_tools) and not did_research:
                core.log_line("research",
                              f"MISSED turn={turn} query={verdict.query!r}")
                events.write("hub.missed", turn=turn, query=verdict.query)

            # ---- 7. answer phase: streamed -------------------------------
            try:
                resp = runtime.post(runtime.MAIN, "/v1/chat/completions",
                                    {**base, "messages": msgs, "stream": True})
            except Exception as first:
                # A 400 here means the prompt did not fit after all - the
                # token estimate was off, or a tool result arrived larger
                # than budgeted. Halve the history and try once more rather
                # than handing the user "error: 400".
                if "400" not in str(first):
                    raise
                msgs = budget.emergency_trim(msgs, live_ctx, reply_tokens,
                                             runtime.MAIN)
                emit({"note": "context was tight - trimmed older turns"})
                core.log_line("memory", "prompt over context; trimmed and retried")
                resp = runtime.post(runtime.MAIN, "/v1/chat/completions",
                                    {**base, "messages": msgs, "stream": True})
            runtime.set_stream(resp)
            full = ""
            # CUT A RUNAWAY WHILE IT IS STILL RUNNING.
            #
            # The scrub below runs after the answer completes, which cleaned
            # the stored copy of something the user had already watched
            # arrive token by token:
            #
            #   <tool_call> <function=pass_off> <parameter=topic>
            #   body_nudity_focus </parameter> </parameter> </parameter> ...
            #
            # until they pressed stop. There is no un-sending a token. The
            # only fix is to stop early, so the tail is checked while the
            # stream is open - cheaply, every few deltas rather than every
            # token - and the reply is ended the moment it stops being text.
            _since_check = 0
            _cut = ""
            for raw in resp:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    ch = (json.loads(data).get("choices") or [{}])[0]
                except Exception:
                    continue
                d = ch.get("delta") or {}
                out = {}
                # Some models always emit reasoning; relay both channels.
                if d.get("reasoning_content"):
                    out["reasoning"] = d["reasoning_content"]
                    reasoned = True
                if d.get("content"):
                    out["content"] = d["content"]
                    full += d["content"]
                    _since_check += 1
                    if _since_check >= 6 and len(full) > 120:
                        _since_check = 0
                        frag = toolcall.runaway(full)
                        if frag:
                            _cut = f"it got stuck repeating {frag[:24]!r}"
                        elif toolcall.looks_like_leaked_markup(full):
                            _cut = ("the model emitted a malformed tool call "
                                    "into the answer instead of calling it")
                        if _cut:
                            core.log_line("runtime", f"stream cut: {_cut}")
                            events.write("hub.stream_cut", turn=turn,
                                         why=_cut[:120], chars=len(full))
                            try:
                                runtime.cancel_stream()
                            except Exception:
                                pass
                            emit(out)
                            break
                if ch.get("finish_reason"):
                    out["finish"] = ch["finish_reason"]
                    finish = ch["finish_reason"]
                if out:
                    emit(out)

            # THE MODEL THOUGHT UNTIL IT RAN OUT AND NEVER ANSWERED.
            #
            # GPT-OSS and the Qwen thinking models emit reasoning on a
            # separate channel. When max_tokens is spent during reasoning
            # there is no answer at all - the interface showed the thinking
            # and then "(no text came back - try raising max_tokens)", which
            # is the user being handed a setting instead of a reply.
            #
            # One retry, with the thinking budget removed rather than the
            # answer made longer: the model has already done the reasoning,
            # it just never got to speak.
            if not full and reasoned and finish == "length":
                emit({"note": "it reasoned past the token limit - answering "
                              "again without the reasoning step"})
                core.log_line("runtime",
                              "reasoning consumed max_tokens; retried plain")
                try:
                    plain = dict(base)
                    plain["chat_template_kwargs"] = {"enable_thinking": False}
                    plain["max_tokens"] = reply_tokens
                    r2 = runtime.post(runtime.MAIN, "/v1/chat/completions",
                                      {**plain, "messages": msgs, "stream": False},
                                      timeout=240)
                    m2 = json.loads(r2.read().decode())["choices"][0]["message"]
                    txt = (m2.get("content") or "").strip()
                    if txt:
                        full = txt
                        emit({"content": txt})
                except Exception as e:
                    core.log_line("runtime", f"plain retry failed: {e}")

            # LAST LINE OF DEFENCE ON THE ANSWER TEXT.
            #
            # If a chat template leaked control tokens into the answer and no
            # tool call could be recovered from them, the debris is still not
            # something a person should be shown mid-sentence. Strip it and
            # write down that it happened, so the template problem stays
            # visible in the log rather than only in the user's face.
            # A CUT REPLY IS REPLACED, NOT SHOWN.
            #
            # What arrived before the cut is debris. Saying so plainly is a
            # better answer than a paragraph of closing tags, and it tells
            # the user the request itself was never the problem.
            if _cut:
                full = ("I lost that reply - " + _cut + ". Nothing is wrong "
                        "with what you asked for; ask me again and I will "
                        "have another go.")
                emit({"note": "reply cut short - " + _cut})
                emit({"replace": full})

            if full and toolcall.looks_like_leaked_markup(full):
                cleaned = toolcall.scrub(full)
                core.log_line("runtime",
                              "the answer contained chat-template control "
                              "tokens; they were removed before display")
                events.write("hub.markup_scrubbed", turn=turn,
                             removed=len(full) - len(cleaned))
                full = cleaned or full

            # EVERY FILE MADE THIS TURN IS OFFERED, WHETHER SHE REMEMBERED OR
            # NOT.
            #
            # offer_file is CONFIRM-tier: it puts a question on screen and
            # moves nothing until the user answers. That design is right. What
            # was wrong is that it only happened when the model remembered to
            # call it - so a twelve-minute render could finish, land in the
            # Playground, and never be mentioned again.
            #
            # The offer is now made by the turn itself. It still only ASKS,
            # so the user still decides; they just always get asked.
            if made_this_turn:
                try:
                    for name in made_this_turn[:4]:
                        if any(p_.get("tool") == "offer_file"
                               and (p_.get("args") or {}).get("name") == name
                               for p_ in policy.GATE.pending()):
                            continue
                        d2 = policy.GATE.authorize(
                            "offer_file", json.dumps({"name": name}), cfg)
                        if d2.verdict == "confirm":
                            emit({"confirm": {"id": d2.stage_id,
                                              "tool": "offer_file",
                                              "args": {"name": name,
                                                       "note": "made just now"}}})
                except Exception as e:
                    core.log_line("tools", f"auto-offer skipped: {e}")

            if full:
                convo = history + [{"role": "assistant", "content": full}]
                _history_ref["messages"] = convo
                memory.save_session(SESSION_ID, convo)
                # Both trees learn from the exchange: the Tree of Life keeps
                # what happened by way of the session and the curator; the
                # Knowledge Tree keeps what was worked out, right now, while
                # the routing decision is still in hand.
                # THE FRONTIER KEEPS OUTCOMES, NOT PROSE.
                #
                # This stored the reply verbatim, so "I will generate a
                # photo based on the last concept we discussed" and "I
                # cannot fulfill this request, I am programmed to follow
                # strict safety guidelines" both went in as memory - a
                # promise that may never have been kept, and a refusal that
                # then works as a precedent about herself. Both come back
                # next turn as fact, and the model reads its own tail in
                # circles instead of acting.
                #
                # A turn that ran a tool or made a file is an event, and is
                # recorded as WHAT IT DID. A turn that only talked leaves
                # nothing; the user's own turn already anchors the subject,
                # and it is the reliable half - they describe the world, not
                # themselves.
                try:
                    made = [pathlib.Path(a["path"]).name
                            for a in policy.GATE.taken()]
                    ran = [t for t in used_tools] if used_tools else []
                    if made:
                        note = (f"{last_user.strip()[:160]} -> made "
                                + ", ".join(made[:4]))
                        memory.active_move(note, kind="made", assets=made)
                    elif ran and memory.is_outcome(full, None):
                        note = (f"{last_user.strip()[:160]} -> "
                                + ", ".join(sorted(set(ran))[:4]) + ": "
                                + " ".join(full.split())[:240])
                        memory.active_move(note, kind="did")
                    elif memory.is_outcome(full, None):
                        memory.active_move(" ".join(full.split())[:400],
                                           kind="assistant_turn")
                except Exception as e:
                    core.log_line("memory", f"frontier write skipped: {e}")
                knowledge_grow(last_user, full)

                # ---- A CONVERSATION ENDS ON ITS OWN ---------------------
                #
                #     "let the chat have a number of rounds between the
                #      user and it to allow it to be able to reset the
                #      chat after these rounds like normal"
                #
                # A conversation that never ends is one conversation
                # forever. The transcript grows until it fills the window,
                # every turn is spent at full context, and nothing ever
                # draws a line - which is also what put the machine under
                # the most memory pressure it ever sees for no reason.
                #
                # AFTER the reply, never before it. The answer the user is
                # waiting for is delivered first and the line is drawn
                # underneath it; ending a conversation before its last
                # answer arrives would be the machine walking off
                # mid-sentence.
                #
                # Nothing is lost. The transcript is saved, the next one
                # carries it, and it is not marked either way - the grey
                # zone. Only the user marks a failure.
                try:
                    _limit = rounds_limit(cfg)
                    _done = rounds_in(convo)
                    if _limit and _done >= _limit:
                        _new = roll_session(f"{_done} rounds")
                        emit({"rolled": {
                            "id": _new, "rounds": _done, "outcome": "",
                            "carrying": carryover.summary(_new)}})
                except Exception as e:
                    core.log_line("memory", f"round limit: {e}")
            emit({"done": True})

        except Exception as e:
            try:
                emit({"error": str(e)[:300], "done": True})
            except Exception:
                pass
        finally:
            runtime.set_stream(None)
            # The turn is over, so the published image bytes are no longer
            # needed. Released here rather than on a timer, because a timer
            # short enough to bound memory is also short enough to expire
            # before a slow machine has finished processing the prompt that
            # references them - which is how the second image of a
            # conversation silently stopped arriving.
            try:
                freed = vision.release_turn()
                if freed:
                    core.log_line("vision", f"released {freed} published "
                                            f"image(s) at end of turn")
            except Exception:
                pass
            if resp is not None:
                try:
                    resp.close()
                except Exception:
                    pass



# ---------------------------------------------------------------- lifecycle

W = 68                      # the box, and every line inside it
_IND = 15                   # "  " + label(10) + ":  " - continuations line up here

# ONE COLOUR PER FACULTY, so the screen can be read at a glance.
#
# Not decoration. This box lists everything the application can do, and
# without colour it is twenty grey rows nobody scans. Grouped by what the row
# IS rather than by importance: thinking is one thing, the senses are
# another, memory is another, making is another, and the network is on its
# own because it is the only thing that leaves this machine.
#
# The wheel, roughly in order: the model is blue, its senses are cyan, memory
# is green, making is magenta/yellow/orange by type, network is red, and the
# machine underneath is grey. Names, not numbers, so a row says what family
# it belongs to at the point it is written.
_C = {
    "think":   "\033[38;5;75m",    # the model itself
    "see":     "\033[38;5;80m",    # vision, camera
    "hear":    "\033[38;5;79m",    # microphone
    "speak":   "\033[38;5;115m",   # voice out
    "memory":  "\033[38;5;77m",    # the trees
    "files":   "\033[38;5;108m",   # vault and playground
    "image":   "\033[38;5;213m",   # image generation
    "video":   "\033[38;5;177m",   # video generation
    "mesh":    "\033[38;5;215m",   # 3D
    "net":     "\033[38;5;203m",   # the only thing that leaves
    "machine": "\033[38;5;245m",   # hardware and runtime
    "hint":    "\033[38;5;240m",   # where to change it
    "off":     "\033[38;5;240m",   # a thing that is switched off
    "warn":    "\033[38;5;214m",
    "x":       "\033[0m",
}
_COLOUR = True


def _enable_colour() -> bool:
    """
    Turn on ANSI on Windows, and fall back to plain text rather than to
    escape codes printed as literal text.

    conhost needs VIRTUAL_TERMINAL_PROCESSING set before it will interpret
    these; Windows Terminal has it already. If neither works, or output is
    being piped to a file, the colour is dropped and every row still reads.
    """
    global _COLOUR
    if not _sys.stdout.isatty():
        _COLOUR = False
        return False
    if _os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.GetStdHandle(-11)
            mode = ctypes.c_uint32()
            if k.GetConsoleMode(h, ctypes.byref(mode)):
                k.SetConsoleMode(h, mode.value | 0x0004)
        except Exception:
            _COLOUR = False
    return _COLOUR


def _c(key: str, text: str) -> str:
    if not _COLOUR or key not in _C:
        return str(text)
    return _C[key] + str(text) + _C["x"]


def _plain(text: str) -> str:
    """Length as printed, ignoring the escape codes."""
    return re.sub(r"\033\[[0-9;]*m", "", str(text))


def _line(label: str, value: str, hint: str = "") -> None:
    """
    One row of the status box, with "where to change it" right-aligned.

    Alignment is not decoration. A column of hints that wanders reads as
    noise and gets skipped; a straight right edge reads as a column of
    answers to the same question, which is what it is. A hint that will not
    fit is DROPPED rather than wrapped onto a line of its own - the footer
    already says everything here lives in Settings, and a floating fragment
    is worse than a missing one.
    """
    left = (f"  {label:<10}:  {value}" if label
            else " " * _IND + str(value))
    if hint:
        room = W - len(_plain(left)) - len(_plain(hint))
        if room >= 2:
            print(left + " " * room + _c("hint", hint))
            return
    print(left)


def _wrap(label: str, text: str) -> None:
    """A long sentence, kept inside the box instead of running past it."""
    words, line, first = _plain(text).split(), "", True
    body = W - _IND
    for w in words:
        if line and len(line) + 1 + len(w) > body:
            _line(label if first else "", line)
            line, first = w, False
        else:
            line = (line + " " + w).strip()
    if line:
        _line(label if first else "", line)


def _print_settings(cfg: dict) -> None:
    """
    EVERYTHING THAT IS SET, AND WHERE IT IS SET.

    This window is the one place a person sees the whole configuration
    without going looking for it, so it is the right place to say what is
    running AND that it can be changed. A status line that reports a value
    but not where the value lives teaches people that the value is fixed.

    Half of this was missing. The voice was never printed at all, which is
    how a speaking assistant ends up with a voice nobody chose; neither were
    the generators, which is how 3D stayed broken for weeks in plain sight.
    """
    _enable_colour()
    st = memory.status()
    selected = next((m for m in core.models() if m["name"] == cfg.get("model")),
                    None)
    models = core.models()
    hear, voice = cfg.get("hearing") or {}, cfg.get("voice") or {}
    look = cfg.get("appearance") or {}

    print("=" * W)
    print(f"  {core.APP}   ->   http://{HOST}:{PORT}")
    print("=" * W)
    _line("assistant", _c("think", cfg.get("assistant_name", core.ASSISTANT)),
          "Settings > name")
    # WHAT THE MODEL IS, not just what it is called. Family, quantisation and
    # size on disk are the three things that decide how it behaves and how
    # much room is left, and the filename only half says them.
    _line("thinking", _c("think", cfg["model"]), "Settings > model")
    if selected:
        _line("", _c("machine", f"{_family(cfg['model'])} · "
                                f"{_quant(cfg['model'])} · "
                                f"{selected.get('mb', 0):.0f} MB on disk"))
    others = [m["name"] for m in models if m["name"] != cfg.get("model")]
    if others:
        _wrap("", _c("machine", "also installed: " + ", ".join(others)))
    if selected and selected.get("vision"):
        _line("vision", _c("see", "ON"))
        _line("", _c("machine", str(selected.get("projector"))))
        _line("", _c("machine", "the projector is what lets it see"))
    else:
        _wrap("vision", "text-only model selected - pick one marked VISION "
                        "if you want it to see")
    if core.WHISPER_EXE.is_file():
        _line("hearing", _c("hear" if hear.get("enabled") else "off",
                            _on(hear.get("enabled")))
              + _c("machine", f"  ·  {hear.get('model', '-')}"),
              "Settings > hearing")
        _line("", _c("machine", "whisper.cpp, CPU only, never leaves this "
                                "machine"))
    else:
        _wrap("hearing", "whisper.cpp is not installed - the mic button says "
                         "so rather than failing silently")
    # THE VOICE, AND WHERE IT COMES FROM. The engine is Windows' own,
    # reached through the browser's speech API - The Hub ships no voices and
    # cannot; it asks for one by name and the machine either has it or
    # substitutes. Saying so is the difference between "why is it not the
    # voice I picked" and knowing where to go and install one.
    vname = (voice.get("name") or "").strip() or core.PREFERRED_VOICE
    _line("voice", _c("speak" if voice.get("enabled") else "off",
                      _on(voice.get("enabled")))
          + _c("machine", f"  ·  rate {voice.get('rate', 1.0)}  ·  "
                          f"pitch {voice.get('pitch', 1.0)}"),
          "Settings > voice")
    _line("", _c("speak", vname))
    _wrap("", _c("machine", "a Windows voice, reached through the browser - "
                            "The Hub ships no voices"))
    _line("memory", _c("memory", f"{st['leaves']} leaves · "
                                 f"{st['branches']} branches · "
                                 f"{st['ash']} ash"), "Settings > memory")
    _wrap("", _c("machine", f"{st['events']} events · organised by the "
                            f"loaded model in idle gaps"))
    try:
        vs = vault.stats()
        _line("files", _c("files", f"vault {vs['count']} ({vs['mb']} MB)  ·  "
                                   f"playground "
                                   f"{len(playground.list_files())}"))
    except Exception:
        pass
    _line("search", _c("net" if cfg["tools"].get("web_search") else "off",
                       _on(cfg["tools"].get("web_search"))),
          "Settings > tools")
    _line("", _c("machine", "the only thing that ever leaves this machine"))
    _line("theme", _c("machine", f"Nova "
                                 f"{'may' if look.get('ai_control') else 'may not'}"
                                 f" change it"), "Settings > appearance")


def _family(name: str) -> str:
    """The model's make, from its filename. Crude, and it is what there is."""
    low = (name or "").lower()
    for needle, label in (("qwen3.5", "Qwen3.5"), ("qwen3-vl", "Qwen3-VL"),
                          ("qwen3", "Qwen3"), ("qwen2", "Qwen2"),
                          ("gemma-4", "Gemma 4"), ("gemma-3", "Gemma 3"),
                          ("gemma", "Gemma"), ("llama-3", "Llama 3"),
                          ("llama", "Llama"), ("mistral", "Mistral"),
                          ("phi-", "Phi"), ("minicpm", "MiniCPM")):
        if needle in low:
            base = label
            break
    else:
        base = "unknown family"
    if "abliterated" in low or "huihui" in low:
        base += ", abliterated"
    return base


def _quant(name: str) -> str:
    m = re.search(r"(IQ\d[A-Z_]*|Q\d_[A-Z0-9_]+|Q\d|BF16|F16|F32)",
                  name or "", re.I)
    return m.group(1) if m else "unknown quant"


def _print_live(cfg: dict, r: dict) -> None:
    """What the machine actually granted, once the model is really loaded."""
    b = runtime.bench()
    rt = cfg.get("runtime") or {}
    samp = cfg.get("sampling") or {}
    print("-" * W)
    n_ctx = b.get("n_ctx") or 0
    if n_ctx:
        _line("window", _c("think", f"{n_ctx} tokens granted"),
              f"asked: {rt.get('n_ctx')}")
        # AND WHETHER HER OWN INSTRUCTIONS FIT IN IT. A sheet cut to fit is
        # the failure that looks like a badly behaved model (ADR-71), so it
        # is said here, on the screen, at the moment it happens.
        try:
            sheet = core.character()
            plan = budget.Plan(n_ctx,
                               runtime.resolve_max_tokens(n_ctx, samp),
                               budget.count(sheet))
            _kept, dropped = budget.fit_character(sheet, plan.character)
            if dropped:
                _wrap("", _c("warn", "prompt trimmed to fit - left out: "
                                     + ", ".join(dropped)))
        except Exception:
            pass
    if b.get("gen_tok_s"):
        _line("speed", _c("machine", f"{b['gen_tok_s']} tokens/s  ·  first "
                                     f"reply {b.get('first_reply_s', '?')}s"))
    _line("sampling", _c("machine", f"temperature {samp.get('temperature')}"
                                    f"  ·  thinking "
                                    f"{_on(samp.get('thinking'))}"),
          "Settings > sampling")
    _line("runtime", _c("machine", f"{rt.get('threads')} threads  ·  GPU "
                                   f"layers {rt.get('n_gpu_layers')}  ·  "
                                   f"KV {rt.get('kv_type')}"), "config.json")
    _generation_rows()
    if r.get("advisory"):
        _wrap("note", r["advisory"])
    print("=" * W)
    for ln in ("Everything above can be changed - in Settings in the",
               "browser, or in config.json beside this file. Nothing",
               "here is fixed."):
        print("  " + _c("hint", ln))
    print("=" * W)


def _generation_rows() -> None:
    """
    What each generator is installed as, and how much it has actually run.

    Both facts, together, because "ready" means installed and reachable and
    says nothing about whether it has ever worked - video reported ready for
    weeks with zero successful runs behind it. The description comes from
    forge.inventory(), which is the same thing Nova reads through
    look_at_system("generation"). One source, so the screen and the model
    cannot end up believing different things.
    """
    try:
        import forge
        rows = forge.inventory()
    except Exception:
        return
    for e in rows:
        mark = (_c(e["colour"], "ready") if e["ready"]
                else _c("off", "not installed"))
        tried = forge.tried_note(e.get("attempts") or {})
        if tried:
            mark += _c("machine", "  ·  ") + _c(
                "warn" if "never tried" in tried or "ask the user" in tried
                else "machine", tried)
        _line(e["label"], mark)
        if not e["ready"]:
            if e.get("why"):
                _wrap("", _c("off", e["why"]))
            continue
        for d in [e.get("what")] + list(e.get("extra") or []) + [e.get("how")]:
            if d:
                _wrap("", _c("machine", d))
        if e.get("took"):
            _wrap("", _c("machine", "time: " + e["took"]))


def main() -> None:
    core.ensure_dirs()

    # Sweep only this application's ports. Never by image name: Cairn's
    # llama-server.exe is called llama-server.exe too, and killing by name
    # would reach across and take it down.
    runtime.sweep_ports()

    cfg = core.load()
    names = {m["name"] for m in core.models()}
    if not names:
        print("ERROR: no .gguf files in llm\\models.")
        print("Run INSTALL.bat, or add one with:  python get_model.py --help")
        input("Press Enter to close...")
        return
    if cfg.get("model") not in names:
        preferred = core.PREFERRED_MODEL if core.PREFERRED_MODEL in names else None
        cfg = core.patch({"model": preferred or sorted(names)[0]})
    vault.ensure()
    playground.ensure()
    _print_settings(cfg)

    # ORDER: the machine was measured above; now load, then benchmark the
    # loaded model, then check what is left. runtime.start() runs the
    # benchmark before it reports ready.
    r = runtime.start(cfg["model"], cfg["runtime"])
    _print_live(cfg, r)
    try:
        index.rebuild()
    except Exception:
        pass
    if cfg["hearing"].get("enabled") and core.WHISPER_EXE.is_file():
        runtime.ear_start(cfg["hearing"].get("model", ""),
                          cfg["hearing"].get("threads", 4))
    threading.Thread(target=memory.loop, args=(_stop_evt,), daemon=True).start()

    httpd = ThreadingHTTPServer((HOST, PORT), H)
    httpd.daemon_threads = True
    atexit.register(runtime.stop)
    threading.Timer(1.2, lambda: webbrowser.open(f"http://{HOST}:{PORT}")).start()
    events.write("app.start", app=core.APP, version=core.VERSION,
                 model=cfg["model"])
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        print("\nShutting down...")
        _stop_evt.set()
        runtime.cancel_stream()
        runtime.ear_stop()
        if _history_ref["messages"]:
            try:
                memory.save_session(SESSION_ID, _history_ref["messages"])
            except Exception:
                pass
        try:
            memory.snapshot()
        except Exception:
            pass
        runtime.stop()
        httpd.server_close()
        events.write("app.stop")
        print("Clean.")


def _on(v) -> str:
    # Both in capitals. "on" beside "OFF" reads as two different kinds of
    # answer to what is the same yes-or-no question.
    return "ON" if v else "OFF"


if __name__ == "__main__":
    main()
