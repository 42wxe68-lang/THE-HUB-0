"""
test_present.py - Nova is allowed to try again.

THE BUG THIS SUITE EXISTS FOR

The user fixed something, said "try again, I fixed it", and was refused.
Nova would quote a failure from weeks earlier - "it ran out of video memory"
- and decline to attempt the thing at all. She went on doing it after the
cause had been fixed, after a reinstall, and after the missing weights had
finished downloading.

It was never one bug. It was four, and only the first was in the model:

  1. tools.py used `playground` and `vault` without importing them, so four
     functions raised NameError the moment they were reached. The model
     reported that as a capability limit and then remembered it.

  2. policy.py's argument shapes for the generators had drifted away from
     the schemas the model reads. generate_3d {"spec": ...} - the route that
     needs no download and cannot fail - was refused as a bad argument.
     Every image-to-image and every video call died the same way.

  3. forge recorded a failure with no age and phrased it as a permanent
     property: "this model does not fit on this card". One run at one size
     became a fact about the machine.

  4. The character sheet was cut to fit the context window from the bottom
     up, and the bottom was where the instructions about generating things
     and answering plainly lived. Two thirds of the prompt was being thrown
     away silently.

Each check here fails on one of those. Together they are the difference
between an assistant that reasons from the present and one that is held in
place by a bad afternoon.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import testkit                                                   # noqa: F401
import core


# ---------------------------------------------------------------- 1. imports

def test_every_module_resolves_the_names_it_uses():
    """The NameError class of bug, checked statically for the whole folder."""
    import verify
    problems = []
    _real_error = verify.error
    verify.error = lambda msg: problems.append(msg)
    try:
        verify.check_name_resolution()
    finally:
        verify.error = _real_error
    assert not problems, "; ".join(problems[:3])


def test_the_generation_tools_import_cleanly_and_are_callable():
    import tools
    for name in ("generate_3d", "generate_image", "generate_video",
                 "offer_file", "look_at_system"):
        assert name in tools.REGISTRY, f"{name} is not registered"


# ---------------------------------------------------------------- 2. the gate

def test_the_gate_accepts_every_argument_the_model_is_shown():
    """
    A schema the model reads and a shape the gate enforces are two halves of
    one contract. They drifted, and the drift looked like a missing feature.
    """
    import tools, policy
    bad = []
    for name, spec in tools.REGISTRY.items():
        params = (((spec.get("schema") or {}).get("function") or {})
                  .get("parameters") or {})
        shown = set((params.get("properties") or {}).keys())
        gate = set((policy.ARGS.get(name) or {}).keys())
        for key in shown - gate:
            bad.append(f"{name}({key})")
    assert not bad, "the gate would refuse: " + ", ".join(sorted(bad))


def test_a_spec_built_mesh_is_authorised_not_refused():
    """
    THE 3D BUG. This is the always-works route: pure geometry, no model, no
    download. It was refused at the gate as an unexpected argument, so it
    never ran once, and "3D flat out doesn't work" was the result.
    """
    import policy
    g = policy.Gate()
    g.begin_turn("t")
    cfg = {"tools": {}, "hub": {"capability_gate": True}}
    spec = json.dumps({"parts": [{"shape": "box", "size": [60, 40, 4]}]})
    d = g.authorize("generate_3d", json.dumps({"spec": spec}), cfg)
    assert d.verdict == "execute", f"{d.verdict}: {d.reason} {d.message}"


def test_image_to_image_and_sized_video_are_authorised():
    import policy
    g = policy.Gate()
    g.begin_turn("t")
    cfg = {"tools": {}, "hub": {"capability_gate": True}}
    d = g.authorize("generate_image", json.dumps(
        {"prompt": "a bracket", "input_image": "x.png",
         "input_scope": "vault", "strength": 0.6, "model": "sd15.safetensors"}), cfg)
    assert d.verdict == "execute", f"image: {d.reason} {d.message}"
    d = g.authorize("generate_video", json.dumps(
        {"prompt": "waves", "width": 384, "height": 256, "frames": 25,
         "steps": 8, "seed": 3}), cfg)
    assert d.verdict == "execute", f"video: {d.reason} {d.message}"


# ---------------------------------------------------------------- 3. history

def test_a_failure_is_described_as_an_event_not_a_capability():
    import forge
    txt = forge._explain("ggml_cuda: CUDA error: out of memory")
    low = txt.lower()
    assert "video memory" in low, txt
    assert not any(w in low for w in
                   ("does not fit", "cannot", "impossible", "unable")), txt
    assert any(w in low for w in ("smaller", "fewer")), txt


def test_a_past_failure_carries_its_age():
    import forge
    assert "days ago" in forge._ago(time.time() - 3 * 86400)
    assert "minutes ago" in forge._ago(time.time() - 900)
    assert "moments ago" in forge._ago(time.time() - 5)


def test_the_generation_report_says_history_is_not_a_limit():
    import forge
    r = forge.report()
    low = r.lower()
    assert "history, not as a limit" in low or "history, not a limit" in low, r
    assert "call it" in low, r


def test_a_failure_from_a_different_install_is_called_out_of_date(tmp_path):
    """
    The user installs the missing weights and says "try again". The old
    failure was measured on a machine that no longer exists, and the report
    has to say so rather than presenting it as current.
    """
    import forge
    state = tmp_path / "forge_state.json"
    state.write_text(json.dumps({"image": {
        "ok": False, "note": "ran out of video memory at that size",
        "seconds": 40.0, "at": time.time() - 20 * 86400,
        "install": "0000deadbeef"}}))
    old_file, old_avail = forge._STATE_FILE, forge.available
    forge._STATE_FILE = state
    forge.available = lambda: {
        "image": {"ready": True, "why": "", "models": ["sd.safetensors"],
                  "last": forge.last_outcome("image")},
        "video": {"ready": False, "why": "not installed", "models": [], "last": {}},
        "model3d": {"ready": False, "why": "not installed", "models": [], "last": {}},
        "mesh": {"ready": True, "why": "", "models": ["built in"], "last": {}}}
    try:
        r = forge.report()
    finally:
        forge._STATE_FILE, forge.available = old_file, old_avail
    assert "20 days ago" in r, r
    assert "no longer describes this machine" in r, r
    assert "out of date" in r.lower(), r


# ---------------------------------------------------------------- 4. prompt

def test_the_character_sheet_tells_her_to_try_again():
    c = " ".join(core.character().split())
    assert 'try again, I fixed it" - try again' in c, "the retry rule is gone"
    assert "Do not refuse something because it failed before." in c
    assert "A tool listed as available is available. Call it." in c


def test_the_prompt_is_never_cut_past_the_window():
    """
    fit_text dropped lines from the end until it fit. On a small window that
    removed most of the sheet and told nobody. Whatever the window, what goes
    to the model must fit AND must still contain the rules that change
    behaviour rather than style.
    """
    import budget
    sheet = core.character()
    total = budget.count(sheet)
    for n_ctx in (2048, 4096, 8192, 16384):
        plan = budget.Plan(n_ctx, n_ctx // 3, total)
        got, dropped = budget.fit_character(sheet, plan.character)
        assert budget.count(got) <= plan.character, (
            f"n_ctx {n_ctx}: sent {budget.count(got)} tokens into a "
            f"{plan.character} allowance")
        # Identity and the retry rule are the last things to go.
        if n_ctx >= 4096:
            assert "You are Nova." in got, f"n_ctx {n_ctx} lost her name"
            assert "try again" in got, f"n_ctx {n_ctx} lost the retry rule"


def test_what_was_cut_is_reported_rather_than_swallowed():
    import budget
    sheet = core.character()
    got, dropped = budget.fit_character(sheet, 300)
    assert dropped, "a sheet cut to 300 tokens reported losing nothing"
    assert all(isinstance(d, str) and d for d in dropped)


def test_the_essential_sections_are_the_ones_that_change_behaviour():
    import budget
    for name in ("TIME", "WHAT THE PAST IS FOR", "MAKING THINGS",
                 "GIVING THE USER WHAT YOU MADE"):
        assert name in budget.ESSENTIAL, f"{name} is droppable"
    heads = [h for h, _ in budget._sections(core.character())]
    for name in budget.ESSENTIAL:
        if name:
            assert name in heads, f"{name} is marked essential but not in the sheet"


# ---------------------------------------------------------------- 5. the lens

def test_she_can_look_at_the_present_instead_of_remembering_it():
    import lens
    out = lens.look("everything", core.load())
    assert "AS IT IS AT" in out
    assert "read just now" in out
    for area in lens.AREAS:
        assert area.upper() in out, f"{area} missing from a full look"


def test_the_lens_never_hands_back_a_key():
    import lens
    cfg = core.load()
    cfg = {**cfg, "search": {**(cfg.get("search") or {}),
                             "brave_key": "SECRET-abc123", "provider": "brave"}}
    out = lens.look("settings", cfg)
    assert "SECRET-abc123" not in out, "the lens leaked an API key"
    assert "brave" in out.lower(), "it should still say a key is set"


def test_a_closed_area_answers_rather_than_failing():
    """
    A closed door and a wall are different things. Nova must be able to tell
    the user which area she wanted and that they can open it.
    """
    import lens
    cfg = {**core.load(), "lens": {"machine": False}}
    out = lens.look("machine", cfg)
    assert "switched off" in out
    assert "not missing" in out and "not broken" in out
    assert lens.allowed(cfg)["machine"] is False
    assert lens.allowed(cfg)["self"] is True, "one switch closed them all"


def test_looking_is_always_available_and_changes_nothing():
    import tools, policy
    assert "look_at_system" in tools.ALWAYS
    assert policy.TIERS["look_at_system"]["writes"] is False
    assert policy.TIERS["look_at_system"]["network"] is False


# ---------------------------------------------------------------- 6. offering

def test_offering_a_file_asks_before_it_moves_anything():
    """
    CONFIRM tier: calling it stages a question and moves nothing. Approval is
    the user's, not the model's.
    """
    import policy
    assert policy.TIERS["offer_file"]["tier"] == policy.CONFIRM
    g = policy.Gate()
    g.begin_turn("t")
    cfg = {"tools": {}, "hub": {"capability_gate": True, "confirm_writes": True}}
    d = g.authorize("offer_file", json.dumps({"name": "a.png"}), cfg)
    assert d.verdict == "confirm", f"{d.verdict}: {d.reason}"
    assert d.stage_id, "nothing was staged for the user to answer"


def test_keeping_a_file_moves_it_out_of_the_playground(tmp_path):
    """
    Moved, not copied. The Playground is scratch that fills a disk; a kept
    file has to LEAVE it, or keeping things is what causes the overflow.
    """
    import playground, vault
    old_pg, old_vault = playground.ROOT, vault.VAULT
    playground.ROOT = tmp_path / "playground"
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    vault.MADE_VAULT = vault.VAULT / "Made"
    try:
        playground.ensure()
        f = playground.ROOT / "2026-09-01 1432 a bracket.stl"
        f.write_bytes(b"solid x\nendsolid x\n")
        (playground.ROOT / "2026-09-01 1432 a bracket.preview.png").write_bytes(b"\x89PNG")

        res = playground.keep(f.name)

        assert res["ok"]
        assert not f.exists(), "the original is still in the Playground"
        kept = vault.MADE_VAULT / "2026-09-01 1432 a bracket.stl"
        assert kept.is_file(), "it did not arrive in the Vault"
        assert (vault.MADE_VAULT / "2026-09-01 1432 a bracket.preview.png").is_file(), \
            "the preview was left behind, so the mesh cannot be looked at"
        assert not list(playground.ROOT.glob("*.stl"))
    finally:
        playground.ROOT, vault.VAULT = old_pg, old_vault
        vault.AI_VAULT = vault.VAULT / "AI"
        vault.CHAT_VAULT = vault.VAULT / "Chat"
        vault.MADE_VAULT = vault.VAULT / "Made"


def test_keeping_never_overwrites_something_already_there(tmp_path):
    import playground, vault
    old_pg, old_vault = playground.ROOT, vault.VAULT
    playground.ROOT = tmp_path / "playground"
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    vault.MADE_VAULT = vault.VAULT / "Made"
    try:
        playground.ensure()
        vault.MADE_VAULT.mkdir(parents=True)
        (vault.MADE_VAULT / "shape.stl").write_bytes(b"the first one")
        (playground.ROOT / "shape.stl").write_bytes(b"the second one")
        res = playground.keep("shape.stl")
        assert res["name"] != "shape.stl", "it overwrote the earlier file"
        assert (vault.MADE_VAULT / "shape.stl").read_bytes() == b"the first one"
    finally:
        playground.ROOT, vault.VAULT = old_pg, old_vault
        vault.AI_VAULT = vault.VAULT / "AI"
        vault.CHAT_VAULT = vault.VAULT / "Chat"
        vault.MADE_VAULT = vault.VAULT / "Made"


def test_the_playground_is_trimmed_only_when_it_is_over_its_cap(tmp_path):
    import playground
    old = playground.ROOT
    playground.ROOT = tmp_path / "playground"
    try:
        playground.ensure()
        for i in range(5):
            (playground.ROOT / f"f{i}.bin").write_bytes(b"x" * 1024)
        r = playground.tidy()
        assert r["over"] is False
        assert r["trimmed"] == []
        assert len(list(playground.ROOT.glob("*.bin"))) == 5
    finally:
        playground.ROOT = old


def test_a_kept_file_is_listed_as_the_users_own(tmp_path):
    import vault
    old = vault.VAULT
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    vault.MADE_VAULT = vault.VAULT / "Made"
    try:
        vault.ensure()
        (vault.MADE_VAULT / "kept.png").write_bytes(b"\x89PNG\r\n\x1a\n")
        rows = {r["name"].split("/")[-1]: r for r in vault.listing()}
        assert "kept.png" in rows, list(rows)
        assert rows["kept.png"]["owner"] == "made"
    finally:
        vault.VAULT = old
        vault.AI_VAULT = vault.VAULT / "AI"
        vault.CHAT_VAULT = vault.VAULT / "Chat"
        vault.MADE_VAULT = vault.VAULT / "Made"


def test_clearing_the_playground_cannot_lose_something_kept(tmp_path):
    """
    The whole point of the Vault space. Scratch can be cleared safely only
    because there is somewhere else for the things worth having, and clearing
    must provably not reach it.
    """
    import playground, vault, purge
    old_pg, old_vault = playground.ROOT, vault.VAULT
    playground.ROOT = tmp_path / "playground"
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    vault.MADE_VAULT = vault.VAULT / "Made"
    try:
        playground.ensure()
        vault.ensure()
        for i in range(4):
            (playground.ROOT / f"scratch{i}.png").write_bytes(b"x" * 2048)
        (playground.ROOT / "the good one.stl").write_bytes(b"solid\nendsolid\n")
        playground.keep("the good one.stl")

        pv = purge.preview("playground")
        assert pv["items"][0]["count"] == 4, pv["items"]
        assert "Vault is untouched" in pv["keeps"]

        purge.commit(purge.stage("playground")["token"], "playground")

        assert playground.list_files() == [], "scratch survived the clear"
        assert (vault.MADE_VAULT / "the good one.stl").is_file(), \
            "clearing the Playground destroyed a file the user had kept"
    finally:
        playground.ROOT, vault.VAULT = old_pg, old_vault
        vault.AI_VAULT = vault.VAULT / "AI"
        vault.CHAT_VAULT = vault.VAULT / "Chat"
        vault.MADE_VAULT = vault.VAULT / "Made"


def test_an_update_never_calls_the_users_history_a_fault(tmp_path):
    r"""
    THE INSTALL THAT FAILED ON A HEALTHY MACHINE.

    verify.check_clean_tree() was written to stop a release shipping with
    somebody's files in it. It ran as part of INSTALL.bat, found the user's
    own conversations, memories and generated pictures exactly where they
    belong, called them "state that is not the user's", and failed the
    install:

        ERROR  this build is carrying state that is not the user's:
               data\sessions\s20260901_011050.json
        The Hub installation failed.

    An update that treats the user's history as debris is an update that
    threatens the one thing the application exists to carry forward. A tree
    with a model in it is an installed Hub, and its data is an asset.
    """
    import verify, core

    root = tmp_path / "hub"
    (root / "llm" / "models").mkdir(parents=True)
    (root / "llm" / "models" / "some-model.Q4_K_M.gguf").write_bytes(b"0" * 16)
    for d in ("sessions", "playground", "tree/yesod", "events", "logs"):
        (root / "data" / d).mkdir(parents=True, exist_ok=True)
    (root / "data" / "sessions" / "s20260901_011050.json").write_text("{}")
    (root / "data" / "playground" / "0923 anime woman.png").write_bytes(b"\x89PNG")
    (root / "data" / "tree" / "yesod" / "leaf.jsonl").write_text("{}\n")

    said = []
    old = (verify.ROOT, core.MODELS, verify.error, verify.ok,
           verify.excluded, verify.section)
    verify.ROOT = root
    core.MODELS = root / "llm" / "models"
    verify.error = lambda m: said.append(("error", m))
    verify.ok = lambda m: said.append(("ok", m))
    verify.excluded = lambda m: said.append(("note", m))
    verify.section = lambda m: None
    try:
        verify.check_clean_tree()
    finally:
        (verify.ROOT, core.MODELS, verify.error, verify.ok,
         verify.excluded, verify.section) = old

    errors = [m for kind, m in said if kind == "error"]
    assert not errors, f"an installed Hub was failed by verify: {errors[:2]}"
    good = " ".join(m for kind, m in said if kind == "ok")
    assert "history" in good and "sessions" in good, good


def test_a_release_tree_with_no_install_still_reports_leftovers(tmp_path):
    """The other half: with no model present this IS a release candidate."""
    import verify, core
    root = tmp_path / "hub"
    (root / "llm" / "models").mkdir(parents=True)
    (root / "data" / "sessions").mkdir(parents=True)
    (root / "data" / "sessions" / "someone_elses.json").write_text("{}")

    said = []
    old = (verify.ROOT, core.MODELS, verify.error, verify.ok,
           verify.excluded, verify.section)
    verify.ROOT = root
    core.MODELS = root / "llm" / "models"
    verify.error = lambda m: said.append(("error", m))
    verify.ok = lambda m: said.append(("ok", m))
    verify.excluded = lambda m: said.append(("note", m))
    verify.section = lambda m: None
    try:
        verify.check_clean_tree()
    finally:
        (verify.ROOT, core.MODELS, verify.error, verify.ok,
         verify.excluded, verify.section) = old

    errors = [m for kind, m in said if kind == "error"]
    assert errors, "a release tree carrying a stranger's session said nothing"


# ------------------------------------------------- 7. the loop, in memory

def test_an_intention_is_not_an_outcome():
    """
    THE LOOP. The frontier stored assistant replies verbatim, so a promise
    and a refusal both became memory:

        [assistant_turn] I will generate a photo based on the last detailed
                         visual concept we discussed.
        [assistant_turn] I cannot fulfill this request. I am programmed to
                         follow strict safety guidelines...

    Next turn they come back as fact. The model reads that it already said
    it would, says it again, and reads its own refusal as evidence about
    itself. Neither is a fact about the world.
    """
    import memory
    for prose in ("I will generate a photo based on the last concept.",
                  "I cannot fulfill this request. I am programmed to follow "
                  "strict safety guidelines.",
                  "Let me check the user's message again.",
                  "I'm going to look at that now.",
                  "Sorry, I am unable to do that.",
                  "Okay, let's see what the last prompt was."):
        assert not memory.is_outcome(prose), f"stored as memory: {prose[:40]}"

    assert memory.is_outcome("The bracket is 60x40x4 mm with two 5 mm holes.")
    assert memory.is_outcome("I will generate", ["girl on a swing.png"]), (
        "a turn that actually produced a file IS an outcome")


def test_the_frontier_does_not_read_as_the_conversation(tmp_path):
    """
    Lines tagged [user_turn] read to a small model as things being asked of
    it now. Given a question about the recent past - "repeat the last
    request" - every one matched, came back, and the model spent the reply
    deciding which was the real request instead of answering.
    """
    import core, memory
    old = (core.DATA, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
           memory.ACTIVE_STATE)
    core.DATA = tmp_path / "data"
    memory.ACTIVE_DIR = core.DATA / "active"
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"
    memory.ACTIVE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        memory.active_move("generate a photo of a girl on a swing at sunset",
                           kind="user_turn")
        block = memory.active_context("try the girl on a swing prompt again")
    finally:
        (core.DATA, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
         memory.ACTIVE_STATE) = old

    assert block, "the frontier returned nothing for a clearly related question"
    assert "[user_turn]" not in block, "still tagged like a transcript"
    assert "NOT requests" in block, "it does not say these are background"
    assert "already happened" in block


def test_an_old_permanent_verdict_is_rewritten_on_read(tmp_path):
    """
    forge_state.json outlives the code. Fixing the wording in _explain() did
    nothing for a machine that already had the old sentence on disk, so Nova
    kept quoting "this model does not fit on this card" - a claim about the
    future - long after the wording was changed.
    """
    import json, time, forge
    f = tmp_path / "forge_state.json"
    f.write_text(json.dumps({"video": {
        "ok": False,
        "note": "ran out of video memory - this model does not fit on this "
                "card. Try a smaller checkpoint, a smaller size, or the CPU "
                "build.",
        "seconds": 12.0, "at": time.time() - 86400, "install": "abc"}}))
    old = forge._STATE_FILE
    forge._STATE_FILE = f
    try:
        note = forge.last_outcome("video")["note"]
    finally:
        forge._STATE_FILE = old
    assert "does not fit on this card" not in note, note
    assert "video memory" in note, "the event itself was lost, not just the verdict"


def test_the_playground_scope_never_targets_the_vault():
    import purge, vault
    targets = [str(t).lower() for t in purge._targets("playground")]
    assert targets, "the scope resolves to nothing"
    for t in targets:
        assert "vault" not in t, f"the Playground purge would reach {t}"
    for scope in purge.SCOPES:
        for t in purge._targets(scope):
            assert "vault" not in str(t).lower(), \
                f"purge scope {scope} reaches the user's Vault"




# ------------------------------------- 8. remember everything, send a little

def _isolated_memory(tmp_path):
    """Point every memory root at a scratch directory and return the modules."""
    import core
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"
    core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"
    core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"
    core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    core.CONFIG = tmp_path / "config.json"
    core.ensure_dirs()
    import events, grove, memory, index
    events.LOG = core.EVENTS / "events.jsonl"
    grove.ASH_FILE = core.ASH / "ash.jsonl"
    memory.YESOD_DIR = core.TREE / "yesod"
    memory.ARCHIVE_DIR = core.SESSIONS / "archive"
    memory.UNSORTED = core.TREE / "unsorted.jsonl"
    index.INDEX = core.DATA / "index"
    return memory, index


def test_nothing_is_ever_deleted_however_much_is_remembered(tmp_path):
    """
    "It should be able to hold everything... while not doing it all at the
    same time."

    That is two claims and they are checked separately. This one: memory
    that overflows the living tree is DEMOTED, never dropped. The living
    tree has small per-sephira caps on purpose - what falls out of it goes
    to ash, and ash is on disk and in the index.
    """
    memory, index = _isolated_memory(tmp_path)
    n = 1500
    memory.graft("chesed", "the zither was restrung with silk in March",
                 origin="user", truth="confirmed")
    for i in range(n):
        memory.graft("chesed", f"note {i}: the bracket was set to {i}",
                     origin="user")
    st = memory.status()
    living, ash = st.get("leaves", 0), st.get("ash", 0)
    assert living + ash >= n, (
        f"{n + 1} memories went in and only {living + ash} can be accounted "
        f"for - something was deleted rather than demoted")
    assert living < n, "nothing was demoted, so the living tree is unbounded"


def test_a_faded_memory_is_still_findable(tmp_path):
    """
    Demotion is only acceptable if the demoted thing can still be reached.
    An ashed leaf that cannot be searched has been forgotten with extra
    steps.
    """
    memory, index = _isolated_memory(tmp_path)
    memory.graft("chesed", "the zither was restrung with silk in March",
                 origin="user", truth="confirmed")
    for i in range(1500):
        memory.graft("chesed", f"note {i}: the bracket was set to {i}",
                     origin="user")
    index.rebuild()
    hits = index.search("zither restrung silk", limit=5)
    assert any("zither was restrung" in h["text"] for h in hits), (
        "a memory that faded out of the living tree became unreachable")
    assert any(h["kind"] == "ash" for h in hits), (
        "the needle was found but not from ash - the test proved nothing")


def test_what_reaches_the_model_stays_small_however_much_is_stored(tmp_path):
    """
    The other half. A thousand memories and a hundred must produce a recall
    block of the same order, or "remember everything" turns into a prompt
    that cannot be sent.
    """
    import budget
    memory, index = _isolated_memory(tmp_path)
    for i in range(120):
        memory.graft("chesed", f"note {i}: the bracket was set to {i}",
                     origin="user")
    index.rebuild()
    small = budget.count(memory.recall_block("tell me about the bracket", 6,
                                             limit_chars=1600))
    for i in range(120, 1600):
        memory.graft("chesed", f"note {i}: the bracket was set to {i}",
                     origin="user")
    index.rebuild()
    big = budget.count(memory.recall_block("tell me about the bracket", 6,
                                           limit_chars=1600))
    assert big <= 700, f"{big} tokens of recall for one question"
    assert big <= small * 2 + 100, (
        f"recall grew from {small} to {big} tokens with the store - it is "
        f"supposed to be bounded by the budget, not by how much is known")


# --------------------------------------- 9. one failure is worth almost nothing

def _ledger(tmp_path):
    import core, ledger
    core.DATA = tmp_path / "data"
    core.DATA.mkdir(parents=True, exist_ok=True)
    ledger.LEDGER = core.DATA / "attempts.jsonl"
    return ledger


def test_one_failure_never_reaches_certainty(tmp_path):
    """
    "When you train 10,000 times you know. When you saw 10 - 5 times, you
    don't know, you have just seen a couple views."

    Laplace's rule of succession, (s+1)/(n+2), is that statement as
    arithmetic. A single failure gives a third, not zero - and a boolean
    cannot express the difference between "did not work once" and "does not
    work", which is the gap a Goku statue fell through.
    """
    ledger = _ledger(tmp_path)
    ledger.record("generate_3d", False, note="out of video memory", install="a")
    r = ledger.reliability("generate_3d", "a")
    assert r["attempts"] == 1
    assert 0.30 < r["score"] < 0.36, r["score"]
    assert r["confidence"] == "unknown"

    for _ in range(4):
        ledger.record("generate_3d", False, note="out of video memory", install="a")
    r = ledger.reliability("generate_3d", "a")
    assert r["score"] > 0.10, (
        f"five failures drove the estimate to {r['score']} - a small sample "
        f"must never reach certainty")
    assert r["confidence"] != "measured", "five observations is not measured"


def test_fewer_than_three_attempts_is_never_a_reason_to_decline(tmp_path):
    ledger = _ledger(tmp_path)
    for n in range(3):
        text = ledger.brief("generate_video", "a").lower()
        assert "try it" in text or "worth trying" in text, text
        assert "cannot" not in text and "unable" not in text, text
        ledger.record("generate_video", False, note="timed out", install="a")


def test_a_change_to_the_machine_retires_the_evidence(tmp_path):
    """
    "The fix would be high on the reliability scale." In code that means a
    fix does not argue with the evidence, it retires it - the old attempts
    were measured on a machine that no longer exists.
    """
    ledger = _ledger(tmp_path)
    for _ in range(6):
        ledger.record("generate_3d", False, note="weights missing", install="old")
    before = ledger.reliability("generate_3d", "old")
    assert before["attempts"] == 6 and before["confidence"] == "weak"

    after = ledger.reliability("generate_3d", "new")
    assert after["attempts"] == 0, "old attempts still counted after a change"
    assert after["retired"] == 6, "the history was lost rather than retired"
    assert "never tried on this build" in ledger.brief("generate_3d", "new")


def test_the_same_error_three_times_says_ask_the_user(tmp_path):
    """
    The one case where retrying is not the answer. What changes the outcome
    then is a person with access to the machine, not another identical run.
    """
    ledger = _ledger(tmp_path)
    for _ in range(3):
        ledger.record("generate_3d", False,
                      note="trellis exited 1: model not found", install="a")
    r = ledger.reliability("generate_3d", "a")
    assert r["same_error_every_time"] is True
    text = ledger.brief("generate_3d", "a")
    assert "ask the user" in text, text
    assert "model not found" in text, "the actual error is not passed on"

    # A DIFFERENT error each time is not that case - the thing is varying,
    # so another attempt still tells you something.
    ledger2 = _ledger(tmp_path / "two")
    for note in ("out of memory", "timed out", "bad checkpoint"):
        ledger2.record("generate_image", False, note=note, install="a")
    assert ledger2.reliability("generate_image", "a")["same_error_every_time"] is False


def test_a_success_after_failures_moves_the_estimate(tmp_path):
    ledger = _ledger(tmp_path)
    for _ in range(3):
        ledger.record("generate_image", False, note="oom", install="a")
    low = ledger.reliability("generate_image", "a")["score"]
    ledger.record("generate_image", True, install="a")
    high = ledger.reliability("generate_image", "a")["score"]
    assert high > low, "evidence that it works did not change the estimate"


def test_the_breakdown_reads_as_counts_not_verdicts(tmp_path):
    """The "how many attempts" view, and it must not print false precision."""
    ledger = _ledger(tmp_path)
    ledger.record("generate_image", True, install="a")
    ledger.record("open_file", True, install="a")
    text = ledger.breakdown("a")
    assert "tried" in text and "confidence" in text
    assert "never a reason to decline" in text
    # A capability with no attempts on this build shows no percentage.
    ledger.record("generate_video", False, note="x", install="old")
    text2 = ledger.breakdown("a")
    row = next(l for l in text2.splitlines() if l.startswith("generate_video"))
    assert "%" not in row, f"a figure with nothing behind it: {row}"
    assert "retired" in row


def test_the_lens_can_show_attempts_and_memory():
    import lens
    assert "attempts" in lens.AREAS and "memory" in lens.AREAS
    out = lens.look("attempts", {})
    assert "ATTEMPTS" in out
    out = lens.look("memory", {})
    assert "MEMORY" in out and "faded" in out.lower()


def test_the_prompt_teaches_the_sample_size_rule():
    c = " ".join(core.character().split())
    assert "a third, not zero" in c, "the sample-size rule is not in the sheet"
    assert "Seeing something five times is not knowing it" in c
    assert "never a reason to decline" in c.lower()
    assert "ask the user whether they can fix it" in c
    assert "retires the evidence" in c, (
        "the fix-retires-evidence rule is missing")


# ------------------------------------- 10. the block that was called a statue

def test_a_spec_is_refused_for_anything_a_spec_cannot_be():
    """
    THE BLOCK WITH TWO HOLES IN IT.

    Asked for "a statue of Goku and Frieza fighting", the model passed a
    spec. meshgen did exactly what a spec says - built a rectangular prism
    with two cylindrical holes, measured it, called it watertight, reported
    SUCCESS - and the user got a block. Nothing errored; every check passed.

    A spec's whole vocabulary is exact primitives. There is no arrangement
    of boxes and cylinders that is a character, so the check has to happen
    on the REQUEST before the build, not on the geometry after it.
    """
    import meshgen
    for subject in ("a statue of Goku and Frieza fighting",
                    "two characters fighting in space",
                    "a realistic dragon",
                    "a figurine of a woman",
                    "a lifelike sculpture of a dog"):
        assert meshgen.spec_suits(subject), f"a spec was allowed for {subject!r}"

    for subject in ("a bracket 60x40x4 with two 5mm holes",
                    "a cylindrical spacer 20mm tall",
                    "a mounting plate for a raspberry pi",
                    "an enclosure with vents",
                    "a vase with a flared rim"):
        assert not meshgen.spec_suits(subject), (
            f"the spec route was blocked for {subject!r}, which is exactly "
            f"what it is good at")


def test_a_character_request_leaves_the_spec_route(tmp_path):
    """
    The spec is DROPPED and the request carries on down the route that can
    do it. Refusing would hand back an error for something the machine can
    do; carrying on gets the user a statue.
    """
    import json, core, playground, tools
    old = (core.DATA, playground.ROOT)
    core.DATA = tmp_path / "data"
    playground.ROOT = core.DATA / "playground"
    playground.ensure()
    try:
        spec = json.dumps({"parts": [{"shape": "box", "size": [60, 40, 20],
                                      "holes": [{"at": [15, 20], "d": 10}]}]})
        out, _ = tools.run("generate_3d",
                           {"prompt": "a statue of Goku and Frieza fighting",
                            "spec": spec}, core.load())
        assert "BUILD SUCCESS" not in out, (
            "a character request still produced a spec-built solid: " + out[:200])
        assert not list(playground.ROOT.glob("*.stl")), (
            "a block was written to disk for a character request")
    finally:
        core.DATA, playground.ROOT = old


# ------------------------------------------- 11. a reply that stops being text

def test_a_runaway_repetition_is_recognised():
    """
    THE HUNDRED CLOSING TAGS. A real session streamed a malformed tool call
    and then repeated one closing tag until the user pressed stop.
    """
    import toolcall
    spam = ("<tool_call> <function=pass_off> <parameter=topic> "
            "body_nudity_focus " + "</parameter> " * 40)
    assert toolcall.runaway(spam) == "</parameter>"
    assert toolcall.looks_like_leaked_markup(spam)


def test_ordinary_writing_is_not_mistaken_for_a_runaway():
    import toolcall
    for text in (
        "The bracket is 60 by 40 by 4 millimetres with two five millimetre "
        "holes, one at each end. It came out watertight and should print "
        "without supports on any bed larger than 80mm.",
        "Steps:\n1. open\n2. read\n3. close\n4. verify\n5. report\n"
        "6. next\n7. done\n8. finish",
        "ha ha ha, that is funny",
        "",
    ):
        assert toolcall.runaway(text) == "", f"false positive on: {text[:40]!r}"


def test_the_stream_is_cut_rather_than_scrubbed_afterwards():
    """
    The scrub ran after the answer completed, so it cleaned the stored copy
    of something the user had already watched arrive. There is no un-sending
    a token; the only fix is to stop early.
    """
    src = Path("server.py").read_text(encoding="utf-8")
    assert "toolcall.runaway(full)" in src, "the stream is not checked while open"
    assert "cancel_stream()" in src, "a runaway is detected but not stopped"
    assert '"replace"' in src, "a cut reply is not replaced with an explanation"
    ui = Path("ui.html").read_text(encoding="utf-8")
    assert "d.replace" in ui, "the page ignores the replacement"


def test_pass_off_cannot_loop():
    """
    pass_off three times in one turn, each handing the task on again, with
    nothing produced and nothing refused. The existing guard only caught
    IDENTICAL calls; these varied their arguments.
    """
    import json, policy
    g = policy.Gate()
    g.begin_turn("t")
    cfg = {"tools": {}, "hub": {"capability_gate": True}}
    verdicts = [g.authorize("pass_off",
                            json.dumps({"reason": f"round {i}",
                                        "focus": f"f{i}"}), cfg).verdict
                for i in range(4)]
    # THE RULE CHANGED AND SO DID THIS. It used to allow exactly two
    # hand-overs and refuse the third, whatever was happening. That number
    # stopped the loop and it also stopped the work - "come up with an
    # image, build it in 3D, then make a video of it" is four or five rounds
    # of real activity. What is measured now is movement: a hand-over after
    # a round that ran a tool is free, and two in a row that ran nothing end
    # the turn. This case runs nothing at all, so it is caught sooner.
    assert verdicts[0] == "execute", verdicts
    assert verdicts[2] == "refuse" and verdicts[3] == "refuse", verdicts

    g.begin_turn("t2")
    assert g.authorize("pass_off", "{}", cfg).verdict == "execute", (
        "the cap did not reset on a new turn")


# --------------------------------------------- 12. recency is not relevance

def test_a_stopword_cannot_admit_an_unrelated_memory():
    """
    The admission test read raw words, so "the" counted. Asked to "recreate
    the statue of Goku and Freiza fighting", a leaf reading "the bracket
    needs two 5mm holes" shared exactly one word - "the" - cleared the gate
    on it, then scored on weight and recency and was admitted.

    A broken ADMISSION test is harder to see than a broken ranking, because
    everything after it behaves correctly.
    """
    import grove
    leaf = grove.Leaf(content="the bracket needs two 5mm holes",
                      limb="hod", branch="general")
    assert leaf.relevance("recreate the statue of Goku and Freiza fighting") == 0.0
    assert leaf.relevance("how wide is the bracket") > 0.0


def test_nothing_unrelated_is_recalled(tmp_path):
    """
    "If I ask for a picture of GOD striking an anvil, I do not want it to
    randomly reference EVERY text where it creates something, only see if
    the relation is even there to begin with."
    """
    import core, memory
    old = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
           core.SESSIONS, core.LOGS, core.WRITABLE, core.CONFIG)
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"; core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"; core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"; core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    core.CONFIG = tmp_path / "config.json"
    core.ensure_dirs()
    try:
        memory.graft("chesed", "asked for a picture of a goth girl yesterday",
                     origin="user")
        memory.graft("hod", "the bracket needs two 5mm holes", origin="user")
        memory.graft("chesed", "wants a Goku and Frieza statue for a desk",
                     origin="user")

        goku = memory.recall_block("recreate the statue of Goku and Freiza "
                                   "fighting", 6, limit_chars=1200)
        assert "Goku" in goku, "the one relevant memory was missed"
        assert "bracket" not in goku, "an unrelated memory came back: " + goku
        assert "goth" not in goku, "yesterday's subject bled in: " + goku

        anvil = memory.recall_block("a picture of GOD striking an anvil", 6,
                                    limit_chars=1200)
        assert "bracket" not in anvil and "goth" not in anvil, anvil
    finally:
        (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
         core.SESSIONS, core.LOGS, core.WRITABLE, core.CONFIG) = old


def test_recency_orders_but_never_admits():
    """
    "Learned recently:" put the eight newest leaves in front of the model on
    every turn regardless of the question, so yesterday's conversation
    arrived in the middle of today's reading as current context.
    """
    src = Path("memory.py").read_text(encoding="utf-8")
    assert "RECENT_MIN_OVERLAP" in src, "the recency tail is still ungated"
    assert "Also learned recently, and related to this:" in src, (
        "the heading still claims relevance it has not checked")


def test_the_frame_speaks_to_her_not_about_her():
    """
    A frame that talks ABOUT Nova teaches the model to talk about Nova, and
    Gemma 4 duly wrote "Nova has attempted to create the desired statue".
    """
    # STRING CONSTANTS ONLY. A regex over the source matched a code comment
    # the first time - comments explaining the bug are not the bug.
    import ast as _ast, re as _re
    tree = _ast.parse(Path("server.py").read_text(encoding="utf-8"))
    bad = []
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Constant) and isinstance(node.value, str):
            if len(node.value) < 30:
                continue
            if _re.search(r"\bNova (is|has|will|can|was|does)\b", node.value):
                bad.append(node.value[:90])
    # Docstrings are documentation, not prompt text.
    docs = {_ast.get_docstring(n) or ""
            for n in _ast.walk(tree)
            if isinstance(n, (_ast.Module, _ast.FunctionDef,
                              _ast.AsyncFunctionDef, _ast.ClassDef))}
    bad = [b for b in bad if not any(b[:60] in d for d in docs)]
    assert not bad, f"the frame narrates Nova: {bad[:1]}"
    c = " ".join(core.character().split())
    assert "in the first person" in c
    assert "third person" in c


def test_a_mesh_reports_what_it_geometrically_is():
    """
    THE SIX VIEWS WERE ATTACHED AND IT DID NOT HELP.

    The block was rendered from six angles, put in front of the model, and
    described as "battle-ready with golden hair, glowing aura, and purple
    dragon eyes". A picture is an interpretation, and a small model
    interprets toward the words it was given. A triangle count is not.

    Counting normals alone is not enough - the real file had 62 of them,
    which sounds like curvature and is not: 56 were the facets of three
    cylindrical holes, carrying almost no surface. What separates a box from
    a body is how much AREA sits on how few planes.
    """
    import json, meshgen
    slab = meshgen.build(json.dumps({"parts": [
        {"shape": "box", "size": [100, 80, 30],
         "holes": [{"at": [25, 40], "d": 12}, {"at": [50, 40], "d": 12},
                   {"at": [75, 40], "d": 12}]}]}))
    note = meshgen.shape_note(slab)
    assert "BOX OR SLAB" in note, note
    assert "not a figure" in note, note
    assert not meshgen.is_figure(slab)

    round_thing = meshgen.build(json.dumps({"parts": [
        {"shape": "torus", "d": 40, "thickness": 8}]}))
    assert "BOX OR SLAB" not in meshgen.shape_note(round_thing)

    assert meshgen.shape_note([]) == "empty - no triangles at all"


def test_the_measurement_travels_with_the_render():
    src = Path("tools.py").read_text(encoding="utf-8")
    assert "meshgen.shape_note" in src, (
        "a mesh is still handed over without saying what it is")
    assert src.count("shape_note") >= 2, (
        "only one of the two 3D paths reports its geometry")


# ----------------------------------- 13. one definition of "installed"

def _trellis_names():
    """The real TRELLIS_NAMES out of install.py. A restated constant drifts."""
    import ast as _ast
    ns = {}
    for node in _ast.parse(Path("install.py").read_text(encoding="utf-8")).body:
        if (isinstance(node, _ast.Assign) and node.targets
                and getattr(node.targets[0], "id", "") == "TRELLIS_NAMES"):
            exec(compile(_ast.Module([node], []), "<i>", "exec"), ns)
    return ns["TRELLIS_NAMES"]


def test_the_release_ships_a_server_and_the_app_uses_it(tmp_path):
    """
    WHAT THE ARCHIVE ACTUALLY CONTAINS.

    Every prebuilt Windows archive for trellis.cpp v0.4.3 holds
    trellis-server.exe and no CLI. The 693 MB CUDA download extracts to
    exactly one executable. Two rounds of work here were wrong in opposite
    directions - one ran the server with CLI flags it cannot parse, the
    other refused it and waited for a trellis-cli.exe the release does not
    contain - and in between every 3D request became a flat relief.

    The server is the interface. It takes --models and --port, answers
    /health, and returns model/gltf-binary from a multipart POST to
    /generate.
    """
    import forge
    d = tmp_path / "trellis"
    d.mkdir()
    (d / "trellis-server.exe").write_bytes(b"0" * 200_000)
    old = forge.TRELLIS_DIR
    forge.TRELLIS_DIR = d
    try:
        kind, exe = forge.trellis_backend()
        assert kind == "server", (
            "the only binary the release ships is not accepted as a way to "
            "run 3D")
        assert exe.name == "trellis-server.exe"
        # A CLI, if one ever exists, still wins.
        (d / "trellis-cli.exe").write_bytes(b"0" * 150_000)
        assert forge.trellis_backend()[0] == "cli"
    finally:
        forge.TRELLIS_DIR = old


def test_the_service_speaks_the_documented_api(tmp_path):
    """
    GET /health -> ok;  POST /generate multipart with image + seed,
    resolution, bg_removal -> model/gltf-binary.
    """
    import forge
    svc = forge.TrellisService(tmp_path / "x.exe", tmp_path, port=8103)
    assert svc.base.endswith(":8103")
    img = tmp_path / "in.png"
    img.write_bytes(b"\x89PNG\r\n\x1a\n" + b"0" * 64)
    body, ctype = forge._multipart(
        {"resolution": "512", "bg_removal": "birefnet", "seed": "7"},
        "image", img)
    assert ctype.startswith("multipart/form-data; boundary=")
    boundary = ctype.split("boundary=")[1].encode()
    assert body.startswith(b"--" + boundary)
    assert body.rstrip().endswith(b"--" + boundary + b"--")
    for field in (b'name="resolution"', b'name="bg_removal"',
                  b'name="seed"', b'name="image"; filename="in.png"'):
        assert field in body, field
    assert b"\x89PNG" in body, "the image bytes are not in the body"


def test_the_service_is_stopped_even_when_it_fails():
    """
    A resident 693 MB process would hold the memory Nova needs to come back
    into. The stop belongs in a finally, not after the happy path.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    block = src.split("if kind == \"server\":")[1].split("else:")[0]
    assert "finally:" in block and "svc.stop()" in block, (
        "the trellis service is not stopped on the failure path")


def test_a_named_binary_beats_a_guess_and_a_guess_is_never_a_server(tmp_path):
    """
    _find_binary returned the first FILE matching any acceptable name, so
    with both executables present the winner was whichever rglob reached
    first. A preference tuple has to be honoured in order.
    """
    import ast as _ast
    ns = {"Path": Path}
    for node in _ast.parse(Path("install.py").read_text(encoding="utf-8")).body:
        if isinstance(node, _ast.FunctionDef) and node.name == "_find_binary":
            exec(compile(_ast.Module([node], []), "<i>", "exec"), ns)
    names = _trellis_names()

    d = tmp_path / "a"
    d.mkdir()
    (d / "trellis-server.exe").write_bytes(b"0" * 200_000)
    assert ns["_find_binary"](d, names).name == "trellis-server.exe", (
        "the installer rejects the only binary the release ships")
    (d / "trellis-cli.exe").write_bytes(b"0" * 150_000)
    assert ns["_find_binary"](d, names).name == "trellis-cli.exe", (
        "a CLI was on disk and the server was chosen anyway")

    # A GUESS still never returns a service.
    g = tmp_path / "b"
    g.mkdir()
    (g / "trellisfoo-server.exe").write_bytes(b"0" * 200_000)
    assert ns["_find_binary"](g, names) is None


def test_the_installer_and_the_runtime_agree_about_trellis(tmp_path):
    """
    THE ROOT CAUSE OF EVERY FLAT 3D MODEL.

    install._find_binary() ends with an inspection fallback - "any .exe over
    100 KB whose name contains 'trellis', largest wins" - so it picked
    trellis-server.exe, reported the 3D generator READY, and skipped the
    download. forge.trellis_exe() rejects any name containing "server",
    because running the HTTP service as a CLI broke 3D outright.

    Both rules are right alone. Together they hid a missing file: the log
    said "3D (TRELLIS) ready" while every request produced an 8 mm plaque.
    """
    import ast as _ast, forge
    ns = {"Path": Path}
    src = Path("install.py").read_text(encoding="utf-8")
    for node in _ast.parse(src).body:
        if isinstance(node, _ast.FunctionDef) and node.name == "_find_binary":
            exec(compile(_ast.Module([node], []), "<i>", "exec"), ns)
    names = _trellis_names()

    d = tmp_path / "trellis"
    d.mkdir()
    (d / "trellis-server.exe").write_bytes(b"0" * 200_000)
    old = forge.TRELLIS_DIR
    forge.TRELLIS_DIR = d
    try:
        # Both sides see the same thing: a usable backend, of kind "server".
        assert ns["_find_binary"](d, names) is not None
        assert forge.trellis_backend()[0] == "server"
        # trellis_exe() specifically means THE CLI, and there is none.
        assert forge.trellis_exe() is None
        (d / "trellis-cli.exe").write_bytes(b"0" * 150_000)
        assert ns["_find_binary"](d, names).name == "trellis-cli.exe"
        assert forge.trellis_exe().name == "trellis-cli.exe"
        assert forge.trellis_backend()[0] == "cli"
    finally:
        forge.TRELLIS_DIR = old


def test_the_installer_asks_the_runtime_rather_than_guessing():
    src = Path("install.py").read_text(encoding="utf-8")
    assert "_forge.trellis_backend()" in src, (
        "install.py still has its own opinion about whether 3D is installed")


def test_the_cpu_fallback_is_left_available():
    """
    trellis.cpp wants 16 GB of VRAM and ~6 GB even at Q4; this card has 4.
    Its CLI carries an optional CPU path, and --require-gpu is what disables
    it. Passing that flag would turn a slow real mesh into instant failure.
    """
    # STRING CONSTANTS, not raw source - the comment explaining why the flag
    # is omitted is not the flag being passed.
    import ast as _ast
    tree = _ast.parse(Path("forge.py").read_text(encoding="utf-8"))
    passed = [n.value for n in _ast.walk(tree)
              if isinstance(n, _ast.Constant) and isinstance(n.value, str)
              and n.value.strip() == "--require-gpu"]
    assert not passed, (
        "--require-gpu is being passed, which kills the only path that fits")


# ------------------------------------- 14. a substitute says it is one

def test_a_relief_is_never_reported_as_a_success():
    """
    THIS TEST OUTLIVED WHAT IT WAS PROTECTING, AND THAT IS THE POINT.

    It began by insisting the plaque was not called a success, then that it
    was labelled a substitute, then that the label came first. Each round
    made the wrong object arrive more honestly. Three of them reached the
    user anyway - "I can do that at home with a bar of soap" - because the
    problem was never the wording.

    So the assertion is now the strongest form of itself: there is no
    substitute headline, because there is no substitute.
    """
    src = Path("tools.py").read_text(encoding="utf-8")
    assert "3D SUBSTITUTE, NOT THE THING ASKED FOR" not in src, (
        "the substitute is back - it should raise instead")
    assert "3D GENERATION SUCCESS (built, not imagined)" not in src, (
        "the old success headline for the fallback is still there")


def test_a_flat_plaque_is_called_a_plaque():
    """
    102,396 triangles across 20,154 surface directions on an 80 x 80 x 8 mm
    plate cleared every threshold and was called "a detailed, organic-scale
    form". The picture pressed into the face really is finely modelled; the
    thing is still 10% as thick as it is wide.
    """
    import json, meshgen
    plate = meshgen.build(json.dumps({"parts": [
        {"shape": "box", "size": [80, 80, 8]}]}))
    note = meshgen.shape_note(plate)
    assert "PLAQUE OR RELIEF" in note or "BOX OR SLAB" in note, note
    assert not meshgen.is_figure(plate)

    tall = meshgen.build(json.dumps({"parts": [
        {"shape": "tube", "d": 30, "wall": 3, "h": 90}]}))
    assert "PLAQUE" not in meshgen.shape_note(tall), (
        "a tall tube was called a plaque")


# --------------------------------------- 15. saying is not doing

def test_a_promise_without_a_call_is_recognised():
    """
    "I am attempting the generation now." Three replies like it, no file.
    To every layer below the model these are ordinary answers.
    """
    import toolcall
    offered = {"generate_image", "generate_video", "generate_3d",
               "web_search", "open_file", "search_memory"}
    for text in ("I am attempting the generation now.",
                 "I will try again. I am rebuilding the request now, "
                 "focusing on a realistic 3D model of two characters.",
                 "I am generating the image now. Please wait.",
                 "I will use web search to find something beautiful in Japan."):
        assert toolcall.promised_action(text, offered), f"missed: {text[:48]}"


def test_ordinary_answers_are_not_mistaken_for_promises():
    import toolcall
    offered = {"generate_image", "generate_3d", "web_search"}
    for text in ("The bracket is 60x40x4 mm with two holes and it printed "
                 "cleanly.",
                 "I will explain how the memory tree works.",
                 "That failed - the runtime is not installed. A smaller size "
                 "would be the next thing to try.",
                 "Here is the summary you asked for.",
                 "I have faith in the process of iteration.",
                 ""):
        assert not toolcall.promised_action(text, offered), (
            f"false positive on: {text[:48]}")


def test_the_turn_pushes_back_on_a_promise():
    src = Path("server.py").read_text(encoding="utf-8")
    assert "toolcall.promised_action" in src, "nothing checks for a promise"
    assert "promised_retried" in src, "the pushback can repeat forever"
    assert "Saying it is not doing it" in src, (
        "the correction does not tell the model what went wrong")


# ------------------------------------------- 16. delivery, and speed

def test_every_made_file_is_offered_without_being_asked():
    """
    offer_file only ever asks, so a turn that ended without the model
    calling it left a twelve-minute render in the Playground with nothing on
    screen. Whether the user saw their file came down to whether a 2B model
    remembered a step.
    """
    src = Path("server.py").read_text(encoding="utf-8")
    assert "made_this_turn" in src
    assert 'authorize(\n                            "offer_file"' in src or \
           '"offer_file", json.dumps({"name": name}), cfg)' in src, (
        "files made this turn are tracked but never offered")


def test_the_expensive_offload_is_spent_in_proportion():
    """
    716 seconds for one 1024px render, with every offload flag on for every
    image. sd.cpp's own docs: aggressive offloading "trades VRAM for speed".
    """
    import forge
    pre = forge.model_preset("dreamshaper-xl-v2-turbo-Q4_K.gguf")
    assert pre["width"] <= 768, (
        f"the turbo preset still defaults to {pre['width']}px, which is what "
        f"forces the VAE onto the CPU")
    src = Path("forge.py").read_text(encoding="utf-8")
    assert "heavy = (width * height) > (768 * 768)" in src, (
        "the CPU offload flags are still unconditional")


def test_a_size_failure_drops_a_rung_before_reporting():
    """
    An out-of-memory failure at 768 is not "this machine cannot make
    pictures", it is "not at that size". The user asked for a picture, not a
    diagnosis.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    img = src.split("def image(")[1].split("def video(")[0]
    assert "retrying at" in img, "images do not retry smaller"
    vid = src.split("def video(")[1].split("def mesh_from_image")[0]
    assert "retrying at" in vid, "video does not retry smaller"


def test_video_finds_all_three_parts_it_needs(tmp_path):
    """Video has never once run. The wiring, at least, is correct."""
    import forge
    old = forge.MODELS
    forge.MODELS = tmp_path
    try:
        for n in ("Wan2.1-T2V-1.3B-Q5_K_M.gguf",
                  "wan_2.1_vae.safetensors",
                  "umt5-xxl-encoder-Q3_K_M.gguf"):
            (tmp_path / n).write_bytes(b"0" * 2048)
        parts = forge._video_parts()
        assert all(parts.values()), parts
        assert "vae" in parts["vae"].name.lower()
        assert "vae" not in parts["diffusion"].name.lower()
    finally:
        forge.MODELS = old


# ------------------------------ 17. the launch screen says what is settable

def _banner(tmp_path, **over):
    """Render both halves of the launch banner into a string."""
    import io, contextlib
    import core, server, memory, vault, playground, runtime, forge
    core.DATA = tmp_path / "data"
    for n in ("TREE", "KNOWLEDGE", "ASH", "EVENTS", "SESSIONS", "LOGS"):
        setattr(core, n, core.DATA / n.lower())
    core.WRITABLE = (core.DATA,) + tuple(
        getattr(core, n) for n in
        ("TREE", "KNOWLEDGE", "ASH", "EVENTS", "SESSIONS", "LOGS"))
    core.CONFIG = tmp_path / "config.json"
    core.ensure_dirs()
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    vault.MADE_VAULT = vault.VAULT / "Made"
    vault.ensure()
    playground.ROOT = core.DATA / "playground"
    playground.ensure()
    forge._STATE_FILE = core.DATA / "forge_state.json"

    cfg = core.load()
    cfg["model"] = "some-model.Q4_K_M.gguf"
    cfg["voice"] = {"enabled": True, "name": "Microsoft Hazel - English "
                    "(United Kingdom)", "rate": 1.0, "pitch": 1.0}
    cfg["hearing"] = {"enabled": False, "model": "ggml-base.en.bin",
                      "threads": 4}
    cfg.update(over)

    real_models, real_whisper, real_bench, real_avail = (
        core.models, core.WHISPER_EXE, runtime.bench, forge.available)
    core.models = lambda: [{"name": cfg["model"], "vision": True,
                            "projector": "some-mmproj.gguf"}]
    core.WHISPER_EXE = tmp_path / "whisper.exe"
    core.WHISPER_EXE.write_bytes(b"x")
    runtime.bench = lambda: {"n_ctx": 32768, "gen_tok_s": 14.2,
                             "first_reply_s": 1.8}
    forge.available = lambda: {
        k: {"ready": True, "why": "", "models": ["x"], "last": {}}
        for k in ("image", "video", "model3d", "mesh")}
    real_backend = forge.trellis_backend
    forge.trellis_backend = lambda: ("server", tmp_path / "trellis-server.exe")
    server._COLOUR = False
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            server._print_settings(cfg)
            server._print_live(cfg, {"advisory": "a note about n_ctx"})
    finally:
        (core.models, core.WHISPER_EXE, runtime.bench, forge.available) = (
            real_models, real_whisper, real_bench, real_avail)
        forge.trellis_backend = real_backend
    return buf.getvalue()


def test_the_launch_screen_names_the_voice(tmp_path):
    """
    The voice was never printed at all - which is how a speaking assistant
    ends up with a voice nobody chose, and no idea it can be changed.
    """
    out = _banner(tmp_path)
    assert "voice" in out
    assert "Microsoft Hazel" in out, "the configured voice is not shown"
    assert "rate" in out and "pitch" in out


def test_the_launch_screen_shows_everything_that_is_running(tmp_path):
    out = _banner(tmp_path)
    for row in ("assistant", "thinking", "vision", "hearing", "voice",
                "memory", "files", "search", "theme", "window", "speed",
                "sampling", "runtime", "images", "video", "3D",
                "3D shapes"):
        assert row in out, f"the launch screen no longer shows {row!r}"


def test_the_launch_screen_says_what_each_thing_IS(tmp_path):
    """
    "images ready" is not enough. Which checkpoint, at what quantisation,
    through which runtime, at what size - those are what change when
    something is swapped, and they are exactly what nobody could see while 3D
    quietly built plaques for weeks.
    """
    out = _banner(tmp_path)
    assert "stable-diffusion.cpp" in out, "the image runtime is not named"
    assert "trellis.cpp" in out, "the 3D runtime is not named"
    assert "meshgen.py" in out, "the built-in geometry builder is not named"
    assert "port 8103" in out, "the 3D service port is not shown"
    # The model's make and quantisation, not just its filename.
    assert "Q4_K_M" in out
    assert "MB on disk" in out
    # Where the voice comes from - it is Windows', not ours.
    assert "Windows voice" in out and "ships no voices" in out


def test_the_model_family_is_read_from_the_filename():
    import server
    assert server._family("Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf") == \
        "Gemma 4, abliterated"
    assert server._family("Huihui-Qwen3.5-4B-abliterated.Q4_K_M.gguf") == \
        "Qwen3.5, abliterated"
    assert server._family("something-else.gguf") == "unknown family"
    assert server._quant("x.Q4_K_M.gguf") == "Q4_K_M"
    assert server._quant("mmproj-BF16.gguf") == "BF16"
    assert server._quant("plain.gguf") == "unknown quant"


def test_the_launch_screen_colours_by_faculty():
    """
    Twenty grey rows do not get scanned. Grouped by what the row IS -
    thinking, senses, memory, making, network - so the screen can be read at
    a glance.
    """
    import server
    for key in ("think", "see", "hear", "speak", "memory", "files",
                "image", "video", "mesh", "net", "machine", "hint"):
        assert key in server._C, f"no colour for {key}"
    was = server._COLOUR
    try:
        server._COLOUR = True
        assert server._c("image", "x").startswith("\033[")
        assert server._c("image", "x").endswith("\033[0m")
        assert server._plain(server._c("image", "hello")) == "hello"
        server._COLOUR = False
        assert server._c("image", "x") == "x", (
            "colour is not optional - a terminal without ANSI would show "
            "escape codes as text")
    finally:
        server._COLOUR = was


def test_the_launch_screen_says_where_to_change_things(tmp_path):
    """
    A status line that reports a value but not where the value lives teaches
    people the value is fixed.
    """
    out = _banner(tmp_path)
    assert "Settings > voice" in out
    assert "Settings > model" in out
    assert "config.json" in out
    assert "can be changed" in out, "nothing tells the user any of it is theirs"


def test_the_launch_screen_stays_inside_its_box(tmp_path):
    import server
    out = _banner(tmp_path)
    long = [ln for ln in out.splitlines() if len(ln) > server.W]
    assert not long, f"lines running past the box: {long[:2]}"
    # And the rules are the width they claim to be.
    rules = [ln for ln in out.splitlines() if set(ln) in ({"="}, {"-"})]
    assert rules and all(len(ln) == server.W for ln in rules)


# ------------------------- 18. installed is not the same as ever having worked

def test_ready_is_reported_beside_how_often_it_has_run(tmp_path):
    """
    "ready" means installed and reachable and says nothing about whether the
    thing has ever worked. Video reported ready for weeks with zero
    successful runs behind it, and nothing on any screen said so.
    """
    import core, forge, ledger
    old = (core.DATA, ledger.LEDGER, forge._STATE_FILE)
    core.DATA = tmp_path
    ledger.LEDGER = tmp_path / "attempts.jsonl"
    forge._STATE_FILE = tmp_path / "state.json"
    try:
        fp = forge._fingerprint()
        for i in range(9):
            ledger.record("image", i > 1, note="" if i > 1 else "oom",
                          install=fp)
        rows = {e["key"]: e for e in forge.inventory()}
        assert forge.tried_note(rows["image"]["attempts"]) == "7 of 9 worked here"
        assert "never tried" in forge.tried_note(rows["video"]["attempts"])
        assert forge.tried_note({}) == ""
    finally:
        core.DATA, ledger.LEDGER, forge._STATE_FILE = old


def test_the_banner_and_nova_read_the_same_inventory():
    """
    ONE SOURCE. The launch screen and look_at_system("generation") were about
    to grow separate copies of "what is installed as what" - which is exactly
    the shape of the trellis bug, two functions with their own opinion about
    the same fact, agreeing until they quietly did not.
    """
    banner = Path("server.py").read_text(encoding="utf-8")
    lens_src = Path("lens.py").read_text(encoding="utf-8")
    assert "forge.inventory()" in banner, "the banner has its own copy again"
    assert "forge.inventory()" in lens_src, "the lens has its own copy again"
    assert "forge.tried_note" in banner and "forge.tried_note" in lens_src


def test_the_inventory_describes_every_generator():
    import forge
    rows = forge.inventory()
    keys = {e["key"] for e in rows}
    assert keys == {"image", "video", "model3d", "mesh"}, keys
    for e in rows:
        assert e["label"] and e["colour"]
        assert "attempts" in e
        assert isinstance(e["ready"], bool)


def test_nova_is_told_how_often_each_generator_has_run():
    import lens
    out = lens.look("generation", {})
    assert "never tried on this build" in out, (
        "Nova sees readiness without ever seeing the attempt count")


# ───────────────────────────────────────────────────────────── ADR-99
#  THE PLAQUE THAT GOT DEEPER AND WALKED PAST THE DETECTOR
# ─────────────────────────────────────────────────────────────────────


def _sphere(cx, cy, cz, r, seg=16):
    import math
    tris = []
    for i in range(seg):
        for j in range(seg * 2):
            t0, t1 = math.pi * i / seg, math.pi * (i + 1) / seg
            p0, p1 = 2 * math.pi * j / (seg * 2), 2 * math.pi * (j + 1) / (seg * 2)

            def P(t, p):
                return (cx + r * math.sin(t) * math.cos(p),
                        cy + r * math.sin(t) * math.sin(p),
                        cz + r * math.cos(t))
            a, b, c, d = P(t0, p0), P(t0, p1), P(t1, p1), P(t1, p0)
            tris.append((a, b, c))
            tris.append((a, c, d))
    return tris


def _plate(w=80.0, deep=20.9, grid=60):
    """A heightmap plate: detail on the front, one flat plane at the back."""
    import math
    step = w / grid
    def h(i, j):
        return 1.0 + (deep - 1.0) * 0.5 * (
            1 + math.sin(i / 5.0) * math.cos(j / 4.0))
    tris = []
    for i in range(grid):
        for j in range(grid):
            x0, y0, x1, y1 = i * step, j * step, (i + 1) * step, (j + 1) * step
            a = (x0, y0, h(i, j))
            b = (x1, y0, h(i + 1, j))
            c = (x1, y1, h(i + 1, j + 1))
            d = (x0, y1, h(i, j + 1))
            tris += [(a, b, c), (a, c, d)]
            # the back, all of it on z = 0
            tris += [((x0, y0, 0.0), (x1, y1, 0.0), (x1, y0, 0.0)),
                     ((x0, y0, 0.0), (x0, y1, 0.0), (x1, y1, 0.0))]
    return tris


def test_a_deeper_relief_is_still_called_a_relief():
    """
    THE ONE THE USER GOT. 80 x 80 x 20.9 mm, 159,996 triangles, a 200x200
    heightmap with 79,202 triangles lying flat on the back plane - and
    shape_note called it "a detailed, organic-scale form", because raising
    the relief depth from 8 mm to 18 mm pushed its thinness from 10% to 26%
    and straight past a "thinner than 22%" rule.

    "I can do that at home with a bar of soap."
    """
    import meshgen
    note = meshgen.shape_note(_plate(80.0, 20.9))
    assert "PLAQUE OR RELIEF" in note, note
    assert not meshgen.is_figure(_plate(80.0, 20.9))


def test_making_the_relief_thicker_does_not_smuggle_it_past():
    """
    The failure mode was a threshold that a deeper plate could out-grow. A
    slab is a slab at 8 mm and at 40 mm; the test is the flat back, not the
    proportion, so no depth should get through.
    """
    import meshgen
    for deep in (4.0, 8.0, 20.9, 30.0, 39.0):
        note = meshgen.shape_note(_plate(80.0, deep))
        assert "PLAQUE OR RELIEF" in note, f"{deep} mm escaped: {note}"


def test_a_standing_figure_is_not_called_a_plaque():
    """
    AND THIS IS WHY THE THRESHOLD WAS NOT SIMPLY RAISED TO 35%.

    A person 80 mm tall is about 26 mm deep - 32% - which is the same
    neighbourhood as the plate. A rule tuned to catch the plate by
    slenderness would start calling real statues plates, which is the worse
    error of the two.
    """
    import meshgen
    fig = []
    fig += _sphere(0, 0, 72, 8)
    fig += _sphere(0, 0, 55, 11, 20)
    fig += _sphere(0, 0, 42, 10, 20)
    fig += _sphere(-13, 3, 50, 5)
    fig += _sphere(13, -3, 52, 5)
    fig += _sphere(-5, 1, 22, 6, 20)
    fig += _sphere(5, -1, 22, 6, 20)
    fig += _sphere(-5, 1, 8, 5)
    fig += _sphere(5, -1, 8, 5)
    note = meshgen.shape_note(fig)
    assert "PLAQUE" not in note, note
    assert "BOX OR SLAB" not in note, note
    assert meshgen.is_figure(fig), note


def test_a_primitive_slab_is_still_called_a_slab_not_a_relief():
    """A box has a flat back too. It should be named as a box."""
    import meshgen
    tris = meshgen.build({"parts": [
        {"shape": "box", "size": [100, 80, 30]}]})
    note = meshgen.shape_note(tris)
    assert "BOX OR SLAB" in note, note


# ───────────────────────────────────────────────────────────── ADR-100
#  NO SUBSTITUTE MESH, EVER
# ─────────────────────────────────────────────────────────────────────


def test_generate_3d_has_no_relief_fallback_left():
    """
    Three separate builds of the relief fallback reached the user, each one
    labelled more honestly than the last and each one still not a model. A
    substitute nobody wants, produced automatically, is also the reason the
    real failure was never read: it always arrived wrapped in a file.
    """
    src = Path("tools.py").read_text(encoding="utf-8")
    body = src[src.index("def _generate_3d("):]
    body = body[:body.index("\ndef _attach_generation_assets")]
    assert "meshgen.relief(" not in body, "the relief fallback is back"
    assert "3D SUBSTITUTE" not in body, "the substitute return is back"
    assert "raise RuntimeError(" in body, (
        "the no-neural-path branch must raise, not build something else")


def test_generate_3d_has_no_unreachable_code_after_the_raise():
    """
    Removing the fallback left its tail behind - code referencing `tris`,
    which no longer exists on that path. It parsed, so nothing complained.
    """
    import ast
    tree = ast.parse(Path("tools.py").read_text(encoding="utf-8"))
    fn = next(n for n in ast.walk(tree)
              if isinstance(n, ast.FunctionDef) and n.name == "_generate_3d")
    names = {n.id for n in ast.walk(fn)
             if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
    bound = {a.arg for a in fn.args.args}
    for node in ast.walk(fn):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            bound.add(node.id)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for al in node.names:
                bound.add(al.asname or al.name.split(".")[0])
        elif isinstance(node, ast.withitem) and node.optional_vars is not None:
            if isinstance(node.optional_vars, ast.Name):
                bound.add(node.optional_vars.id)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            bound.add(node.name)
    # anything tools.py defines or imports at module level is in scope too
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                             ast.ClassDef)):
            bound.add(node.name)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for al in node.names:
                bound.add(al.asname or al.name.split(".")[0])
        elif isinstance(node, ast.Assign):
            for tgt in node.targets:
                if isinstance(tgt, ast.Name):
                    bound.add(tgt.id)
    import builtins
    stray = names - bound - set(dir(builtins))
    assert not stray, f"_generate_3d reads names it never binds: {sorted(stray)}"


# ───────────────────────────────────────────────────────────── ADR-101
#  THE CURATOR THAT NEVER RAN
# ─────────────────────────────────────────────────────────────────────


class _FakeCurator:
    """A stand-in for consolidate.Session: answers, never loads a model."""

    ok = True

    def __init__(self):
        self.asked = 0

    def expired(self):
        return False

    def interrupted(self):
        return False

    def ask(self, system, user, limit):
        self.asked += 1
        if "FACT" in str(system).upper() or "fact" in str(system):
            return "The user prefers short answers."
        return "A conversation about the weather."


def test_the_curator_actually_writes_a_digest(tmp_path):
    """
    THE CHECK THAT PASSED WHILE THE THING DID NOTHING.

    Two tests already guarded consolidation, and both read the source and
    asserted that run_curator() was CALLED. It was. What neither could see
    is that the entire body of run_curator - digesting sessions, extracting
    facts, merging echoes, seventy-one lines of it - sat one indent level
    too deep, underneath `if not cur.ok: return`. So every pass entered the
    model lock, found the model free, and returned zeros.

    Memory grew and was never distilled, silently, for as long as that
    indentation stood. A test that reads source can only ever prove the call
    is written; this one proves it does something.
    """
    import json, memory, core
    from datetime import datetime, timezone, timedelta
    old = (core.DATA, core.SESSIONS, memory.YESOD_DIR, memory.ARCHIVE_DIR,
           core.WRITABLE)
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    core.DATA = tmp_path
    core.SESSIONS = tmp_path / "sessions"
    core.SESSIONS.mkdir(parents=True, exist_ok=True)
    memory.YESOD_DIR = tmp_path / "tree" / "yesod"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    memory.ARCHIVE_DIR = core.SESSIONS / "archive"
    try:
        stale = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
        (core.SESSIONS / "s1.json").write_text(json.dumps({
            "id": "s1", "started": stale, "updated": stale,
            "messages": [{"role": "user", "content": "is it raining"},
                         {"role": "assistant", "content": "not today"}],
        }), encoding="utf-8")
        cur = _FakeCurator()
        res = memory.run_curator({"memory": {"expire_days": 10}},
                                 _session=cur)
        assert cur.asked > 0, (
            "the curator never asked the model anything - the body is "
            "unreachable again")
        assert res.get("made", 0) >= 1, res
        written = list(memory.YESOD_DIR.glob("*.json"))
        assert written, "a pass that reports work but writes no digest"
    finally:
        (core.DATA, core.SESSIONS,
         memory.YESOD_DIR, memory.ARCHIVE_DIR, core.WRITABLE) = old


def test_no_module_carries_unreachable_code():
    """
    Python has no warning for a statement that can never run, and the one
    that mattered was not a stray line after a `return` - it was the whole
    working body of a function, indented one level too far.
    """
    import verify
    problems = []
    real_error = verify.error
    verify.error = lambda m: problems.append(m)
    quiet = verify._state["quiet"]
    verify._state["quiet"] = True
    try:
        verify.check_dead_code()
    finally:
        verify.error = real_error
        verify._state["quiet"] = quiet
    assert not problems, problems


# ───────────────────────────────────────────────────────────── ADR-102
#  THE SERVER THAT COULD NOT SPEAK, AND THEREFORE COULD NOT START
# ─────────────────────────────────────────────────────────────────────


_CHATTY = '''
import sys, http.server
port = int(sys.argv[sys.argv.index("--port") + 1])
for i in range(4000):
    print("load: tensor %05d ..................................... ok" % i,
          flush=True)
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
    def log_message(self, *a): pass
http.server.HTTPServer(("127.0.0.1", port), H).serve_forever()
'''


def _free_port():
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    n = s.getsockname()[1]
    s.close()
    return n


def test_a_talkative_server_is_not_strangled_by_its_own_output(tmp_path):
    """
    THE REASON 3D NEVER RAN, AND IT WAS NEVER ABOUT 3D.

        stdout=PIPE with nobody reading it is a deadlock, not a silence.

    A pipe buffer is 64 KB, often far less. trellis-server loads six GGUFs
    and narrates every one. When the buffer fills, the next print blocks -
    and a process stopped inside write() never reaches the line that binds
    its socket. /health then cannot answer, the full 300-second deadline
    burns, and the error says the server did not respond: true, and blaming
    the wrong participant. The relief fallback then hid even that.

    Measured before the fix: a stand-in that prints 4,000 lines before
    binding never became healthy in 20 seconds. After: healthy in 2.
    """
    import subprocess, sys as _s, forge
    from pathlib import Path as _P
    script = tmp_path / "chatty.py"
    script.write_text(_CHATTY, encoding="utf-8")
    (tmp_path / "w.gguf").write_bytes(b"x")
    port = _free_port()

    real = subprocess.Popen
    subprocess.Popen = lambda argv, **kw: real(
        [_s.executable, str(script), "--port", str(port)], **kw)
    svc = forge.TrellisService(_P(_s.executable), tmp_path, port=port)
    try:
        svc.start(deadline=45)
        assert svc.log, "the server's output was not captured"
        # /health can answer while the reader is still catching up on the
        # backlog, so give the drain a moment to finish. If the pipe were
        # undrained the last line would never arrive at all, however long
        # this waited - which is the failure being guarded against.
        import time as _t
        end = _t.time() + 10
        while _t.time() < end and "tensor 03999" not in svc.said():
            _t.sleep(0.2)
        assert "tensor 03999" in svc.said(), (
            "the drain never caught up - output is being lost or blocked")
    finally:
        subprocess.Popen = real
        svc.stop()


def test_the_server_pipe_is_drained_on_a_thread():
    """
    The structural half of the same claim: a future edit that reverts to
    reading the pipe only after the process exits reintroduces the deadlock
    without failing anything at runtime until a real 3D request is made.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    body = src[src.index("class TrellisService"):src.index("def _multipart(")]
    assert "_drain" in body and "threading.Thread" in body, (
        "nothing is reading the server's stdout while it runs")
    assert "self.proc.stdout.read()" not in body, (
        "reading the pipe only after exit is the deadlock, restored")


def test_a_3d_failure_carries_what_the_server_said():
    """
    Every 3D failure for weeks arrived as one of two sentences with nothing
    behind them. An error you can read is the whole point of removing the
    fallback.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    start = src[src.index("    def start(self"):src.index("    def generate(self")]
    assert "self.said()" in start, "the start failure does not quote the log"
    gen = src[src.index("    def generate(self"):src.index("    def stop(self")]
    assert "HTTPError" in gen and "e.read()" in gen, (
        "an HTTP error body is being thrown away again")
    mesh = src[src.index("    def mesh_from_image("):]
    mesh = mesh[:mesh.index("class Session(Session")]
    assert "svc.said(" in mesh, (
        "the mesh step reports a category instead of the reason")


def test_a_resident_server_is_borrowed_not_killed(tmp_path):
    """
    A run that was killed rather than stopped leaves a server holding the
    port and the card. Starting a second one produces "address in use" in a
    log nobody reads; and stopping the borrowed one would take down
    something this session did not start.
    """
    import http.server, threading, forge
    from pathlib import Path as _P

    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *a):
            pass

    port = _free_port()
    srv = http.server.HTTPServer(("127.0.0.1", port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        svc = forge.TrellisService(_P("nonexistent.exe"), tmp_path, port=port)
        svc.start(deadline=10)          # must not raise: one is already up
        assert svc.borrowed is True
        assert svc.proc is None
        svc.stop()                      # must not kill someone else's server
        import urllib.request
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health",
                                    timeout=3) as r:
            assert r.status == 200, "stop() killed a server it did not start"
    finally:
        srv.shutdown()


def test_a_missing_binary_or_missing_weights_says_which(tmp_path):
    """"the 3D runtime could not run here" named neither."""
    import forge
    from pathlib import Path as _P
    port = _free_port()
    svc = forge.TrellisService(tmp_path / "not-there.exe", tmp_path, port=port)
    try:
        svc.start(deadline=5)
        assert False, "a missing binary started"
    except RuntimeError as e:
        assert "not where the installer put it" in str(e), e

    exe = tmp_path / "there.exe"
    exe.write_bytes(b"")
    svc = forge.TrellisService(exe, tmp_path / "empty", port=port)
    try:
        svc.start(deadline=5)
        assert False, "an empty model folder started"
    except RuntimeError as e:
        assert "no .gguf weights" in str(e), e


# ───────────────────────────────────────────────────────────── ADR-103
#  VIDEO WAS NOT TOO BIG FOR THE CARD; IT WAS NEVER TOLD ABOUT THE CARD
# ─────────────────────────────────────────────────────────────────────


def test_the_text_encoder_is_kept_off_the_card():
    """
    THE 2.5 GB THAT SHRINKING THE PICTURE COULD NEVER FIX.

    A Wan run loads three files, and the largest by far is the umt5 text
    encoder at 2,500 MB - against a 900 MB diffusion model and a 200 MB VAE.
    It is loaded first and stays resident. On a 4 GB card there is no frame
    size that leaves room for it, which is why the retry ladder failed at
    480x320x33 and then at 320x192x17 and looked like proof that video does
    not fit here.

    It was not proof. Both rungs ran with the same missing flag. sd.cpp has
    had one for exactly this the whole time - --clip-on-cpu, "keep clip in
    cpu (for low vram)" - and nothing was passing it.
    """
    import forge
    for flag in ("--clip-on-cpu", "--vae-on-cpu"):
        assert flag in forge.LOW_VRAM_VIDEO, flag
    src = Path("forge.py").read_text(encoding="utf-8")
    vid = src[src.index("    def video(self"):
              src.index("    def mesh_from_image(")]
    assert "sd_flags(LOW_VRAM_VIDEO)" in vid, (
        "the video run is not asking for the low-VRAM flags")


def test_a_flag_this_build_does_not_know_is_never_passed(tmp_path):
    """
    AND THE OTHER HALF, WHICH IS THE LESSON FROM TRELLIS.

    The TRELLIS command line was written from a guess and was wrong in every
    particular; it survived two releases because nothing ever asked the
    binary. Flags move between sd.cpp builds, and passing one this build does
    not know turns a slow-but-working run into an instant usage error - the
    worse failure, and one that looks exactly like the bug being fixed.
    """
    import forge
    forge._SD_HELP["text"] = ("usage: sd-cli\n  --vae-tiling ...\n"
                              "  --offload-to-cpu ...\n  --diffusion-fa\n")
    try:
        got = forge.sd_flags(forge.LOW_VRAM_VIDEO)
        assert got == ["--vae-tiling", "--offload-to-cpu", "--diffusion-fa"], got
        assert "--clip-on-cpu" not in got
    finally:
        forge._SD_HELP["text"] = None


def test_an_unreadable_binary_still_gets_every_flag():
    """
    If the binary will not say what it accepts, try everything. Refusing to
    attempt is the worse error - that is the whole argument of this build.
    """
    import forge
    forge._SD_HELP["text"] = ""
    try:
        assert forge.sd_flags(forge.LOW_VRAM_VIDEO) == forge.LOW_VRAM_VIDEO
    finally:
        forge._SD_HELP["text"] = None


# ───────────────────────────────────────────────────────────── ADR-104
#  A REAL PICTURE OF A CHARACTER THE MODEL HAS NEVER SEEN
# ─────────────────────────────────────────────────────────────────────


def _png(w, h, rgb=(200, 60, 40)):
    import struct, zlib

    def chunk(tag, data):
        c = tag + data
        return (struct.pack(">I", len(data)) + c
                + struct.pack(">I", zlib.crc32(c)))
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)
    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))


def _serve(pages: dict):
    """A tiny site, returned with its base URL and a shutdown callable."""
    import http.server, threading, socket
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            body, ctype = pages.get(self.path, (None, None))
            if body is None:
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    srv = http.server.HTTPServer(("127.0.0.1", port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return f"http://127.0.0.1:{port}", srv.shutdown


def test_a_reference_picture_is_fetched_and_kept_with_its_source(tmp_path):
    """
    "the lack of characters it does not know in its training data is exposed"

    A 4B model asked for GARO does not know that it does not know. It writes
    a confident prompt out of the words the name suggests, the image model
    draws a generic figure, and nothing in the loop can see the difference -
    least of all the model, which then describes its own prompt back.

    Sentences about a character do not help; the model already had too many
    of those. A picture does. So one is brought in and put in the Playground
    with everything else that feeds a generator - and the URL travels with
    it, because "where did this come from" must always have an answer.
    """
    import tools, playground, core
    page = (b'<html><head><meta property="og:image" content="/icon.png">'
            b'</head><body><img src="/hero.png"></body></html>')
    base, stop = _serve({
        "/page": (page, "text/html"),
        "/hero.png": (_png(640, 480), "image/png"),
        "/icon.png": (_png(32, 32), "image/png"),
    })
    old_root, old_wiki, old_ddg = (playground.ROOT, tools._wikipedia,
                                   tools._ddg)
    old_writable = core.WRITABLE
    playground.ROOT = tmp_path / "playground"
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    tools._wikipedia = lambda q, n: [
        {"title": "Local", "url": base + "/page", "snippet": ""}]
    tools._ddg = lambda q, n: []
    try:
        playground.ensure()
        out = tools._fetch_reference_image({"query": "garo"}, {})
        assert "REFERENCE IMAGE FETCHED" in out, out
        assert "640x480" in out, out
        assert base + "/hero.png" in out, "the source url is not reported"

        names = [f["name"] for f in playground.list_files()]
        pic = [n for n in names if n.endswith(".png")]
        assert pic, names
        side = [n for n in names if n.endswith(".source.json")]
        assert side, "no provenance was kept beside the file"
        import json
        rec = json.loads((playground.ROOT / side[0]).read_text("utf-8"))
        assert rec["image_url"] == base + "/hero.png"
        assert rec["page_url"] == base + "/page"
    finally:
        stop()
        playground.ROOT, tools._wikipedia, tools._ddg = (old_root, old_wiki,
                                                         old_ddg)
        core.WRITABLE = old_writable


def test_an_icon_is_not_mistaken_for_a_reference(tmp_path):
    """
    og:image is often a 32-pixel site badge. Conditioning a generator on a
    favicon is worse than not having a reference at all, because it looks
    like it worked.
    """
    import tools, playground, core
    page = (b'<html><head><meta property="og:image" content="/small.png">'
            b'</head><body></body></html>')
    base, stop = _serve({"/page": (page, "text/html"),
                         "/small.png": (_png(32, 32), "image/png")})
    old_root, old_wiki, old_ddg = (playground.ROOT, tools._wikipedia,
                                   tools._ddg)
    old_writable = core.WRITABLE
    playground.ROOT = tmp_path / "playground"
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    tools._wikipedia = lambda q, n: [
        {"title": "Local", "url": base + "/page", "snippet": ""}]
    tools._ddg = lambda q, n: []
    try:
        playground.ensure()
        out = tools._fetch_reference_image({"query": "garo"}, {})
        assert "REFERENCE NOT FETCHED" in out, out
        assert "32x32" in out, out
        assert not [f for f in playground.list_files()
                    if f["name"].endswith(".png")], "an icon was saved"
    finally:
        stop()
        playground.ROOT, tools._wikipedia, tools._ddg = (old_root, old_wiki,
                                                         old_ddg)
        core.WRITABLE = old_writable


def test_the_reference_tool_is_gated_like_every_other_network_tool():
    import tools, policy
    assert tools.REGISTRY["fetch_reference_image"]["network"] is True
    assert policy.TIERS["fetch_reference_image"]["network"] is True
    assert policy.ARGS["fetch_reference_image"]["url"]["type"] is str


def test_nova_is_told_to_look_before_she_draws_a_character():
    """
    A tool she does not know to reach for is no better than no tool. The
    complaint that started this was that she would not use web images at
    all.
    """
    text = Path("character.md").read_text(encoding="utf-8")
    assert "fetch_reference_image" in text, (
        "nothing in the character tells her the reference route exists")
    # The rail does the fetching now, so the sheet no longer has to teach a
    # procedure - but it must still say the picture is fetched rather than
    # invented, because the user has to be told where it came from.
    assert "fetched" in text and "not yours" in text, (
        "she is not told to pass on where the reference came from")
    # And the reason, which is the part a model will not work out alone.
    assert "sentences" in text, (
        "nothing explains why searching is not the same as looking")


# ───────────────────────────────────────────────────────────── ADR-105
#  A NAME IS A SUBJECT, AND THE NEWEST TURN OUTRANKS THE OLDEST
# ─────────────────────────────────────────────────────────────────────


def test_a_named_character_is_recognised_as_the_subject():
    """
    "Research the terrible tornado, the character, you cannot forget it."

    Not one capital letter in the name, no file extension, and nothing in
    any vocabulary focus.py shipped with - so `_subject_cues` returned the
    empty set and the turn was judged to have no subject at all. A person
    reads that sentence and knows the subject immediately, from a lookup
    verb in front and an appositive behind, neither of which needs to know
    what a Tatsumaki is.
    """
    import focus
    got = focus.named_subjects(
        "Research the terrible tornado, the character, you cannot forget it.")
    assert "terrible tornado" in got or "tornado" in got, got
    assert "goku" in focus.named_subjects(
        "create an image of Goku in ultra instinct")
    # And a name stops where the sentence turns, or it is not a name.
    long_one = focus.named_subjects(
        "an image of Goku in ultra instinct and a separate image of "
        "terrible tornado")
    assert all(len(n.split()) <= 4 for n in long_one), long_one


def test_the_newest_turn_outranks_the_oldest_subject():
    """
    THE ONE `and` THAT INVERTED THIS FILE'S OWN RULE.

    `_current_anchor` required the LATEST turn to carry a subject cue, while
    an EARLIER turn qualified on cues OR on merely being substantive. The
    newest message was held to the stricter test, so any subject focus.py
    had no vocabulary for lost to whatever came before it.

    focus.py's first line reads "CURRENT FOCUS OUTRANKS BACKGROUND". The
    code said the opposite, and the user watched a Goku statue from four
    turns earlier be restated as the goal every single turn while they tried
    to ask about someone else.
    """
    import focus
    hist = [{"role": "user", "content":
             "I would like you to recreate the statue of Goku and Frieza "
             "fighting for me please, a realistic one."},
            {"role": "assistant", "content": "..."},
            {"role": "user", "content":
             "Research the terrible tornado, the character, you cannot "
             "forget it."}]
    got = focus._current_anchor(hist)
    assert "tornado" in got.lower(), got
    assert "goku" not in got.lower(), (
        "the old subject is still being carried over the new one")


def test_saying_not_that_ends_the_old_subject():
    """
    "I am NOT asking for a 3D model at the moment."

    One turn later, generate_3d was called. A denial is not a short
    follow-up about the thing being denied.
    """
    import focus
    assert focus.changed_subject("I am NOT asking for a 3D model at the "
                                 "moment.")
    assert focus.changed_subject("We are not talking about a natural "
                                 "disaster in any sort of way.")
    assert not focus.changed_subject("Can you make it a bit taller?")
    hist = [{"role": "user", "content":
             "Recreate the statue of Goku and Frieza fighting, realistic."},
            {"role": "assistant", "content": "..."},
            {"role": "user", "content":
             "I am NOT asking for a 3D model at the moment."}]
    assert "goku" not in focus._current_anchor(hist).lower()


def test_a_short_followup_still_inherits_its_subject():
    """
    The guard on the fix above. This mechanism exists because "what about
    the frame" carries one content word, and breaking that to fix the other
    case would cost the conversation its thread.
    """
    import focus
    hist = [{"role": "user", "content":
             "I am building a greenhouse with a cedar frame and "
             "polycarbonate panels."},
            {"role": "assistant", "content": "..."},
            {"role": "user", "content": "what about the frame"}]
    assert "greenhouse" in focus._current_anchor(hist).lower()


def test_a_finished_goal_is_not_handed_over_as_the_current_one(tmp_path):
    """
    End to end, with memories planted exactly like the ones in the session
    that produced this: what actually reaches the model on a turn about a
    different subject.
    """
    import memory, focus, core
    old = (memory.YESOD_DIR, core.WRITABLE)
    memory.YESOD_DIR = tmp_path / "yesod"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    try:
        hist = [{"role": "user", "content":
                 "Recreate the statue of Goku and Frieza fighting, a "
                 "realistic one, for shelf decoration."},
                {"role": "assistant", "content": "..."},
                {"role": "user", "content":
                 "Research the terrible tornado, the character, you cannot "
                 "forget it."}]
        block = focus.perception(hist[-1]["content"], 700, history=hist)
        assert "goku" not in (block or "").lower(), block
        assert "frieza" not in (block or "").lower(), block
    finally:
        memory.YESOD_DIR, core.WRITABLE = old


def test_the_remembered_block_says_it_is_background():
    """A block of notes must say it is notes. The alternative is a model
    treating its own recollection as orders, which is what happened."""
    src = Path("server.py").read_text(encoding="utf-8")
    assert "[what you remember - background only" in src, (
        "the heading is bare again")
    assert "the message at the end of this turn" in src


# ───────────────────────────────────────────────────────────── ADR-106
#  THE SEARCH THAT LOST THE QUESTION ON THE WAY
# ─────────────────────────────────────────────────────────────────────


def test_the_category_the_user_named_reaches_the_query():
    """
    "terrible tornado" alone returns a weather system, a video-game skin and
    an S-Class hero with equal confidence. The user said "the character" out
    loud and it was dropped before the query was built.
    """
    import research, focus
    assert focus.subject_kind(
        "Research the terrible tornado, the character.") == "character"
    q = research.build_query(
        "Research the terrible tornado, the character, you cannot forget it.",
        [])
    assert "tornado" in q.lower() and "character" in q.lower(), q


def test_an_instruction_is_not_a_search_term():
    """
        "Goku search create image ultra instinct separate"

    from "Can you search for and create an image of Goku in ultra instinct
    and a separate image of terrible tornado?". Four of those seven words
    are the user talking to Nova.
    """
    import research
    q = research.build_query(
        "Can you search for and create an image of Goku in ultra instinct "
        "and a separate image of terrible tornado?", [])
    for junk in ("search", "create", "separate", "image"):
        assert junk not in q.lower().split(), f"{junk!r} in query {q!r}"
    assert "goku" in q.lower() and "tornado" in q.lower(), q


def test_no_word_appears_twice_in_a_query():
    import research
    q = research.build_query("what is the latest version of llama.cpp", [])
    words = [w.lower().strip(".,") for w in q.split()]
    assert len(words) == len(set(words)), q


def test_results_arrive_with_the_question_they_answer():
    """
    "I had asked for a character, so only one of those three descriptions
     that you have just matched up actually applies... you also brought up
     general context. I didn't ask for that either."

    The results were not wrong - a search returns what matches the words.
    By the time they were read, what was ASKED had been dropped, and a page
    of unfiltered matches with no question attached is an invitation to
    summarise all of them.
    """
    import tools
    rec = {"id": "x", "query": "terrible tornado character",
           "asked": "Research the terrible tornado, the character.",
           "results": [{"title": "Tatsumaki", "url": "https://a",
                        "snippet": "S-Class hero"},
                       {"title": "Tornado skins", "url": "https://b",
                        "snippet": "game cosmetics"}]}
    out = tools._format_search_page(rec, 0, 8)
    assert "YOU SEARCHED FOR: terrible tornado character" in out, out[:200]
    assert "a character" in out, "the category was not carried through"
    assert "not evidence" in out or "unrelated" in out, (
        "nothing tells her to reject a result that does not answer it")
    assert "Tatsumaki" in out, "the results themselves must still be there"


# ───────────────────────────────────────────────────────────── ADR-107
#  A TIMEOUT IS A GUESS ABOUT SOMEBODY ELSE'S MACHINE
# ─────────────────────────────────────────────────────────────────────


_SLOW = "\n".join([
    "import sys, time",
    "CR = chr(13)",
    "for i in range(1, 9):",
    "    sys.stdout.write('  |' + '=' * (i * 4) + '| %d/8 - 1.0s/it' % i + CR)",
    "    sys.stdout.flush()",
    "    time.sleep(0.25)",
    "sys.stdout.write(chr(10) + 'sampling completed' + chr(10))",
])


def test_no_generator_is_killed_by_a_clock():
    """
    "if the model is used on a machine barely able to run this it should
     still run"

    Every generator ran under a deadline - 40 minutes for an image, two
    hours for video, three for a mesh - and when it passed, the run was
    KILLED and reported as "timed out". None of those numbers was ever
    measured; they were picked, and picking one wrong turns a slow success
    into a failure on exactly the hardware this is built for.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    run = src[src.index("    def _run(self"):src.index("    def cancel(self")]
    assert "subprocess.run(" not in run, (
        "back to a blocking run() - which cannot report progress either")
    assert "timeout=timeout" not in run, "the kill deadline is back"
    for dead in ("timeout=2400", "timeout=7200", "timeout=10800"):
        assert dead not in src, f"{dead} is back in forge.py"
    # And the user is the deadline instead, which means there must be a way
    # for them to be it.
    assert "def cancel(self)" in src and "def cancel() -> bool" in src
    assert "forge.cancel()" in Path("server.py").read_text(encoding="utf-8"), (
        "the halt button no longer reaches the generator")


def test_progress_is_visible_while_the_generator_runs(tmp_path):
    """
    THE OTHER HALF, AND IT IS NOT DECORATION.

    Removing the deadline is only honest if the person waiting can see. A
    timeout at least said something was wrong; silence says nothing at all -
    and capture_output=True hid every line until the process exited, which
    is the moment the output stops being useful.

    sd.cpp writes its bar with a carriage return and no newline, so this
    also proves the reader splits on \r: with readline() the whole run
    would arrive as one line at the very end.
    """
    import sys as _s, forge
    script = tmp_path / "slow.py"
    script.write_text(_SLOW, encoding="utf-8")

    class _S(forge.Session):
        def __init__(self):
            self.what = "a picture"
            self.steps = []
            self._child = None

    sess = _S()
    seen = []

    def watch():
        import time as _t
        for _ in range(60):
            p = forge.progress()
            if p["backend"] and p["total"]:
                seen.append(p["step"])
            _t.sleep(0.1)
    import threading as _th
    _th.Thread(target=watch, daemon=True).start()
    ok, out, secs = sess._run("image", [_s.executable, str(script)])
    assert ok, out
    assert len(set(seen)) >= 4, (
        f"only saw steps {sorted(set(seen))} while it ran - progress is "
        f"arriving at the end, not during")
    assert "sampling completed" in out, "the output itself was lost"
    assert forge.progress()["backend"] == "", "the board was left dirty"


def test_a_carriage_return_bar_is_parsed_into_a_percentage():
    import forge
    forge._progress_start("image", "a picture")
    try:
        forge._progress_line("  |==============| 3/8 - 12.3s/it")
        p = forge.progress()
        assert p["step"] == 3 and p["total"] == 8
        assert abs(p["pct"] - 37.5) < 0.1, p
        # A line with no counter is still proof of life, which is most of
        # the value on a machine where one step can take minutes.
        before = forge.progress()["seen"]
        forge._progress_line("[INFO] loading vae")
        assert forge.progress()["seen"] >= before
        assert forge.progress()["line"].endswith("loading vae")
    finally:
        forge._progress_clear()


def test_the_interface_can_draw_the_bar():
    """The board is useless if it never reaches the screen. /api/state is
    already polled every two seconds, so it goes there."""
    server_src = Path("server.py").read_text(encoding="utf-8")
    assert '"forge": {**forge.busy(), "progress": forge.progress()}' in \
        server_src, "progress is not published on /api/state"
    ui = Path("ui.html").read_text(encoding="utf-8")
    assert 'id="progwrap"' in ui and 'id="progfill"' in ui
    assert "s.forge" in ui, "the interface never reads it"


def test_the_server_pipe_is_not_left_buffered():
    """
    BufferedReader.read(n) blocks until it has exactly n bytes. On a server
    that stays up, the last partial chunk never arrives - so `said()` was
    missing the newest lines, which are the only ones that matter in an
    error.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    svc = src[src.index("class TrellisService"):src.index("def _multipart(")]
    assert "bufsize=0" in svc, "the server pipe is buffered again"
    run = src[src.index("    def _run(self"):src.index("    def cancel(self")]
    assert "bufsize=0" in run, "the generator pipe is buffered again"


# ───────────────────────────────────────────────────────────── ADR-109
#  ONE NUMBER CANNOT DESCRIBE A MEMORY
# ─────────────────────────────────────────────────────────────────────


def test_the_curve_is_anchored_where_it_says_it_is():
    """R = 0.9 exactly at t = S, which is what makes stability readable."""
    import hold
    for S in (1, 7, 60, 365, 3650):
        assert abs(hold.retrievability(S, S) - 0.9) < 1e-9, S


def test_a_hard_recall_teaches_more_than_an_easy_one():
    """
    Bjork A3, the whole reason two numbers are needed: the gain in
    durability is a DECREASING function of how available it already was.
    Recalling something you just said is worth almost nothing; recalling
    something nearly lost is worth a great deal.
    """
    import hold
    easy = hold.strengthen(30.0, 1)
    hard = hold.strengthen(30.0, 300)
    assert hard > easy * 4, (easy, hard)
    # And massing repetitions must not manufacture durability.
    import grove
    leaf = grove.Leaf("said five times in a minute", "hod", "general")
    for _ in range(5):
        leaf.came_back()
    assert leaf.stability < 1.5, leaf.stability


def test_forgotten_is_not_gone():
    """
    The property that decides the whole design, and the one a single
    `weight` cannot express: completely out of reach, one reminder from
    being back. If this ever fails, the two scalars have collapsed into one.
    """
    import hold
    S = 5.0
    assert hold.retrievability(S, 900) < 0.2, "should be out of reach"
    back = hold.strengthen(S, 900)
    assert hold.retrievability(back, 30) > 0.9, (
        "one recall did not bring it back - stability is not being kept")


def test_the_better_held_fade_more_slowly():
    """Bjork A5. Nothing is pinned by hand; durability does the work."""
    import hold
    a = hold.retrievability(2, 180)
    b = hold.retrievability(400, 180)
    assert b > a * 3, (a, b)


def test_the_sting_fades_faster_than_the_glow():
    """
    Fading Affect Bias, replicated at N=2,163 across 12,314 memories. The
    CONTENT is untouched by this - that separation is the point. A system
    that decays them together forgets its lessons; one that decays neither
    keeps flinching at them.
    """
    import hold
    for days in (30, 90, 180):
        bad = hold.affect_now(1.0, -1, days)
        good = hold.affect_now(1.0, +1, days)
        assert bad < good, (days, bad, good)
    # Retelling fades the feeling further while the content strengthens.
    told = hold.affect_now(1.0, -1, 60, recalls=3)
    untold = hold.affect_now(1.0, -1, 60, recalls=0)
    assert told < untold


def test_the_content_is_never_faded_with_the_feeling():
    import grove, hold
    leaf = grove.Leaf("the run crashed the laptop", "hod", "general",
                      affect=1.0, valence=-1.0)
    before = leaf.content
    leaf.stability = 30.0
    leaf.recalled_at = "2026-01-01T00:00:00+00:00"
    leaf.came_back()
    assert leaf.content == before
    assert leaf.stability > 30.0, "the lesson did not get more durable"


def test_affect_that_never_fades_is_reported_as_a_fault():
    """
    The literature names this failure mode, and it is not a metaphor:
    negative charge that does not settle is the dysphoric profile. In a
    memory system it is a bug, so it is looked for by hand rather than
    silently corrected - a silent correction would hide whatever caused it.
    """
    import hold
    healthy = [{"valence": -1, "age_days": 200, "recalls": 1,
                "affect": hold.affect_now(1.0, -1, 200, 1)}]
    assert not hold.check(healthy)
    stuck = [{"valence": -1, "age_days": 200, "recalls": 1, "affect": 1.0}]
    assert hold.check(stuck), "a stuck negative weight went unreported"
    glow = [{"valence": 1, "age_days": 200, "recalls": 0, "affect": 0.9}]
    assert not hold.check(glow), "a lasting good memory is not a fault"


# ───────────────────────────────────────────────────────────── ADR-110
#  THE STORE THAT HAD GONE SILENT
# ─────────────────────────────────────────────────────────────────────


def test_a_plural_no_longer_hides_the_answer(tmp_path):
    """
    MEASURED, WITH THE ANSWER SITTING IN THE TREE:

        stored: "Image generation takes about 170 seconds at 768x768"
        asked:  "how long does an image take here"
        got:    NOTHING

    "take" and "takes" are different strings; "image" was on the weak list
    and could not admit anything alone. Between them a question and the
    exact fact that answers it had no admissible word in common.

    Every step that got there was a real fix for a real leak. Each one
    subtracted, none added anything back, and the end of that road is a
    store that never says anything.
    """
    import memory, core
    old = (memory.YESOD_DIR, core.WRITABLE)
    memory.YESOD_DIR = tmp_path / "y"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    try:
        memory.graft("hod", "Image generation takes about 170 seconds at "
                            "768x768", origin="user")
        hits = memory.recall("how long does an image take here", 4)
        assert hits, "the store is silent again"
        assert "170 seconds" in hits[0]["line"], hits
    finally:
        memory.YESOD_DIR, core.WRITABLE = old


def test_words_the_user_says_together_become_related():
    """
    "what card am I on" against "a GTX 1650 with 4 GB of VRAM" shares no
    word in any tense. Overlap cannot answer it however it is tuned.

    Association can, and it is built from this user's own memories: if they
    ever said "card" and "GTX" in one breath those two are linked FOR THEM,
    and if nobody ever did they are not. No dictionary, no model, no
    download. It starts knowing nothing.
    """
    import grove
    grove.set_neighbours(grove.learn_neighbours([
        "The GTX card is the one that runs out of VRAM",
        "Nova stops while the card is in use by the GTX",
        "A GTX 1650 with 4 GB of VRAM",
    ]))
    near = grove.neighbours_for([grove.stem("card")])
    assert "gtx" in near, near
    # One accident is not an association.
    grove.set_neighbours(grove.learn_neighbours([
        "the bracket and the kestrel were mentioned once together"]))
    assert not grove.neighbours_for([grove.stem("bracket")])


def test_an_unrelated_question_still_recalls_nothing(tmp_path):
    """The guard on all of the above. Widening retrieval must not reopen
    the leak that made every creative request drag in every other one."""
    import memory, core
    old = (memory.YESOD_DIR, core.WRITABLE)
    memory.YESOD_DIR = tmp_path / "y"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    try:
        memory.graft("hod", "The machine has a GTX 1650 with 4 GB of VRAM",
                     origin="user")
        memory.graft("hod", "Image generation takes about 170 seconds",
                     origin="user")
        assert not memory.recall("what did I have for lunch", 4)
        assert not memory.recall("how do I get to Glasgow", 4)
    finally:
        memory.YESOD_DIR, core.WRITABLE = old


def test_being_needed_is_what_makes_a_memory_durable(tmp_path):
    """Retrieval is a write. A store that only reads on recall can never
    tell what it lives by from what it merely happens to contain."""
    import memory, core
    old = (memory.YESOD_DIR, core.WRITABLE)
    memory.YESOD_DIR = tmp_path / "y"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    try:
        memory.graft("hod", "Trellis needs six gigabytes even at Q4",
                     origin="user")
        leaf = next(l for l in memory.all_leaves(memory.RECALLABLE)
                    if "Trellis" in l.content)
        import datetime
        start = leaf.stability
        for gap in (7, 30, 120):
            d = datetime.datetime.fromisoformat(
                leaf.recalled_at.replace("Z", "+00:00"))
            leaf.recalled_at = (d - datetime.timedelta(days=gap)).isoformat(
                timespec="seconds")
            memory.recall("how much does trellis need", 4)
        assert leaf.stability > start * 20, (start, leaf.stability)
        assert leaf.recalls >= 3
    finally:
        memory.YESOD_DIR, core.WRITABLE = old


# ───────────────────────────────────────────────────────────── ADR-111
#  A COMPLAINT IS NOT A BOUNDARY
# ─────────────────────────────────────────────────────────────────────


def test_a_complaint_about_the_last_reply_is_never_identity():
    r"""
        Boundaries:
        - I don't see it.
        - what? why did you copy me, don't do that

    On the user's screen, at the top of every prompt, under the same
    heading as "everything must run offline". A regex scoring 5 for
    /(never|must not|do not|don't) \w+/ matched "don't do that", and a
    moment's irritation became permanent identity.

    Grammar is not salience. A complaint about the previous reply is the
    most predictable thing a person can say after a bad reply, and
    predictability is what says something is not worth storing.
    """
    import intake
    for line in ("what? why did you copy me, don't do that",
                 "I don't see it.",
                 "I was saying to try again, not to repeat my sentence",
                 "that's not what I asked for",
                 "why did you copy me"):
        assert intake._about_the_exchange(line), line
    for line in ("Everything must run offline",
                 "Never send the vault files anywhere",
                 "The budget is capped at 4 GB of VRAM"):
        assert not intake._about_the_exchange(line), (
            f"a real boundary was mistaken for a complaint: {line}")


def test_what_is_at_stake_is_read_from_their_words():
    import intake
    assert intake._arousal("this run crashed my laptop") > 0.2
    assert intake._valence("this run crashed my laptop") < 0
    assert intake._valence("Image generation finally works, thank you") > 0
    assert intake._arousal("the file is called bracket.stl") == 0.0
    assert intake._valence("the file is called bracket.stl") == 0.0


def test_the_frame_shows_the_strongest_not_the_newest():
    """
    frame()'s own docstring said "only the strongest leaves appear - that
    is what the weights are for", and the code took rows[-8:]: the eight
    most recently added, weights untouched. The newest thing always won by
    being newest, which is how a moment's irritation stayed at the top of
    every prompt once it got there.
    """
    src = Path("memory.py").read_text(encoding="utf-8")
    body = src[src.index("def frame(limit_chars"):
               src.index("front_block = frame")]
    # CODE, NOT PROSE. The comment above the fix quotes the old line, and a
    # test that reads comments fails on its own explanation.
    code = "\n".join(l for l in body.splitlines()
                     if not l.lstrip().startswith("#"))
    assert "rows[-8:]" not in code, "the frame is back to picking the newest"
    assert "key=_holding_strength" in code


def test_surprise_is_what_earns_a_place():
    """Something already known in other words is not a new memory."""
    import hold
    known = ["The machine has a GTX 1650 with 4 GB of VRAM"]
    assert hold.surprise("the GTX 1650 has 4 GB of VRAM", known) < 0.3
    assert hold.surprise("Trellis needs six gigabytes even at Q4",
                         known) > 0.6
    # Nothing starts strong. One mention is one mention.
    assert hold.initial_stability(surprise_score=1.0, arousal=1.0) < 8.0


# ───────────────────────────────────────────────────────────── ADR-112
#  THE FLOOR THAT REPLACED THE CLOCK
# ─────────────────────────────────────────────────────────────────────


def test_a_run_eating_the_machine_is_stopped(tmp_path):
    """
    THE GUARD WORKS, AND IT IS OFF, AND BOTH OF THOSE ARE ON PURPOSE.

    It was written for "also this run crashed my laptop" and it does stop a
    run that crosses the floor. Then the user's own log showed what it was
    actually stopping:

        memory low: 150 MB free (strike 1)
        memory low: 686 MB free (strike 2)
        stopping the generator to keep the machine responsive
        video exited 1: | 20/20 - 46.69s/it
        sampling completed, taking 921.97s

    Sampling COMPLETED. All twenty steps, tensors 108 of 108 loaded for the
    final decode. Four runs, four kills, at the one moment free memory is
    lowest by design - and the machine never crashed in any of them. Low
    memory during a video decode is what a working run looks like on 16 GB.

    So this test passes a floor explicitly. The DEFAULT is zero, and the
    test below asserts that, because a number I pick from here has now
    stopped the thing it was protecting three times.
    """
    import sys as _s, forge
    script = tmp_path / "patient.py"
    script.write_text("import time\n"
                      "for i in range(200):\n"
                      "    print('step %d/200' % i, flush=True)\n"
                      "    time.sleep(0.2)\n", encoding="utf-8")

    class _S(forge.Session):
        def __init__(self):
            self.what = "a picture"
            self.steps = []
            self._child = None

    real, gap = forge.free_mb, forge.RAM_SAMPLE_SECONDS
    seen = {"n": 0}

    def falling():
        seen["n"] += 1
        return 5000.0 if seen["n"] < 3 else 200.0
    forge.free_mb = falling
    forge.RAM_SAMPLE_SECONDS = 0.4
    real_guard = forge._RamGuard
    forge._RamGuard = lambda proc, floor_mb=None: real_guard(proc, 700.0)
    try:
        ok, out, secs = _S()._run("image", [_s.executable, str(script)])
        assert not ok
        assert "keep the machine usable" in out, out[:200]
        assert "NOT a timeout" in out, "it must not read as a timeout"
        assert secs < 20, "it should stop promptly once the floor is crossed"
    finally:
        forge.free_mb, forge.RAM_SAMPLE_SECONDS = real, gap
        forge._RamGuard = real_guard


def test_nothing_watches_the_memory_unless_the_user_asks():
    """
    Four finished videos were killed by a floor I chose from here, at the
    exact moment a working run uses the most memory. The mechanism stays
    for whoever wants it; the default decides nothing on their behalf.
    """
    import forge, core, json
    assert forge.RAM_FLOOR_MB == 0.0, "a default floor is back"
    assert forge._ram_floor() == 0.0
    shipped = json.loads(Path("config.json").read_text(encoding="utf-8"))
    assert shipped.get("generation", {}).get("ram_floor_mb") == 0, shipped


def test_a_healthy_machine_is_never_interrupted(tmp_path):
    """The whole point of removing the clock was that a slow run finishes."""
    import sys as _s, forge
    script = tmp_path / "short.py"
    script.write_text("import time\n"
                      "for i in range(8):\n"
                      "    print('step %d/8' % i, flush=True)\n"
                      "    time.sleep(0.2)\n", encoding="utf-8")

    class _S(forge.Session):
        def __init__(self):
            self.what = "a picture"
            self.steps = []
            self._child = None

    real, gap = forge.free_mb, forge.RAM_SAMPLE_SECONDS
    forge.free_mb = lambda: 6000.0
    forge.RAM_SAMPLE_SECONDS = 0.2
    try:
        ok, out, secs = _S()._run("image", [_s.executable, str(script)])
        assert ok, out[:200]
        assert "keep the machine usable" not in out
    finally:
        forge.free_mb, forge.RAM_SAMPLE_SECONDS = real, gap


def test_a_run_that_cannot_fit_says_so_before_starting():
    """Knowable from the file sizes. The alternative is finding out by
    taking the machine down, which is what happened."""
    import forge
    real = forge.free_mb
    forge.free_mb = lambda: 300.0
    try:
        ok, why = forge.room_for([Path("forge.py")], margin_mb=900.0)
        assert not ok and "free" in why, why
    finally:
        forge.free_mb = real


# ───────────────────────────────────────────────────────────── ADR-113
#  THE REFERENCE LOOKUP THAT INCRIMINATED ITS OWN PROMPT
# ─────────────────────────────────────────────────────────────────────


def _tainted_gate():
    import policy
    g = policy.Gate()
    g.begin_turn("t")
    g.note_user("Come up with ideas for an image then build it in 3D and "
                "then after that make a Video of it.")
    g.taint("reference-image",
            "Bioluminescent leviathan concept art gallery. Abyssal creature "
            "renders, cinematic breaching poses, deep sea megafauna "
            "illustration, artstation trending, octane render")
    return g


def test_making_a_local_file_is_not_an_exfiltration_channel():
    """
        user:  "Come up with ideas for an image then build it in 3D and then
                after that make a Video of it."
        ->  generate_image invents "bioluminescent abyssal leviathan"
        ->  the reference rail searches the web for exactly that
        ->  the page comes back, so those words become "untrusted"
        ->  generate_3d gets the SAME prompt and is REFUSED for using
            "wording that came only from a retrieved page"

    The words it called contraband - abyssal, bioluminescent, breaching -
    were Nova's own, written before any page existed. The lookup searched
    for them and the result made them evidence against her.

    ADR-108 said MAYBE being truthy meant every `if spec["network"]` would
    keep working unchanged. This block does two jobs and only one of them
    applies to a tool whose product is a file on disk.
    """
    import json, policy
    g = _tainted_gate()
    cfg = {"tools": {"web_search": True}, "appearance": {}}
    args = json.dumps({"prompt": "a bioluminescent abyssal leviathan "
                                 "breaching, cinematic"})
    for tool in ("generate_image", "generate_3d", "generate_video"):
        d = g.authorize(tool, args, cfg)
        assert d.verdict != "refuse", f"{tool} refused: {d.reason}"


def test_but_a_real_query_still_cannot_carry_a_page_out():
    """The narrow property, unchanged. This is what the rule is FOR."""
    import json
    g = _tainted_gate()
    cfg = {"tools": {"web_search": True}, "appearance": {}}
    d = g.authorize("web_search", json.dumps(
        {"query": "megafauna artstation octane illustration"}), cfg)
    assert d.verdict == "refuse" and d.reason == "tainted-query", d.reason


def test_the_lookup_is_dropped_rather_than_the_whole_job():
    """
    The protection moves to where it costs nothing: once a page has been
    read this turn, the picture is made without a lookup and the model is
    told why - rather than the user's request being refused for a threat
    that did not apply to it.
    """
    import tools, policy
    real = policy.GATE
    policy.GATE = _tainted_gate()
    try:
        path, why = tools._reference_for("a bioluminescent leviathan",
                                         {"tools": {"web_search": True}})
        assert path is None
        assert "already been read this turn" in why, why
    finally:
        policy.GATE = real


def test_a_refusal_names_the_tool_it_refused():
    """It said "that search" for a tool that is not a search, and Nova
    reported it to the user as "the tool refused the prompt"."""
    src = Path("policy.py").read_text(encoding="utf-8")
    i = src.index('"tainted-query"')
    assert "{name} would send wording" in src[i:i + 400], (
        "the refusal still calls every tool a search")


# ───────────────────────────────────────────────────────────── ADR-114
#  THE FILE WAS THERE. IT WAS JUST KEPT.
# ─────────────────────────────────────────────────────────────────────


def _stage(tmp_path):
    """A Playground and Vault of our own, and a generated image in it."""
    import playground, vault, core, json
    old = (playground.ROOT, vault.VAULT, vault.MADE_VAULT, core.WRITABLE)
    playground.ROOT = tmp_path / "playground"
    vault.VAULT = tmp_path / "vault"
    vault.MADE_VAULT = vault.VAULT / "Made"
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    playground.ensure()
    vault.ensure()
    (playground.ROOT / "Cosmic_Forge_Base.png").write_bytes(
        b"\x89PNG\r\n\x1a\n" + b"x" * 400)
    (playground.ROOT / "Cosmic_Forge_Base.generation.json").write_text(
        json.dumps({"kind": "image",
                    "prompt": "a cosmic forge where divine energy manifests"}),
        encoding="utf-8")
    return old


def _unstage(old):
    import playground, vault, core
    (playground.ROOT, vault.VAULT, vault.MADE_VAULT, core.WRITABLE) = old


def test_keeping_a_file_does_not_leave_its_sidecar_behind(tmp_path):
    """
        Cosmic_Forge_Base.generation.json
        Goku_Ultra_Instinct.generation.json
        terrible_tornado.generation.json

    All three in the Playground listing with no images beside them, because
    keeping MOVES a file to the Vault and left the sidecar where it was. A
    sidecar without its subject is worse than no sidecar: it is a filename
    that reads as a promise, and Nova read it as one.
    """
    import playground
    old = _stage(tmp_path)
    try:
        playground.keep("Cosmic_Forge_Base.png")
        left = [f["name"] for f in playground.list_files()]
        assert not left, f"orphans left in the Playground: {left}"
    finally:
        _unstage(old)


def test_a_kept_file_is_copied_back_in_when_it_is_needed(tmp_path):
    """
        "The attempt to build the video failed because the required input
         image, Cosmic_Forge_Base.png, was not found in the Playground"

    Three times, while the user said the file was there. It was - in
    vault/Made/, because they had kept it - and vault.resolve() only ever
    matched the vault ROOT, so the one lookup that mattered could not
    succeed.

        "it should be able to copy from the vault if it is not in the
         playground"
    """
    import playground, tools
    old = _stage(tmp_path)
    try:
        playground.keep("Cosmic_Forge_Base.png")
        assert not playground.list_files(), "precondition: playground empty"
        got = tools._resolve_input("Cosmic_Forge_Base.png", "playground")
        assert got is not None and got.is_file()
        assert got.parent == playground.ROOT, (
            "it read the Vault original instead of copying a working copy in")
        assert [f["name"] for f in playground.list_files()] == [
            "Cosmic_Forge_Base.png"]
    finally:
        _unstage(old)


def test_a_sidecar_resolves_to_the_picture_it_describes(tmp_path):
    """She named the .json because that is what the listing showed."""
    import tools
    old = _stage(tmp_path)
    try:
        got = tools._resolve_input("Cosmic_Forge_Base.generation.json",
                                   "playground")
        assert got.name == "Cosmic_Forge_Base.png", got
    finally:
        _unstage(old)


def test_a_missing_file_says_what_is_actually_usable(tmp_path):
    """
    A bare "not found" against a listing full of .json sidecars is how the
    same wrong filename got tried three times in a row.
    """
    import tools
    old = _stage(tmp_path)
    try:
        try:
            tools._resolve_input("Nothing_Like_This.png", "playground")
            assert False, "a missing file resolved"
        except FileNotFoundError as e:
            msg = str(e)
        assert "Cosmic_Forge_Base.png" in msg, msg
        assert "NOTE ABOUT a file" in msg, msg
    finally:
        _unstage(old)


def test_a_keyword_argument_call_is_a_call(tmp_path):
    """
        Calling tool: generate_video(prompt="A short video based on the
        provided image.", input_image="cosmic forge.png")

    Written exactly like that, twice, as prose - because every recovery
    pattern needed a `{` and there is not one in it. The promise check
    fired, the model was asked to actually do it, and it wrote the same
    sentence again. Nothing ran either time.
    """
    import toolcall
    offered = {"generate_video", "generate_image", "list_playground"}
    name, args, _ = toolcall.recover(
        'Calling tool: generate_video(prompt="A short video based on the '
        'provided image.", input_image="cosmic forge.png")', offered)
    assert name == "generate_video", name
    assert args["input_image"] == "cosmic forge.png", args
    assert args["prompt"].startswith("A short video"), args


def test_prose_that_merely_mentions_a_tool_is_still_prose():
    """The guard. Recovering too eagerly turns an explanation into an act,
    which is a worse bug than the one being fixed."""
    import toolcall
    offered = {"generate_video", "open_file"}
    chat = ("I could use generate_video(prompt=\"x\") here, but first let "
            "me explain what that would do and why you might not want it, "
            "because the video model is slow and the result may not be what "
            "you expect at this size on this card.")
    assert toolcall.recover(chat, offered)[0] is None


# ───────────────────────────────────────────────────────────── ADR-115
#  A PICTURE CAN BE A QUESTION
# ─────────────────────────────────────────────────────────────────────


def test_a_generated_image_carries_its_own_search_terms(tmp_path):
    """
        "it doesn't have search query from an image ... it needs to have
         this"

    Everything could turn words into a picture and nothing could turn a
    picture back into words to look something up with. An image this
    machine generated has the prompt that made it stored beside it - exact
    words, no model involved, and they work with no vision at all.
    """
    import tools
    old = _stage(tmp_path)
    try:
        import playground
        q, how = tools._image_query(
            playground.ROOT / "Cosmic_Forge_Base.png")
        assert "cosmic forge" in q.lower(), q
        assert "prompt" in how, how
    finally:
        _unstage(old)


def test_a_picture_it_cannot_read_is_never_guessed_at(tmp_path):
    """
    No stored prompt and no vision means there is nothing to search with.
    Inventing terms from the filename would be the thing this whole project
    keeps refusing to do.
    """
    import tools, playground
    old = _stage(tmp_path)
    try:
        (playground.ROOT / "IMG_0247.png").write_bytes(
            b"\x89PNG\r\n\x1a\n" + b"y" * 200)
        q, how = tools._image_query(playground.ROOT / "IMG_0247.png")
        assert q == "" and how == "", (q, how)
        out = tools._search_from_image({"name": "IMG_0247.png"},
                                       {"tools": {"web_search": True}})
        assert "CANNOT SEARCH FROM" in out, out
        assert "Do not guess" in out, out
    finally:
        _unstage(old)


def test_searching_from_an_image_is_gated_like_every_search():
    import tools, policy
    assert tools.REGISTRY["search_from_image"]["network"] is True
    assert policy.TIERS["search_from_image"]["network"] is True
    assert tools.FOLLOWS["search_from_image"] == "web_search"


# ───────────────────────────────────────────────────────────── ADR-116
#  ONE NAMESPACE. NAME A FILE, GET THE FILE.
# ─────────────────────────────────────────────────────────────────────


def _spaces(tmp_path):
    import playground, vault, core
    old = (playground.ROOT, vault.VAULT, vault.AI_VAULT, vault.MADE_VAULT,
           vault.CHAT_VAULT, core.WRITABLE)
    playground.ROOT = tmp_path / "playground"
    vault.VAULT = tmp_path / "vault"
    vault.AI_VAULT = vault.VAULT / "AI"
    vault.MADE_VAULT = vault.VAULT / "Made"
    vault.CHAT_VAULT = vault.VAULT / "Chat"
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    playground.ensure()
    vault.ensure()
    png = b"\x89PNG\r\n\x1a\n" + b"x" * 300
    (vault.CHAT_VAULT / "chat-mti6v7ff").mkdir(parents=True, exist_ok=True)
    (vault.CHAT_VAULT / "chat-mti6v7ff" /
     "2026-09-03 2309 cosmic forge where divine energy manifests p (3).png"
     ).write_bytes(png)
    vault.MADE_VAULT.mkdir(parents=True, exist_ok=True)
    (vault.MADE_VAULT / "Cosmic_Forge_Base.png").write_bytes(png)
    (playground.ROOT / "draft.png").write_bytes(png)
    return old


def _unspace(old):
    import playground, vault, core
    (playground.ROOT, vault.VAULT, vault.AI_VAULT, vault.MADE_VAULT,
     vault.CHAT_VAULT, core.WRITABLE) = old


def test_a_name_is_enough_wherever_the_file_lives(tmp_path):
    """
        "What if we only divide the difference by files able to be edited by
         the model ... marked only by naming the file instead of leaving the
         playground and the vault in different spaces?"

    The split was never about safety - it was about where things sit, which
    is a fact about the disk and not about permission. A whole release went
    on "not found in the Playground workspace" about files that existed.
    """
    import files
    old = _spaces(tmp_path)
    try:
        for name in ("draft.png", "Cosmic_Forge_Base.png",
                     "Cosmic_Forge_Base.generation.json"):
            assert files.find(name) is not None, name
        assert files.find("nothing_like_this.png") is None
    finally:
        _unspace(old)


def test_a_copy_suffix_does_not_hide_a_file(tmp_path):
    """
    The user's uploaded copy landed as "... p (3).png" while the name Nova
    knew was "... p.png". Character-for-character they were never going to
    match, and did not.
    """
    import files
    old = _spaces(tmp_path)
    try:
        got = files.find("2026-09-03 2309 cosmic forge where divine energy "
                         "manifests p.png")
        assert got is not None and "(3)" in got.name, got
    finally:
        _unspace(old)


def test_permission_belongs_to_the_file_not_the_folder(tmp_path):
    import files
    old = _spaces(tmp_path)
    try:
        import playground
        assert files.writable(playground.ROOT / "draft.png")
        assert not files.writable(files.find("Cosmic_Forge_Base.png"))
        assert not files.writable(files.find(
            "2026-09-03 2309 cosmic forge where divine energy manifests "
            "p.png"))
    finally:
        _unspace(old)


def test_working_on_theirs_never_touches_theirs(tmp_path):
    """
        "you can take files to copy them from the vault and paste them into
         the playground for you to use, this is for you to be able to use
         both file spaces without changing the users files, that's me."
    """
    import files, playground
    old = _spaces(tmp_path)
    try:
        original = files.find("Cosmic_Forge_Base.png")
        before = original.read_bytes()
        got, note = files.bring("Cosmic_Forge_Base.png")
        assert files.writable(got), "the copy is not hers to change"
        assert got.parent == playground.ROOT
        assert original.is_file() and original.read_bytes() == before
        assert "untouched" in note, note
    finally:
        _unspace(old)


def test_the_listing_says_what_may_be_done_with_each(tmp_path):
    import tools
    old = _spaces(tmp_path)
    try:
        out = tools._list_playground()
        assert "YOURS" in out and "THE USER'S" in out, out
        assert "draft.png" in out
        assert "Cosmic_Forge_Base.png" in out, (
            "a file the user kept is invisible again")
    finally:
        _unspace(old)


def test_the_call_that_failed_all_release(tmp_path):
    import tools, files
    old = _spaces(tmp_path)
    try:
        got = tools._resolve_input(
            "2026-09-03 2309 cosmic forge where divine energy manifests "
            "p.png", "playground")
        assert got is not None and got.is_file()
        assert files.writable(got), "she got a path she cannot work from"
    finally:
        _unspace(old)


# ───────────────────────────────────────────────────────────── ADR-117
#  WORKING IS NOT CIRCLING
# ─────────────────────────────────────────────────────────────────────


def test_she_can_keep_working_as_long_as_work_is_happening():
    """
        "a tool that starts another loop ... to continue what it was doing
         to complete the task in as long as it needs rather than the short
         bursts it gives"

    The cap was two hand-overs per turn. "Come up with an image, build it in
    3D, then make a video of it" is four or five rounds of real work, so the
    limit that stopped the loop also stopped the task.
    """
    import json, policy
    cfg = {"tools": {"web_search": True}, "appearance": {}}
    g = policy.Gate()
    g.begin_turn("t")
    for i in range(6):
        g.authorize("list_playground", "{}", cfg)
        g.authorize("list_local_tools", "{}", cfg)
        d = g.authorize("pass_off", json.dumps({"reason": f"step {i}"}), cfg)
        assert d.verdict != "refuse", f"round {i + 1}: {d.reason}"


def test_but_two_empty_hand_overs_end_the_turn():
    """
    What separates working from circling is not the count - it is whether
    anything happened in between. Seen in a real session: three pass_offs
    inside one turn, each handing on to the next, nothing produced.
    """
    import json, policy
    cfg = {"tools": {"web_search": True}, "appearance": {}}
    g = policy.Gate()
    g.begin_turn("t")
    g.authorize("pass_off", json.dumps({"reason": "thinking"}), cfg)
    d = g.authorize("pass_off", json.dumps({"reason": "still thinking"}), cfg)
    assert d.verdict == "refuse" and d.reason == "pass-off-loop", d.reason
    assert "no tool ran in between" in (d.message or "")


def test_there_is_still_a_ceiling():
    import json, policy
    cfg = {"tools": {"web_search": True}, "appearance": {}}
    g = policy.Gate()
    g.begin_turn("t")
    refused = None
    for i in range(policy.LIMITS["passes_per_turn"] + 3):
        # Varied arguments, or the identical-call rule catches it first and
        # this measures the wrong thing.
        g.authorize("list_playground", "{}", cfg)
        g.authorize("open_file", json.dumps({"name": f"f{i}.txt"}), cfg)
        d = g.authorize("pass_off", json.dumps({"reason": f"round {i}"}), cfg)
        if d.verdict == "refuse":
            refused = d.reason
            break
    assert refused in ("pass-off-limit", "turn-call-limit"), refused


# ───────────────────────────────────────────────────────────── ADR-118
#  NOTHING STOPS A GENERATION FOR TAKING TOO LONG. NOTHING.
# ─────────────────────────────────────────────────────────────────────


def test_no_estimate_may_refuse_a_run_before_it_starts():
    """
        "we are trying to see if its possible in the first place, not to
         make the fastest run in the world on the smallest computer"

    room_for() used to RAISE and never start the video, on the sum of three
    file sizes plus a margin somebody guessed. That is a timeout wearing a
    different coat: a number picked in advance deciding something will not
    work, so it never gets the chance to. It warns now and gets out of the
    way.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    vid = src[src.index("    def video(self"):
              src.index("    def mesh_from_image(")]
    code = "\n".join(l for l in vid.splitlines()
                     if not l.lstrip().startswith("#"))
    assert "room_for" in code, "the estimate is gone entirely"
    assert "raise RuntimeError" not in code.split("room_for")[1][:400], (
        "video refuses to start on an estimate again")
    assert "starting anyway" in vid


def test_nothing_in_the_generation_path_kills_on_elapsed_time():
    """
    The standing rule, asserted as a rule rather than case by case. Three
    separate limiters have been removed for breaking it - the subprocess
    deadlines, the trellis /health deadline, and the size refusal - and each
    one looked reasonable when it went in.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    run = src[src.index("    def _run(self"):src.index("    def cancel(self")]
    code = "\n".join(l for l in run.splitlines()
                     if not l.lstrip().startswith("#"))
    assert "timeout=" not in code.replace("timeout=10", ""), code[:200]
    assert "subprocess.run(" not in code
    # And the generate call waits rather than giving up on the socket.
    gen = src[src.index("    def generate(self"):src.index("    def stop(self")]
    assert "timeout: int | None = None" in src[
        src.index("    def generate(self"):src.index("    def generate(self")
        + 300], "the mesh request has a deadline again"


def test_a_long_job_is_not_cut_short_by_a_call_ceiling():
    """
    20 calls was chosen when a turn meant one or two. A job that makes a
    listing, a look, a generation and a check per round walks into it, and
    stopping there stops the work for a reason unrelated to the work. The
    runaway being guarded against is repetition, and identical_calls catches
    that at two.
    """
    import policy
    assert policy.LIMITS["calls_per_turn"] >= 100, policy.LIMITS
    assert policy.LIMITS["identical_calls"] == 2


def test_the_memory_floor_is_the_users_to_switch_off():
    """
    The one thing that may still stop a run, and it is not a clock - it
    fires on measured free memory, because the alternative was measured
    too: "also this run crashed my laptop". It is still a judgement about
    someone else's machine, so they can overrule it.
    """
    import forge, core
    old = core.load
    try:
        core.load = lambda: {"generation": {"ram_floor_mb": 0}}
        assert forge._ram_floor() == 0.0
        g = forge._RamGuard(None, floor_mb=0.0).start()
        assert g._t is None, "the guard ran with the floor switched off"
        core.load = lambda: {"generation": {"ram_floor_mb": 1500}}
        assert forge._ram_floor() == 1500.0
    finally:
        core.load = old


def test_how_long_it_really_takes_is_read_back_out_of_the_log(tmp_path):
    """
        "we can find out when it is done when a log shows it"

    Every attempt has carried its duration since the ledger existed and
    nothing ever read it back - so "how long does a video take here" was
    only answerable by guessing, and guesses are what became timeouts.
    """
    import core, ledger
    old = (core.DATA, ledger.LEDGER)
    core.DATA = tmp_path
    ledger.LEDGER = tmp_path / "attempts.jsonl"
    try:
        for sec, ok in ((169.9, True), (210.4, True), (1980.0, True),
                        (9.2, False)):
            ledger.record("image", ok, seconds=sec, install="fp")
        d = ledger.how_long("image", "fp")
        assert d["worked"] == 3 and d["failed"] == 1
        assert d["fastest"] == 169.9 and d["slowest"] == 1980.0
        # A failure that died in 9 seconds says nothing about how long a
        # working run needs; averaging them is how a too-short expectation
        # gets built.
        assert d["typical"] == 210.4, d
        assert "min" in ledger.took("image", "fp")

        ledger.record("video", False, seconds=812.0, install="fp")
        said = ledger.took("video", "fp")
        assert "nothing has finished yet" in said, said
        assert "before it stopped" in said, said
        assert ledger.took("model3d", "fp") == ""
    finally:
        core.DATA, ledger.LEDGER = old


def test_the_screen_says_how_long_and_that_there_is_no_limit():
    import forge
    rows = {e["key"]: e for e in forge.inventory()}
    assert "took" in rows["image"], "duration never reaches the inventory"
    lens_src = Path("lens.py").read_text(encoding="utf-8")
    assert "no time limit" in lens_src, (
        "nothing tells Nova the run has no deadline")
    assert 'e.get("took")' in Path("server.py").read_text(encoding="utf-8")


# ───────────────────────────────────────────────────────────── ADR-119
#  THE TREE GROWS ITS OWN SHAPE
# ─────────────────────────────────────────────────────────────────────


def test_size_is_not_structure():
    """
        "branches become limbs if wide enough with information flows"

    The obvious reading is a count - promote at twenty leaves - and it is
    wrong in a way that shows immediately. Twenty near-identical notes about
    one bracket are one subject with a lot said about it. Six notes covering
    six different things might be a limb. Category utility can tell them
    apart; a threshold cannot.
    """
    import growth
    uniform = [(f"the bracket needs a {d} mm hole at position {i}",
                ["bracket"]) for i, d in enumerate([3, 4, 5, 6] * 3)]
    varied = [("the bracket needs a 5 mm hole", ["bracket"]),
              ("the bracket is 60 mm wide", ["bracket"]),
              ("whisper transcribes speech here", ["voice"]),
              ("the microphone picks up keyboard noise", ["voice"]),
              ("the GTX 1650 has 4 GB of VRAM", ["machine"]),
              ("image generation takes 170 seconds", ["machine"]),
              ("Trellis needs six gigabytes", ["machine"]),
              ("the laptop has 15.7 GB of RAM", ["machine"])]
    other = [[("notes about cooking dinner", ["food"]),
              ("the recipe calls for two onions", ["food"])]]
    big, _ = growth.should_promote(growth._split_by_feature(uniform), other)
    mixed, _ = growth.should_promote(growth._split_by_feature(varied), other)
    assert not big, "twelve near-identical notes became a limb"
    assert mixed, "eight notes about three subjects stayed one branch"


def test_a_distinction_that_stopped_mattering_dies():
    """
    Category death is the same arithmetic, not a rule of its own - and
    nothing is lost when it happens, because the leaves land together.
    """
    import growth
    a = [("the image model takes 170 seconds", ["gen"]),
         ("the image model runs at 768x768", ["gen"])]
    b = [("the image model uses dreamshaper", ["gen"]),
         ("the image model is stable diffusion", ["gen"])]
    people = [("Zero prefers direct answers", ["people"]),
              ("Zero builds local AI systems", ["people"])]
    other = [[("cooking dinner tonight", ["food"])]]
    yes, _ = growth.should_merge(a, b, other)
    assert yes, "two branches about the same thing stayed apart"
    no, _ = growth.should_merge(a, people, other)
    assert not no, "a person and a model were merged into one branch"


def test_restructuring_happens_on_surprise_not_on_a_timer():
    import growth
    known = [[("the bracket needs a 5 mm hole", ["bracket"]),
              ("the bracket is 60 mm wide", ["bracket"])]]
    assert not growth.surprised(known, "the bracket needs a 7 mm hole")
    assert growth.surprised(known, "my sister Jo visits on Thursday")


def test_the_limbs_that_are_always_there():
    """A person does not derive "there are other people" from experience;
    they start with somewhere to put people."""
    import growth
    for name in ("observations", "people", "environment", "studies"):
        assert growth.is_permanent(name), name
    assert not growth.is_permanent("brackets")


def test_a_permanent_limb_is_never_restructured_away():
    import growth

    class _B:
        def __init__(self, name, leaves):
            self.name = name
            self.leaves = leaves

    class _L:
        def __init__(self, content, tags):
            self.content = content
            self.tags = tags

    class _Limb:
        pass
    limb = _Limb()
    limb.branches = {
        "people": _B("people", [_L("Zero builds local AI", ["p"]),
                                _L("Zero prefers direct answers", ["p"])]),
        "observations": _B("observations", [_L("Zero builds local AI", ["p"]),
                                            _L("Zero is direct", ["p"])]),
    }
    for step in growth.plan(limb):
        assert not growth.is_permanent(step["branch"]), step
        assert not growth.is_permanent(step.get("with", "")), step


# ───────────────────────────────────────────────────────────── ADR-120
#  WHAT IS REAL, WHAT THEY THINK, AND WHAT THEY SAY SOMEONE ELSE THINKS
# ─────────────────────────────────────────────────────────────────────


def test_where_a_memory_came_from_is_bound_when_it_is_written():
    """
    Humans do not store a source tag - they reconstruct it at retrieval
    from how the memory feels, and every source error follows from that.
    A machine does not have to inherit the flaw.
    """
    import grove
    assert grove.Leaf("x", "hod", "g", kind="observed").is_about_the_world()
    for k in ("stated", "attributed", "inferred", "unknown"):
        leaf = grove.Leaf("x", "hod", "g", kind=k, holder="someone")
        assert not leaf.is_about_the_world(), k
    # A nonsense kind is not silently accepted as fact.
    assert grove.Leaf("x", "hod", "g", kind="fact").kind == "unknown"
    # And a belief with nobody holding it is indistinguishable from a claim
    # about the world, which is the confusion the field exists to prevent.
    assert grove.Leaf("x", "hod", "g", kind="attributed").kind == "stated"


def test_a_belief_cannot_answer_a_question_about_the_world(tmp_path):
    """
    "Zero says his brother thinks the card is fine" is not evidence about
    the card. Ask what is true and it must not be reachable; ask what
    someone thinks and it is right there.
    """
    import memory, core
    # core.TREE TOO, NOT JUST YESOD_DIR.
    #
    # graft() writes the leaf to yesod AND saves the limb to core.TREE.
    # Redirecting one of the two left "the GTX 1650 card has 4 GB of VRAM"
    # sitting in the shipped data/tree/hod.json - a test fixture that would
    # have installed on somebody's machine as a memory. Exactly the ADR-97
    # shape: two paths, one redirected.
    old = (memory.YESOD_DIR, core.TREE, core.WRITABLE)
    memory.YESOD_DIR = tmp_path / "y"
    memory.YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.TREE = tmp_path / "tree"
    core.TREE.mkdir(parents=True, exist_ok=True)
    memory._loaded = False
    core.WRITABLE = tuple(core.WRITABLE) + (tmp_path,)
    try:
        memory.graft("hod", "the GTX 1650 card has 4 GB of VRAM",
                     kind="observed", origin="user")
        memory.graft("hod", "the card is fine and needs no upgrade",
                     kind="attributed", holder="Zero's brother",
                     origin="user")
        world = memory.recall("how much VRAM does the card have", 5)
        assert world, "nothing came back at all"
        assert all(h["kind"] != "attributed" for h in world), world
        asked = memory.recall("what does Zero's brother think about the card",
                              5)
        assert any(h["kind"] == "attributed" for h in asked), asked
    finally:
        memory.YESOD_DIR, core.TREE, core.WRITABLE = old
        memory._loaded = False


def test_the_question_decides_whether_the_seal_opens():
    import memory
    for q in ("what does he think", "what did she say about it",
              "according to Zero", "his opinion on the card"):
        assert memory.asking_about_belief(q), q
    for q in ("how much VRAM does the card have", "what is the file called"):
        assert not memory.asking_about_belief(q), q


# ───────────────────────────────────────────────────────────── ADR-121
#  WHICH LOG ANSWERS "DID IT EVEN RUN"
# ─────────────────────────────────────────────────────────────────────


def test_the_duration_separates_never_ran_from_ran_and_failed(tmp_path):
    """
        "which log would tell us if the system was or was not working and if
         the limit of 20 turns or the video generation not doing anything is
         the actual problem"

    All of it was already written down and no two parts were in the same
    file. The deciding number is the duration: a run that never started
    reads as a second, one that failed at the end reads as minutes - two
    different faults printed under one sentence, "the generation failed".
    """
    import core, ledger, lens
    old = (core.DATA, ledger.LEDGER)
    core.DATA = tmp_path
    ledger.LEDGER = tmp_path / "attempts.jsonl"
    try:
        ledger.record("video", False, seconds=1.4,
                      note="no file named 'x.png' anywhere", install="fp")
        said = "\n".join(lens._last_run())
        assert "NEVER REALLY RAN" in said, said
        assert "no time limit" in said

        ledger.record("video", False, seconds=4120.0,
                      note="ran out of video memory at that size",
                      install="fp")
        said = "\n".join(lens._last_run())
        assert "RAN AND THEN FAILED" in said, said
        assert "69 min" in said, said
        # And it names the three files, because they are in three places.
        for f in ("forge.log", "policy.log", "attempts.jsonl"):
            assert f in said, f
    finally:
        core.DATA, ledger.LEDGER = old


def test_she_is_told_to_pass_on_the_reason():
    """The tool returned the reason. She printed "The generation failed"."""
    text = Path("character.md").read_text(encoding="utf-8")
    assert "TELLS YOU WHY" in text
    assert '"The generation failed" is not a report' in text


# ───────────────────────────────────────────────────────────── ADR-122
#  THE REASON WAS A PICTURE OF A LOADING BAR
# ─────────────────────────────────────────────────────────────────────


def test_a_progress_bar_is_never_recorded_as_the_reason():
    """
    Taking the last 220 characters of the output wrote this into the ledger
    as why four videos failed:

        |####################################| 108/108 - 626.91MB/s
        model_loader.cpp:1229 - loading tensors completed, taking 0.22s

    A progress bar and a success message. The actual event was further up.
    Four rows whose stated reason is a picture of a loading bar.
    """
    import forge
    finished = ("[INFO ] sampling completed, taking 921.97s\n"
                "[INFO ] generating latent video completed, taking 922.35s\n"
                "  |####################################| 108/108 - 626.9MB/s\n"
                "model_loader.cpp:1229 - loading tensors completed, 0.22s")
    said = forge._explain(finished)
    assert "108/108" not in said.split("printed was:")[0], said
    # A run that finished its work and then stopped is a DIFFERENT fault
    # from one that errored, and that difference is what was lost.
    assert "ran to the end" in said, said


def test_a_real_error_is_still_found():
    import forge
    oom = ("ggml_extend.hpp:70 - alloc_tensor_range: failed to allocate "
           "CUDA0 buffer of size 6387875840\n"
           "[ERROR] model_manager.cpp:280 - alloc compute params failed\n"
           "  |####################| 108/108 - 626.91MB/s")
    said = forge._explain(oom)
    assert "out of video memory" in said or "failed" in said, said
    assert "|" not in said, said


def test_a_long_quiet_stretch_is_called_normal():
    """
        "here says quiet and I haven't seen that with the video"

    TRELLIS prints once per flow step and a step takes about seventeen
    minutes on this machine, so the gap between lines is supposed to be
    long. "quiet 145s" on its own reads like a hang.
    """
    ui = Path("ui.html").read_text(encoding="utf-8")
    assert "normal - it prints once a step" in ui, (
        "a quiet stretch still reads as a fault")


# ───────────────────────────────────────────────────────────── ADR-123
#  THE CORRECTION MACHINERY WAS CAUSING THE LOOP
# ─────────────────────────────────────────────────────────────────────


def test_the_users_request_decides_the_tool_not_her_last_reply():
    """
    THE WHOLE SEQUENCE, AS IT HAPPENED:

        user: "now try a 3D model."
        user: "you choose for all features like this on this go around."
        Nova: "I will build a video using any PNG file I can access."
        SYSTEM: "STOP ... The tool is generate_video. Call it NOW."
        -> generate_video

        user: "That was a video generation attempt, not a 3D model."
        Nova: "...that was a video generation attempt..."
        SYSTEM: "The tool is generate_video."     <- the word she was NEGATING
        -> generate_video AGAIN

    Three times, while the user corrected her each time. The model was
    obeying. The correction machinery read the tool out of HER OWN REPLY,
    and her reply is always about whatever she was last doing - so every
    round reinforced the last round.
    """
    import toolcall, tools
    have = tools.enabled({"tools": {"web_search": True}})
    asks = []
    for asked, reply, want in (
            ("Try again..", "I will try the video again.", "generate_video"),
            # She asked a question rather than promising; there is nothing
            # to push back on, and "" is the right answer here.
            ("now try a 3D model.",
             "I am ready to try a 3D model. Please provide the spec.", ""),
            ("Choose one to test with.",
             "I will build a video using any PNG file.", "generate_3d"),
            ("you choose for all features like this on this go around.",
             "I will build a video using the image.", "generate_3d"),
            ("That was a video generation attempt, not a 3D model.",
             "The video failed. I will try the video again.", "generate_3d")):
        asks.insert(0, asked)
        got = toolcall.promised_action(reply, have, asked_for=asks[:6])
        assert got == want, f"{asked!r} -> {got}, wanted {want}"


def test_a_correction_is_read_the_way_a_person_reads_it():
    """
    "That was a video, not a 3D model" names both things, and the wanted one
    is the one after "not". Reading left to right gets it exactly backwards.

    But "I wanted a picture, not a video" is the opposite shape - the FIRST
    thing named is the wanted one - and a rule that treats both the same is
    wrong on one of them every time.
    """
    import toolcall, tools
    have = set(tools.enabled({"tools": {"web_search": True}}))
    for text, want in (
            ("That was a video generation attempt, not a 3D model.",
             "generate_3d"),
            ("I wanted a picture, not a video", "generate_image"),
            ("no more video, do the 3D one", "generate_3d"),
            ("build a 3D model of the image", "generate_3d"),
            ("make me a video of it", "generate_video"),
            ("that is not what I asked for", ""),
            ("Try again..", "")):
        assert toolcall._names_tool(text, have) == want, text


def test_a_failure_hands_over_the_failure_and_nothing_else():
    """
        "The generation failed ... the result is only 1 out of 7 views
         worked, which is roughly 22%. This is a leaning, not a conclusion."

    There were no views. "1 of 7" is how often the video BACKEND has ever
    worked and "a leaning, not a conclusion" is the ledger's wording about
    sample size - every number real, none of it about the run that just
    failed. The tool had appended a page of statistics next to the error and
    a 4B model narrated the statistics as the outcome.
    """
    import tools
    out = tools._failed("VIDEO", RuntimeError("could not allocate CUDA0"))
    assert "could not allocate CUDA0" in out
    for banned in ("worked here", "leaning", "%", "of 7", "attempts"):
        assert banned not in out, f"{banned!r} is back in a failure result"
    src = Path("tools.py").read_text(encoding="utf-8")
    for fn in ("_generate_image", "_generate_video", "_generate_3d"):
        body = src[src.index(f"def {fn}("):]
        body = body[:body.index("\ndef ", 10)]
        # Code, not the comment that explains why the code is gone.
        code = "\n".join(l for l in body.splitlines()
                         if not l.lstrip().startswith("#"))
        assert "report()" not in code, fn


def test_the_turn_opens_with_the_task_and_closes_the_last_one(tmp_path):
    """
        "it should have all the information reorganized to what the user
         says BEFORE it EVER hits the VLM/OMNI modal"

    The request used to arrive last, after the remembered background. And a
    finished action was never marked finished anywhere, so the last thing
    attempted stayed readable as a standing goal.
    """
    import server, core, ledger
    old = (core.DATA, ledger.LEDGER)
    core.DATA = tmp_path
    ledger.LEDGER = tmp_path / "attempts.jsonl"
    try:
        ledger.record("video", False, seconds=1064.0, note="stopped",
                      install="x")
        said = server._this_turn("Choose one to test with.",
                                 ["Choose one to test with.",
                                  "now try a 3D model.", "Try again.."])
        assert said.startswith("[this turn]")
        assert "WHAT IS BEING ASKED, NOW: Choose one to test with." in said
        assert "generate_3d" in said, said
        assert "That attempt is OVER" in said, said
        assert "not something you are still doing" in said
    finally:
        core.DATA, ledger.LEDGER = old


def test_the_turn_header_comes_before_the_remembered_block():
    src = Path("server.py").read_text(encoding="utf-8")
    body = src[src.index("    parts = []"):src.index("rep = budget.report(")]
    assert body.index("_this_turn(") < body.index("[what you remember"), (
        "the background is being read before the request again")


if __name__ == "__main__":
    sys.exit(testkit.run(dict(globals()),
                         "NOVA IS ALLOWED TO TRY AGAIN"))
