"""
test_model3d.py - geometry reading, rendering and conversion.

WHAT CHANGED AND WHY

This test used to `import trimesh` and `import PIL.Image` at the point of
use. Neither is installed. The Hub ships a private embedded Python with no
pip and no network step for wheels, so on any real install this file raised
ModuleNotFoundError and stopped - after passing the four assertions before
it, which meant the failure looked like a broken subsystem rather than a
test reaching for something the product does not have.

model3d.py is written to work without either: it parses STL/OBJ/PLY/3MF
itself and writes PNGs itself, using trimesh only as an optional upgrade for
GLB/GLTF. The test now matches that contract - the offline path is REQUIRED
and must pass; the trimesh path is OPTIONAL and is reported as such.
"""
from __future__ import annotations

import os
import struct
import sys
import tempfile
import zipfile
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import model3d

C = {"g": "\033[92m", "r": "\033[91m", "y": "\033[93m",
     "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0, "optional": 0}


def check(label: str, cond: bool, detail: str = "") -> None:
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


def optional(label: str, detail: str = "") -> None:
    _n["optional"] += 1
    print(f"  {C['y']}OPT{C['x']}   {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


# ---------------------------------------------------------------- fixtures

BOX_V = [(0, 0, 0), (1, 0, 0), (1, 2, 0), (0, 2, 0),
         (0, 0, 3), (1, 0, 3), (1, 2, 3), (0, 2, 3)]
BOX_F = [(0, 1, 2), (0, 2, 3), (4, 5, 6), (4, 6, 7), (0, 1, 5), (0, 5, 4),
         (2, 3, 7), (2, 7, 6), (1, 2, 6), (1, 6, 5), (0, 3, 7), (0, 7, 4)]


def write_ascii_stl(p: Path) -> None:
    p.write_text("solid box\n facet normal 0 0 1\n  outer loop\n"
                 "   vertex 0 0 0\n   vertex 1 0 0\n   vertex 0 1 0\n"
                 "  endloop\n endfacet\nendsolid box\n")


def write_binary_stl(p: Path) -> None:
    with open(p, "wb") as f:
        f.write(b"\0" * 80)
        f.write(struct.pack("<I", len(BOX_F)))
        for a, b, c in BOX_F:
            f.write(struct.pack("<fff", 0.0, 0.0, 0.0))
            for v in (BOX_V[a], BOX_V[b], BOX_V[c]):
                f.write(struct.pack("<fff", *v))
            f.write(b"\0\0")


def write_obj(p: Path) -> None:
    p.write_text("".join(f"v {x} {y} {z}\n" for x, y, z in BOX_V)
                 + "".join(f"f {a+1} {b+1} {c+1}\n" for a, b, c in BOX_F))


def write_ply(p: Path) -> None:
    head = ("ply\nformat ascii 1.0\n"
            f"element vertex {len(BOX_V)}\n"
            "property float x\nproperty float y\nproperty float z\n"
            f"element face {len(BOX_F)}\n"
            "property list uchar int vertex_indices\nend_header\n")
    p.write_text(head
                 + "".join(f"{x} {y} {z}\n" for x, y, z in BOX_V)
                 + "".join(f"3 {a} {b} {c}\n" for a, b, c in BOX_F))


def write_3mf(p: Path) -> None:
    verts = "".join(f'<vertex x="{x}" y="{y}" z="{z}"/>' for x, y, z in BOX_V)
    tris = "".join(f'<triangle v1="{a}" v2="{b}" v3="{c}"/>' for a, b, c in BOX_F)
    model = ('<?xml version="1.0" encoding="UTF-8"?>'
             '<model xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">'
             f'<resources><object id="1" type="model"><mesh>'
             f'<vertices>{verts}</vertices><triangles>{tris}</triangles>'
             '</mesh></object></resources></model>')
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("3D/3dmodel.model", model)


def png_size(p: Path):
    """Width and height straight out of the IHDR chunk. No image library."""
    data = p.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", data[16:24])


# ---------------------------------------------------------------- the tests

def main() -> int:
    print("\n1. GEOMETRY READS WITHOUT ANY THIRD-PARTY LIBRARY")
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        # model3d.convert() writes its result into the Playground, which is
        # its actual contract - so without this the suite left box.obj,
        # box.ply and box.stl in the shipping tree on every run, and a
        # release was packaged with them. The source files are in `root`;
        # the OUTPUT needs somewhere temporary too.
        model3d.PLAYGROUND = root / "playground"
        model3d.PLAYGROUND.mkdir(parents=True, exist_ok=True)
        one = root / "one.stl"; write_ascii_stl(one)
        check("ASCII STL", len(model3d.triangles(one)) == 1)

        for name, writer in (("box.stl", write_binary_stl), ("box.obj", write_obj),
                             ("box.ply", write_ply), ("box.3mf", write_3mf)):
            p = root / name; writer(p)
            tris = model3d.triangles(p)
            check(f"{name:9} -> {len(tris)} triangles", len(tris) == len(BOX_F),
                  "" if len(tris) == len(BOX_F) else f"expected {len(BOX_F)}")

        print("\n2. EVERY FORMAT AGREES ON THE SAME SOLID")
        import vision
        dims = {}
        for name in ("box.stl", "box.obj", "box.ply", "box.3mf"):
            d = vision.model3d_facts(root / name).get("dimensions") or {}
            dims[name] = (d.get("x"), d.get("y"), d.get("z"))
        check("all four report 1 x 2 x 3",
              all(v == (1.0, 2.0, 3.0) for v in dims.values()),
              "; ".join(f"{k}={v}" for k, v in dims.items()))

        print("\n3. RENDERING PRODUCES A REAL PNG, WITH NO IMAGE LIBRARY")
        out = model3d.render(one, root / "one.png", 160)
        check("render() writes a file", bool(out) and out.exists())
        check("it is a PNG with a plausible size",
              bool(out) and out.stat().st_size > 100
              and out.read_bytes()[:8] == b"\x89PNG\r\n\x1a\n")

        six = model3d.render_views(one, root / "six.png", 160)
        check("render_views() writes a file", bool(six) and six.exists())
        size = png_size(six) if six else None
        check("six cube faces compose 3x2 at 160px", size == (480, 320),
              f"IHDR reports {size}")

        custom = model3d.render_views(one, root / "custom.png", 160,
                                      yaw=35, pitch=20, distance=1.4)
        check("a custom viewpoint also renders", bool(custom) and custom.exists())

        print("\n4. CONVERSION USES THE NATIVE WRITERS FIRST")
        for target in ("obj", "stl", "ply"):
            r = model3d.convert(root / "box.stl", target)
            check(f"stl -> {target}", bool(r.get("ok")) and Path(r["path"]).exists(),
                  str(r.get("error", "")))

        print("\n5. OPTIONAL UPGRADES ARE OPTIONAL")
        try:
            import trimesh  # noqa: F401
            check("trimesh present - GLB/GLTF geometry available", True)
        except Exception:
            optional("trimesh not installed - GLB/GLTF read as file size only",
                     "STL/OBJ/PLY/3MF are unaffected; this is not required")

    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed, {_n['optional']} optional")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
