# The Hub — handoff

Written for a chat that has no context. Read this top to bottom before
changing anything. `DECISIONS.md` (ADR-01..141) has the evidence behind every
claim here.

    Emergence  →  Cairn  →  The Hearth  →  The Hub
                                ↑
                            HUB-ZERO (did not survive testing;
                            what it got right was kept, ADR-41..48)

Zero builds it, runs it, and sends back logs. Nova is the assistant inside
it. Target machine: Windows 11, GTX 1650 (4 GB VRAM), 15.7 GB RAM. Everything
runs locally and offline except one user-gated web-search switch.

---

## 1. Zero's standing rules

These are his words. They are not preferences — most of the bugs in this file
were caused by ignoring one of them.

> **"We: Learn, implement, simplify then repeat. You build things that
> work."**

> **"Take what works and leave the rest."** — the rule for this last pass.
> Versions 12 and 13 had the continuity; 15 had the memory, barely; 22–24
> have the generation, the progress board and the ledger. The job was to put
> the working pieces together, not to pick a favourite release.

> **"Don't become the reason it stops, let go and see if it runs."**
> Nothing may fail for taking time. A generation may fail because it never
> started, or because it ran and errored. Never because a number ran out.
> Said at least four separate times, each time after one of my limiters had
> killed the thing it was protecting.

> **"Stop severing limbs and correct this, stitch it back on and allow it to
> do the things it is built for."**
> When something misbehaves, fix the cause. Do not remove the capability.
> This is what ADR-128 is: one filter, switched from a gate to a sort.

> **"It's bad to assume that something will or will not work just because you
> tried it a couple of times in the past. When you train 10,000 times you
> know. When you saw 10 - 5 times, you don't know."**
> This is why `ledger.py` exists, why nothing refuses on a small sample, and
> why `growth.reshape` is off until its log has been read.

> **"This should never be timed for 'how long it should take', only for how
> long it has taken in the past."**
> Estimates come from `ledger.how_long()`. Nothing extrapolates.

> **"If you are not sure, that is what the internet is for."**
> Check upstream docs and source before designing against an interface.
> Two whole sessions were lost to guessing at trellis.cpp's CLI.

> **"Tacos are not a rock, books are not a kiln, and Goku and Freiza fighting
> is not a block with some holes in it."**
> Only surface a memory if the relation is really there.

Also standing: **wait for his agreement before downloading any model**, and
the app must **hold the user's files across every update** — that is the
whole point of it.

---

## 2. Where the build stands

**Verified from Zero's own logs and from the test suites, not from
confidence.**

| | status | measured |
|---|---|---|
| images | works, always has | 21 runs, 2–13 min, usually ~2 min |
| video | **works** — first successes | 3 runs: 43.3 / 43.5 / 46.6 min |
| 3D (TRELLIS) | starts reliably; a mesh has not finished yet | ~3.4 h expected on this hardware |
| 3D (`meshgen.py`) | works, instant, no VRAM | exact solids from a spec only |
| memory | **rebuilt** — see §3 | 30 suites, all green |
| the machine | **the model fits the card, and the first load is careful until it knows** — see §2.1 | ADR-142..151 |
| the store | **as much room as the machine has, measured, never written down** — §2.2 | ADR-152 |
| the prompt | **three things are the user's; the wiring is not editable** — §2.3 | ADR-153..154 |

**THE MACHINE WENT DOWN TWICE, STARTING A GENERATION.** Both things that
could have caught it were off: `room_for()` logged "starting anyway" and the
RAM floor was disarmed. Each had been disarmed for a good reason and together
they left nothing. There is now ONE check, asked once, before `Popen`, in
`_run()` where every backend passes: **the files this command line names are
bigger than the memory that is free right now, so it cannot start.** stat()
against GlobalMemoryStatusEx, no margin, no prediction. Never starting is the
permitted failure; stopping something that is running is not, and nothing
here can reach a process that exists. The background memory loop also stands
down while a generator runs — "idle" used to mean the USER was idle, and
during a 45-minute generation the user is idle by definition. ADR-138.

**Video was never broken.** Four runs were killed by my RAM floor at 17.7–18.5
minutes against successes at 43–47 — roughly 25 minutes short, every time.
`forge.RAM_FLOOR_MB` now defaults to `0.0`. **Do not arm it again.** It stays
in the code as a user knob and nothing more (ADR-122).

**3D is slow because of physics, not a fault.** Upstream (pwilkin/trellis.cpp)
reports 3:16–12:39 end-to-end on a 16 GB RTX 5060 Ti and describes the CPU
fallback as "very slow, RAM-hungry". Zero's run reached flow step 10 of 12 at
10,211 s with ~2,042 s left — about 3.4 hours, 30–60× the GPU figure, which
is the expected behaviour of a 4 GB card on the CPU path. A 3-hour deadline
was always going to lose. There is no deadline now (ADR-125).

**The trellis-server interface, confirmed against upstream:** exactly two
endpoints, `GET /health` → `"ok"` and `POST /generate` (multipart `image`
part; optional text fields `seed`, `resolution` 512/1024/1536, `bg_removal`
threshold|birefnet; returns `model/gltf-binary`). Generation is
**synchronous** and **there is no progress or job endpoint** — scraping the
server's stdout is not a workaround, it is the only signal that exists.
`--require-gpu` would disable the CPU fallback, so it is deliberately never
passed.

**The relief plaque is gone.** Three builds of it reached Zero ("I can do that
at home with a bar of soap"). `generate_3d` now raises with the real reason
rather than substituting an object nobody asked for. `spec` still builds
exact shapes from dimensions and is unaffected.

---

## 2.1 The machine-fit limiter (ADR-142..149) — READ THIS FIRST

Three hard resets in one evening. `BugcheckCode 0`, `WHEABootErrorCount 0`,
not sleep, not the power button: **no software fault. The rail went away.**
The laptop has no battery, so there is nothing to absorb a draw the adapter
cannot follow, and a battery is not coming (no available one matches).

Zero's instruction was that the limiter already existed and had to be
**repaired, not replaced**. He was right, and more so than expected.

**`runtime.plan()` is byte-identical in The Hearth Step 5 and in every Hub
build v2 → v24.** Nothing was ever removed. It was never *connected*:

- `plan()` computed `gpu_mb` — what it expected the card to hold — used it as
  a subtraction in the **host RAM** sum, and dropped it. It never reached the
  process.
- `_argv` omitted `-ngl` on `auto`, believing llama.cpp would size the offload
  to free VRAM. **It does not.** At the pinned build `b10456`,
  `llama_model::n_gpu_layers()` returns `n_layer_all + 1` when the flag is
  absent. No VRAM is consulted. Omitting the flag *is* `-ngl 99`.
- `plan()`'s justification for having no VRAM check — "llama.cpp fails with a
  real error when it cannot" — **expired with NVIDIA driver 536.40**. System
  Memory Fallback is on by default: an over-subscribed card does not raise,
  the driver pages it over PCIe into system RAM and pins the GPU at full board
  power for as long as the model is loaded.

So 3.6 GB of Gemma, plus its cache, plus its buffers, plus a 600 MB projector,
went onto a card with 3,938 MB free. Every single load, for thirteen releases.

**What it does now,** in the order Zero specified — *"the model should always
load in with this as the primary focus to stay under then that of its memory
use (context window) within that"*:

1. `best_ngl(ctx)` picks the largest offload that fits the card once weights,
   cache and buffers are counted, and **sends it**.
2. The existing binary search fits the window against *both* ceilings. Because
   a layer moved off the card takes its share of the cache with it, the card
   is answered with fewer layers, not a narrower window; the window only gives
   when the host cannot hold what came off.
3. `vision.projector_args` gets the real claim, so the projector takes what is
   genuinely left or loads on the CPU. It never pushes the model off.

On Zero's profile: **`-ngl 27` of 36, 3,480 MB claimed of 3,538 usable, and
the full 32,768-token window kept.**

**Nothing is refused.** `fits()` still returns True, `start()` still has no
bail-out, and `test_fit.py` asserts that structurally.

**Also in this pass, all of it downstream of the same evening:**

- **The cache is sized the way llama.cpp sizes it.** Gemma windows five layers
  in six and shares fifteen caches; we were charging full attention on all
  thirty-five. At 32k that is 243 MB, not 2,240 MB — a 9× overestimate that
  had been quietly costing context (ADR-143).
- **Per-layer weights come from the GGUF tensor table**, not from dividing the
  file size, because the token embedding is not a layer and prorating it
  undercounts every layer in the dangerous direction (ADR-144).
- **The compute buffers are read out of llama-server's own load report** and
  filed in `data/logs/fit.json`, so the second load budgets from measurement
  (ADR-144).
- **`vram_free_mb()` no longer caches forever.** It was read once, before the
  model loaded, and reused for the process lifetime — `3938` in 122 of 122 of
  Zero's benchmarks over nine days (ADR-145).
- **The bring-up is ramped** (`SETTLE_S = 2.5`) and `n_ubatch` is a setting,
  default 512, offered at 256 — the peak-power knob (ADR-146).
- **Kernel-Power 41 is read and reported** on the settings panel, so a reset
  the machine had is no longer invisible to the application it happened to
  (ADR-147). *Caution: `wevtutil /f:text` prints local time, `/f:xml` prints
  UTC. The fractional seconds are how to tell.*
- **`events.jsonl` is fsynced.** Zero's is NUL-padded — the signature of a
  lost write. The log the memory is rebuilt from was dropping exactly the
  events before each reset (ADR-148).
- **`/api/state` stopped re-reading every conversation on every 2-second
  poll** (ADR-149).

**Build 28 — what 27 left.** 27 was a GO and ran an image generation, but the
FIRST load still reset the machine. That is the unmeasured load: every number
in the card budget except the reserve is an estimate until a load has produced
a report, and 27 packed the card to within 60 MB of the ceiling on that
estimate. The second load, budgeted from the measurement the first one left
behind, was fine.

So an **unmeasured** model now gets only a share of the card
(`FIRST_LOAD_SHARE` 0.70, or 0.55 if the machine's last boot followed a power
loss), and a real measurement removes the share entirely — the penalty is for
not knowing, never for having failed. On top of that, `_correct_offload()`
checks the plan against llama-server's own allocation report and reloads with
fewer layers **before** the warm-up, probe and benchmark, which is the window
that actually costs the machine. On the target profile:

| | layers | claimed | context |
|---|---:|---:|---:|
| first load, no history | 18 of 36 | 2,366 MB | 32,768 |
| first load, reset last boot | 13 of 36 | 1,860 MB | 32,768 |
| once measured | 28 of 36 | 3,518 MB | 32,768 |

The window never pays. (ADR-150, ADR-151)

---

## 2.2 The memory store (ADR-152)

`store.py`. Three numbers, one choice, and the rule Zero set:

> *"these should not be limited by anything other than an automatically
> understood 'computers limit' ... this way we can scale when we install on a
> new device"*

- **CEILING** — free disk plus what we already hold, less the OS share.
  **Measured every time, never written to config.** Copy the folder to a
  bigger drive and the bar gets longer on its own.
- **CHOSEN** — `storage.limit_gb`; `0` means the ceiling and is the default.
  A number is honoured and clamped, and the interface says when it clamped.
- **USED** — `data/` walked, held 20 s. Folders nobody named still count.

**Nothing here deletes anything**, asserted at the source level. A full store
says so and a large generation will not *start*; `purge.py` remains the only
thing that removes anything, and it asks first.

`install.py` stopped freezing `n_ctx` at 4096/8192 from a setup-time VRAM
reading — which also **overwrote a number the user had chosen** on every
re-install. It writes `"auto"`, and `report_limits()` prints what the running
code would decide rather than forming its own opinion.

---

## 2.3 The system prompt, split (ADR-153, ADR-154)

`persona.py`. The `###` seam Zero asked for:

```
### YOURS: NAME ###
Nova
### END ###
```

What is between the markers in `character.md` is a **default**; the user's own
text lives in `data/persona.json`, never shipped, never replaced — so an
update rewrites the wiring and leaves the person alone. The markers never
reach the model.

Settings shows **NAME**, **CHARACTER**, **CHARACTERISTICS** and nothing else.
The wiring — tools, how to use the app, the app's name, its creator — is not
reachable from the interface at all: `persona.save()` knows three keys and
drops everything else, which is why the endpoint can take a body straight from
the browser. `core.character()` returns the merged sheet, so nothing
downstream knows the split exists.

**Watch the preamble.** `budget._sections` makes everything before the first
capitals-only line uncuttable, and that is where TWO RULES ABOVE ALL lives.
Adding a heading above them moved them into a droppable section and at n_ctx
4096 they went — caught by `test_present.py` and `test_assets.py` the same
afternoon. `test_persona.py` now asserts the ordering directly.

---

## 3. The memory, rebuilt (ADR-126..141)

This is the whole of the last pass. Read it before touching anything in
`memory.py`, `focus.py`, `carryover.py` or `timeline.py`.

### 3.1 What was actually wrong

Four separate faults, none of them "memory does not work":

1. **It was never handed over.** Every conversation was on disk and nothing
   read one back into a prompt. `build_messages()` took the browser's array,
   which starts empty on every page load. (ADR-126)
2. **One filter woke up.** `focus.perception()` ended its cue filter with
   `else: hits = []`. It was unreachable dead code until `named_subjects()`
   made cues fire on any capitalised word — after which memory returned a
   couple of literal substring matches or nothing, unpredictably. That is
   "tiny fragments scattered about pretty randomly". (ADR-128)
3. **Provenance was thrown away at the last step.** `recall()` returns when,
   how, how firmly, and whether confirmed. The renderer printed the line and
   dropped the rest, so a machine guess read like something the user said
   this morning. That is "saying too much without any information about it".
   (ADR-129, ADR-130)
4. **Time never reached the model at all.** Ranking has no opinion about
   which of two matching memories came second, so "the latest" was answered
   by luck. (ADR-131)

### 3.2 What is there now

The prompt walks forward through time, and every block says what it is:

    SYSTEM (stable within a session, so the prefix cache stays warm)
      character.md            who she is
      WORKSPACE + KEY/LEGEND  what she can reach
      vault catalogue         the user's files
      [earlier conversations] carryover.py — last ≤10 rounds × last 2 sessions
      [what is current]       timeline.py — newest thing known per subject

    HISTORY                   this conversation, newest turns that fit

    THE USER'S TURN (volatile, next to the question where a 2B model looks)
      [this turn]             the task, and the last attempt closed
      [where what you know is] pointer to [what is current]
      [where the past is]     pointer to [earlier conversations]
      [what you remember]     focus.perception — retrieval for THIS question
      evidence                web result, or the inward lookup
      [the message, in the user's own words]  ← the line, then the message

`carryover.py` — the last ≤10 rounds of each of the last two sessions.
Rounds, not messages, so a question and its answer travel together. Trimmed
from the OLDEST end; `budget.fit_text` drops from the wrong one for a
transcript. Assembled once and reused until the session files change.

`timeline.py` — groups what is known by subject, orders each subject by time,
names the newest **now** and an already-superseded earlier one **was**. Also
`versions()` / `latest()`, which answer the literal "most recent version of
something" for files, by family name and modified time. It never writes to
the tree.

`memory.remembered_line()` — the one renderer. Every recalled line carries
its date, how it was learned, and how well it is known, in words:

    - (2026-09-06, 3 days ago, they told you, known well) the card has 4 GB
    - (2026-08-14, 3 weeks ago, you worked this out, said once, NOT
      confirmed) the turbo preset renders at 768

`research.py` "inward" — a question about this machine's own past is searched
INWARD and the findings arrive in the same evidence slot, in the same shape,
as a web result. "Look in your memory" used to score on the words "look
into" and take the web branch.

**A conversation ends by itself.** After `chat.rounds_per_conversation`
rounds (20 by default, Settings, 0 to never) the server saves the transcript,
takes a new session id and tells the page — *after* the reply, so the answer
is read and then the line is drawn. This is what an F5 used to do by accident
in 13–15, and it is what keeps the context percentage falling back down
instead of climbing forever. A button had to be remembered; this does not.

**And one button, and it is Failure.** Press it when a conversation has gone
too far wrong to be worth fixing in place. It ends it the same way — the
transcript is KEPT, never deleted — and marks the session `failure`, which
reaches the model as a header on that conversation in the carry-over block,
next to its last rounds. Two presses: it arms, then commits, because a stray
click would teach her the wrong thing about what going wrong looks like.

**The grey zone.** Two states and no third: `MARKED A FAILURE`, or `not
marked either way`. Unmarked is not a pass, and it says so in those words —
almost every conversation is unmarked, so a model that read silence as
approval would make the mark worth nothing. The failure COUNT is in
`/api/state` for you and is never shown to her: a running score is a
judgement about her rather than about one piece of work. ADR-139, ADR-140.

**History has its share back**: 0.44 of what is left after the character
sheet, the number from the releases that worked. Every new block was paid for
out of the other blocks (ADR-132).

### 3.3 Where to look when memory misbehaves

| symptom | look at |
|---|---|
| "I have no memory of that" | is `[earlier conversations]` in the prompt? `/api/state` → `carrying` |
| recalls nothing on some turns | ADR-128. `test_remembering.py` first |
| states a guess as fact | is the line carrying its provenance? `memory.remembered_line` |
| wrong "latest" | `timeline.about(question)`, then `data/tree/*.json` dates |
| a correction never sticks | `data/logs/learning.log` — ADR-133 was exactly this |
| a conversation that will not end | `chat.rounds_per_conversation` in Settings; `/api/state` → `rounds` |
| which ones went wrong | `data/logs/failure.log`, and `/api/state` → `marks` |
| the tree's shape looks wrong | `data/logs/memory.log`, lines starting "growth would" |

---

## 4. Open work, in the order Zero named it

### 4.1 Voice — next, and the largest

Read `ui.html` around the `watch()` loop (~line 855) and `hush()` (line 811)
before starting. The findings below are from the current code, not memory.

**Barge-in stops the speaker and nothing else.** `hush()` clears the speech
queue and calls `speechSynthesis.cancel()`. That is all it does. The halt
button at the bottom of the file does the real thing:

    halt.onclick=()=>{ hush(); fetch("/api/stop",{method:"POST"}); if(ctl) ctl.abort(); };

Barge-in calls only `hush()`, so the model keeps generating while the room
goes quiet. **Zero's ask is that speaking cuts the model off at all times** —
so barge-in needs the halt button's three steps, not one of them.

There is also a live comment in the quiet branch reading *"there is nothing
to interrupt, so never cancel queued speech here"*. That assumption is the
bug in one sentence: it is true of the speaker and false of the generation.

**Echo suppression is half built and throws the good half away.** `watch()`
already learns the speaker's leakage into the mic: `speechLeakRms` is an
EWMA that settles fast for the first 850 ms of an utterance (`.96/.04`) and
slowly after (`.985/.015`), feeding
`selfFloor = max(th*1.25, speechLeakRms*1.85)`. That measurement is thrown
away at the end of every utterance. Zero wants it kept as a **secondary sound
memory** — what the machine heard of itself, stored apart from what it heard
of the user.

**Still to do beyond that:**

- Remove every timeout in the listening path (a person pausing mid-sentence
  is not a failure).
- Non-speech sound — typing, keyboard, a door — reported **as a sound**, not
  transcribed as speech. "(typing)" is information.
- Zero: *"look in luminova for this, it is what starts the whole thing as
  Luminova started with."* See `[[vera]]` for the Luminova lineage.

Hearing itself is already fully local: 16 kHz mono PCM captured with Web
Audio, speech/silence detected by energy in the page, WAV posted to The Hub,
handed to whisper.cpp on loopback. Audio never leaves the machine. Do not
replace this with the browser's `SpeechRecognition` — that streams to a
vendor server and would make hearing internet-dependent.

### 4.2 Sight

`vision.py` publishes an image to llama-server over loopback, probes whether
a projector actually loaded, and — when nothing can see — *measures* the
image and says so rather than describing it. That honesty rail must survive
whatever is added; `test_sight.py` guards it.

What Zero wants added:

- **Screen capture, cycled and budgeted** rather than continuous — attention
  that rotates, not a firehose.
- **Time and date** available as a sense, not just a tool call.
- **"I" statements double-checked with the user before they are stored.**
  Nova hearing "I'm a nurse" is a claim to confirm, not a fact to file.
  (The `kind`/`holder` machinery from ADR-130 is what this hangs off now:
  an unconfirmed claim about the user is `attributed` until they say yes.)
- **Windows facial recognition binding an identity to a face**, so a person
  is the same person across sessions. The `people` branch is permanent and
  waiting.
- Emotion, gesture and distance come later; do not start there.

### 4.3 Turn the reshaping on, once its log says something sensible

`growth.tend()` runs every idle pass and writes what it would do to
`data/logs/memory.log`. When those lines look right on Zero's real tree, set
`memory.reshape` true in `config.json`. Only merges are applied; promotion is
deliberately not (ADR-134).

### 4.4 The next test will settle one open question

`tools.log` now stamps every line and records the ask beside the promise:

    2026-09-06 14:22:01 promised an action without calling a tool
    (generate_3d); pushed back once | asked: 'now try a 3D model.'

If the tool named there matches what Zero asked for, the perseveration fix
(ADR-123, plus ADR-136) held.

---

## 5. What not to do

Each of these cost a session. They are shapes, not incidents — look for the
shape.

**Never add a wall-clock deadline anywhere a generator can reach.** Four of
mine each killed exactly what they protected: subprocess deadlines, a size
refusal, a RAM floor, and a silent `range(7)` on the tool loop.
`test_nowalls.py` asserts this as a property over eight modules rather than
as a list of numbers, and it now covers the memory path too — reading a
transcript off a disk has no business having a deadline. One shape is allowed
and must declare itself: a `# PROBE:` under 90 s, for asking a binary to
print its own `--help`.

**Never let two definitions of the same fact exist.** `install._find_binary`
said TRELLIS was ready while `forge.trellis_exe` said it was not, so every 3D
request quietly became a plaque for weeks while the log said "ready". The fix
is always one definition both sides call. `memory.remembered_line` and
`carryover.archive_dir` are that rule applied to this pass.

**A filter that cannot fire is not safe, it is asleep.** `hits = []` sat
unreachable for four releases and then something upstream woke it. If a
branch cannot run today, either delete it or write the test that would catch
it running. (ADR-128)

**A field nothing writes is a comment.** `kind`/`holder` were in the schema,
in `graft()`'s signature and in a seal inside `recall()`, and no caller ever
passed one — so the seal could not fire on any leaf that has ever existed.
(ADR-130)

**When you redirect a path in a test, redirect all of them.** Three times
now: `core.DATA` without `vault.VAULT` (29 stray scripts shipped),
`memory.YESOD_DIR` without `core.TREE` (a fixture leaf in the shipped tree),
`core.DATA` without `memory.ACTIVE_DIR` (a fixture question in the shipped
active memory — caught only because a real prompt was printed and had six
copies of it in). `verify.py` snapshots vault, playground, tree, knowledge,
ash, sessions **and active** around the whole run.

**Never put a bare `except` around code that references a name.** "No vision
module" and "tools unavailable this reply" were both a `NameError` swallowed
whole. `learning.teach()` reading a `.scores` that never existed was the same
shape and cost every correction Zero ever made. `verify.check_name_resolution()`
finds these statically — **run `verify.py` before shipping, not after** — and
when a wrapper swallows an exception, read the log it writes.

**A check must ask what it is looking at.** `check_clean_tree` failed the
install of a healthy machine by calling the user's own history "state that is
not the user's"; later it called an *empty* tree "somebody's content". The
worst kind of check is one that is loudest when everything is right.

**Never store a summary where the evidence should be.** `_explain()` recorded
a picture of a loading bar as four separate failure reasons. `forge.log` kept
the last 400 characters. Summarise for the model, which has a small context.
Keep everything for us. `carryover` follows this: it is a window onto the
transcripts, never a digest of them.

**Guidance to a small model must say what to DO, not what to weigh.** Video
never even attempted for weeks because `KEY_LEGEND` said "confirm the user
wants it before starting" — a 2B model given that offers, and then waits.

**Never re-arm the RAM floor, and never turn the start check into one.**
They are different questions asked at different moments. "Is free memory low
right now" is the state a healthy 45-minute run lives in, and acting on it
killed four of them. "Are the weights bigger than free memory" is asked once,
before anything exists, and is arithmetic on two measurements. The moment the
second one grows a margin, a peak estimate or a clock, it has become the
first one. (ADR-138)

**An `if` with an `else` is one statement.** Inserting a new block between
them changes what the `else` belongs to. One line of new UI took the `else`
from `if(ans)` and every ordinary turn had its finished reply painted over
with "(no answer came back)". Nothing threw; only the rendered page knew.
New work goes after the whole chain. (ADR-141)

**Never let The Hub's own notes read as the user's words.** Everything added
to a turn is joined on with a blank line. Without a marked boundary, Nova
transcribes the scaffolding as something the user typed (ADR-135).

---

## 6. How a failure is diagnosed now

Four places, and they no longer disagree.

| where | holds |
|---|---|
| the model's turn | one sentence from `_explain()` — what to tell the user |
| `data/attempts.jsonl` | one line per attempt: what, ok, seconds, install fingerprint |
| `data/logs/*.log` | every line stamped; policy, forge, tools, memory, research, learning |
| `data/logs/failures/` | **the complete output of every generation that failed**, with the command, the exit code and the duration at the top |

`forge.report()` — which the model reads every turn — carries the measured
durations (*"3 finished: 43 min to 47 min, usually about 43 min"*) and, for
3D, whether the runtime started at all. `model3d_start` and `model3d` are
separate ledger rows precisely so an install fault and a generation fault
stop looking identical.

A precondition failure — "the video runtime is not installed" — writes no
failure file on purpose. Nothing ran, so there is nothing to keep, and an
empty file would be worse than none. `test_logging.py` states that rule.

---

## 7. Mechanics

### Running

    INSTALL.bat   private Python 3.13, llama.cpp, model, projector, whisper
    HUB.bat       http://127.0.0.1:8440
    STOP.bat      stops only The Hub's own ports
    TEST.bat      every suite

No system Python required; all launchers resolve `.runtime\python\python.exe`
first.

### Ports — check first on any fork

    Cairn        8420 / 8080 / 8081 / 8082
    The Hearth   8430 / 8090 / 8091 / 8092
    The Hub      8440 / 8100 / 8101 / 8102 / 8103

Declared in `core.py` with `ANCESTOR_PORTS` naming the ones that belong to
somebody else.

### Verification

`verify.py` discovers suites from disk rather than a list. **27 suites** (26
test files plus the placement benchmark). It also prints an "ok" count —
read it as a signal, not a target. **Two errors are expected in a checkout
with no install** (`llama-server.exe missing`, `no .gguf model present`);
`INSTALL.bat` clears both.

The ones worth knowing by name:

| suite | proves |
|---|---|
| `test_remembering.py` | recall reaches the model, and says where it came from |
| `test_timeline.py` | one subject, in time order, and which end is now |
| `test_carryover.py` | the previous conversations are present, and are used |
| `test_growth.py` | the tree's shape is tended and nothing is lost tending it |
| `test_nowalls.py` | nothing stops for being slow, and the one thing allowed to say no says it before anything is running |
| `test_logging.py` | every log line is ordered; a failed run keeps its whole output |
| `test_present.py` | Nova is allowed to try again, and memory holds (179 cases) |
| `test_live.py` | the real server, real SSE, stub model — the *wiring* |
| `test_browser.py` | the rendered page in Chromium, typed and sent |
| `test_forge.py` | exclusivity, ordering, honest failure |
| `test_toolsurface.py` | registry, offer and gate agree on every tool |
| `test_meshgen.py` | every built shape is a closed solid, not a surface |

### Files that carry the design

    forge.py       generation. One lock, Nova stopped once per pipeline
    ledger.py      every attempt as an event; Laplace, never a refusal
    hold.py        storage vs retrieval strength — read before touching memory
    grove.py       the tree; leaves carry stability, affect, kind, holder
    growth.py      branch→limb promotion. Wired in; reports always, reshapes
                   only when memory.reshape is true
    carryover.py   the last rounds of the last two sessions, always present
    timeline.py    what is current, by subject, in time order
    focus.py       what this turn is about; the per-question memory slice
    policy.py      the capability gate; default-deny, and the only ceiling
    files.py       one namespace; permission is a property of the file
    lens.py        what the machine actually is, user-gated
    character.md   what Nova is told about herself, cut by section not by tail

### Optional, and genuinely optional

whisper.cpp (mic), ffmpeg (video frames), trimesh (GLB/GLTF), FreeCAD
(STEP/STP), ComfyUI/A1111 (preferred generators when present), Playwright
(`test_browser.py` only). Nothing here is needed to install, start, think,
remember or see.

---

## 8. Still unmeasured

- `bench_llama.py` against the live runtime
- b10456 KV-cache / flash-attention behaviour (`kv_type` stays `f16` until
  measured)
- grammar-constraint overhead on this hardware
- BM25 vs hybrid retrieval on real memories
- **growth's thresholds** — TAU 0.5, MIN_TO_CONSIDER 7, MERGE_MARGIN 1.02
  have never been run against a real tree. `memory.reshape` stays false until
  the log says they are sensible.
- **The model choice itself.** Qwen3.5-2B abliterated is the default on
  architecture and size, but its answers have not been graded. Qwen3.5-4B and
  the abliterated Gemma 4 E2B install beside it for that comparison.
  **No more Qwen3-VL:** it re-read its own context in a loop (ADR-83).

Measured and no longer open: `n_ctx` is 32768 with the 2B and 15360 with a 4B
(below ~6k the character sheet gets cut); memory holds 4,001 memories in
3.7 MB with 0.010 s search and the oldest faded leaf still findable from ash;
one 1024px image cost 716 s with every offload flag on, so the turbo preset
renders at 768.
