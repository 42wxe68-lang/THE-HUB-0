"""
memory.py - the Tree of Life. Cairn's topology, Luminova's biology.

THE INTEGRATION, PLAINLY
------------------------
Cairn had ten sephirot, and each one held a flat list of strings. Good
shape, dead contents: a fact written on day one and a fact written this
morning were indistinguishable, and the only way anything ever left was by
falling off the end of a cap.

Luminova had a living tree - leaves with weight, decay, reinforcement,
branches that bud and close - but only three limbs, and no notion of what
kind of memory a thing was.

Neither is thrown away. The sephirot are the coordinate system; each one is
a Limb from grove.py. So a sephira is no longer a list. It is a small living
tree of its own, with branches that grow as the subject matter grows.

    KETER   ── identity ─── one branch, everything pinned, nothing decays
    HOD     ── fact ─────── branches bud per subject as facts accumulate
    TIFERET ── focus ────── decays fast on purpose; focus is meant to move

WHAT EACH SEPHIRA IS FOR (Cairn's assignment, unchanged)
--------------------------------------------------------
  1  KETER     crown          who the user fundamentally is       permanent
  2  CHOKMAH   wisdom         insights, realizations, principles  slow decay
  3  BINAH     understanding  how their systems and work fit      slow decay
  4  CHESED    mercy          preferences, likes, what they enjoy slow decay
  5  GEVURAH   severity       boundaries, constraints, hard rules permanent
  6  TIFERET   beauty         current focus - the balanced centre volatile
  7  NETZACH   endurance      goals, ambitions, long drives        slow decay
  8  HOD       splendor       facts, specifics, details            decays
  9  YESOD     foundation     conversation digests - working mem   flowing
 10  MALKUTH   kingdom        raw live sessions - the present      10 days

Yesod and Malkuth stay as files rather than leaves. They already worked in
Cairn, they are whole conversations rather than single memories, and there
is no reason to convert something that is not broken.

FLOW  (Cairn's, unchanged)
--------------------------
  MALKUTH (raw session)
      | age >= expire_days
      v
  curator writes digest(s) -> YESOD          <- only now is Malkuth deleted
      |
      v
  curator extracts durable facts -> KETER..HOD

DEATH
-----
Cairn's cap dropped the oldest node on the floor. Luminova's prune deleted
faded leaves outright. The Hub does neither: a leaf that fades or
overflows is written to data/ash/ash.jsonl first, and that file is never
rewritten. Decay changes what is in mind. It does not change what happened.

INJECTION  (Cairn's two tiers, and the reason is still speed)
-------------------------------------------------------------
  FRAME   Keter, Gevurah, Tiferet, Netzach, Chesed. Compact and stable, so
          it sits at the head of the prompt where llama.cpp's prefix cache
          keeps it warm and it costs nothing after the first turn.

  RECALL  Scored leaves from Chokmah, Binah, Hod, plus Yesod digests.
          Volatile, so it goes at the TAIL, just before the newest user
          message. At the head it would invalidate the cache and force a
          full re-prefill every single turn.
"""
from __future__ import annotations

import json
import math
import re
import uuid
import contextlib
import threading
import time
from datetime import datetime, timedelta, timezone

import classify
import consolidate
import core
import events
import grove
import knowledge

# ---------------------------------------------------------------- the tree

SEPHIROT = {
    "keter": {
        "n": 1, "title": "Keter", "gloss": "identity", "cap": 24,
        "front": True, "decay": 0.0, "pinned": True,
        "seeds": {"self": "who they are name identity role what they do for a living",
                  "nature": "how they think what they are like character temperament"},
    },
    "chokmah": {
        "n": 2, "title": "Chokmah", "gloss": "insight", "cap": 40,
        "front": False, "decay": 0.004, "pinned": False,
        "seeds": {"principles": "principle rule of thumb insight realisation lesson learned",
                  "patterns": "pattern tends to always ends up recurring theme"},
    },
    "binah": {
        "n": 3, "title": "Binah", "gloss": "structure", "cap": 40,
        "front": False, "decay": 0.004, "pinned": False,
        "seeds": {"systems": "architecture structure how the parts fit together design",
                  "process": "workflow method process how they work order of steps"},
    },
    "chesed": {
        "n": 4, "title": "Chesed", "gloss": "preference", "cap": 30,
        "front": True, "decay": 0.008, "pinned": False,
        "seeds": {"likes": "likes enjoys prefers favourite loves fond of",
                  "style": "prefers style tone format way of working"},
    },
    "gevurah": {
        "n": 5, "title": "Gevurah", "gloss": "boundary", "cap": 24,
        "front": True, "decay": 0.0, "pinned": True,
        "seeds": {"rules": "never always must not required forbidden rule limit",
                  "constraints": "cannot budget deadline hardware limit constraint"},
    },
    "tiferet": {
        "n": 6, "title": "Tiferet", "gloss": "focus", "cap": 8,
        "front": True, "decay": 0.15, "pinned": False,
        "seeds": {"now": "currently working on right now this week today building"},
    },
    "netzach": {
        "n": 7, "title": "Netzach", "gloss": "goal", "cap": 24,
        "front": True, "decay": 0.006, "pinned": False,
        "seeds": {"goals": "goal aim wants to build plans to intends ambition",
                  "direction": "long term eventually one day where this is going"},
    },
    # DA'AT - the hidden sephira at the centre of the Tree of Life, whose
    # name means "knowledge". Vera kept what-was-understood in a second,
    # separate tree, and separating it was right for HER: a camera planting
    # 15,224 observations into the same pool drowned it. But the fix for
    # drowning is a limb with its own weighting, not a second tree - and this
    # tree already has a place for knowledge, in the middle, where the paths
    # cross. So the Knowledge Tree is a limb now, and there is ONE tree.
    #
    # Its branches are Vera's domains. Her routing vocabulary still decides
    # which branch a thing belongs to; only the storage moved.
    "daat": {
        "n": 0, "title": "Da'at", "gloss": "knowledge", "cap": 400,
        "front": False, "decay": 0.003, "pinned": False,
        "seeds": {"math": "number algebra geometry proof equation calculus statistics",
                  "science": "physics chemistry biology energy matter experiment theory",
                  "art": "music colour composition design story craft aesthetic",
                  "craft": "code python hardware model runtime system build debug"},
    },
    "hod": {
        "n": 8, "title": "Hod", "gloss": "fact", "cap": 60,
        "front": False, "decay": 0.02, "pinned": False,
        # THE BRANCHES THAT EXIST BEFORE ANYTHING IS LEARNED.
        #
        #     "it should have enough permanent branches to keep going and
        #      never stop such as observations, people known (this would
        #      include AI and any other it can talk to), and other things
        #      related to its environment, studies"
        #
        # A person does not derive "there are other people" from
        # experience; they start with somewhere to put people. growth.py
        # has named these as permanent - unmergeable, however the shape of
        # the tree changes - since it was written, and nothing created
        # them, so its one protection protected nothing.
        "seeds": {"machine": "hardware ram vram gpu cpu disk laptop device model specs",
                  "software": "version build library runtime package tool release",
                  "people": "person name who works with family friend colleague assistant model",
                  "observations": "saw noticed watched observed measured looked appeared on screen",
                  "environment": "this computer folder drive port window installed here operating system",
                  "studies": "learning studying practising reading course working through teaching",
                  "doing": "tried ran attempted generated took minutes failed succeeded finished",
                  "details": "specific fact detail number date measurement"},
    },
}
# Every limb that holds a durable memory is searchable.
#
# This was ("chokmah", "binah", "hod", "daat"), which left NETZACH and
# CHESED out - so "my daughter Ada is learning piano" scored 0.705 relevance
# against "what is my daughter learning" and was never returned, because the
# limb holding it was not in the list. People and preferences were being
# stored and then made unreachable.
#
# Keter and Gevurah stay out for a different reason: they are already in
# frame() on every single turn, so including them here would return the same
# lines twice and spend the recall budget on something already present.
# Yesod and Malkuth hold digests and live sessions, not leaves.
RECALLABLE = ("chokmah", "binah", "chesed", "netzach", "hod", "daat")
FRONT_ORDER = [("keter", "Who they are"), ("gevurah", "Boundaries"),
               ("tiferet", "Current focus"), ("netzach", "Goals"),
               ("chesed", "Preferences")]

YESOD_DIR = core.TREE / "yesod"

_lock = threading.RLock()
_limbs: dict[str, grove.Limb] = {}
_active = grove.ActiveTree()
_loaded = False
_curating = False
_last_run = 0.0
_last_result: dict = {}
_last_prune = 0.0


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ---------------------------------------------------------------- limbs

def _path(name: str):
    return core.TREE / f"{name}.json"


def limbs() -> dict:
    """Load once, then hold in memory. Every write saves the limb it touched."""
    global _loaded
    with _lock:
        if _loaded:
            return _limbs
        core.TREE.mkdir(parents=True, exist_ok=True)
        for name, spec in SEPHIROT.items():
            lb = grove.Limb(name, seeds=spec["seeds"],
                            decay_rate=spec["decay"], cap=spec["cap"],
                            permanent_leaves=spec["pinned"])
            grove.load_limb(lb, _path(name))
            _limbs[name] = lb
        _loaded = True
        return _limbs


def _save(name: str) -> None:
    try:
        grove.save_limb(limbs()[name], _path(name))
    except Exception as e:
        core.log_line("memory", f"{now()} save {name} failed: {e}")


def snapshot() -> None:
    for name in SEPHIROT:
        _save(name)


# ---------------------------------------------------------------- writing

def graft(sephira: str, text: str, tags=None, weight: float = None,
          source: str = "experience", origin: str = "user",
          truth: str = "probable", branch: str = None,
          stability: float = 0.0, affect: float = 0.0,
          valence: float = 0.0, kind: str = "", holder: str = "") -> bool:
    """
    Add one memory. The ONLY write path into the upper tree.

    The sephira name is checked against the allowlist here, so a malformed
    or malicious tool call cannot invent a branch of the tree, and the leaf
    itself is built by grove.Limb.plant which enforces length, dedup and
    tagging. A repeat of something already known is not an error: it
    reinforces the leaf that is already there and returns False.
    """
    sephira = (sephira or "").lower().strip()
    text = (text or "").strip()
    if sephira not in SEPHIROT or len(text) < 3:
        return False
    spec = SEPHIROT[sephira]
    if weight is None:
        weight = 0.9 if spec["pinned"] else 0.7
    lb = limbs()[sephira]
    leaf = lb.plant(text[:400], tags=tags, branch=branch, weight=weight,
                    pin=spec["pinned"], source=source, truth=truth,
                    origin=origin, stability=stability, affect=affect,
                    valence=valence, kind=kind, holder=holder)
    if leaf is None:
        return False
    _save(sephira)
    return True


def forget(leaf_id: str, reason: str = "user removed") -> bool:
    """
    Take a leaf out of the living tree by hand.

    It goes to ash like any other fallen leaf. The user removing something
    from view is not the same as it never having been said, and the ash is
    where that difference is kept.
    """
    for name, lb in limbs().items():
        with lb._lock:
            for b in lb.branches.values():
                for l in list(b.leaves):
                    if l.leaf_id == leaf_id:
                        b.remove(leaf_id)
                        grove._to_ash(l, reason)
                        _save(name)
                        return True
    return False


def prune(sephira: str, index: int) -> bool:
    """
    Index-based removal, kept for the interface's delete buttons.

    The index is against the same ordering the interface was given by
    tree(), so what the user clicked is what goes.
    """
    rows = tree().get(sephira) or []
    if not (0 <= index < len(rows)):
        return False
    return forget(rows[index]["leaf_id"], "user removed")


def reweight(leaf_id: str, weight: float = None, pin: bool = None,
             truth: str = None) -> bool:
    for name, lb in limbs().items():
        leaf = lb.find(leaf_id)
        if leaf is None:
            continue
        if weight is not None:
            leaf.weight = max(0.0, min(1.0, float(weight)))
        if pin is not None:
            leaf.pin = bool(pin)
        if truth is not None and truth in grove.Leaf.TRUTHS:
            leaf.truth = truth
            events.write("leaf.truth", leaf_id=leaf_id, truth=truth)
        _save(name)
        return True
    return False


# ---------------------------------------------------------------- reading

def tree() -> dict:
    """
    The living tree, flattened for display.

    Ordered weakest-first inside each sephira so the strongest memories sit
    at the end, which is where the interface and the prompt builder both
    read from.
    """
    out = {}
    for name, lb in limbs().items():
        rows = []
        for b in lb.branches.values():
            for l in b.leaves:
                rows.append({
                    "text": l.content, "tags": l.tags, "created": l.created_at,
                    "leaf_id": l.leaf_id, "branch": l.branch,
                    "weight": round(l.weight, 3), "pin": l.pin,
                    "truth": l.truth, "uses": l.access_count,
                    "stability": round(l.stability, 2),
                    "recalled": l.recalled_at, "recalls": l.recalls,
                    "feeling": l.feeling(), "valence": l.valence,
                })
        rows.sort(key=lambda r: (r["weight"], r["created"]))
        out[name] = rows
    return out


def shape() -> dict:
    """Branch structure per sephira - what the tree actually looks like."""
    out = {}
    for name, lb in limbs().items():
        out[name] = [{"branch": b.name, "theme": b.theme,
                      "leaves": len(b.leaves), "permanent": b.permanent}
                     for b in sorted(lb.branches.values(),
                                     key=lambda x: -len(x.leaves))]
    return out


def all_leaves(only=None) -> list:
    src = limbs()
    keys = only or list(src.keys())
    return [l for k in keys for l in src[k].all_leaves()]


# ---------------------------------------------------------------- scoring

def _tok(s: str) -> set:
    return {w for w in re.findall(r"[a-z0-9]{3,}", (s or "").lower())
            if w not in grove.STOP}


def _score_digest(q: set, text: str, tags, created: str) -> float:
    t = _tok(text) | {str(x).lower() for x in (tags or [])}
    if not t or not q:
        return 0.0
    overlap = len(q & t) / len(q)
    age = grove._age_days(created or "")
    return overlap * (0.6 + 0.4 * max(0.0, 1.0 - age / 60.0))


# ---------------------------------------------------------------- yesod

def digests() -> list[dict]:
    YESOD_DIR.mkdir(parents=True, exist_ok=True)
    out = []
    for f in YESOD_DIR.glob("*.json"):
        d = core.read_json(f, None)
        if isinstance(d, dict) and d.get("line"):
            d["_file"] = f.name
            out.append(d)
    return out


ARCHIVE_DIR = core.SESSIONS / "archive"
MERGED_DIR = core.TREE / "yesod" / "merged"
UNSORTED = core.TREE / "unsorted.jsonl"


def _archive_session(f) -> None:
    """
    A digested session is moved, never deleted.

    Cairn unlinked it once the digest existed, which is correct about the
    fuse and wrong about the raw material: the digest is a lossy summary
    written by a 350M model, and the transcript it came from is the only
    copy of what was actually said. Summaries are derived. Transcripts are
    not.
    """
    try:
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        dest = core.under(ARCHIVE_DIR, f.name)
        if dest.exists():
            dest = core.under(ARCHIVE_DIR, f"{f.stem}_{int(time.time())}.json")
        f.replace(dest)
        events.write("session.archive", file=f.name)
    except Exception as e:
        core.log_line("memory", f"{now()} could not archive {f.name}: {e}")


def _retire_digest(d: dict, into: str) -> None:
    """
    A merged digest keeps its own record and gains a pointer to the merge.

    Cairn deleted both sources once the path node existed, so the trace that
    made the path meaningful - these two specific moments, on these two
    days - was the first thing thrown away. The merged line says two things
    echoed; without the sources there is no way to ask which two.
    """
    fn = d.get("_file")
    if not fn:
        return
    try:
        MERGED_DIR.mkdir(parents=True, exist_ok=True)
        src = YESOD_DIR / fn
        payload = core.read_json(src, None) or {}
        payload["merged_into"] = into
        payload["merged_at"] = now()
        core.write_json(core.under(MERGED_DIR, fn), payload)
        src.unlink(missing_ok=True)
        events.write("digest.merge", source=d.get("id"), into=into)
    except Exception as e:
        core.log_line("memory", f"{now()} could not retire {fn}: {e}")


def _park(text: str, placement) -> None:
    """
    Somewhere to put what the classifier could not place.

    A guess costs more than a gap: a fact filed in the wrong sephira is
    invisible forever, because nobody looks in the crown for a detail about
    a graphics card. Parked statements stay readable and are what the
    classifier gets tuned against.
    """
    try:
        core.TREE.mkdir(parents=True, exist_ok=True)
        with UNSORTED.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"t": now(), "text": text[:400],
                                **placement.as_dict()},
                               ensure_ascii=False) + "\n")
    except Exception:
        pass
    events.write("leaf.parked", text=text[:200], **placement.as_dict())


def parked(limit: int = 40) -> list:
    out = []
    try:
        if UNSORTED.exists():
            for line in UNSORTED.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        pass
    except Exception:
        pass
    return list(reversed(out))[:limit]


def learn(text: str, query: str = "", origin: str = "conversation") -> bool:
    """
    Plant something worked out into Da'at, on the branch its subject routes to.

    This is what used to be a whole second tree. Vera's routing vocabulary
    still decides the branch - math, science, art, craft - but the leaf lands
    in the one tree with everything else, ages with everything else, and is
    found by the one search engine.
    """
    text = (text or "").strip()
    if len(text) < 20:
        return False
    domain, conf = knowledge.route(query or text)
    if not domain:
        return False
    return graft("daat", text[:400], branch=domain,
                 weight=0.55 + 0.25 * min(1.0, conf * 2),
                 source="reflection", origin=origin, truth="uncertain",
                 kind="inferred")


def _write_digest(name: str, obj: dict) -> None:
    YESOD_DIR.mkdir(parents=True, exist_ok=True)
    core.write_json(core.under(YESOD_DIR, name), obj)
    events.write("digest.write", id=obj.get("id"), line=obj.get("line", "")[:300],
                 tags=obj.get("tags"), path=obj.get("path"))


# ---------------------------------------------------------------- malkuth

# How a conversation ended, and the grey zone between.
#
#     "make it a failure button for the model to have a way of knowing when
#      it is doing things wrong ... also to give it a grey zone of what
#      isn't labeled as bad"
#
# Two states and no third. FAILURE is a thing the user did on purpose. Not
# marked is not a pass - it is the absence of a judgement, and the moment
# that reads as approval the signal is worth nothing, because almost every
# conversation is unmarked. The word for it is written out where the model
# can see it, in carryover.py, rather than left to be inferred.
OUTCOMES = ("failure", "")


def save_session(sid: str, messages: list, outcome: str = None) -> None:
    """
    Write the transcript. `outcome` is sticky: passing None keeps whatever
    is already on the file, so the per-turn save cannot quietly erase a
    mark the user made.
    """
    sid = re.sub(r"[^A-Za-z0-9_-]", "", sid or "")[:40] or "session"
    p = core.under(core.SESSIONS, sid + ".json")
    old = core.read_json(p, {})
    mark = old.get("outcome", "") if outcome is None else str(outcome or "")
    if mark not in OUTCOMES:
        mark = ""
    body = {
        "id": sid,
        "started": old.get("started") or now(),
        "updated": now(),
        "outcome": mark,
        "messages": messages[-400:],
    }
    if mark and not old.get("marked_at"):
        body["marked_at"] = now()
    elif old.get("marked_at") and mark:
        body["marked_at"] = old["marked_at"]
    core.write_json(p, body)


def sessions() -> list[dict]:
    out = []
    for f in core.SESSIONS.glob("*.json"):
        d = core.read_json(f, None)
        if isinstance(d, dict) and d.get("messages"):
            out.append({
                "id": d.get("id", f.stem),
                "started": d.get("started", ""),
                "updated": d.get("updated", ""),
                "turns": len(d["messages"]),
            })
    return sorted(out, key=lambda x: x.get("updated", ""), reverse=True)


# ---------------------------------------------------------------- prompt

def _holding_strength(row: dict) -> float:
    """
    How firmly a frame row is held: durability, weighted by availability.

    Both terms are needed. Durability alone keeps something at the front
    forever that nobody has thought about in years; availability alone is
    the old recency behaviour wearing a new name.
    """
    try:
        import hold
        from grove import _age_days
        st = float(row.get("stability") or hold.S_NEW)
        r = hold.retrievability(
            st, _age_days(row.get("recalled") or row.get("created") or ""))
        return (float(row.get("weight", 0.7)) * (0.4 + 0.6 * r)
                * (1.0 + math.log10(max(st, 1.0))))
    except Exception:
        return float(row.get("weight", 0.7))


def frame(limit_chars: int = 0) -> str:
    """
    The reality frame. What Nova knows before the question arrives.

    First person, bounded, and stable from turn to turn so the prefix cache
    keeps it warm. Ordered by how load-bearing it is: who they are, then
    what must not be crossed, then what is happening now.

    Only the strongest leaves in each sephira appear. That is what the
    weights are for - the tree decides what is worth saying, rather than
    the newest thing always winning simply by being newest.
    """
    parts = []
    t = tree()
    for key, label in FRONT_ORDER:
        rows = t.get(key) or []
        if not rows:
            continue
        # WHAT THE DOCSTRING ABOVE ALREADY PROMISED.
        #
        # "Only the strongest leaves in each sephira appear. That is what
        # the weights are for" - and the code took rows[-8:], the eight most
        # recently added, weights untouched. The newest thing always won by
        # being newest, which is the opposite, and it is how
        #
        #     Boundaries:
        #     - I don't see it.
        #     - what? why did you copy me, don't do that
        #
        # reached the top of every prompt and stayed there: filed once by a
        # grammar match, then held in place by recency for good.
        rows = sorted(rows, key=_holding_strength, reverse=True)
        take = rows[:4] if key == "tiferet" else rows[:8]
        lines = []
        for n in take:
            mark = ""
            if n["truth"] in ("contradicted", "disproven"):
                mark = f" [{n['truth']}]"
            lines.append(f"- {n['text']}{mark}")
        parts.append(label + ":\n" + "\n".join(lines))
    return "\n\n".join(parts)[:2200]


# Kept under Cairn's name as well: server.py and anything ported from Cairn
# calls front_block(), and there is no reason to break that.
front_block = frame


# Asking what is TRUE is a different question from asking what anyone
# believes, and the difference has to survive retrieval or the tag is
# decoration. A sealed belief answers the second and never the first.
_ABOUT_BELIEF = re.compile(
    r"(?i)\b(thinks?|thought|believes?|belief|sa(?:y|ys|id)|claims?|"
    r"reckons?|mentioned|reported|"
    r"according to|in .{0,12}s? (?:opinion|view)|feels? that|"
    r"told (?:me|you|us)|opinion|perspective|point of view)\b")


def asking_about_belief(query: str) -> bool:
    return bool(_ABOUT_BELIEF.search(query or ""))


def recall(query: str, k: int = 4) -> list[dict]:
    """
    What surfaces when this is asked.

    The Active Tree is woven across the recallable sephirot - Luminova's
    weave, over Cairn's branches - and the Yesod digests are scored beside
    it so a whole remembered conversation can outrank a single fact.
    """
    q = _tok(query)
    if not q:
        return []

    _refresh_neighbours()
    pool = []
    leaf_of = {}
    _active.weave(all_leaves(RECALLABLE), query)
    wants_belief = asking_about_belief(query)
    for leaf in _active.leaves:
        # THE SEAL. "Zero says his brother thinks the card is fine" is not
        # evidence about the card, and a question about the card must not
        # be able to reach it. Ask what someone thinks and it is right
        # there; ask what is true and it is not.
        if getattr(leaf, "kind", "") == "attributed" and not wants_belief:
            continue
        leaf_of[id(leaf)] = leaf
        pool.append((leaf.relevance(query), {
            "_leaf": id(leaf),
            "line": leaf.content,
            "when": (leaf.created_at or "")[:10],
            "from": SEPHIROT[leaf.limb]["title"],
            "branch": leaf.branch,
            "weight": round(leaf.weight, 2),
            "truth": leaf.truth,
            "kind": getattr(leaf, "kind", "unknown"),
            "holder": getattr(leaf, "holder", ""),
        }))
    for d in digests():
        pool.append((_score_digest(q, d["line"], d.get("tags"),
                                   d.get("created", "")),
                     {"line": d["line"],
                      "when": d.get("when", "") or d.get("created", ""),
                      "from": "Yesod", "branch": "digest",
                      "weight": 1.0, "truth": "probable",
                      "kind": "inferred", "holder": ""}))

    pool = [(s, d) for s, d in pool if s > 0.08]
    pool.sort(key=lambda x: -x[0])
    hits = [d for _, d in pool[:k]]

    # RETRIEVAL IS A WRITE. It is the single most useful thing this file
    # learned from how memory actually works: bringing something back makes
    # it more durable, and by MORE the harder it was to reach. A store that
    # only reads on recall can never distinguish what it lives by from what
    # it merely happens to contain.
    #
    # Only what was actually handed over counts. Everything the ranking
    # considered and rejected was not remembered, and pretending otherwise
    # would strengthen the whole tree evenly, which is the same as
    # strengthening nothing.
    for d in hits:
        lf = leaf_of.get(d.pop("_leaf", None))
        if lf is not None:
            try:
                lf.came_back()
                d["held"] = round(lf.stability, 1)
                d["recalls"] = int(getattr(lf, "recalls", 0) or 0)
                d["feeling"] = lf.feeling()
            except Exception:
                pass
    for d in pool:
        d[1].pop("_leaf", None)
    if hits:
        _save_touched()
    return hits


# ── association, rebuilt when the tree has changed ───────────────────────

_NEIGH_AT = {"n": -1}


def _refresh_neighbours() -> None:
    """
    Teach grove which words keep company in THIS user's memories.

    Rebuilt rather than cached to disk: it is a few thousand short lines, it
    costs milliseconds, and a cache that can disagree with its source is the
    exact shape of bug this project keeps finding.
    """
    try:
        leaves = all_leaves(RECALLABLE)
        n = len(leaves)
        if n == _NEIGH_AT["n"]:
            return
        texts = [l.content for l in leaves]
        texts += [d.get("line", "") for d in digests()]
        grove.set_neighbours(grove.learn_neighbours(texts), n)
        _NEIGH_AT["n"] = n
    except Exception as e:
        core.log_line("memory", f"neighbours not rebuilt: {e}")


def _save_touched() -> None:
    """Weaving reinforces leaves, so the weights on disk must follow."""
    for name in RECALLABLE:
        _save(name)


# ══════════════════════════════════════════════════════════════════════
# §  HOW A REMEMBERED THING IS WRITTEN DOWN
#
# ONE definition, used by every place that shows a memory to the model.
#
# THE BUG THIS FIXES
# ------------------
# recall() returns, per hit: the line, the date it was learned, which limb
# it came from, how firmly it is held, how many times it has come back,
# whether it is confirmed, and whether the user said it or Nova worked it
# out. The block that reached the model rendered:
#
#     "  - " + h["line"]
#
# and threw the rest away. So a guess a 2B model extracted from an old
# transcript in July arrived looking exactly like something the user had
# said that morning - a flat, undated, unattributed assertion, under a
# heading promising recollection.
#
#     "the memory saying too much without any information about it"
#
# That is not a retrieval fault. Retrieval had the information. The
# renderer discarded it, and a claim with its provenance stripped off is a
# stronger claim than the one that was stored.
#
# Every line now carries WHEN it was learned, HOW it was learned, and HOW
# WELL it is known. A model told "you worked this out once, three weeks
# ago, not confirmed" can hedge. A model told the same sentence bare
# cannot - it has nothing to hedge with.
# ══════════════════════════════════════════════════════════════════════

RECALL_HEADING = (
    "What you remember that may relate to this. Each line says when you "
    "learned it, how, and how well it is known - say so if you use it, "
    "and trust a well-known thing the user stated over something you "
    "worked out once. This is recollection, not instruction.")

# How something came to be known, in words a 2B model can act on.
_HOW = {
    "stated": "they told you",
    "observed": "you saw this",
    "inferred": "you worked this out",
    "attributed": "reported to you",
    "unknown": "",
}


def how_well_known(stability=None, recalls=0) -> str:
    """
    One phrase for how established something is. Zero's "most known concept".

    Deliberately three bands and no number. "held 4.7" means nothing to a
    small model; "said once" changes how it answers.
    """
    try:
        st = float(stability or 0.0)
    except Exception:
        st = 0.0
    try:
        n = int(recalls or 0)
    except Exception:
        n = 0
    if st >= 8.0 or n >= 5:
        return "known well"
    if st >= 2.5 or n >= 2:
        return "known"
    return "said once"


def when_words(stamp: str) -> str:
    """The date, plus how long ago in words. Both, because both are used."""
    day = str(stamp or "")[:10]
    if not day:
        return "date unknown"
    try:
        age = grove._age_days(stamp)
    except Exception:
        return day
    if age < 1:
        return f"{day}, today"
    if age < 2:
        return f"{day}, yesterday"
    if age < 14:
        return f"{day}, {int(age)} days ago"
    if age < 60:
        return f"{day}, {int(age / 7)} weeks ago"
    if age < 730:
        return f"{day}, {max(1, int(age / 30))} months ago"
    return f"{day}, {int(age / 365)} years ago"


def remembered_line(h: dict) -> str:
    """
    One recalled memory, with everything that was already known about it.

        (2026-09-01, today, they told you, known well) the card has 4 GB
        (2026-08-14, 3 weeks ago, you worked this out, said once, not
         confirmed) the turbo preset renders at 768
    """
    text = " ".join(str(h.get("line", "")).split())[:300]
    marks = [when_words(h.get("when", ""))]

    kind = str(h.get("kind") or "unknown")
    holder = str(h.get("holder") or "").strip()
    if kind == "attributed" and holder:
        marks.append(f"{holder} said it")
    elif _HOW.get(kind):
        marks.append(_HOW[kind])
    elif str(h.get("branch")) == "digest" or str(h.get("from")) == "Yesod":
        marks.append("a summary of a past conversation")

    marks.append(how_well_known(h.get("held"), h.get("recalls")))

    truth = str(h.get("truth") or "")
    if truth == "uncertain":
        marks.append("NOT confirmed")
    elif truth == "superseded":
        marks.append("was true, later replaced")
    elif truth in ("contradicted", "disproven"):
        marks.append(f"later {truth}")
    return f"({', '.join(m for m in marks if m)}) {text}"


def recall_block(query: str, k: int, limit_chars: int = 0) -> str:
    hits = recall(query, k)
    if not hits:
        return ""
    lines = ["- " + remembered_line(h) for h in hits]
    return (RECALL_HEADING + "\n" + "\n".join(lines))[:(limit_chars or 1600)]


# ---------------------------------------------------------------- ageing

def age_tree(force: bool = False) -> dict:
    """
    Let time pass across the whole tree.

    Called on a timer, not per message: decay is measured in days, and
    running it every turn would only add work. Everything that falls goes
    to ash first.
    """
    global _last_prune
    with _lock:
        elapsed = time.time() - (_last_prune or 0)
        if not force and _last_prune and elapsed < 3600:
            return {"skipped": "too soon"}
        days = elapsed / 86400.0 if _last_prune else 0.0
        _last_prune = time.time()
    if days <= 0 and not force:
        return {"fell": 0, "days": 0}
    fell = 0
    for name, lb in limbs().items():
        n = lb.age(max(days, 0.0), floor=0.05)
        if n:
            fell += n
        _save(name)
    if fell:
        core.log_line("memory", f"{now()} aged {days:.2f}d, {fell} leaves to ash")
    return {"fell": fell, "days": round(days, 3),
            "ash_total": grove.ash_count()}


# ---------------------------------------------------------------- rebuild

def rebuild() -> dict:
    """
    Reconstruct the living tree from the event log alone.

    This is the claim that makes the event log worth having: delete
    data/tree entirely and the tree comes back, because every plant, ash
    and truth change was written down as it happened. What cannot come
    back is the exact decayed weight at the moment of the crash, since
    decay is a function of wall-clock time - so weights are replayed from
    the planting weight and then aged forward.

    verify.py runs this against a scratch copy on every install. If it ever
    stops working, the log has stopped being the source of truth and the
    system has quietly become unrepairable.
    """
    global _limbs, _loaded
    hist = events.read(kinds=("leaf.", "branch."))
    ashed = {e["d"].get("leaf_id") for e in hist if e.get("k") == "leaf.ash"}

    fresh: dict[str, grove.Limb] = {}
    for name, spec in SEPHIROT.items():
        fresh[name] = grove.Limb(name, seeds=spec["seeds"],
                                 decay_rate=spec["decay"], cap=0,
                                 permanent_leaves=spec["pinned"])

    planted = 0
    for e in hist:
        if e.get("k") != "leaf.plant":
            continue
        d = e.get("d") or {}
        limb = d.get("limb")
        if limb not in fresh or d.get("leaf_id") in ashed:
            continue
        b = fresh[limb].add_branch(d.get("branch") or "general")
        b.add(grove.Leaf(
            content=d.get("text", ""), limb=limb, branch=b.name,
            tags=d.get("tags") or [], weight=float(d.get("weight", 0.7)),
            pin=bool(d.get("pin")), source=d.get("source", "experience"),
            truth=d.get("truth", "probable"), leaf_id=d.get("leaf_id"),
            created_at=e.get("t"), origin=d.get("origin", "")))
        planted += 1

    # Truth changes are replayed after planting so the last one wins.
    for e in hist:
        if e.get("k") != "leaf.truth":
            continue
        lid = (e.get("d") or {}).get("leaf_id")
        for lb in fresh.values():
            leaf = lb.find(lid)
            if leaf:
                leaf.truth = (e["d"].get("truth") or leaf.truth)

    # RESTORE THE CAPS.
    #
    # Planting ran with cap=0 on purpose: replaying history through a cap
    # would ash leaves in replay order rather than by weight, and the tree
    # that came back would not be the tree that was lost. But the caps were
    # never put back, so a rebuilt limb grew without limit forever after -
    # measured at 1,442 leaves in a limb capped at 60. Every one of those
    # counts toward context pressure, so a single repair quietly turned the
    # working set into a landfill.
    #
    # Now: replay uncapped, then set the real cap and let each limb settle
    # by weight, which ashes the weakest and keeps what earned its place.
    for name, spec in SEPHIROT.items():
        lb = fresh.get(name)
        if not lb:
            continue
        lb.cap = int(spec["cap"])
        try:
            lb._enforce_cap()
        except AttributeError:
            # Older limbs settle on the next plant; force it with a no-op
            # age so the cap is applied now rather than eventually.
            lb.age(days=0)


    with _lock:
        _limbs = fresh
        _loaded = True
    snapshot()
    return {"events": len(hist), "planted": planted, "ashed": len(ashed),
            "leaves": sum(l.leaf_count() for l in fresh.values())}


# ---------------------------------------------------------------- status

def status() -> dict:
    t = tree()
    counts = {k: len(t.get(k) or []) for k in SEPHIROT}
    counts["yesod"] = len(list(YESOD_DIR.glob("*.json"))) if YESOD_DIR.is_dir() else 0
    counts["malkuth"] = len(list(core.SESSIONS.glob("*.json")))
    with _lock:
        running, last, result = _curating, _last_run, _last_result
    return {
        "running": running, "last": last, "result": result,
        "sessions": counts["malkuth"],
        "counts": counts,
        "leaves": sum(len(v) for k, v in t.items()),
        "branches": sum(len(v) for v in shape().values()),
        "ash": grove.ash_count(),
        "parked": len(parked(9999)),
        "archived": len(list(ARCHIVE_DIR.glob("*.json"))) if ARCHIVE_DIR.is_dir() else 0,
        "events": events.count(),
        "active": _active.stats(),
    }


# ---------------------------------------------------------------- curator
# Cairn's curator, unchanged in shape. Python decides everything structural;
# the small model is used only to find words.

SUM_SYS = (
    "Compress the conversation excerpt. Reply with EXACTLY two lines and nothing else.\n"
    "Line 1: one sentence under 25 words saying what happened.\n"
    "Line 2: 3 to 8 lowercase keywords separated by commas."
)

# The curator is asked for a flat list, and nothing else.
#
# Cairn asked it for {"keter":[...],"chesed":[...],"gevurah":[...],...} - a
# 350M model, on a CPU, sorting statements into Hebrew sephirot names it has
# no reason to understand. It did what small models do under structural load
# and took the first branch in the schema, so the crown of the tree filled up
# with facts about graphics cards. Placement is classify.place()'s job now,
# and the model does the one thing it is genuinely good at: reading what was
# said and writing it down plainly.
FACT_SYS = (
    "List durable facts about the user from this conversation. Reply with ONE "
    "JSON array of short strings and no other text:\n"
    '["fact one", "fact two"]\n'
    "Each string is one complete statement in plain English. Include what "
    "they are, what they like, rules they set, goals, what they are working "
    "on, things they worked out, and concrete details. Skip pleasantries and "
    "anything already obvious. Reply with [] if there is nothing durable."
)

FOCUS_SYS = (
    "In one sentence under 18 words, say what the user is currently working on. "
    "Reply with the sentence only. If unclear, reply exactly: unclear"
)

MERGE_SYS = (
    "Two memories are related. Write ONE sentence under 30 words that keeps both "
    "details and notes the echo between them. Reply with the sentence only."
)


def _chunks(messages: list, cap: int) -> list[str]:
    """
    Up to `cap` digests per session, but one digest per ~9000 characters.

    A normal conversation yields exactly one. Reaching ten requires roughly
    90,000 characters in a single session - hard, but not impossible.
    """
    out, buf, size = [], [], 0
    for m in messages:
        line = f"{m.get('role','?')}: {(m.get('content') or '')[:1500]}"
        buf.append(line)
        size += len(line)
        if size >= 9000:
            out.append("\n".join(buf))
            buf, size = [], 0
    if buf:
        out.append("\n".join(buf))
    if len(out) <= cap:
        return out
    head, tail = out[:cap - 1], "\n".join(out[cap - 1:])
    return head + [tail[:12000]]


def _parse_sum(raw: str):
    lines = [l.strip() for l in (raw or "").splitlines() if l.strip()]
    if not lines:
        return None, []
    line = re.sub(r"^(line\s*1\s*[:.]|summary\s*[:.])\s*", "", lines[0], flags=re.I)[:220]
    tags = []
    if len(lines) > 1:
        raw_tags = re.sub(r"^(line\s*2\s*[:.]|keywords\s*[:.])\s*", "", lines[1], flags=re.I)
        tags = [t.strip().lower()[:24] for t in raw_tags.split(",") if t.strip()][:8]
    return (line or None), (tags or sorted(_tok(line))[:6])


def _facts_from(raw: str) -> list:
    """
    Pull a flat list of statements out of whatever the small model produced.

    Tolerant on purpose: a JSON array is the ask, but a fenced block, an
    object with one array in it, or a plain bulleted list all carry the same
    information and all appear in practice. Refusing them would throw away a
    good extraction over formatting.
    """
    s = re.sub(r"^```[a-z]*|```$", "", (raw or "").strip(), flags=re.M).strip()
    i, j = s.find("["), s.rfind("]")
    if 0 <= i < j:
        try:
            got = json.loads(s[i:j + 1])
            if isinstance(got, list):
                return [str(x).strip() for x in got if isinstance(x, (str, int, float))]
        except Exception:
            pass
    obj = _json_from(s)
    for v in (obj or {}).values():
        if isinstance(v, list) and v:
            return [str(x).strip() for x in v if isinstance(x, str)]
    lines = []
    for line in s.splitlines():
        line = re.sub(r'^\s*[-*\d\.\)]+\s*', "", line).strip().strip('",')
        if 6 < len(line) < 300:
            lines.append(line)
    return lines[:12]


def _json_from(raw: str):
    s = re.sub(r"^```[a-z]*|```$", "", (raw or "").strip(), flags=re.M).strip()
    i, j = s.find("{"), s.rfind("}")
    if i < 0 or j <= i:
        return {}
    try:
        got = json.loads(s[i:j + 1])
        return got if isinstance(got, dict) else {}
    except Exception:
        return {}


def _expired(days: int) -> list:
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    out = []
    for f in core.SESSIONS.glob("*.json"):
        d = core.read_json(f, None)
        if not isinstance(d, dict) or not d.get("messages"):
            continue
        try:
            stamp = datetime.fromisoformat(d.get("updated") or d.get("started"))
            if stamp.tzinfo is None:
                stamp = stamp.replace(tzinfo=timezone.utc)
        except Exception:
            continue
        if stamp < cutoff:
            out.append((f, d))
    return out


def _pairs(ds: list[dict]) -> list[tuple]:
    """Python decides what echoes. The curator only finds the words."""
    out, used = [], set()
    for i in range(len(ds)):
        if i in used:
            continue
        for j in range(i + 1, len(ds)):
            if j in used:
                continue
            a = set(ds[i].get("tags") or [])
            b = set(ds[j].get("tags") or [])
            if a and b and len(a & b) / len(a | b) >= 0.5:
                out.append((i, j))
                used.add(i)
                used.add(j)
                break
    return out[:3]


def run_curator(cfg: dict, _session=None) -> dict:
    """
    One pass. Called only by the idle loop - there is no button for it.

    `_session` lets the caller hand in a lock it already holds, so a single
    idle window can digest, roll up and relieve pressure without releasing
    and re-taking the model between each step.

    Nothing is deleted before its replacement exists. A failed summary
    leaves the session in place to be retried on the next pass, so a bad
    generation costs a delay, never a memory.
    """
    global _curating, _last_run, _last_result
    with _lock:
        if _curating:
            return {"skipped": "already running"}
        _curating = True

    made = merged = facts = parked = 0
    try:
        mcfg = cfg.get("memory", {})
        exp = _expired(int(mcfg.get("expire_days", 10)))
        ds = digests()
        pairs = _pairs(ds)
        aged = age_tree()
        if not exp and not pairs:
            return {"made": 0, "merged": 0, "facts": 0, "idle": True,
                    "aged": aged}

        cap = int(mcfg.get("max_digests_per_session", 10))
        # The model already loaded does this now. No second process, no
        # second model file, no 350M trying to read a conversation.
        # Reuse the caller's lock when there is one; take our own when there
        # is not. nullcontext lets both paths read identically instead of
        # duplicating the whole body under an if.
        with (contextlib.nullcontext(_session) if _session
              else consolidate.Session("organising memory")) as cur:
            if not cur.ok:
                return {"skipped": "model busy", "aged": aged}

            # --- Malkuth -> Yesod, then upward ---------------------------
            for f, sess in exp:
                if cur.expired() or cur.interrupted():
                    break          # the user's next reply matters more
                ok = True
                for n, chunk in enumerate(_chunks(sess["messages"], cap)):
                    line, tags = _parse_sum(cur.ask(SUM_SYS, chunk, 120))
                    if not line:
                        ok = False
                        break
                    _write_digest(f"{sess['id']}_{n}.json", {
                        "id": f"{sess['id']}_{n}",
                        "line": line,
                        "tags": tags,
                        "when": (sess.get("started") or "")[:10],
                        "created": now(),
                    })
                    made += 1

                    for stmt in _facts_from(cur.ask(FACT_SYS, chunk, 320))[:14]:
                        pl = classify.place(stmt)
                        if pl.unsorted or not pl.sephira:
                            # Parked, not dropped. Something the classifier
                            # could not place is a case worth reading later;
                            # a guess would be invisible forever.
                            _park(stmt, pl)
                            parked += 1
                            continue
                        # Confidence rides into the leaf weight. A placement
                        # the classifier was unsure of starts weaker and has
                        # to earn its place by being used.
                        w = 0.55 + 0.30 * min(1.0, pl.confidence)
                        # A 2B model reading an old transcript and
                        # deciding what is durably true about the user is
                        # inference, whatever it sounds like. Marked here,
                        # it reaches the prompt as "you worked this out,
                        # NOT confirmed" instead of as a plain fact.
                        if graft(pl.sephira, stmt, weight=w,
                                 source="reflection", origin="curator",
                                 truth="uncertain", kind="inferred"):
                            facts += 1
                            events.write("leaf.placed", sephira=pl.sephira,
                                         **{k: v for k, v in pl.as_dict().items()
                                            if k != "sephira"})

                    focus = cur.ask(FOCUS_SYS, chunk, 60).strip()
                    if focus and "unclear" not in focus.lower() and len(focus) > 8:
                        if graft("tiferet", focus, source="reflection",
                                 origin="curator", kind="inferred",
                                 truth="uncertain"):
                            facts += 1
                if ok:
                    _archive_session(f)   # the fuse burns only once the digest exists

            # --- paths: Python pairs, curator words ----------------------
            for i, j in pairs:
                if cur.expired() or cur.interrupted():
                    break
                a, b = ds[i], ds[j]
                txt = cur.ask(
                    MERGE_SYS,
                    f"A ({a.get('when','')}): {a['line']}\nB ({b.get('when','')}): {b['line']}",
                    90,
                ).strip()
                if not txt:
                    continue
                _write_digest(f"path_{int(time.time())}_{i}{j}.json", {
                    "id": f"path_{int(time.time())}_{i}{j}",
                    "line": txt[:240],
                    "tags": sorted(set(a.get("tags") or []) | set(b.get("tags") or []))[:10],
                    "when": a.get("when", ""),
                    "created": now(),
                    "path": [a.get("id"), b.get("id")],
                })
                for d in (a, b):
                    _retire_digest(d, into=f"path_{int(time.time())}_{i}{j}")
                merged += 1

            return {"made": made, "merged": merged, "facts": facts,
                    "parked": parked, "aged": aged}

    except Exception as e:
        core.log_line("memory", f"{now()} curator failed: {e}")
        return {"error": str(e)[:220]}
    finally:
        with _lock:
            _curating = False
            _last_run = time.time()
            _last_result = {"made": made, "merged": merged,
                            "facts": facts, "parked": parked}


def loop(stop_evt: threading.Event) -> None:
    """
    Continuous. No timer to configure, no button to press.

    Three things happen here, in a deliberate order.

    1. AGE THE ACTIVE FRONTIER. Cheap, every pass, no model involved. What
       was recently touched stays reachable and what was not fades. This is
       external state, not weights - the model never changes.

    2. PROMOTE CANDIDATES. Also deterministic, also no generation, so it
       runs whether or not a model is loaded.

    3. CONSOLIDATE. This one costs real inference, so it is governed by
       measured pressure - how much of THIS model's window living memory
       would want - and only fires past the point where memory starts
       costing the conversation more than it gives it.

    An interval was the wrong control. Twenty minutes is too often for a
    quiet day and far too rare for a busy one, and either way it is a number
    someone has to guess. Pressure is measured, so nobody guesses.

    WHAT WAS LOST AND HAS BEEN PUT BACK
    HUB-ZERO reduced this loop to promotion plus decay. That reads like a
    simplification, but it deleted every caller of run_curator(), roll_up()
    and relieve() - so consolidate.py was still installed, still imported,
    still tested, and never once ran. Memory grew and was never distilled.
    It also dropped the idle check and the 90-second start delay, which put
    background memory work directly in competition with model load on a
    machine measured at 4 GB of VRAM and under 1 GB of free RAM.
    """
    import consolidate
    stop_evt.wait(90)                      # never compete with model load
    while not stop_evt.is_set():
        try:
            # ---- 0. STAND DOWN WHILE A GENERATOR IS RUNNING --------------
            #
            # "Idle" here meant the USER was idle. During a 45-minute video
            # generation the user is idle by definition - so this loop was
            # doing its heaviest work, on every pass, at the exact moment
            # the machine had least to give: a diffusion model holding
            # several GB, Nova stopped to make room for it, and this
            # walking the whole tree beside it. That is memory pressure and
            # CPU contention added to the one situation on this machine
            # that has actually taken it down.
            #
            # Nothing is skipped, only postponed. Ageing, promotion and
            # consolidation all happen on the next pass, and the frontier
            # decays by wall-clock elapsed rather than by pass, so waiting
            # costs it nothing.
            try:
                import forge as _forge
                if _forge.busy().get("what"):
                    stop_evt.wait(20)
                    continue
            except Exception:
                pass

            # ---- 1. the moving frontier ages on every pass ---------------
            # Cheap, and it must keep happening even when the machine is
            # busy: decay that only runs when idle is not decay, it is a
            # record of how often the user walked away.
            try:
                rows = _active_load()
                if rows:
                    _active_save([{**r, "weight": max(0.0, float(r.get("weight", 0.0)) * 0.995)}
                                  for r in rows])
            except Exception as e:
                core.log_line("memory", f"active frontier aging failed: {e}")

            cfg = core.load()
            # Through the resolver: with n_ctx on auto, config holds the
            # word "auto" and the granted window is the only real number.
            import runtime as _rt
            n_ctx = _rt.live_ctx(cfg)
            p = pressure(n_ctx)

            # Only when the machine is genuinely idle. Memory work must never
            # be the reason a reply is slow.
            if consolidate.idle_for() < consolidate.IDLE_BEFORE:
                stop_evt.wait(15)
                continue

            # ---- 2. candidate -> memory ---------------------------------
            # Deterministic and cheap, so it runs on every idle pass
            # regardless of whether the model is available - promotion needs
            # no generation at all. Ahead of the pressure gate on purpose:
            # candidates that never get promoted never count toward
            # pressure, which is how a backlog hides from the thing that is
            # supposed to notice it.
            try:
                import intake
                if intake.stats().get("ready"):
                    r = intake.promote()
                    if r.get("promoted"):
                        core.log_line("memory",
                                      f"{now()} promoted {r['promoted']} "
                                      f"candidate(s) into the tree")
            except Exception as e:
                core.log_line("memory", f"promote failed: {e}")

            if p["negligible"]:
                stop_evt.wait(300)         # nothing useful to do at this size
                continue

            # The machine's own verdict, measured at load. On a large model
            # and a full laptop, a summarising pass costs minutes of thrash
            # for a benefit the user never asked for at that moment.
            try:
                bench = _rt.bench()
                if bench and bench.get("can_consolidate") is False:
                    stop_evt.wait(300)
                    continue
            except Exception:
                pass

            # ---- 3. consolidation ---------------------------------------
            work = p["over"] or _has_expired_sessions(cfg)
            if not work:
                stop_evt.wait(45)
                continue

            with consolidate.Session("organising memory") as cur:
                if not cur.ok:
                    stop_evt.wait(30)
                    continue
                run_curator(cfg, _session=cur)
                roll_up(cur)
                if pressure(n_ctx)["over"]:
                    relieve(cur, n_ctx)

                # THE TREE'S SHAPE, TENDED.
                #
                # growth.py has been written, tested and imported by
                # nothing but its own test since it was added. A tree
                # whose shape can never change is a tree with opinions
                # about growth and no growth.
                #
                # It reports by default and reshapes only when asked,
                # because these thresholds have never been run against a
                # real tree and this project has a rule about that. What
                # it would do is in data/logs/memory.log from the first
                # idle pass, which is what turning it on should be
                # decided from.
                try:
                    import growth
                    _g = growth.tend(
                        limbs(),
                        reshape=bool(cfg.get("memory", {}).get("reshape")))
                    _GROWTH.update({"at": now(), **_g})
                except Exception as e:
                    core.log_line("memory", f"{now()} growth pass: {e}")

        except Exception as e:
            core.log_line("memory", f"{now()} memory loop: {e}")
        stop_evt.wait(60)


# What the last growth pass saw. Read by /api/state so the shape of the
# tree is something that can be watched rather than guessed at.
_GROWTH: dict = {"at": "", "proposed": [], "applied": [], "reshape": False}


def growth_state() -> dict:
    return {"at": _GROWTH.get("at", ""),
            "reshape": bool(_GROWTH.get("reshape")),
            "proposed": len(_GROWTH.get("proposed") or []),
            "applied": len(_GROWTH.get("applied") or []),
            "next": (_GROWTH.get("proposed") or [])[:4]}


def _has_expired_sessions(cfg: dict) -> bool:
    """Is there a finished conversation waiting to be turned into a digest?"""
    try:
        days = float(cfg["memory"].get("expire_days", 3))
        for f in core.SESSIONS.glob("*.json"):
            d = core.read_json(f, None)
            if isinstance(d, dict) and grove._age_days(
                    d.get("updated") or d.get("started") or "") >= days:
                return True
    except Exception:
        pass
    return False


# ═══════════════════════════════════════════════════════════════════════════
# §  CONTINUOUS MEMORY  -  pressure, the cascade, and the ranked front door
#
# Three things were wrong before this section existed.
#
# 1. MEMORY HAD BUTTONS. "Organise memory now" is a contradiction: if it
#    needs pressing, it is not automatic. Consolidation is driven by
#    measured pressure now and there is nothing to press.
#
# 2. IT WAS NOT CONTINUOUS. A twenty-minute timer is not continuity. Luminova
#    ran constantly and built a picture of the day out of what it kept
#    seeing. What matters is not how often the timer fires but that detail
#    keeps compressing upward while nothing is ever lost.
#
# 3. EVERYTHING RECENT WENT TO THE MODEL. frame() took the last eight leaves
#    per sephira, which is fine for a hundred leaves and absurd for a
#    hundred thousand. A search engine does not hand you the whole index; it
#    ranks first and gives you a page. Memory has to work the same way, and
#    `context()` below is that page.
#
# THE CASCADE
#
#    living leaves     what was said, in full          days
#      -> digests      one line per conversation       weeks
#      -> daily        one paragraph per day           months
#      -> monthly      one paragraph per month         forever
#
# Every tier stays searchable through index.py, so compression never means
# deletion. Detail becomes harder to reach, not impossible - which is what
# remembering a year ago actually feels like.
# ═══════════════════════════════════════════════════════════════════════════

CHARS_PER_TOKEN = 3.1
PRESSURE_TRIGGER = 0.50     # half the window, as specified
NEGLIGIBLE_CTX = 2048       # below this, consolidation costs more than it saves

DAILY = core.TREE / "daily"
MONTHLY = core.TREE / "monthly"
ACTIVE_DIR = core.DATA / "active"
ACTIVE_LOG = ACTIVE_DIR / "flow.jsonl"
ACTIVE_STATE = ACTIVE_DIR / "state.json"
# This is external memory state, not neural training data. It is intentionally
# rebuildable so the model weights never need to change to learn from experience.


def _active_load() -> list[dict]:
    ACTIVE_DIR.mkdir(parents=True, exist_ok=True)
    out = []
    try:
        for line in ACTIVE_LOG.read_text(encoding="utf-8").splitlines()[-128:]:
            if line.strip():
                try:
                    d = json.loads(line)
                    if isinstance(d, dict): out.append(d)
                except Exception:
                    pass
    except Exception:
        pass
    return out


def _active_save(rows: list[dict]) -> None:
    ACTIVE_DIR.mkdir(parents=True, exist_ok=True)
    rows = rows[-128:]
    ACTIVE_LOG.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")


# WHAT AN ASSISTANT TURN IS ALLOWED TO LEAVE BEHIND.
#
# THE LOOP.
#
# The frontier stored assistant replies verbatim. Two kinds of sentence
# should never have been in there, and both of them are self-reinforcing:
#
#   an intention   "[assistant_turn] I will generate a photo based on the
#                  last detailed visual concept we discussed."
#
#   a refusal      "[assistant_turn] I cannot fulfill this request. I am
#                  programmed to follow strict safety guidelines..."
#
# Neither is a fact about the world. The first is a promise that may never
# have been kept - and on the next turn it comes back as memory, so the
# model reads that it already said it would, and says it again. The second
# is worse: a refusal, remembered, becomes a precedent. Nova declines, the
# decline is filed, and the next time the subject comes up she is handed her
# own "I cannot" as evidence about herself.
#
# The observed result was a model reading its own context in circles -
# "Wait, maybe there's a mix-up. Let me check the user's message again." -
# spending an entire reply working out what the request was, and never doing
# it. That reads as a bad model. Some of it was the model. This was us
# feeding it its own tail.
#
# So the frontier keeps OUTCOMES, not prose. A turn that ran a tool or made
# a file is an event and is worth remembering, recorded as what it did. A
# turn that only talked leaves nothing; the user's own turn already anchors
# the subject, and it is the reliable half of the exchange because the user
# is describing the world rather than describing themselves.
_INTENT = re.compile(
    r"^\s*(i (will|'ll|am going to|can|could|should|need to|shall)\b"
    r"|let me\b|i'?m going to\b|okay,? (let'?s|i)\b"
    r"|i (cannot|can't|won'?t|am unable|am not able|am programmed)\b"
    r"|sorry\b|unfortunately\b)", re.I)


def is_outcome(text: str, assets=None) -> bool:
    """
    Did this reply record something that happened, or only talk about it?

    Anything that produced a file happened. Otherwise a reply whose opening
    is a statement about the assistant itself - what it will do, what it
    cannot do - is prose about intention, and intention is not memory.
    """
    if assets:
        return True
    body = (text or "").strip()
    if not body:
        return False
    first = next((ln.strip() for ln in body.splitlines() if ln.strip()), "")
    return not _INTENT.match(first)


def active_move(text: str, *, kind: str = "turn", assets=None) -> dict:
    """Persist the moving frontier of recently active memory outside model weights.

    Activity raises a memory's live weight; silence lets it decay. This is not
    training the neural weights. It is an external, rebuildable memory substrate
    that controls what reaches the model's bounded context.
    """
    now_iso = now()
    terms = list(_tok(text))[:24]
    rows = _active_load()
    for r in rows:
        r["weight"] = max(0.0, float(r.get("weight", 0.0)) * 0.965)
    entry = {"id": uuid.uuid4().hex[:10], "at": now_iso, "kind": kind,
             "text": (text or "").strip()[:700], "terms": terms,
             "weight": 1.0, "hits": 1, "assets": list(assets or [])[:12]}
    rows.append(entry)
    _active_save(rows)
    try:
        ACTIVE_DIR.mkdir(parents=True, exist_ok=True)
        ACTIVE_STATE.write_text(json.dumps({
            "updated": now_iso,
            "active": sorted(rows, key=lambda r: (float(r.get("weight", 0)), r.get("at", "")), reverse=True)[:24]
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return entry


# Two entries must share at least this fraction of the question's distinctive
# words before the frontier will volunteer one. Low, because a follow-up often
# repeats only a word or two of its subject - but not zero, which is what it
# effectively was.
ACTIVE_MIN_OVERLAP = 0.16

# The bar for the recency tail in recall_block. Lower than the ranked search
# above it, because a follow-up often carries only a word or two of its
# subject - and firmly not zero, which is what it used to be.
RECENT_MIN_OVERLAP = 0.12


def active_context(query: str, tokens: int = 500) -> str:
    """
    A small weighted slice of recent activity that RELATES to this question.

    THE BUG THIS FIXES, AND IT IS THE "GOKU" BUG.

    The score was  weight * (0.55 + 0.45 * overlap)  against a threshold of
    0.16. A fresh entry has weight 1.0, so an entry with ZERO overlap scored
    0.55 - more than three times the bar. Relevance was in the formula and
    did nothing: every recent turn was injected into every question. Ask
    "what is the capital of France" after generating a picture and the model
    was handed:

        Active memory frontier (recently moving context; not a transcript):
        - [user_turn] Goku in super Saiyan form 2

    and, reasonably, kept talking about Goku. Across sessions, because the
    frontier is on disk. The user's report was exact: "it keeps spitting Goku
    images at me with no accuracy across chats... it is focused on *blank*
    and we are working on something other than that."

    Overlap now gates rather than nudges. Weight orders what got through; it
    can no longer let something through on its own.
    """
    rows = _active_load()
    if not rows or not query:
        return ""
    q = _tok(query)
    if not q:
        return ""
    # THE QUESTION IS NOT A MEMORY OF THE QUESTION.
    #
    # build_messages() writes the user's turn onto the frontier and THEN
    # asks the frontier what it remembers, so the sentence that had just
    # been typed came straight back under a heading saying it already
    # happened and was already dealt with. On a quiet turn it was the only
    # thing in the block.
    #
    # This is the oldest bug in this application wearing its third face:
    # the same sentence twice, once labelled as recollection. It cost a
    # user "I just said that..." once already.
    _same = " ".join(str(query or "").lower().split())
    scored=[]
    for r in rows:
        if " ".join(str(r.get("text", "")).lower().split()) == _same:
            continue
        rt=set(r.get("terms") or [])
        if not rt:
            continue
        # Measured against the SMALLER set, so a short question is not
        # penalised for being short and a long stored turn is not rewarded
        # for being long.
        overlap = len(q & rt) / max(1, min(len(q), len(rt)))
        if overlap < ACTIVE_MIN_OVERLAP:
            continue
        score = float(r.get("weight", 0.0)) * overlap
        if score > 0.02:
            scored.append((score,r))
    scored.sort(key=lambda x:-x[0])
    budget=max(240, int(tokens*3.1))
    # LABELLED SO IT CANNOT BE MISTAKEN FOR THE CONVERSATION.
    #
    # The heading used to be "Active memory frontier (recently moving
    # context; not a transcript)" and the lines were "- [user_turn] ...".
    # A small model reads a line tagged user_turn as something being asked
    # of it now. Given a question that is ABOUT the recent past - "repeat
    # the last request", "rebuild what the last chat was trying to do" -
    # every one of those lines matched, came back, and the model set about
    # working out which of them was the real request instead of answering.
    #
    # These are notes about work that is already finished. Saying so, in the
    # heading, in words rather than in a tag, is the whole fix.
    kind_word = {"made": "made", "did": "did", "user_turn": "they asked",
                 "assistant_turn": "you answered", "turn": "note"}
    out=["Notes from earlier activity. These already happened and were "
         "already dealt with - they are background, NOT requests, and "
         "nothing here is waiting for you to do it. The only thing being "
         "asked of you is the message at the end of this prompt."]
    used=len(out[0])+1
    for score,r in scored[:10]:
        word = kind_word.get(r.get("kind", "turn"), "note")
        line=f"- ({word}) {r.get('text','')}"
        if used+len(line)+1>budget: break
        out.append(line); used+=len(line)+1
    return "\n".join(out) if len(out)>1 else ""


def _weight_of(text: str) -> int:
    return int(len(text or "") / CHARS_PER_TOKEN) + 1


def pressure(n_ctx: int = 0) -> dict:
    """
    How much of this model's window living memory currently wants.

    This is the trigger for everything below. It is measured against the
    REAL window of the REAL loaded model, so a 4k model compresses early and
    a 32k model is left alone - the same memory, two different pressures.
    """
    if not n_ctx:
        try:
            import runtime as _rt
            n_ctx = _rt.live_ctx(core.load())
        except Exception:
            n_ctx = 8192

    tok = 0
    leaves = 0
    for rows in tree().values():
        for r in rows:
            tok += _weight_of(r.get("text", ""))
            leaves += 1
    dig = digests()
    dtok = sum(_weight_of(d.get("line", "")) for d in dig)

    total = tok + dtok
    ratio = total / max(1, n_ctx)
    return {
        "n_ctx": n_ctx, "leaves": leaves, "digests": len(dig),
        "tokens": total, "ratio": round(ratio, 3),
        "over": ratio > PRESSURE_TRIGGER and n_ctx >= NEGLIGIBLE_CTX,
        # A tiny window cannot be helped by summarising - the summary itself
        # would not fit. Say so rather than thrashing.
        "negligible": n_ctx < NEGLIGIBLE_CTX,
    }


def context(query: str, tokens: int, base: str = None) -> str:
    """
    THE front door. Everything memory sends to the model comes through here.

    This is the piece that makes libraries possible. It does not walk the
    tree and take what is recent; it asks the search engine to RANK
    everything against this turn, then takes the top of that ranking until
    the token allowance is spent - exactly the way a search engine returns a
    page instead of the index.

    Three parts, in the order a person would want them:

      ANCHOR   identity and boundaries. Small, pinned, always present. These
               are who the user is and what must never happen, and they do
               not compete for space with anything.
      RANKED   the best matches for what was just said, drawn from living
               leaves, ash, past conversations, daily and monthly summaries.
      RECENT   a thin tail of what was learned lately, so the assistant is
               not amnesiac about yesterday just because yesterday did not
               match the query.
    """
    import index

    budget_chars = max(200, int(tokens * CHARS_PER_TOKEN))
    out, used = [], 0

    def add(line: str) -> bool:
        nonlocal used
        if used + len(line) + 1 > budget_chars:
            return False
        out.append(line)
        used += len(line) + 1
        return True

    # ── ANCHOR ────────────────────────────────────────────────────────────
    anchor = []
    for seph, label in (("keter", "Who they are"),
                        ("gevurah", "Boundaries that must hold")):
        rows = sorted(tree().get(seph) or [], key=lambda r: -r.get("weight", 0))
        for r in rows[:4]:
            anchor.append(f"  ({label}) {r['text']}")
    if anchor:
        add("What you know about this person:")
        for a in anchor:
            if not add(a):
                break

    # ── RANKED ────────────────────────────────────────────────────────────
    if query and len(query.strip()) > 2:
        hits = index.search(query, limit=24)
        if hits:
            add("")
            add("Relevant to what they just said, best match first:")
            for h in hits:
                tag = {"leaf": "", "ash": " (faded)", "digest": " (a past talk)",
                       "session": " (transcript)", "daily": " (that day)",
                       "monthly": " (that month)",
                       "file": " (their file)"}.get(h["kind"], "")
                mark = ""
                if h.get("truth") in ("disproven", "contradicted"):
                    mark = " [they later corrected this]"
                if not add(f"  ({h['when'][:10]}{tag}){mark} {h['text'][:300]}"):
                    break

    # ── RECENT ────────────────────────────────────────────────────────────
    #
    # RECENCY IS NOT RELEVANCE. This is the Goku bug again, in a different
    # function.
    #
    # This block took the eight NEWEST leaves and put them in front of the
    # model on every single turn, under the heading "Learned recently:",
    # with no reference to what had been asked. Yesterday's conversation
    # therefore arrived in the middle of today's, reading as current
    # context. Asked to build a statue of Goku and Frieza, the model
    # produced a tool call whose topic was a subject from the previous day -
    # a request the user had never made in that conversation, assembled out
    # of a real memory of a different one.
    #
    # The user's description is exact: "if I ask for a picture of GOD
    # striking an anvil, I do not want it to randomly reference EVERY text
    # where it creates something, only see if the relation is even there to
    # begin with. Tacos are not a rock, books are not a kiln."
    #
    # The intent behind it was sound - not being amnesiac about yesterday
    # just because yesterday's words do not match today's. But something
    # recent and unrelated is worse than nothing: it is a wrong answer
    # dressed as context. So recency now only ORDERS what already relates;
    # it can no longer admit anything on its own.
    #
    # The bar is lower than the ranked section above, because a follow-up
    # often repeats only a word or two of its subject - but it is not zero,
    # which is what it was.
    room = budget_chars - used
    q = _tok(query) if query else set()
    if room > 220 and q:
        fresh = []
        for seph, rows in tree().items():
            if seph in ("keter", "gevurah"):
                continue
            for r in rows:
                rt = _tok(r.get("text", ""))
                if not rt:
                    continue
                shared = len(q & rt) / max(1, min(len(q), len(rt)))
                if shared >= RECENT_MIN_OVERLAP:
                    fresh.append((shared, r))
        fresh.sort(key=lambda pair: (pair[1].get("created", ""), pair[0]),
                   reverse=True)
        if fresh:
            seen = {l for l in out}
            add("")
            add("Also learned recently, and related to this:")
            for _, r in fresh[:8]:
                line = f"  ({(r.get('created') or '')[:10]}) {r['text'][:200]}"
                if line in seen or not add(line):
                    break

    return "\n".join(out).strip()


# ---------------------------------------------------------------- the cascade

def _day_key(iso: str) -> str:
    return (iso or "")[:10]


def roll_up(cur) -> dict:
    """
    Compress upward, one tier at a time. Called only from the idle loop.

    Digests older than a day become one paragraph for that day. Daily
    paragraphs older than a month become one paragraph for that month. Each
    step keeps a pointer back to what it replaced, and the originals move to
    an archive rather than being deleted - the index still reaches them.
    """
    DAILY.mkdir(parents=True, exist_ok=True)
    MONTHLY.mkdir(parents=True, exist_ok=True)
    made = {"daily": 0, "monthly": 0}

    # ── digests -> a day ──────────────────────────────────────────────────
    by_day = {}
    for d in digests():
        when = d.get("created") or d.get("when") or ""
        if grove._age_days(when) < 1.0:
            continue                       # today is still being lived
        by_day.setdefault(_day_key(when), []).append(d)

    for day, group in sorted(by_day.items()):
        if (DAILY / f"{day}.json").exists() or len(group) < 2:
            continue
        if cur.expired() or cur.interrupted():
            break
        lines = "\n".join(f"- {g.get('line','')}" for g in group[:40])
        para = cur.ask(
            "You are compressing one day of a person's conversations into a "
            "single short paragraph. Keep what they did, decided, asked "
            "about and cared about. Drop pleasantries. Write plainly, past "
            "tense, no preamble, no bullet points, under 80 words.",
            f"Everything from {day}:\n{lines}")
        if not para:
            continue
        core.write_json(DAILY / f"{day}.json", {
            "day": day, "text": para.strip()[:900],
            "from": [g.get("id") for g in group],
            "created": now()})
        events.write("memory.daily", day=day, digests=len(group))
        made["daily"] += 1

    # ── days -> a month ───────────────────────────────────────────────────
    by_month = {}
    for f in sorted(DAILY.glob("*.json")):
        d = core.read_json(f, None)
        if not isinstance(d, dict):
            continue
        if grove._age_days(d.get("created", "")) < 31:
            continue
        by_month.setdefault(d["day"][:7], []).append(d)

    for month, group in sorted(by_month.items()):
        if (MONTHLY / f"{month}.json").exists() or len(group) < 5:
            continue
        if cur.expired() or cur.interrupted():
            break
        lines = "\n".join(f"- {g['day']}: {g['text']}" for g in group[:40])
        para = cur.ask(
            "You are compressing one month into a single short paragraph. "
            "Keep the throughline - what they were working on, what changed, "
            "what mattered. Drop the day-to-day. Under 90 words, plain past "
            "tense, no preamble.",
            f"{month}:\n{lines}")
        if not para:
            continue
        core.write_json(MONTHLY / f"{month}.json", {
            "month": month, "text": para.strip()[:900],
            "days": [g["day"] for g in group], "created": now()})
        events.write("memory.monthly", month=month, days=len(group))
        made["monthly"] += 1

    return made


def summaries() -> list:
    """Daily and monthly paragraphs, for the index to reach."""
    out = []
    for folder, kind in ((DAILY, "daily"), (MONTHLY, "monthly")):
        if not folder.is_dir():
            continue
        for f in sorted(folder.glob("*.json")):
            d = core.read_json(f, None)
            if isinstance(d, dict) and d.get("text"):
                out.append({"kind": kind, "text": d["text"],
                            "when": d.get("day") or d.get("month") or "",
                            "id": f.stem})
    return out


def relieve(cur, n_ctx: int) -> dict:
    """
    Bring pressure back under the line by compressing, never by deleting.

    Ash is the only thing that removes a leaf from the living tree, and ash
    is reversible reading - the leaf is still on disk and still indexed. So
    the way to make room is to summarise more aggressively, then let the
    normal decay move the weakest leaves to ash.
    """
    before = pressure(n_ctx)
    if not before["over"]:
        return {"skipped": "not over", **before}

    made = roll_up(cur)

    # Still over? Age the tree forward so the weakest leaves fall to ash on
    # their own terms, rather than picking victims.
    after = pressure(n_ctx)
    rounds = 0
    while after["over"] and rounds < 6 and not cur.interrupted():
        for lb in limbs().values():
            lb.age(days=7)
        rounds += 1
        after = pressure(n_ctx)

    events.write("memory.relieve", before=before["ratio"],
                 after=after["ratio"], rounds=rounds, **made)
    return {"before": before["ratio"], "after": after["ratio"],
            "aged_rounds": rounds, **made}
