# INVENTORY

Every meaningful component of Cairn, LuminovaZero and VeraZero, classified.
This exists so nothing important disappears silently and nobody has to
assume something was carried over.

```
KEEP AS-IS   copied, unchanged in substance
ADAPT        carried over, changed for a stated reason
MERGE        combined with something from another source
REPLACE      the source approach was wrong; something else does the job
REMOVE       deliberately not carried over, with a reason
NOT YET      belongs here eventually, absent today, named so it is not forgotten
```

---

## CAIRN

| Component | Class | What happened |
|---|---|---|
| `core.py` sandbox — `under()`, `writable()`, `Denied` | **KEEP AS-IS** | The path jail is correct. Copied verbatim. |
| `core.py` atomic `write_json` | **KEEP AS-IS** | Temp-and-rename. Correct. |
| `core.py` config merge / `patch()` | **KEEP AS-IS** | Deep merge over defaults. Correct. |
| `core.py` paths | **ADAPT** | Added `KNOWLEDGE`, `ASH`, `EVENTS`; added `log_line()`; added the port block so shutdown can be scoped. |
| `core.py` defaults | **ADAPT** | Added `kv_type`, `ram_budget_mb`, `knowledge`, `hearth` sections. Per-sephira decay moved into `memory.py`. |
| `runtime.py` process ownership | **KEEP AS-IS** | `Popen` with `shell=False`, clamped argv, `CREATE_NO_WINDOW`, log file per process. |
| `runtime.py` `_warm()` | **KEEP AS-IS** | Pays the ~12.5s CUDA kernel load at startup so the user never sees it. |
| `runtime.py` `Curator` context manager | **KEEP AS-IS** | Spawn, serve one batch, exit. CPU-only by construction. |
| `runtime.py` ports | **ADAPT** | 8080/8081/8082 → 8090/8091/8092 via `core`. Cairn keeps its own. |
| `runtime.py` argv | **ADAPT** | Added `--cache-type-k/v` from `kv_type`, defaulting f16 because quantised KV is unmeasured on build b10456. v25: **`-ngl` is now sent** — omitting it was never "let llama.cpp fit the offload", it was every layer (ADR-142). Added `-ub`/`-b`; the projector is main-model-only so the curator still cannot touch the card. |
| `runtime.py` `plan()` | **REPAIRED, NOT REPLACED** | Byte-identical from The Hearth through v24 and never connected: it computed `gpu_mb` and threw it away. v25 gives it the second ceiling its own file-header always named — the card — and sends the answer. Same shape, same `fit_policy` modes, same binary search, **still no refusal path** (ADR-142). |
| `runtime.py` `vram_free_mb()` | **FIX** | Was cached for the process lifetime from a reading taken *before* the model loaded: `3938` in 122 of 122 of Zero's benchmarks. Now a 2s TTL plus `forget_vram()` on start, stop and ready (ADR-145). |
| `runtime.py` `learn_from_log()` | **NEW** | Reads llama-server's own allocation report out of `llama.log` into `data/logs/fit.json`. Compute what is computable, measure what is not (ADR-144). |
| `runtime.py` `last_power_loss()` | **NEW** | Kernel-Power 41. `BugcheckCode 0` = no crash, the power went away. The application was the only thing that did not know the machine had reset (ADR-147). |
| `runtime.py` `_bring_up()` | **ADAPT** | `SETTLE_S` between load, warm-up, probe and benchmark. A sleep, not a deadline — nothing fails for taking longer (ADR-146). |
| `gguf.py` cache arithmetic | **ADAPT** | Reads sliding-window and shared-KV metadata and sizes the cache the way llama.cpp sizes it. Gemma at 32k: 243 MB, not 2,240 MB (ADR-143). Per-layer weights now come from the tensor table, not from dividing the file size (ADR-144). |
| `server.py` `kill_orphans` by image name | **REPLACE** | Became `runtime.sweep_ports()`: finds the PID listening on **Hearth's** port, checks the image name, kills only that. The original would have killed Cairn's model from inside The Hub. |
| `server.py` prompt assembly | **ADAPT** | Same cache-aware ordering. Knowledge context and research evidence added at the tail with recall. |
| `server.py` SSE streaming | **KEEP AS-IS** | Including the `reasoning_content` relay for thinking models. |
| `server.py` fail-soft tool phase | **KEEP AS-IS** | A broken tool round-trip drops the half-built exchange; the user still gets an answer. |
| `server.py` tool loop | **ADAPT** | Every call now goes through `policy.GATE.authorize()`; every result through `postflight()`. |
| `server.py` vision passthrough | **KEEP AS-IS** | data: URL into llama.cpp with the projector. Nothing uploaded. |
| `memory.py` ten sephirot + glosses | **KEEP AS-IS** | The topology is right and is the coordinate system. |
| `memory.py` flat node lists | **MERGE** | Each sephira is now a `grove.Limb`. Cairn's shape, Luminova's biology. |
| `memory.py` `graft()` allowlist | **KEEP AS-IS** | Still the only write path into the upper tree. |
| `memory.py` cap eviction (oldest) | **REPLACE** | Weakest goes, not oldest; pins are exempt; overflow falls to ash. |
| `memory.py` Yesod digests as files | **KEEP AS-IS** | Whole conversations, not single memories. Working, untouched. |
| `memory.py` Malkuth sessions | **KEEP AS-IS** | Same format and rotation. |
| `memory.py` curator flow | **KEEP AS-IS** | Malkuth → digest → facts → focus → paths. The fuse still burns only once the digest exists. |
| `memory.py` `FACT_SYS` sephira JSON | **REPLACE** | Flat list from the model, `classify.place()` decides where. See PATCH 1. |
| `memory.py` `_pairs()` | **KEEP AS-IS** | Python decides what echoes; the curator only finds the words. |
| `memory.py` session deletion after digest | **REPLACE** | Archived to `data/sessions/archive/`. See PATCH 2. |
| `memory.py` digest deletion after merge | **REPLACE** | Retired to `yesod/merged/` with a `merged_into` pointer. See PATCH 3. |
| `memory.py` `front_block` / `recall_block` | **ADAPT** | `frame()` is the same two-tier idea, now marking `[disproven]` / `[contradicted]`. `front_block` kept as an alias so nothing ported from Cairn breaks. |
| `tools.py` allowlisted hosts | **KEEP AS-IS** | A tool cannot decide to phone somewhere new. |
| `tools.py` nonce spotlighting | **KEEP AS-IS** | Per-request random nonce; the closing marker cannot be forged. |
| `tools.py` `_strip` / `_SCRIPTISH` | **KEEP AS-IS** | Script and style bodies dropped whole, not just their tags. |
| `tools.py` offline detection + memo | **KEEP AS-IS** | `_is_offline_error`, `believed_offline`, `OFFLINE_MEMO`. |
| `tools.py` AST calculator | **KEEP AS-IS** | Whitelist, never `eval()`. |
| `tools.py` `clock` | **KEEP AS-IS** | Removes a needless internet dependency for something the machine knows. |
| `tools.py` `remember(where, text)` | **REPLACE** | `where` removed. See PATCH 5. |
| `tools.py` `execute()` deciding and running | **ADAPT** | Split into `run()` (executes) and `execute()` (kept for compatibility). Deciding moved to `policy.py`. |
| `ui.html` chat, SSE, voice, mic, camera | **KEEP AS-IS** | Including the browser-side WAV encoder — audio never leaves the machine. |
| `ui.html` Tree-of-Life SVG | **KEEP AS-IS** | Ten spheres, twenty-two paths, brightness by fullness. |
| `ui.html` per-section try/catch in `refresh()` | **KEEP AS-IS** | One failing block can never blank the others. Comment says this cost the model list once already. |
| `ui.html` panes | **ADAPT** | Added KNOWLEDGE and HEARTH tabs, ash/unsorted sub-views, weight bars, truth badges, confirm chips. |
| `install.py` pinned build + asset choice | **KEEP AS-IS** | `b10456`, driver ≥ 551 → CUDA 12.4, else CPU. |
| `install.py` `fetch` / `unzip_into` | **KEEP AS-IS** | Resume, size floor to catch error pages, flatten nested extracts. |
| `install.py` model set | **ADAPT** | Same two models; now writes `threads`, `ram_budget_mb` and `n_ctx` from measurement instead of constants. |
| `install.py` `verify()` | **ADAPT** | Now calls `verify.py`, and speaks in ERROR / OPTIONAL / EXCLUDED. |
| `get_model.py` | **ADAPT** | Added `--import` / `--all` / `--move` so existing models can be brought in explicitly, with a free-space check. |
| `CAIRN.bat` | **ADAPT** | → `HEARTH.bat`. |
| `STOP.bat` image-name kill | **REPLACE** | Port-scoped, image-name-checked. The original would kill both applications. |
| `MIGRATE.bat` / `migrate.py` | **REMOVE** | The Hub is a separate application that starts with an empty `data/`. Migration machinery is exactly the deliverable this build exists not to produce. |

---

## LUMINOVAZERO

| Component | Class | What happened |
|---|---|---|
| `Leaf` — weight, pin, tags, source, timestamps | **KEEP AS-IS** | The atom of the whole design. |
| `Leaf.relevance` proportions 0.50/0.25/0.15/0.10 | **KEEP AS-IS** | Luminova's weighting, unchanged. |
| `Leaf.relevance` admitting zero-overlap leaves | **REPLACE** | No shared word, no recall. The floor was ~0.25 against a 0.10 cutoff, so **every** recent leaf passed. |
| `Leaf.decay` / `reinforce` / `is_alive` | **KEEP AS-IS** | Time takes weight; use gives it back; pins are exempt. |
| `Leaf.from_dict` = `cls(**d)` | **ADAPT** | Unknown keys dropped. One added field would otherwise make an older build read a limb as empty. |
| `Branch` — bud, close, permanent, theme | **KEEP AS-IS** | |
| `Branch.relevance` (top-5 average) | **ADAPT** | Now also scores the branch *theme*, so seed branches can win before any leaf exists. |
| Branch naming from `content.split()[0]` | **REPLACE** | Keywords are computed first, and the longest is used. Otherwise every branch is named `the` or `a`. |
| `Limb` — three, hard-asserted | **ADAPT** | Created by name. The three-limb model is not lost: it is what `data/knowledge` holds, one layer over. |
| `LIMB_SEEDS` (knowledge/core/reality branches) | **ADAPT** | Replaced by per-sephira seed branches with wider themes so memories land somewhere meaningful. |
| `ActiveTree.weave` + reinforce-on-weave | **KEEP AS-IS** | Being thought about strengthens a leaf. |
| `ActiveTree.context_for_llm` | **REPLACE** | The Hub renders through `memory.frame()` and `recall_block()`, which are cache-aware. Grouping by limb with `=== Your Active Memory ===` headers is not. |
| `TreeOfLife.prune` deleting faded leaves | **REPLACE** | Faded leaves go to `data/ash/ash.jsonl` first, which is never rewritten. |
| `TreePruner` daily thread | **ADAPT** | Folded into `memory.age_tree()`, called by the curator loop. One background timer instead of three. |
| `_save_limb` plain `open(...,"w")` | **ADAPT** | Through `core.write_json` — atomic. |
| `threading.Lock` | **ADAPT** | `RLock`. `plant → best_branch → relevance` re-enters. |
| `plant_seed_memories()` | **REMOVE** | Vera's identity seeds are Vera's. The Hub's equivalent is `character.md`, which the user can edit, rather than pinned leaves they would have to hunt down. |
| `~/luminova` paths | **REPLACE** | Everything under the app folder. Vera already fixed this; the fix is inherited. |
| Ollama subprocess LLM calls | **REMOVE** | The Hub is llama.cpp over HTTP, from Cairn. Ollama is a second runtime with a second model store. |
| Trinity Minds (`SOPHIA`/`HARMONIA`/`ELYSIA`) | **REMOVE** | Removed in Vera already. The Knowledge Tree occupies that slot, which is what v4.0 did. |
| `sight_system.py` (IMX500 + Hailo) | **REMOVE** | Raspberry Pi hardware. The target is a Windows laptop. Cairn's camera path covers vision here. |
| `voice_system.py` (faster-whisper + Piper) | **REMOVE** | Linux/Pi audio stack. Cairn's whisper.cpp + Windows SpeechSynthesis path is the Windows equivalent and already works. |
| Event-queue / Brain loop architecture | **NOT YET** | Genuinely good for an always-on device with sensors. The Hub is request/response over HTTP today. Revisit when streaming voice lands. |

---

## VERAZERO

| Component | Class | What happened |
|---|---|---|
| `knowledge_tree.py` in full | **ADAPT** | Copied as `knowledge.py`. Keyword sets, scoring, branches, seeds, leaf lifecycle all intact. |
| Domain keyword sets (math/science/art) | **KEEP AS-IS** | ~400 lines of curated vocabulary. Not retyped, not trimmed. |
| Unigram/bigram/trigram scoring with `len**0.6` penalty | **KEEP AS-IS** | The routing maths is the verified part. |
| `context_for()` returning a tuple | **KEEP AS-IS** | And now asserted in `verify.py`. |
| `grow()` domain-positional arity | **KEEP AS-IS** | And now asserted in `verify.py`. |
| Two-leaf growth (question anchor + insight) | **KEEP AS-IS** | |
| `KTREE_DIR` under the run directory | **ADAPT** | → `core.KNOWLEDGE`, inside the sandbox. |
| `_save` plain `open(...,"w")` | **ADAPT** | Through `core.write_json` — atomic. |
| Hard-coded three domains in three places | **ADAPT** | `DOMAIN_SPECS` registry. A domain is a row now. |
| **Fourth domain: `craft`** | **NEW** | Vera talked about gravity and music. This machine's traffic is Python, llama.cpp, quantisation, GPUs and Raspberry Pis — none of which routes anywhere useful in math/science/art, so the tree would have stayed near-empty while looking connected. Same machinery, new vocabulary. |
| `grow()` planting error strings | **ADAPT** | Refusals, `[LLM ERROR]` and bracket-wrapped non-answers are rejected. A tree fed error strings learns error strings. |
| Emoji in log lines | **ADAPT** | Removed. `cp1252` consoles raise `UnicodeEncodeError`, and the traceback looks like the knowledge tree failing rather than the log line failing. |
| Separation from the Tree of Life | **KEEP AS-IS** | The single most important architectural finding in the three sources. 15,224 observations vs 30 conversations, knowledge at zero. |
| One message per role, question last | **KEEP AS-IS** | Applied in `server.build_messages`. |
| Removing "use your memory when relevant" | **KEEP AS-IS** | A reason, not information. |
| Reading the model name out of the core | **ADAPT** | `install.py` writes config from measurement; `server.py` falls back to what is actually on disk. The two cannot drift. |
| Self-containment (nothing outside the folder) | **KEEP AS-IS** | The governing rule for The Hub. |
| `install.sh` / `start.sh` | **REMOVE** | Bash on a Pi. `INSTALL.bat` / `HEARTH.bat` are the Windows equivalents. |
| Hailo VLM / IMX500 / picamera2 | **REMOVE** | Not this machine. |
| `LEARN_FROM_THINKING` (planting `<think>` content) | **NOT YET** | A real idea — what the model *noticed* is worth more than what it *said*. Needs a thinking model as the daily driver first. Named here so it is not lost. |

---

## NEW IN THE HEARTH

| Component | Why it exists |
|---|---|
| `events.py` | Append-only history. Every structure under `data/` is derived from it, so deleting them all is repairable rather than fatal. **fsynced** since v25 — Zero's copy was NUL-padded by the hard resets, which is a lost write (ADR-148). |
| `grove.py` | Luminova's biology, made into a substrate any named limb can use. |
| `classify.py` | Deterministic placement. Replaces two separate cases of asking a small model to understand Kabbalah. |
| `research.py` | The preflight. Hearth decides whether the world needs checking, before Nova runs and independent of what Nova asks for. |
| `policy.py` | The capability gate. Default deny, per-turn limits, taint, staged confirmations, provenance postflight. |
| `verify.py` | ERROR / OPTIONAL / EXCLUDED, never a silent skip. Includes the rebuild claim and both Vera shape mismatches. |
| `memory.rebuild()` | The repairability claim, executable. |
| `data/ash/ash.jsonl` | The Tree of Death. Decay changes what is in mind, not what happened. |
| `test_hub.py` | Twelve scenarios, half of them with Nova deliberately failing. A suite where the model cooperates proves nothing. |

---

## NOT YET — the honest gaps

Named so that nobody assumes they were carried over.

| Missing | Why it is not here | What it needs |
|---|---|---|
| **Streaming voice** (VAD, barge-in, turn-taking) | Cairn's push-to-talk works; conversational voice is a different architecture, not a setting | The event-loop model from Luminova v3.3, plus abort-and-restart on barge-in |
| **Screen vision** (screenshots, OCR, screen understanding) | The camera path works; screen capture is a separate capability with its own permission questions | A capability entry in `policy.TIERS`, a projector model |
| **`bench_llama.py` measurements** | Requires the live runtime on the target machine | Run against a started server; settle whether `q8_0` KV falls back to CPU on b10456 |
| **BFCL V4 tool-calling scores** for the models on hand | Needs the models and hours | Would tell us whether 2.6B is enough for the tool phase or whether the gate is carrying it |
| **Hybrid retrieval** (BM25 + embeddings) | Lexical is honest and fast and there is no traffic yet to tune against | Measure lexical recall on real Hearth memories first |
| **NLI contradiction detection** | `truth` states exist and are settable; nothing sets them automatically yet | A small entailment model, or a deterministic rule set, measured on this domain |
| **Multi-dimensional relevance** (project / identity / object / temporal) | Single lexical score today | Real traffic to show where one score fails |
| **Placement-correction feedback loop** | Unsorted statements are parked and readable, but corrections do not yet retrain anything | A UI affordance to re-file a parked statement, feeding `tests/placement.jsonl` |

---

## The memory pass (ADR-126..137)

What came from where, and what was left behind.

| from | piece | verdict |
|---|---|---|
| v12/v13 | `budget.Plan` + `fit_history` + the `context N%` chip | **KEEP** — the trimming was never the problem; its share was. History is back to 0.44 of what is left after the character sheet. |
| v12/v13 | an F5 ending the conversation | **REPLACE** — it was an accident, and it was the only thing that ever drew a line. Now a **New conversation** control that keeps the transcript. |
| v13 | `character.md`: *"say when you are working from memory that might be stale"* | **RESTORE** — dropped at v15, and it is the one line that makes provenance actionable. Now in `budget.ESSENTIAL` so a small window cannot cut it. |
| v15 | `memory.recall_block()`'s honest render — date, source, hedge | **PROMOTE** — it was dead code while the live path printed bare assertions. It is now `memory.remembered_line()`, the one renderer. |
| v15 | the curator dedent (facts extracted from old transcripts) | **KEEP, MARK** — the extraction is real work; it is inference, and it now says so. `truth="uncertain", kind="inferred"` reaches the prompt as "you worked this out, NOT confirmed". |
| v16 | `named_subjects()` | **KEEP** — naming people and projects as subjects is right. What it woke up was the bug. |
| v16 | `focus.py` `else: hits = []` | **REPLACE** — a cue ranks, it does not gate. This is the amnesia. |
| v16+ | `forge.progress()`, the progress bar, `/api/stop` reaching the generator | **KEEP AS-IS** — the part Zero says works well in the later versions. Untouched. |
| v19 | `hold.py`, stability/retrievability, strongest-8 frame | **KEEP AS-IS** — right, and now visible: "known well" / "known" / "said once" comes from it. |
| v19 | `intake` arousal, valence, surprise → initial stability | **KEEP AS-IS** |
| v22 | `kind` / `holder` provenance | **WIRE IN** — declared in the schema, never written by any caller, so the seal in `recall()` could not fire on any leaf that has ever existed. All six graft sites now say how they know it. |
| v22 | `growth.py` | **WIRE IN** — imported by nothing but its test for three releases. Runs every idle pass; reports always, reshapes only when `memory.reshape` is true. |
| v22 | `ledger.how_long()` / measured durations | **KEEP AS-IS** |
| v24 | `carryover.py` | **NEW** — the last ≤10 rounds × last 2 sessions, always present. v25: `marks()` memoises per file and `previous()` stops early, so a 2s poll no longer re-reads every conversation (ADR-149). |
| v25 | `test_fit.py` | **NEW** — 49 checks over both ceilings, the cache maths, the argv contract, the first-load share and the no-refusal rule. |
| v26 | `store.py` | **NEW** — the memory's ceiling, measured from the disk every time and never written down. Nothing in it can delete (ADR-152). |
| v26 | `persona.py` | **NEW** — the three blocks of the system prompt that belong to the user, kept in their own file so an update cannot overwrite them (ADR-153). |
| v26 | `test_store.py` / `test_persona.py` | **NEW** — 18 + 16 checks. |
| — | `timeline.py` | **NEW** — one subject, in time order, newest named as now. |
| — | `learning.teach()` reading `placement.scores` | **FIX** — the attribute never existed, both callers swallowed the exception, and every correction anyone ever made taught nothing. |
| — | growth's PERMANENT branches (observations, people, environment, studies, doing) | **CREATE** — named as unmergeable since growth was written, and nothing ever made them. |

---

## The crash, and how a conversation ends (ADR-138..141)

| from | piece | verdict |
|---|---|---|
| v19–v22 | `RAM_FLOOR_MB = 700` sampled every 4s | **STAYS OFF** — it killed four video runs at 17-18 min against successes at 43-47. On this machine, low free memory is what a healthy run looks like. |
| v22+ | `room_for()` — three file sizes plus a picked margin | **STAYS A NOTE** — an estimate has no business ending anything; it logs and starts. |
| — | `enough_room_to_start()` in `_run()` | **NEW** — the one permitted no. stat() the files this command line names against free memory right now, no margin. Asked once, before Popen; cannot reach a process that exists. |
| — | memory loop standing down while a generator runs | **NEW** — "idle" meant the USER was idle, so the heaviest background work ran during every 45-minute generation. |
| v24 | the **New conversation** button | **REPLACED** — a button has to be remembered. The conversation ends itself after `chat.rounds_per_conversation` rounds. |
| — | the **Failure** button, two presses | **NEW** — the only way anything is ever called bad, and the only signal she gets about what going wrong looks like. |
| — | the grey zone | **NEW** — unmarked is not a pass, said in those words. No running score reaches the model; the count is in `/api/state` for the user. |
