"""
timeline.py - knowing, rather than fetching.

    "we need it to remember but also be able to find the most recent
     version of something or the most known concept by searching and
     knowing, we need it to know, not to just read and write. It needs to
     move through time and not be limited to calling information back
     from then"

WHAT WAS MISSING
----------------
The tree stores every leaf with a date, a stability, a recall count and a
truth value, and every one of those is a fact about TIME. None of them
reached the model. Retrieval answered one question - "what matches these
words" - and answered it fresh on every turn, from nothing. So Nova could
recall that the card has 4 GB and, in the same breath, recall a line from
six weeks earlier saying it has 6, with no way to tell which one was now.
Everything was equally present and nothing was current.

Two things are needed for a machine to be inside time rather than
querying it:

  1. THE SAME SUBJECT, IN ORDER.  Ten leaves about the lighthouse video
     are not ten memories, they are one subject with a history. The last
     one is what is true now; the earlier ones are what it was.

  2. A STANDING SENSE OF NOW.  What is current should be present before
     the question arrives, not assembled in response to it. A person does
     not run a search to know what they are working on.

WHAT THIS IS NOT
----------------
It does not summarise, rewrite or merge leaves - grove owns the leaves and
memory.py owns writing them. Nothing here writes to the tree at all. It is
a reading of what is already stored, organised by subject and by time.

And it does not invent contradiction. Two statements about one subject
made a month apart are "the newest" and "an earlier one" - they are only
"was, until" when something already marked the older one superseded.
Guessing at conflict would be the same error as the relief plaque: an
answer nobody asked for, standing where the real one should be.

    "Tacos are not a rock, books are not a kiln."
"""
from __future__ import annotations

import re
import threading
from pathlib import Path

import core
import grove

# How many subjects the standing block may name, and how many past entries
# one subject may show. Ceilings on what is SHOWN. Nothing is dropped.
SUBJECTS = 8
PAST_PER_SUBJECT = 1

# A stem seen in this fraction of all leaves or more is not a subject, it
# is vocabulary. "file" in a tree about files identifies nothing.
#
# THE FLOOR MATTERS AS MUCH AS THE FRACTION. On a tree of four memories,
# a word in two of them is 50% and was being thrown out as vocabulary - so
# "lighthouse", said twice, was disqualified and the two memories about
# the lighthouse were filed under "about" and "finished" instead. A
# fraction alone is meaningless on a small sample, which is the same
# mistake as trusting five runs: something has to have been seen a real
# number of times before how often it appears means anything.
COMMON_AT = 0.34
COMMON_FLOOR = 4

_lock = threading.Lock()
_cache: dict = {"key": None, "value": None}


# ---------------------------------------------------------------- subjects

# A subject is a thing, not what was done to it. There is no part-of-speech
# tagger here and there is not going to be one, so noun-likeness is read off
# the shape of the word as the user wrote it: a capital letter mid-sentence,
# a digit, a dot with an extension. "GTX", "1650", "trellis", "bracket.stl"
# are things. "prefer", "finished", "reached" are not, and a memory filed
# under "finished" is a memory nobody will ever find again.
_VERBISH = re.compile(
    r"(?:ed|ing|es|s)$|^(?:be|is|are|was|were|has|had|have|do|does|did|"
    r"go|goes|went|get|got|make|made|take|took|give|gave|say|said|see|saw|"
    r"want|need|like|try|tried|use|used|run|ran|work|worked|start|started|"
    r"finish|finished|prefer|prefers|preferred|think|thought|know|knew|"
    r"come|came|keep|kept|put|set|let|ask|asked|tell|told|call|called)$")

_WORDS = re.compile(r"[A-Za-z0-9][A-Za-z0-9'._-]*")

# Words long enough to look like nouns to a length test, which are not the
# name of anything. grove.WEAKS is tuned for retrieval and lets these
# through; a subject index needs a shorter leash than a search does.
_NOT_A_SUBJECT = {
    "about", "again", "against", "already", "also", "always", "another",
    "anything", "around", "because", "before", "being", "below", "better",
    "between", "both", "could", "different", "does", "doing", "done",
    "during", "each", "either", "else", "enough", "even", "ever", "every",
    "everything", "first", "from", "further", "general", "here", "into",
    "itself", "just", "last", "later", "least", "less", "like", "little",
    "long", "made", "many", "maybe", "might", "more", "most", "much",
    "must", "never", "next", "nothing", "often", "once", "only", "other",
    "over", "part", "perhaps", "please", "quite", "rather", "really",
    "right", "same", "several", "should", "since", "some", "something",
    "still", "such", "sure", "than", "that", "their", "them", "then",
    "there", "these", "they", "thing", "things", "this", "those",
    "though", "through", "thus", "together", "toward", "under", "until",
    "upon", "very", "well", "were", "what", "when", "where", "whether",
    "which", "while", "with", "within", "without", "would", "your",
}
_NOT_A_SUBJECT = {grove.stem(w) for w in _NOT_A_SUBJECT} | _NOT_A_SUBJECT


def _strong(text: str) -> list:
    """Stemmed content words, in order, with the filler removed."""
    try:
        out = []
        for w in _WORDS.findall(str(text or "").lower()):
            if len(w) < 3:
                continue
            st = grove.stem(w)
            if st in grove.WEAKS or len(st) < 3:
                continue
            out.append(st)
        return out
    except Exception:
        return []


_EXT = re.compile(r"\.[A-Za-z]{2,5}$")


def _thingish(word: str, before: str = "") -> int:
    """
    How much this word looks like the NAME of a thing. 0, 1 or 2.

    2  a filename or an extension, an all-capitals initialism, or a bare
       number that follows a name - "GTX 1650" is a card
    1  a capital inside a sentence, or a long ordinary word
    0  a verb, a short function word, or a bare number that follows a
       preposition or an ordinary noun - "at 10211 seconds" is a
       measurement, and a memory filed under "10211" is lost

    The distinction between those last two is the whole reason `before` is
    passed in. Both are digits. Only one of them is what the sentence is
    about.
    """
    w = str(word or "")
    if not w:
        return 0
    if _EXT.search(w):
        return 2
    digits = any(c.isdigit() for c in w)
    if digits and not w.replace(".", "").replace(",", "").isdigit():
        return 2                      # bracket_v2, LFM2.5, Q4_K_M
    if digits:
        b = str(before or "")
        named = bool(b) and (b.isupper() or (b[:1].isupper() and not b.isupper()))
        return 2 if named else 0      # "GTX 1650" vs "at 10211 seconds"
    if w.isupper() and len(w) > 1:
        return 2                      # GTX, VRAM, GLB - named in shouting
    low = w.lower()
    if low in _NOT_A_SUBJECT or grove.stem(low) in _NOT_A_SUBJECT:
        return 0
    if _VERBISH.search(low):
        return 0
    if w[:1].isupper():
        return 1
    return 1 if len(w) >= 5 else 0


def _shapes(text: str) -> dict:
    """
    stem -> (how thing-like, {written form: count}, {phrase: count}).

    The phrase is the word with the name in front of it, where there is
    one: "turbo preset", "GTX 1650". A subject called "preset" is correct
    and useless; the user says "the turbo preset", so that is what it
    should be called back to them.
    """
    out = {}
    raw = _WORDS.findall(str(text or ""))
    for i, w in enumerate(raw):
        if len(w) < 3:
            continue
        st = grove.stem(w.lower())
        if st in grove.WEAKS or len(st) < 3:
            continue
        before = raw[i - 1] if i else ""
        score, forms, phrases = out.get(st, (0, {}, {}))
        forms[w] = forms.get(w, 0) + 1
        if (before and len(before) >= 3
                and grove.stem(before.lower()) not in grove.WEAKS
                and _thingish(before, raw[i - 2] if i > 1 else "") >= 1):
            ph = f"{before} {w}"
            phrases[ph] = phrases.get(ph, 0) + 1
        out[st] = (max(score, _thingish(w, before)), forms, phrases)
    return out


def _label_for(stem_key: str, words: dict, phrases: dict) -> str:
    """The words the user actually uses for this subject, not its stem."""
    forms = words.get(stem_key) or {}
    if not forms:
        return stem_key
    bare = max(forms.items(), key=lambda kv: (kv[1], -len(kv[0])))
    ph = phrases.get(stem_key) or {}
    if ph:
        best = max(ph.items(), key=lambda kv: (kv[1], len(kv[0])))
        if best[1] * 2 >= bare[1]:
            return best[0]
    return bare[0]


def _leaves() -> list:
    import memory
    try:
        return memory.all_leaves(memory.RECALLABLE)
    except Exception:
        return []


def subjects() -> list[dict]:
    """
    Everything known, grouped by what it is about, each group in time order.

    Three tests, in this order, and the order is the design:

      1. DOES IT RECUR?  A subject is something that came up more than
         once. Grouping by the rarest word - the obvious first attempt -
         gives every leaf its own group, which is a list with extra steps.
         So a word shared with other memories wins.

      2. IS IT A THING?  Between two equally recurring words, the one that
         looks like the name of something beats the one that looks like
         something happening. Filed under the first attempt's answer, "the
         lighthouse video finished in 46.6 minutes" became a subject
         called "finished".

      3. IS IT DISTINCTIVE?  A word in a third of all memories identifies
         nothing; it is this user's vocabulary. Those are excluded before
         the other two tests run.

    Cheap, no model, no embedding, and wrong in a way that is visible on
    screen - which matters more here than being subtly right.
    """
    leaves = _leaves()
    if not leaves:
        return []

    df: dict = {}
    shape: dict = {}
    words: dict = {}
    phrases: dict = {}
    per_leaf = []
    for lf in leaves:
        text = getattr(lf, "content", "") or ""
        st = _strong(text)
        per_leaf.append((lf, st))
        for s in set(st):
            df[s] = df.get(s, 0) + 1
        for k, (score, forms, phr) in _shapes(text).items():
            shape[k] = max(shape.get(k, 0), score)
            bag = words.setdefault(k, {})
            for w, c in forms.items():
                bag[w] = bag.get(w, 0) + c
            pbag = phrases.setdefault(k, {})
            for w, c in phr.items():
                pbag[w] = pbag.get(w, 0) + c

    n = max(1, len(leaves))
    groups: dict = {}
    for lf, st in per_leaf:
        pool = [s for s in st
                if df.get(s, 0) < max(COMMON_FLOOR, n * COMMON_AT)] or st
        if not pool:
            continue
        # Thing-likeness weighs three times what one more mention does, so
        # a pronoun that happens to recur cannot take a subject away from
        # the file the sentence is actually about.
        real = [s for s in pool if s not in _NOT_A_SUBJECT] or pool
        key = max(real, key=lambda s: (shape.get(s, 0) * 3
                                       + min(df.get(s, 0), 6),
                                       len(s)))
        groups.setdefault(key, []).append(lf)

    out = []
    for key, group in groups.items():
        group = sorted(group, key=lambda l: (getattr(l, "created_at", "") or ""))
        entries = [_entry(l) for l in group]
        out.append({
            "key": key,
            "label": _label_for(key, words, phrases),
            "entries": entries,
            "current": entries[-1],
            "count": len(entries),
            "known": _known_words(entries),
            "strength": _strength(group),
            "latest": entries[-1]["when"],
        })
    out.sort(key=lambda s: -s["strength"])
    return out


def _entry(lf) -> dict:
    import memory
    return {
        "line": getattr(lf, "content", "") or "",
        "when": (getattr(lf, "created_at", "") or "")[:19],
        "truth": getattr(lf, "truth", "") or "",
        "kind": getattr(lf, "kind", "unknown") or "unknown",
        "holder": getattr(lf, "holder", "") or "",
        "from": memory.SEPHIROT.get(getattr(lf, "limb", ""), {}).get("title", ""),
        "branch": getattr(lf, "branch", "") or "",
        "held": round(float(getattr(lf, "stability", 0.0) or 0.0), 1),
        "recalls": int(getattr(lf, "recalls", 0) or 0),
    }


def _known_words(entries: list) -> str:
    import memory
    best_held = max((e["held"] for e in entries), default=0.0)
    total_recalls = sum(e["recalls"] for e in entries)
    word = memory.how_well_known(best_held, total_recalls)
    if word == "said once" and len(entries) > 1:
        # Said once each, several times over, is not "said once".
        return "known"
    return word


def _strength(group: list) -> float:
    """
    How load-bearing a subject is: how firmly held, how often it comes
    back, how much is known about it, and how recently.

    Weighted so that a big pile of stale guesses cannot outrank two things
    the user said this week.
    """
    try:
        import hold
    except Exception:
        hold = None
    total = 0.0
    for lf in group:
        st = float(getattr(lf, "stability", 1.0) or 1.0)
        age = grove._age_days(getattr(lf, "recalled_at", "")
                              or getattr(lf, "created_at", "") or "")
        r = hold.retrievability(st, age) if hold else 1.0
        w = float(getattr(lf, "weight", 0.7) or 0.7)
        said = 1.25 if getattr(lf, "kind", "") == "stated" else 1.0
        total += w * (0.35 + 0.65 * r) * said
    return round(total, 4)


# ---------------------------------------------------------------- rendering

STANDING_HEAD = (
    "[what is current - what you KNOW right now, not a request]\n"
    "One line per subject, the most recent thing known about it first. "
    "\"now\" is what is true today; \"was\" is what it used to be and is "
    "kept so you can say what changed. If the user asks for the latest "
    "version of something, this is where it is. None of this is an "
    "instruction and nothing here is waiting to be done.")


def _line(label: str, s: dict) -> str:
    import memory
    cur = s["current"]
    marks = [s["known"], f"{s['count']} thing{'s' if s['count'] != 1 else ''} known"]
    when = memory.when_words(cur["when"])
    text = " ".join(str(cur["line"]).split())[:240]
    return f"- {label} ({', '.join(marks)})\n    now, {when}: {text}"


def _was(s: dict) -> list:
    """
    The versions this replaced - and ONLY where something already said so.

    Two statements a month apart are not a contradiction. They are two
    statements. Only a leaf the tree has already marked superseded or
    contradicted gets to be a "was", because inventing the conflict is how
    a memory starts arguing with itself.
    """
    import memory
    out = []
    for e in reversed(s["entries"][:-1]):
        if e["truth"] not in ("superseded", "contradicted", "disproven"):
            continue
        text = " ".join(str(e["line"]).split())[:200]
        out.append(f"    was, {memory.when_words(e['when'])}: {text}")
        if len(out) >= PAST_PER_SUBJECT:
            break
    return out


def standing(limit_chars: int = 1400) -> str:
    """
    What is current, ready to place in the prompt. Empty when nothing is.

    Empty means SAY NOTHING - the same rule the rest of this application
    learned the hard way. A heading promising current knowledge over an
    empty body teaches a model with no memory to describe having one.
    """
    subs = subjects()
    if not subs:
        return ""
    room = int(limit_chars) - len(STANDING_HEAD) - 2
    if room < 120:
        return ""
    lines, used, shown = [], 0, 0
    for s in subs:
        if shown >= SUBJECTS:
            break
        block = [_line(s["label"], s)] + _was(s)
        text = "\n".join(block)
        if used + len(text) + 1 > room and shown:
            break
        lines.append(text)
        used += len(text) + 1
        shown += 1
    if not lines:
        return ""
    return STANDING_HEAD + "\n" + "\n".join(lines)


def about(query: str, limit_chars: int = 1200) -> str:
    """
    The history of whatever the question is about, oldest to newest.

    This is the answer to "what is the latest on X" and to "what did it
    used to be" - one subject, in order, with dates, so the model can say
    what changed rather than picking whichever line retrieval ranked first.
    """
    import memory
    want = set(_strong(query))
    if not want:
        return ""
    subs = subjects()
    scored = []
    for s in subs:
        # Naming the subject counts double. Sharing a word with something
        # it once said counts a little, and one such word is not enough -
        # "look into the last prompt" shares a word with almost anything,
        # and answering it with the history of the graphics card is the
        # relation that was not there.
        named = len(want & ({s["key"]} | set(_strong(s["label"]))))
        body = " ".join(e["line"] for e in s["entries"])
        shared = len(want & set(_strong(body)))
        score = named * 2.0 + shared * 0.5
        if score >= 1.5:
            scored.append((score + 0.001 * s["strength"], s))
    if not scored:
        return ""
    scored.sort(key=lambda x: -x[0])
    s = scored[0][1]
    out = [f"[the history of \"{s['label']}\", oldest first - {s['known']}, "
           f"{s['count']} thing(s) known. The LAST line is what is true "
           f"now.]"]
    used = len(out[0])
    for e in s["entries"][-6:]:
        line = "  " + memory.remembered_line(e)
        if used + len(line) + 1 > limit_chars and len(out) > 1:
            break
        out.append(line)
        used += len(line) + 1
    return "\n".join(out)


def prepared(limit_chars: int = 1400) -> str:
    """
    standing(), assembled once and reused until the tree changes.

    Organised before the turn, not gathered during it - and byte-identical
    between turns, so it sits in the cached head instead of forcing a
    re-evaluation of the whole prompt every message.
    """
    key = (int(limit_chars), _fingerprint())
    with _lock:
        if _cache["key"] == key:
            return _cache["value"]
    value = standing(limit_chars)
    with _lock:
        _cache["key"] = key
        _cache["value"] = value
    return value


def forget_cache() -> None:
    with _lock:
        _cache["key"] = None
        _cache["value"] = None


def _fingerprint() -> tuple:
    marks = []
    try:
        for f in sorted(core.TREE.glob("*.json")):
            st = f.stat()
            marks.append((f.name, st.st_mtime_ns, st.st_size))
    except Exception:
        pass
    return tuple(marks)


# ---------------------------------------------------------------- versions

# bracket_v3.stl, bracket 3.stl, bracket(3).stl, bracket-final-2.stl,
# bracket copy.stl - all the same object, five times, and a name match
# alone calls them five different things.
_VER = re.compile(
    r"[ _\-.]*(?:v(?:er(?:sion)?)?[ _\-.]?)?\d{1,4}\s*$"
    r"|[ _\-.]*\(\d{1,4}\)\s*$"
    r"|[ _\-.]*(?:final|latest|newest|new|old|copy|revised|fixed)\s*$",
    re.I)


def family(name: str) -> str:
    """The name with its version marks stripped: what the thing is called."""
    stem = Path(str(name or "")).stem.strip()
    prev = None
    while stem and stem != prev:
        prev = stem
        stem = _VER.sub("", stem).strip(" _-.")
    return stem.lower()


def versions(name: str) -> list[dict]:
    """
    Every file that is a version of this one, NEWEST FIRST.

    "Find the most recent version of something", in the most literal sense
    the phrase has: files.find() matches a name or a stem and returns one
    file, and it has no idea that bracket_v2.stl came after bracket.stl.
    Modified time decides, because that is the only thing on disk that
    actually records when the object last changed.
    """
    import playground
    import vault
    want = family(name)
    if not want:
        return []
    out = []
    for root, mine in ((playground.ROOT, True), (vault.VAULT, False)):
        try:
            base = Path(root)
            if not base.is_dir():
                continue
            for f in base.rglob("*"):
                if not f.is_file() or f.name.startswith("."):
                    continue
                if any(f.name.lower().endswith(t)
                       for t in getattr(__import__("files"), "SIDECARS", ())):
                    continue
                if family(f.name) != want:
                    continue
                st = f.stat()
                out.append({"name": f.name, "path": str(f),
                            "mine": mine, "at": st.st_mtime,
                            "mb": round(st.st_size / 1048576, 3)})
        except Exception:
            continue
    out.sort(key=lambda d: -d["at"])
    return out


def latest(name: str):
    """The newest version of `name`, or None. One definition, both callers."""
    got = versions(name)
    return got[0] if got else None


def versions_block(name: str, limit: int = 6) -> str:
    """What to tell the model when it asks which version is current."""
    import time as _t
    got = versions(name)
    if not got:
        return ""
    lines = [f"Versions of \"{family(name)}\", newest first. The first one "
             f"is the current version."]
    for d in got[:limit]:
        when = _t.strftime("%Y-%m-%d %H:%M", _t.localtime(d["at"]))
        whose = "yours" if d["mine"] else "the user's"
        lines.append(f"  - {d['name']}  ({when}, {whose}, {d['mb']} MB)")
    if len(got) > limit:
        lines.append(f"  ...and {len(got) - limit} older one(s).")
    return "\n".join(lines)


def stats() -> dict:
    subs = subjects()
    return {"subjects": len(subs),
            "top": [{"label": s["label"], "known": s["known"],
                     "count": s["count"], "latest": s["latest"][:10]}
                    for s in subs[:6]]}
