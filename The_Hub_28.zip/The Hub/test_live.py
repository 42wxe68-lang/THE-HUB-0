"""
test_live.py - a real turn through the real server, with a stub model.

    python test_live.py

WHAT THIS ADDS OVER THE OTHER SUITES
------------------------------------
`test_hub.py` proves the logic: preflight decides correctly, the gate
refuses correctly, postflight taints correctly. It calls those modules
directly.

This proves the WIRING. It starts the actual `server.py` HTTP handler,
posts a real message to `/api/chat`, and reads the real SSE stream back. If
`policy.GATE.authorize()` were never called from the chat path - if the
whole supervisory layer existed as excellent, well-tested modules that
nothing actually invoked - every other suite would still pass and this one
would fail.

That is not a hypothetical. It is precisely the state this project was in
before: research.py and policy.py existed, were tested, and were not wired
into `server.chat()`.

THE STUB
--------
A tiny HTTP server on The Hub's own main port speaking enough of the
OpenAI chat-completions API to be a model: `/health`, one unstreamed
response for the tool phase, one SSE stream for the answer. It is scripted,
so the test can make Nova do specific wrong things - call a tool that does
not exist, try to write to memory, loop - and check that the outcome is
still correct.

No llama.cpp, no model file, no network, about two seconds.
"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

# Scratch data root before anything caches a path.
_TMP = Path(tempfile.mkdtemp(prefix="hub-live-"))
import core                                                     # noqa: E402

core.DATA = _TMP / "data"
core.TREE = core.DATA / "tree"
core.KNOWLEDGE = core.DATA / "knowledge"
core.ASH = core.DATA / "ash"
core.EVENTS = core.DATA / "events"
core.SESSIONS = core.DATA / "sessions"
core.LOGS = core.DATA / "logs"
core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
                 core.SESSIONS, core.LOGS)
core.ensure_dirs()

import events      # noqa: E402
import grove       # noqa: E402
import memory      # noqa: E402
import consolidate # noqa: E402
import index       # noqa: E402
import policy      # noqa: E402
import vault       # noqa: E402
import runtime     # noqa: E402
import server      # noqa: E402

events.LOG = core.EVENTS / "events.jsonl"
grove.ASH_FILE = core.ASH / "ash.jsonl"
memory.YESOD_DIR = core.TREE / "yesod"
memory.ARCHIVE_DIR = core.SESSIONS / "archive"
memory.UNSORTED = core.TREE / "unsorted.jsonl"
vault.VAULT = _TMP / "vault"

PASS, FAIL = [], []


def check(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(f"  {'ok  ' if cond else 'FAIL'}  {name}")
    if detail:
        print(f"        {detail}")


# ---------------------------------------------------------------- the stub

SCRIPT = {"tool_calls": [], "answer": "Nothing to say."}


class StubModel(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send(200, b'{"status":"ok"}')
        self._send(404, b"no")

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n).decode() or "{}")

        # /tokenize is not a chat turn. The first version of this stub
        # answered every POST as a chat request, so budget.count() silently
        # consumed the scripted tool call and wiped last_messages - the tests
        # then reported a product regression that did not exist.
        if self.path.endswith("/tokenize"):
            txt = str(body.get("content") or "")
            return self._send(200, json.dumps(
                {"tokens": list(range(max(1, len(txt) // 4)))}).encode())

        StubModel.last_messages = body.get("messages") or []

        if not body.get("stream"):
            # Tool phase. Serve each scripted round once.
            calls = SCRIPT["tool_calls"].pop(0) if SCRIPT["tool_calls"] else []
            return self._send(200, json.dumps({"choices": [{"message": {
                "role": "assistant", "content": "", "tool_calls": calls}}]}).encode())

        # Answer phase, streamed.
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()
        for piece in SCRIPT["answer"].split(" "):
            self.wfile.write(b"data: " + json.dumps({"choices": [{"delta":
                {"content": piece + " "}}]}).encode() + b"\n\n")
            self.wfile.flush()
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


StubModel.last_messages = []


def tool_call(name, args, cid="c1"):
    return [{"id": cid, "type": "function",
             "function": {"name": name, "arguments": json.dumps(args)}}]


# ---------------------------------------------------------------- drive

def say(text, image=None):
    """Post a turn and collect every SSE event the server emitted."""
    req = urllib.request.Request(
        f"http://127.0.0.1:{core.UI_PORT}/api/chat",
        data=json.dumps({"messages": [{"role": "user", "content": text}],
                         "image": image}).encode(),
        headers={"Content-Type": "application/json"}, method="POST")
    out = []
    with urllib.request.urlopen(req, timeout=60) as r:
        for raw in r:
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("data:"):
                try:
                    out.append(json.loads(line[5:].strip()))
                except Exception:
                    pass
    return out


def texts(evts):
    return "".join(e.get("content", "") for e in evts).strip()


def main() -> int:
    cfg = core.load()
    cfg["tools"] = {"clock": True, "calculator": True, "remember": True,
                    "web_search": False}
    cfg["_unused"] = {"preflight": True, "capability_gate": True,
                     "research_interception": True, "confirm_writes": True,
                     "log_decisions": True}
    cfg["model"] = "stub.gguf"
    core.save(cfg)

    stub = ThreadingHTTPServer(("127.0.0.1", core.MAIN_PORT), StubModel)
    stub.daemon_threads = True
    threading.Thread(target=stub.serve_forever, daemon=True).start()

    # The runtime believes a model is loaded; nothing is spawned.
    runtime._set("ready")
    if not runtime.health(runtime.MAIN, 3):
        print("ERROR: stub model did not come up")
        return 2

    hub = ThreadingHTTPServer(("127.0.0.1", core.UI_PORT), server.H)
    hub.daemon_threads = True
    threading.Thread(target=hub.serve_forever, daemon=True).start()
    time.sleep(0.3)

    print("\n  stub model on", runtime.MAIN, " |  The Hub on 127.0.0.1:%d"
          % core.UI_PORT)

    # ---------------------------------------------------------- 1
    print("\n1. A PLAIN TURN reaches the model with memory attached")
    memory.graft("keter", "Goes by Zero and builds local AI systems",
                 origin="user", truth="confirmed")
    memory.graft("gevurah", "Everything must run offline", origin="user")
    SCRIPT.update({"tool_calls": [], "answer": "Understood."})
    e = say("what am I working on")
    check("the turn completes", any(x.get("done") for x in e))
    check("the answer streams back", texts(e).startswith("Understood"), texts(e))
    # Checks that the content REACHED the model, not which role carried it.
    # Memory and evidence now ride on the user's own message, because a
    # second system message makes Qwen and Gemma templates raise
    # "System message must be at the beginning" and return HTTP 500.
    sent = " ".join(m["content"] for m in StubModel.last_messages
                    if isinstance(m.get("content"), str))
    check("the reality frame reached the model", "Goes by Zero" in sent)
    check("boundaries reached the model", "offline" in sent)
    check("the character sheet is at the head",
          StubModel.last_messages[0]["content"].startswith("You are Nova"))
    check("the user's question is LAST",
          StubModel.last_messages[-1]["role"] == "user",
          StubModel.last_messages[-1]["content"][:40])

    # ---------------------------------------------------------- 2
    print("\n2. PREFLIGHT fires from inside the real chat path")
    SCRIPT.update({"tool_calls": [], "answer": "I could not check."})
    e = say("what is the latest version of llama.cpp")
    notes = [x["hub"] for x in e if "hub" in x]
    check("The Hub announced a research decision", bool(notes), str(notes))
    check("and said plainly that search is off",
          any("web search is off" in n for n in notes), str(notes))
    # Checks that the content REACHED the model, not which role carried it.
    # Memory and evidence now ride on the user's own message, because a
    # second system message makes Qwen and Gemma templates raise
    # "System message must be at the beginning" and return HTTP 500.
    sent = " ".join(m["content"] for m in StubModel.last_messages
                    if isinstance(m.get("content"), str))
    check("the model was told it could not check, not left to guess",
          "could not check" in sent or "possibly out of date" in sent)

    # ---------------------------------------------------------- 3
    print("\n3. PREFLIGHT stays silent on a personal question")
    SCRIPT.update({"tool_calls": [], "answer": "You told me you build things."})
    e = say("what did I tell you about my work")
    check("no research note at all", not any("hub" in x for x in e))

    # ---------------------------------------------------------- 4
    print("\n4. THE GATE runs a permitted tool")
    SCRIPT.update({"tool_calls": [tool_call("calculator", {"expression": "17*23"})],
                   "answer": "That is 391."})
    e = say("what is 17 times 23")
    check("the tool ran", any(x.get("tool") == "calculator" for x in e))
    toolmsg = [m for m in StubModel.last_messages if m["role"] == "tool"]
    check("the result came back through postflight, labelled",
          toolmsg and "[calculator - local, trusted]" in toolmsg[-1]["content"],
          toolmsg[-1]["content"][:60] if toolmsg else "no tool message")
    check("and it is the real answer", toolmsg and "391" in toolmsg[-1]["content"])

    # ---------------------------------------------------------- 5
    print("\n5. THE GATE refuses a tool Nova invented")
    SCRIPT.update({"tool_calls": [tool_call("run_shell", {"cmd": "format c:"})],
                   "answer": "I could not do that."})
    e = say("delete everything")
    ref = [x for x in e if "refused" in x]
    check("refused, and the interface was told", bool(ref), str(ref))
    check("refused for being unknown",
          ref and ref[0].get("why") == "unknown-tool")
    toolmsg = [m for m in StubModel.last_messages if m["role"] == "tool"]
    check("Nova was told why, in words",
          toolmsg and "Refused:" in toolmsg[-1]["content"],
          toolmsg[-1]["content"][:70] if toolmsg else "")
    check("nothing ran", not any(x.get("tool") for x in e))

    # ---------------------------------------------------------- 6
    print("\n6. THE PROMPT NEVER EXCEEDS THE WINDOW  (the 400 bug)")
    for i in range(80):
        memory.graft("hod", f"Recorded detail {i} about component {i} "
                            f"rated at {i*17} units", origin="user")
    big = "A long answer that goes on and on. " * 700
    hist = []
    for i in range(24):
        hist.append({"role": "user", "content": f"Tell me about {i} at length."})
        hist.append({"role": "assistant", "content": big})
    hist.append({"role": "user", "content": "and what about the last one"})
    raw = sum(len(m["content"]) for m in hist)
    msgs, _, rep = server.build_messages(hist, core.load(),
                                         "UNTRUSTED " + ("page text " * 400))
    check("a prompt that used to 400 is assembled to fit",
          rep["used"] + rep["reply"] <= rep["n_ctx"],
          f"{raw:,} raw chars -> {rep['used']} tokens of {rep['n_ctx']}")
    check("headroom is left for the reply", rep["headroom"] > 0,
          f"{rep['headroom']} tokens spare")
    check("identity survived the trim",
          msgs[0]["content"].startswith("You are Nova"))
    check("the newest question survived the trim",
          msgs[-1]["content"].endswith("last one"))
    e = say("and what about the last one")
    check("and a real turn with that much history still completes",
          any(x.get("done") for x in e) and
          not any("error" in x for x in e),
          str([x for x in e if "error" in x])[:80])

    print("\n6b. MEMORY SEARCH replaces the model writing its own memory")
    index.rebuild()
    SCRIPT.update({"tool_calls": [tool_call(
        "search_memory", {"query": "component 42"})], "answer": "Found it."})
    e = say("what did I record about component 42")
    check("the search tool ran", any(x.get("tool") == "search_memory" for x in e))
    tm = [m for m in StubModel.last_messages if m["role"] == "tool"]
    check("and it found the memory",
          bool(tm) and "component 42" in tm[-1]["content"],
          tm[-1]["content"][:70] if tm else "no tool message")
    check("there is no remember tool for the model to call",
          "remember" not in policy.TIERS)

    print("\n7. A TOOL LOOP is stopped inside a real turn")
    SCRIPT.update({"tool_calls": [
        tool_call("calculator", {"expression": "2+2"}, "a"),
        tool_call("calculator", {"expression": "2+2"}, "b"),
        tool_call("calculator", {"expression": "2+2"}, "c")],
        "answer": "It is 4."})
    e = say("keep adding two and two")
    ran = sum(1 for x in e if x.get("tool") == "calculator")
    stopped = [x for x in e if x.get("why") == "repeat-loop"]
    check("the identical call is stopped after twice",
          ran == 2 and stopped, f"ran={ran} stopped={len(stopped)}")
    check("and the turn still produced an answer", texts(e).startswith("It is 4"))

    # ---------------------------------------------------------- 8
    print("\n8. THE STATE ENDPOINT reports the supervisory layer")
    with urllib.request.urlopen(
            f"http://127.0.0.1:{core.UI_PORT}/api/state", timeout=20) as r:
        st = json.loads(r.read().decode())
    check("hub state is exposed to the interface", "hub" in st)
    check("memory counts are exposed",
          st.get("memory", {}).get("events", 0) > 0,
          f"{st.get('memory',{}).get('events')} events")
    check("the app identifies itself as The Hub",
          st.get("app") == "The Hub", st.get("app"))

    # ---------------------------------------------------------- 9
    print("\n9. THE EVENT LOG recorded the whole session")
    kinds = {e["k"] for e in events.read()}
    for want in ("leaf.plant", "hub.gate", "hub.research", "hub.tool"):
        check(f"recorded {want}", want in kinds)

    hub.shutdown()
    stub.shutdown()

    print("\n" + "=" * 62)
    print(f"  {len(PASS)} passed, {len(FAIL)} failed")
    for f in FAIL:
        print(f"    FAILED: {f}")
    print("=" * 62)
    return 1 if FAIL else 0


if __name__ == "__main__":
    try:
        code = main()
    finally:
        shutil.rmtree(_TMP, ignore_errors=True)
    raise SystemExit(code)
