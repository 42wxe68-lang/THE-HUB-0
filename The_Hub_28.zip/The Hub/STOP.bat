@echo off
title The Hub - shutdown
cd /d "%~dp0"

REM ---------------------------------------------------------------------
REM  Kills The Hub and nothing else.
REM
REM  Cairn's STOP.bat does  taskkill /F /IM llama-server.exe  which kills
REM  every llama-server on the machine, including this one. Doing the same
REM  thing here would kill Cairn's model mid-sentence. So this script only
REM  ever touches the five ports The Hub declares in core.py, and checks
REM  the image name before killing the PID it found there.
REM
REM  HUB-ZERO got the mechanism right and the numbers wrong: it kept The
REM  Hearth's ports, so this careful port-scoped shutdown was pointed
REM  straight at The Hearth. These five numbers must match core.py.
REM ---------------------------------------------------------------------

echo Asking The Hub to close cleanly...
curl.exe -s -m 5 -X POST http://127.0.0.1:8440/api/shutdown >nul 2>&1
timeout /t 3 /nobreak >nul

echo Releasing The Hub ports only (8440 8100 8101 8102 8103)...
for %%P in (8440 8100 8101 8102 8103) do (
  for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":%%P " ^| findstr "LISTENING"') do (
    for /f "tokens=1 delims=," %%n in ('tasklist /FI "PID eq %%a" /NH /FO CSV') do (
      if %%n=="llama-server.exe"   taskkill /F /PID %%a >nul 2>&1
      if %%n=="whisper-server.exe" taskkill /F /PID %%a >nul 2>&1
      if %%n=="trellis-server.exe" taskkill /F /PID %%a >nul 2>&1
      if %%n=="python.exe"         taskkill /F /PID %%a >nul 2>&1
      if %%n=="pythonw.exe"        taskkill /F /PID %%a >nul 2>&1
    )
  )
)

echo.
echo   The Hub is out. Anything else on this machine is untouched.
timeout /t 2 >nul
