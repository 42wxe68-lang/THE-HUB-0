# DECISIONS

Architectural decision records. Each one states what was decided, why, what
was rejected, what evidence exists, what it costs, and what would make it
worth revisiting. A decision without a revisit condition is a belief.

---

## ADR-01 — The sephirot are limbs, not lists

**Decision.** Each of the eight upper sephirot is a `grove.Limb` holding
branches holding leaves. Yesod and Malkuth stay as files.

**Why.** Cairn's topology was right and its contents were dead: a node was
`{text, tags, created}` and nothing distinguished a fact used every day from
one nobody has referred to since it was written. Luminova had exactly the
missing part — weight, decay, reinforcement, pins — and only three limbs to
put it in. Neither is sufficient alone; both together are.

**Alternatives rejected.**
- *Keep Cairn's flat lists and add a `weight` field.* Half the mechanism.
  Branches are what let a sephira grow structure as its subject matter
  grows, and without them Hod is one undifferentiated pile of 60 facts.
- *Adopt Luminova's three limbs and drop the sephirot.* Loses the thing that
  makes placement meaningful. "Identity" and "boundary" are different kinds
  of memory; `core` does not express that.
- *Ten limbs from scratch.* Would have thrown away both working
  implementations to write a third.

**Evidence.** `test_hub.py` scenario 9; `python classify.py` at 68 cases,
0 hard failures.

**Cost.** More moving parts than a list. A sephira can now be structurally
wrong — an over-budded branch set — in a way a list cannot.

**Revisit if.** Branch counts grow faster than leaf counts in real traffic,
which would mean `BUD_THRESHOLD` is too low and the tree is fragmenting.

---

## ADR-02 — Nothing is deleted; faded memories fall to ash

**Decision.** A leaf that decays below the floor, or is evicted by a cap, or
is removed by hand, is appended to `data/ash/ash.jsonl` before it leaves the
living tree. That file is never rewritten or trimmed.

**Why.** Cairn's cap dropped the oldest node on the floor. Luminova's prune
deleted faded leaves outright. Both treat "not currently relevant" and
"never happened" as the same state, and they are not. A claim that turned
out to be wrong is worth more than a claim that was never made, because
knowing you were wrong is information.

**Alternatives rejected.**
- *Keep everything in the living tree forever.* The Active Tree has a
  budget; an unbounded tree means recall degrades to noise, which is the
  15,224-observations failure from Vera in a different costume.
- *Soft-delete with a `deleted` flag in the tree file.* The tree file is
  derived and gets rewritten. The ash needs to be append-only to be trusted.

**Evidence.** `verify.py` "faded leaves fall to ash rather than being
deleted"; `test_hub.py` scenario 12.

**Cost.** `ash.jsonl` grows without bound. At ~300 bytes a leaf that is
roughly 3 MB per 10,000 memories, which is not a problem on any machine that
can run a 2.6B model.

**Revisit if.** The ash file passes ~200 MB, at which point it wants a
yearly roll like the event log has.

---

## ADR-03 — The event log is the source of truth

**Decision.** Every plant, ash, branch-bud, digest, truth change and gate
decision is appended to `data/events/events.jsonl`. `memory.rebuild()`
reconstructs the living tree from it alone.

**Why.** Cairn's memory *was* `tree.json`. If that file went wrong the
memory was wrong, and there was nothing underneath to appeal to. A system
that cannot be repaired is a system whose worst day is permanent.

**Alternatives rejected.**
- *Periodic backups of the tree.* Backs up corruption just as faithfully.
- *A database with a write-ahead log.* Adds a dependency to an application
  whose whole promise is standard library only.

**Evidence.** `verify.py` deletes `data/tree` and rebuilds on every run;
`test_hub.py` scenario 12 asserts identity and boundaries survive.

**Cost.** Decayed weights cannot be reconstructed exactly, because decay is
a function of wall-clock time. Rebuild replays planting weights and ages
forward, so a rebuilt tree is *equivalent*, not *identical*. This is stated
in the docstring rather than hidden.

**Revisit if.** Something needs exact weight restoration — then the pruner
would have to write weight snapshots as events.

---

## ADR-04 — Placement is decided in Python, never by a model

**Decision.** The curator returns a flat list of statements. `classify.place()`
assigns the sephira, with a confidence distribution. `remember` has no
`where` argument.

**Why.** Cairn asked a 350M model for `{"keter":[],"chesed":[],...}` and a
2.6B model for an eight-value enum of Hebrew names, mid-conversation. Small
models under structural load take the first branch they recognise, so the
crown of the tree filled with facts about graphics cards. The model is good
at reading a conversation and saying what was said; it is bad at
taxonomy-in-JSON. Give each the job it is good at.

**Alternatives rejected.**
- *A better prompt.* This is the failure mode prompting cannot fix — it is
  a capability limit, not an instruction problem.
- *An embedding classifier.* Adds a model and a dependency to solve a
  problem that ~200 lines of readable, testable, arguable rules solves at
  0 hard failures.

**Evidence.** `tests/placement.jsonl`, 68 cases, 0 hard failures, 7%
unsorted. "Coconuts are tropical fruits" → Hod, not Keter.

**Cost.** Keyword rules are English-only and need maintenance as vocabulary
drifts.

**Revisit if.** Unsorted exceeds ~25% on real traffic, or a class of
statement is consistently misfiled. The parked file is the dataset for that
argument.

---

## ADR-05 — Unsorted is a legitimate outcome

**Decision.** When `place()` cannot reach `MIN_CONFIDENCE`, the statement is
written to `data/tree/unsorted.jsonl` rather than filed.

**Why.** A memory filed in the wrong sephira is invisible forever, because
nobody looks in the crown for a detail about a graphics card. A parked one
is readable, reviewable, and is the training data for improving the
classifier.

**Alternatives rejected.**
- *Always guess.* Optimises the metric that is easy to measure at the
  expense of the one that matters.
- *Drop it.* Silent loss, which this project treats as the worst class of
  bug.

**Evidence.** 7% parked on the benchmark. `tools.remember` returns a plain
explanation rather than a false success.

**Revisit if.** Parked statements accumulate without ever being reviewed —
which would mean the UI needs a re-file affordance, not that the policy is
wrong.

---

## ADR-06 — The research trigger lives outside the model

**Decision.** `research.preflight()` runs before Nova is called. If it says
the question depends on the outside world, The Hub searches, and hands
Nova the evidence.

**Why.** The alternative is a line in `character.md` saying "use web search
when the answer depends on current information". That is asking the model to
notice its own blind spot, and it will forget exactly when it is most
confidently wrong. **This is the failure the whole application exists to
prevent, so it must not be implemented as a prompt instruction.**

**Alternatives rejected.**
- *Prompt instruction.* Recreates the failure.
- *Always search.* Sends private sentences to a search engine and burns
  latency on "what time is it".
- *Let Nova decide and check afterwards.* Too late — the wrong answer is
  already streaming.

**Evidence.** `tests/research.jsonl`, 44 cases, 0 false positives, 0 false
negatives. `test_hub.py` scenarios 1 and 2.

**Cost.** A deterministic classifier will miss phrasings a model would
catch. Every decision is logged to `data/logs/research.log` so the misses
are countable rather than arguable.

**Revisit if.** False negatives appear in real use. Add the phrasing to the
corpus first, then the rule.

---

## ADR-07 — Suppressors are checked before signals

**Decision.** Privacy and locality suppressors run first and end the
decision. Signals are only scored on what survives.

**Why.** "What did I tell you about my daughter" contains a question, a
proper noun and the present tense. Every signal fires. Searching for it
would be a privacy failure, and a privacy failure is worse than a
helpfulness failure because the user never finds out it happened.

**Evidence.** `test_hub.py` scenario 2 asserts `suppressed_by ==
"personal"` **and** that no query string was constructed at all.

**Revisit if.** Never, for the personal and memory suppressors. The clock
and arithmetic suppressors could be revisited if those tools were removed.

---

## ADR-08 — A question mark is not a signal

**Decision.** `QUESTION` adds 0.5 only when at least one real signal is
already present. Alone it decides nothing.

**Why.** "Why do I keep doing this?" and "How does a hash map work?" are
both questions, and neither wants the internet. Treating interrogative form
as evidence of currentness makes the classifier fire on curiosity.

**Evidence.** Nine of the 44 research cases are questions expecting `false`.

---

## ADR-09 — Default deny at the capability gate

**Decision.** `policy.TIERS` is the whole policy. A tool absent from it is
refused. Tiers are AUTO / LIMITED / CONFIRM / REFUSE.

**Why.** A registry that runs anything it recognises is a list of exceptions
to permission. A gate that refuses anything it does not recognise is
permission with a list of exceptions. The second one fails safe when
somebody adds a tool and forgets to think about it.

**Evidence.** `test_hub.py` scenario 3: `run_shell` is refused for being
unknown, not for looking dangerous.

**Cost.** Adding a tool means adding two rows — a tier and an argument
shape. That friction is the feature.

---

## ADR-10 — Untrusted content taints the turn, and taint blocks further search

**Decision.** Once a web result enters a turn, `web_search` is refused for
the rest of it.

**Why.** Exfiltration, not politeness. A poisoned page that can induce one
more search controls the query string, and the query string goes to a third
party. One search per poisoned page is a nuisance; a loop of them is a
channel out of a machine whose entire promise is that nothing leaves it.

**Alternatives rejected.**
- *Sanitise and continue.* Sanitising is a filter, and filters are guessed
  at; the nonce spotlighting already does what filtering can do.
- *Allow a lower search budget after taint.* A smaller channel is still a
  channel.

**Evidence.** `test_hub.py` scenarios 4 and 5.

**Cost.** Real. A legitimate follow-up search in the same turn is refused,
and Nova is told to answer from what it has.

**Revisit if.** This proves annoying in daily use — measure how often it
fires on non-adversarial turns first. Security got the initial vote
deliberately; the measurement comes after, not instead.

---

## ADR-11 — State changes are staged, not blocked

**Decision.** `remember` is CONFIRM tier. The gate stages the write, returns
"held for the user", the reply keeps streaming, and the UI shows Keep /
Discard.

**Why.** A confirmation that blocks the stream makes every remembered fact a
pause in the conversation, and a memory system nobody lets run is not a
memory system. Staging gets the control without the interruption.

**Alternatives rejected.**
- *Block until answered.* Ruins the conversation.
- *Auto-approve.* Nova writes to durable memory unattended, which is the
  thing this tier exists to prevent.

**Evidence.** `test_hub.py` scenario 8, both approve and decline paths.

**Cost.** A staged write that is never answered never happens. Acceptable:
the statement is still in the session transcript, and the curator will see
it again.

**Revisit if.** Users approve everything without reading, which would mean
the tier is theatre. `hub.confirm_writes` turns it off honestly.

---

## ADR-12 — Postflight is the only path back into context

**Decision.** Every tool result passes through `policy.GATE.postflight()`,
which labels provenance and applies taint.

**Why.** If a result can re-enter Nova's context by any other route, then
"untrusted content is marked" is a convention rather than a property. It has
to be structurally true. Taint is applied here rather than at the call site
so a tool that grows a network path later cannot forget to declare it.

**Evidence.** `test_hub.py` scenario 5: `postflight` alone sets taint.

---

## ADR-13 — Hearth's ports are Hearth's, and shutdown is port-scoped

**Decision.** 8430 / 8090 / 8091 / 8092, declared in `core.py`. Orphan
sweeps find the PID listening on those ports and check the image name before
killing.

**Why.** Cairn does `taskkill /F /IM llama-server.exe` on startup and in
`STOP.bat`. Copying that into The Hub means starting one application
kills the other's model mid-sentence. Cairn is the fallback and must keep
working.

**Evidence.** `verify.py` asserts no Hearth port collides with Cairn's.
`runtime.sweep_ports()` and `STOP.bat` both check image names.

**Cost.** Four hard-coded ports. A third application in this family needs a
third set — which is correct, and better than discovery, because a declared
port is what makes a scoped shutdown possible at all.

---

## ADR-14 — KV cache stays f16 until measured

**Decision.** `runtime.kv_type` defaults to `f16`. Quantised KV is
configurable and not enabled.

**Why.** It is not established whether the pinned build `b10456` has the
CUDA kernel for quantised attention. If it does not, attention falls back to
the CPU **with no error**, and generation halves in speed. A silent
performance cliff is worse than a known ceiling, and this project's stated
rule is not to make speculative performance changes.

**Evidence.** None yet. That is the point.

**Revisit if.** `bench_llama.py` is run against the live server on the
target machine — which is the top item in NOT YET.

---

## ADR-15 — Small models by default

**Decision.** The installer fetches LFM2.5-2.6B-Q4_K_M (~1.6 GB) and
LFM2.5-350M-Q8_0 (~0.4 GB). Nothing else.

**Why.** ~2 GB installs in minutes and leaves room for the curator to spawn
beside the main model, which is the entire reason for having a background
memory model. A large model that fills VRAM means memory consolidation
cannot coexist with conversation.

**Alternatives rejected.**
- *Ship with the largest model that fits.* First run then either works or
  fails for reasons that have nothing to do with The Hub.
- *Link to models already on the machine.* Breaks the day that folder moves,
  and the failure looks like a Hearth bug. `get_model.py --import` copies,
  explicitly, when asked.

**Revisit if.** The 2.6B proves too weak at the tool phase — measure with
BFCL before swapping, and note that the gate is designed to carry a weak
model rather than depend on a strong one.


---

## ADR-16 — ONE tree. Knowledge is Da'at. (supersedes part of ADR-01)

**Decision.** The separate Knowledge Tree is gone. What was worked out lives
in Da'at, a limb of the single Tree of Life, with the four domains as its
branches.

**Why the reversal.** Copying Vera's separation copied her *solution*
without her *problem*. Her camera planted 15,224 observations against 30
conversations; a second tree was the cheapest way to stop knowledge
drowning. The Hub has no camera firehose, and a limb with its own decay
rate and its own cap solves the same problem inside one structure. Two trees
meant two ageing rules, two rebuild paths, two search paths, and two places
to look for one memory.

**What was kept.** All of Vera's routing vocabulary — ~400 lines of curated
domain keywords and the unigram/bigram/trigram scoring. It decides which
branch, and stores nothing.

**Revisit if.** A perception source is added that plants at high volume. Then
the answer is still not a second tree — it is a limb with a lower weight
ceiling.

---

## ADR-17 — The curator process is gone; the loaded model organises its own memory

**Decision.** No second model. `consolidate.Session` takes the one loaded
model, and while it holds it the chat endpoint answers 409 with what it is
doing.

**Why.** 350M parameters is not enough to read a conversation, which is why
it needed a rigid schema, which is why it put everything in the first field.
And on the measured target machine it could not spawn at all: free RAM
bottomed at 0.1 GB with the 20B loaded. A background process that cannot run
on the machine it was written for is not a feature.

**Cost.** Nova cannot talk while organising. That is one mind doing one thing
at a time, said out loud, and consolidation only starts after 25 seconds of
quiet and stops the moment the user types.

---

## ADR-18 — Every prompt is budgeted against the context window

**Decision.** `budget.Plan` divides n_ctx before assembly. Each section is
trimmed by dropping whole items from its weakest end.

**Why.** This is the `error: 400` bug. Six growing blocks were added together
and sent, counting nothing. Two turns with a long answer and a search result
went past 8192 and llama-server refused the request. Deleting memories made
it work again, so it looked like a memory bug — memory growing was correct
behaviour, and the missing piece was the thing that decides how much of it
fits today.

**Evidence.** 588,665 characters of raw material assembled to 2,040 tokens
inside an 8,192 window with 5,128 spare, in `test_live.py` scenario 6.

---

## ADR-19 — Taint blocks the query, not the turn (supersedes ADR-10)

**Decision.** After untrusted content enters a turn, a search is refused only
if its query shares two or more uncommon words with what was retrieved.

**Why the reversal.** ADR-10 said measure usability later, and later arrived.
In real use the blanket rule fired on the ordinary case: Hearth's own
preflight search tainted the turn, Nova's follow-ups were refused, and she
answered from training data **while citing a Wikipedia URL she had never
read**. The rule did not prevent a bad answer, it caused one.

**What is still protected.** The actual exfiltration path is a poisoned page
putting *its* words into a query that leaves the machine. That is now checked
directly, which is narrower and stronger than refusing everything.

---

## ADR-20 — The fit check advises; it never refuses

**Decision.** `runtime.plan()` has no refusal path. It lowers n_ctx to make
the chosen model fit and says so, or warns and starts anyway.

**Why.** An earlier version returned `{"ok": False}` and `/api/model` passed
that to the dropdown, so a model downloaded on purpose could become
permanently unselectable — a capability Cairn had and this removed. Worse,
the numbers doing the blocking (`MMAP_RESIDENT`, the GPU share) are
calibrated guesses. **A guess must never outrank a decision.** llama.cpp is
the only component qualified to say a model will not load.

**Consequence.** GPT-OSS-20B-HauhauCS-Balanced-MXFP4 loads, because it has
been tested and it works.


---

## ADR-21 — One switch. Everything else is automatic.

**Decision.** `config.tools` contains `web_search` and nothing else. The
`hearth` and `knowledge` config sections are deleted. The clock, calculator,
memory search and file reading are always available.

**Why.** The settings surface had grown to six tabs and eight checkboxes, and
almost every one of them was a switch on the memory or the search — the two
things this application exists to do. A toggle that disables memory placement
produces an assistant that looks like it is working and quietly remembers
nothing, which is a worse failure than not having the feature. Web search
stays a switch for one reason: it is the only thing that leaves the machine.

**Consequence.** `policy.Gate` now asks `tools.enabled()` rather than reading
config directly, so the schema list offered to the model and the gate's own
view of what exists can no longer disagree.

---

## ADR-22 — Knowledge renders inside the tree, not beside it

**Decision.** The KNOWLEDGE tab is gone. Da'at renders as a sephira in the
memory tree, grouped by its subject branches.

**Why.** ADR-16 already made knowledge a limb of the one tree. Leaving it a
separate panel in the interface contradicted that in the only place the user
can actually see: structurally it was in the tree, visually it was still a
side feature. All memory now has exactly one place to be looked at.

---

## ADR-23 — Vision is probed, never configured

**Decision.** `config.vision.enabled` is gone. `vision.probe()` runs when the
model loads, beside the context-window measurement, and confirms sight
against a generated test image before believing it.

**Why.** The toggle was a switch with no wire behind it — turning it on did
nothing, because nothing checked whether the loaded model could see and
nothing converted a file into something a model could look at.

**Why probed rather than declared.** Luminova's sight system already
documented the failure mode: the wrong input size yields *a fluent
description of nothing*. A model without working vision handed an image does
not error. It describes a plausible image. So `/props` and the GGUF header
only nominate a candidate; a flat red square settles it.

**The two layers.** Measurement always runs and never needs a model —
dimensions, dominant colours by hue, brightness, contrast, geometry,
embedded text, duration. The model's description is added on top and labelled
as an interpretation. A colour histogram is measured; an account of a
photograph is not, and the output says which is which.

**Revisit if.** A dedicated vision model can be loaded alongside the main one.
That needs the memory headroom that ADR-17 measured as unavailable.


---

## ADR-24 — The interface is tested like code

**Decision.** `test_ui.py` runs on every check. It resolves every `$("id")`
against the markup, executes the whole script against a minimal DOM with a
real `/api/state` payload, and asserts the model dropdown ends up populated.

**Why.** Three regressions shipped in a row, all in `ui.html`, all invisible
to a suite that only exercised Python:

1. the system prompt pane was orphaned — its tab button was deleted, its
   loader left running on a condition that could never fire
2. `$("savehth").onclick = ...` survived the panel it belonged to. That is
   top-level code. `null.onclick` throws, and **every line after it never
   ran** — the model list, the status poller, the send button. The page
   loaded and sat there inert. This is the reported "LLM bar shows nothing".
3. `lockParams()` lost its only caller when the same panel went, so the
   runtime fields silently stopped locking during a load

**The part that stings.** Cairn's own `refresh()` already carried the
comment: *"Every section is wrapped separately: one failing block can never
blank the others. That bug cost us the model list once already."* It cost the
model list a second time because that lesson lived in a comment instead of a
test. A comment warns whoever reads it; a test stops whoever doesn't.

**Also added.** `wire(id, event, fn)` — attaching a handler to an absent
element is now a console warning, not a page-killing TypeError. Removing a
panel can no longer take the application down with it.

**Evidence.** Reintroducing the exact bug makes the suite fail twice, once
statically with the offending line quoted and once by execution, and exit 1.

---

## ADR-25 — A saved config is pruned on load

**Decision.** `core._prune()` strips keys that no longer exist — the old tool
switches, `hearth`, `knowledge`, `curator_model` — every time config loads.

**Why.** The merge kept unknown keys, so a config written by an earlier build
silently restored switches that were deliberately removed. An upgrading user
would have `clock`, `calculator` and `remember` back in their file, disagreeing
with an interface that no longer shows them, and `tools.enabled()` reading a
value nothing can set.


---

## ADR-26 — Memory has no controls

**Decision.** "Organise memory now" and "Rebuild tree" are gone, and so are
`/api/curate` and `/api/rebuild`. The interface reports what memory is doing
and offers nothing to press.

**Why.** A button means it is not automatic. Consolidation was on a
twenty-minute timer with a manual override, which is two wrong answers: a
timer is a number somebody has to guess, and an override exists because the
timer is wrong.

**What replaced it.** `memory.pressure(n_ctx)` — how much of THIS model's
window living memory currently wants. Over half, and the idle loop
compresses. A 4k model compresses early, a 32k model is left alone, and
below 2048 it reports `negligible` and does nothing, because a summary that
does not fit is not a saving.

---

## ADR-27 — The cascade, and the ranked front door

**Decision.** Memory compresses upward — leaves → digests → daily → monthly —
and everything entering a prompt comes through `memory.context()`, which asks
the search engine to rank the whole store and returns the top of that ranking
until the token allowance is spent.

**Why.** `frame()` took the last eight leaves per sephira. That is fine at a
hundred leaves and absurd at a hundred thousand. A search engine does not
hand you the index, it ranks and gives you a page — and that is the only
structure that lets the store grow to a library while the prompt does not
grow at all.

**Measured.** A 3,004-item store returns a 988-character context in 0.01s.
Growing it to 1,448 items changed the context length by nothing.

**Anchoring.** Identity and boundaries are not ranked. They are small, pinned
and always present — being outranked by a well-matching note about a
regulator is not a tradeoff worth having.

---

## ADR-28 — Two real defects found while building the above

**The ash path was captured at import.** `ASH_FILE` was a module constant
built from `core.ASH` when grove first loaded, while the `mkdir` beside it
used the *current* `core.ASH`. Anything that relocated the data directory
made them diverge, and `except Exception: pass` swallowed the failure — a
leaf could leave the living tree and never arrive in ash. That is the one
promise memory makes. The path resolves at call time now, the event is
written before the leaf is let go, and a failed write is logged loudly.

**Rebuild never restored the caps.** Replay ran with `cap=0` deliberately, so
that history replays by weight rather than ashing in arrival order. But the
caps were never put back, so a rebuilt limb grew without limit forever after
— measured at 1,442 leaves in a limb capped at 60, every one of them counting
toward context pressure. One repair quietly turned the working set into a
landfill. Caps are restored and settled at the end of rebuild.

---

## ADR-29 — Sight asks the probe, and every image source reaches it

**Decision.** The chat path gates images on `vision.capability()`, not on
`config.runtime.mmproj`. Cameras are enumerated and selectable. Web results
bring back the pictures a page is about.

**Why.** "Vision doesn't work" had a plain cause: the image path was gated on
a config field the user had to know to type. A model with working eyes stayed
blind because a text box was empty.

**When the model cannot see.** The frame is not discarded. It is measured —
size, dominant colours by hue, contrast, any readable text — and handed over
as facts, labelled as measurement. Useful either way, and never a description
of an image the model never processed.

**Compound words.** Found while testing retrieval: `Hailo-10H` indexed as one
token, so a search for "hailo" found nothing. Model names, part numbers and
versions are exactly what people half-remember, and exactly what carries
hyphens. Compounds now index as themselves and as their parts.


---

## ADR-30 — Sight: a projector, a helper, or honest measurement

**Researched before building, against llama.cpp's own documentation.**

**The fact everything follows from.** A projector is architecture-specific.
Confirmed on the llama.cpp tracker: an InternVL3 `mmproj` was tried against
gemma3, gpt-oss and qwen3.6 and none of them would accept an image. It cannot
be borrowed, and no configuration works around it.

**What was actually installed.** Seven GGUFs on the machine, **not one
projector among them**. `Qwen3.5-9B-Uncensored` is not `Qwen3-VL` — a
different model line entirely. Vision was never going to work, and the app
reported "fine" on load because nothing was broken; the models simply have no
eyes. That is the failure this ADR exists to make impossible to miss.

**Routing, and nothing else decides it:**

| | |
|---|---|
| model has a matching projector | the image goes straight to it |
| model does not | a small VLM on port 8091 describes it; that text enters the turn |
| neither installed | measured, and it says plainly that nothing looked |

**A model that can see is never routed through the helper.** Looking beats
reading someone else's description. This is asserted in the suite, by
replacing `sidecar_look` with a tripwire and checking it is never called.

**Detection, from documented fields only.** `/props` → `modalities.vision`,
then `/v1/models` → `architecture.input_modalities`, which the server README
tells clients to check before a multimodal request. Then a flat red square,
because a broken projector produces a confident description rather than an
error. The previous version read `props.has_multimodal`, `props.mmproj` and
GGUF keys beginning `clip.` — **none of which exist** — so it returned False
identically whether the model was blind or the detection was broken.

**`--mmproj` was also gated on `gpu`.** Multimodal does not need a GPU;
`--no-mmproj-offload` exists precisely for a full card. Gated that way, a
CPU-only machine could never have seen anything.

---

## ADR-31 — Rebuilt from the last working version, not from the broken one

The memory rewrite replaced the store without migrating it, so memories
became unreachable. That work is **discarded**, not repaired. This build
starts from the version that worked and carries across only changes with a
confirmed cause and a test:

- `RECALLABLE` omitted **netzach** and **chesed**, so "my daughter Ada is
  learning piano" scored 0.705 relevance and was never returned — the limb
  holding it was not in the searched list. People and preferences were being
  stored and made unreachable. One line; four questions now answer correctly.
- **Save settings did nothing.** `d.tools` was never initialised while the
  loop writing into it remained, so the handler threw before `saveCfg()`. The
  interface suite now invokes every handler, because a click handler only
  throws when it runs.
- **`OverconstrainedError` on the camera.** Before permission,
  `enumerateDevices()` returns empty device ids, so `{exact:""}` matched
  nothing and the first capture always failed. Permission is requested
  unconstrained first, then constraints narrow down a ladder — Chromium
  misreports an unsatisfiable resolution as `constraint:"deviceId"`, so the
  blamed constraint cannot be trusted.


---

## ADR-32 — Qwen3.5 is natively multimodal, and I said otherwise

**The correction.** I told the user their `Qwen3.5-9B-Uncensored-Q4_K_M.gguf`
was "not Qwen3-VL, a different model line, text-only." **That was wrong.**

Unsloth's Qwen3.5 documentation: *"The multimodal hybrid reasoning LLMs...
excel in agentic coding, vision, chat"* and *"Currently no Qwen3.5 GGUF works
in Ollama due to separate mmproj vision files."* The HauhauCS card for that
exact build: *"This model is natively multimodal. The mmproj file is the
vision encoder — you need it alongside the main GGUF."*

The model was never blind. One 918 MB file was missing.

**The bug this exposed.** unsloth ships the projector as a bare
`mmproj-F16.gguf` - no model name, because the repository supplied it.
`find_projector` required two matching name tokens, scored zero, and returned
None. **Downloading the correct file would still have left vision off.**

**And the fix's first attempt was worse.** Relaxing the matcher paired
Qwen3.5's projector with Llama-3.1, because both filenames contain
"uncensored" and "q4" - two tokens, enough to clear the bar, entirely wrong
architecture. Quantisation tags and generic words are now excluded from
scoring; only the model family and its size count.

**Three conventions, all handled:**

| filename | rule |
|---|---|
| `mmproj-gemma-3-4b-it-Q8_0.gguf` | matched on distinctive tokens |
| `<model>.mmproj.gguf` | exact twin, checked first |
| `mmproj-F16.gguf` | generic — paired only when alone with one model |

A generic projector loose among several models is refused, and the sight
line names the exact filename to rename it to. `get_model.py vision
qwen35-9b-vision` downloads it already correctly named.

---

## ADR-33 — Thinking is off by default on Qwen3.5's small models

Unsloth: *"For Qwen3.5 0.8B, 2B, 4B and 9B, reasoning is disabled by default.
To enable it, use `--chat-template-kwargs '{"enable_thinking":true}'`."*

So a model that can reason silently does not, and nothing about that is
visible from outside. Every request now carries
`chat_template_kwargs.enable_thinking`, default on, switchable via
`sampling.thinking`. A chat template that never mentions the key ignores it,
so it is safe on every other model.


---

## ADR-34 — Two faults, both read from the llama.cpp log

Diagnosed from `llama.log`, not guessed at.

### A projector was being loaded as a main model

```
E llama_model_load: error loading model: CLIP cannot be used as main model,
                    use it with --mmproj instead
E srv  llama_server: exiting due to model loading error
```

`core.models()` returned every `*.gguf` in the folder, so each projector
appeared in the dropdown. Selecting one passed it to `-m`, llama-server
exited immediately, and the interface reported

```
[WinError 10061] No connection could be made because the target machine
actively refused it
```

which describes a dead server rather than the actual fault. Every projector
downloaded made the list worse - and the more the user did right, the more
broken it looked.

`core.models()` now excludes them; `core.projectors()` reports them
separately. `find_projector` is unaffected: it scans the directory itself.

### Every turn carrying memory or an image returned HTTP 500

```
Error: Jinja Exception: System message must be at the beginning.
{"code":500,"type":"server_error"}
```

`build_messages` appended memory and search results as **further system
messages** just before the question. Qwen3.5, Qwen3-VL and Gemma 4 chat
templates all raise on a system message that is not the first.

The placement instinct was right - volatile context belongs next to the
question, where a small model pays most attention. The mechanism was wrong.
That context now rides **on the user's own message**, so there is exactly one
system message and it is first. `budget.emergency_trim` enforces the same
invariant, since trimming is when it would be hardest to spot.

### What the log also proved

```
I srv  load_model: loaded multimodal model,
       '...\Qwen3.5-9B-Uncensored-Q4_K_M.mmproj.gguf'
I srv  llama_server: model loaded
```

Automatic projector pairing **works**. Qwen3.5-9B-Uncensored loaded with
vision. The image then failed on the chat template, one layer above - which
is why sight appeared broken when it was not.


---

## ADR-35 — A model with eyes must be handed the picture, not a paragraph about it

**The evidence.** A saved session in which Nova opened `IMG_0247.JPG` and
replied with real measurements - `dark grey #3e3e3e covering about 42%`,
`4032x3024` - and then: *"I'd need to see the full image to describe specific
subjects or details."*

Accurate. Useless. And the model **could** see: Qwen3.5-9B had loaded with its
projector.

**The cause, in my own comment.** `vision.look()` returned measurements when
the model could see, with the note *"the caller sends the image to the model
itself."* But the caller is `open_file` — a TOOL — and a tool result is text.
There was no mechanism to put a picture in front of the model, and no owner
for the responsibility that comment assumed.

**The fix.** `policy.Gate` gains a per-turn attachment channel, cleared with
every other per-turn state. `open_file` registers the file; the chat path
attaches it as a real `image_url` message after the tool phase, once,
consumed. Measurements still travel with it, because a colour histogram is a
measured fact and a description is not.

**Also.** `runtime.benchmark()` computed `can_consolidate` and **nothing ever
read it**. Background memory work now requires both room (>800 MB) and speed
(≥6 tok/s) — organising a day of conversation is several generations, and at
3 tok/s on a 9B that is minutes of a laptop being unresponsive while the user
waits. Recording and search are unaffected; only the summarising pass is
skipped, and the reason is reported.

**And the character sheet now says what Nova can do:** open anything in the
vault without asking, look at images directly once opened, read PDFs, code and
markdown, get real dimensions from STL and OBJ. With the counterpart rule —
when it cannot see, report measurements as measurements and never describe
subjects, mood or composition it has not seen.


---

## ADR-36 — Three things were blocking research, and one of them was the safety rule

Diagnosed from a transcript in which the user said *"anytime I say continue,
do deeper research"* and got nothing back, five turns in a row.

### The taint rule was refusing the research it was meant to protect

ADR-19 refused a search sharing two uncommon words with a retrieved page.
**Following a topic means reusing its vocabulary.** Asked about humanoid
robots, given a page about humanoid robots, the obvious next search is
"GROOT humanoid robot" — refused, every time, for containing the words the
USER introduced.

The comparison is now against the **user's own vocabulary**, matched by
prefix so "robots" covers "robot", and the bar is three terms rather than
two. Only words that appear in the retrieved content and **nowhere in the
conversation** count as carried out. The security property is unchanged and
narrower: a poisoned page cannot put ITS words into an outbound query. A word
the user supplied is the user's word, whatever else also contains it.

This is the third revision of this rule. Each earlier one failed in the same
direction — too broad, blocking real work, and the harm it caused was never
hypothetical while the attack it prevented always was.

### The search ceiling made deeper research structurally impossible

`web_per_turn: 3`. Research is iterative — search, read, notice a gap, search
the gap — so three was spent before anything could be written. Now 10, with
`calls_per_turn` 20 and the tool phase widened from 3 rounds to 6. The
`identical_calls` guard is untouched at 2, because repeating one query is the
actual runaway, and that is what should be caught.

### The model reasoned past the token limit and never answered

GPT-OSS and the Qwen thinking models emit reasoning on a separate channel.
When `max_tokens` is spent during reasoning there is no answer at all, and
the interface showed the thinking followed by *"(no text came back — try
raising max_tokens in settings)"* — handing the user a setting instead of a
reply.

One automatic retry now runs with `enable_thinking: false`. The model has
already done the reasoning; it simply never got to speak. Proven against a
stub that reasons until it hits the limit: where the user got nothing, they
now get an answer.


---

## ADR-37 — The window sizes itself, at the ceiling

**The question that prompted it:** why is `n_ctx` a setting at all, when the
system already measures everything needed to decide it?

It had no good answer. `gguf.py` already read the model's trained context
from its header. `plan()` already clamped a typed number down to that, then
lowered it again to fit measured memory. `benchmark()` already read back what
llama-server actually granted. The user's number was a guess that got
overruled twice and reported back as something else — being asked for a value
that is not the one used is worse than not being asked.

**Both numbers are now `"auto"`:**

```
n_ctx       min(model's trained context, largest that fits, 32768)
max_tokens  n_ctx // 3        (the share budget.Plan already reserves)
```

**Auto means the CEILING, not the floor.** A window smaller than necessary is
the direct cause of the failure this removes: the model runs out of room and
answers nothing. Given a choice, take the room. `CTX_AUTO_MIN` is 4096 so auto
can never land somewhere a conversation and a memory will not both fit.

**`max_tokens` was the constant 1024**, and that is what produced *"no text
came back — try raising max_tokens in settings"*. A thinking model spends its
whole allowance reasoning and emits no answer. An 8192 window now allows 2730.

**The manual override stays**, because fitting is not the only consideration:
a large window costs prompt-processing time on every turn, so capping it on a
slow model is a legitimate choice a measurement cannot make. What changed is
that the user is no longer required to make it. A typed number is still
clamped to what the model was trained for — asking an 8k model for 32k does
not give you 32k, it gives you a failed load or silent truncation.

**`runtime.live_ctx(cfg)`** is the one place that answers "what window is in
force". What the server GRANTED wins over what config asked for; budgeting
against a lowered request is how a prompt overflows a window it was told it
had. Three other call sites were casting `cfg["runtime"]["n_ctx"]` straight
to `int` and now raise on the string `"auto"` — all routed through it.

**Two bugs the suites caught during this change:**

- the settings form ran every sampling value through `num()`, so `"auto"`
  became `NaN` and then silently reverted to the previous number — an
  automatic setting quietly becoming a typed one on the first save
- `autonum()` called `.trim()` on `.value` without coercing to string, which
  threw and killed the whole save handler before `saveCfg()` — the same class
  of failure as ADR-33, caught this time because the suite clicks the buttons


---

## ADR-38 — The pipeline. Keep the Tree, rebuild what feeds it.

The finalized memory direction, implemented. **This is not a redesign of the
foundation** - the Tree, the event log, lexical retrieval, Cairn's structure
and Vera's knowledge routing all stay. What was missing was everything
around them.

```
USER / WORLD → INGESTION → CANDIDATE → MEMORY → RETRIEVAL
                                                    ↓
                              NOVA ← ACTIVE PERCEPTION ← FOCUS + TASK
```

### Rule 1 — not everything becomes memory  (`intake.py`)

`graft()` was the front door, so anything reaching it entered the Tree. That
is why it filled with "lol ok" and half-sentences. A memory system whose
intake is "whatever arrived" is a log.

`observe()` now takes everything cheaply and scores it: lexical shape,
provenance, repetition, specificity, and whether `classify` can place it at
all. Below 0.20 it is discarded with a reason. Above 0.55 it is promoted.
**Said in two separate turns promotes it regardless of score** — a person
repeating themselves is telling you it matters. Held candidates expire after
30 days unmentioned.

Measured: `lol ok` 0.00, `what time is it?` 0.00 (a question, not a
statement), `The card is loading right now` 0.12 (true now, not worth
keeping), `Everything must run offline` 1.00.

### Rule 2 — Nova does not decide where memory belongs

Nothing in `intake.py` calls the model; the suite asserts it. Scoring is
deterministic and explainable, and placement is `classify.place()`, which has
68 cases behind it. The model can neither choose a sephira nor force a
promotion.

### Rule 3 — memory is larger than context  (`focus.perception`)

Nova receives an assembled slice — **anchor, focus, relevant, recent** —
bounded in tokens before assembly. Measured: 1,082 characters out of a 365-leaf
tree, and it does not grow when the tree does.

### Rule 4 — time matters  (`superseded`)

A new truth state, distinct from `contradicted`. "I use vim" followed by "I
use helix now" is one fact with a history, not two in conflict. The earlier
leaf is marked superseded, ranks at 0.35 of its former relevance, stays
findable as history and stops being reported as current. Supersession is
detected at intake, where both versions are visible at once, and only for the
same SUBJECT with a different predicate — shared vocabulary alone is not a
version.

### Rule 5 — current focus outranks background  (`focus.py`)

Retrieval against the question alone fails on a short follow-up. Three turns
into designing a greenhouse, "what about the frame" carries one content word
and matches picture frames.

Focus is derived from the user's **own** turns only, weighted with a 2.5-turn
half-life. Letting Nova's answers feed it would let the assistant decide what
the conversation is about, which is the drift this exists to detect.

Drift is measured, not acted on — that is a policy question and this is not
the policy layer. Measured overlaps: on-topic 0.38–0.58, a materials tangent
0.14, unrelated 0.00. `DRIFT_AT` sits at 0.12, below the tangent, because a
false "you have wandered off" costs more than a missed one.

**A normalisation bug caught in testing:** dividing by the weight of all
fourteen focus terms meant matching one central subject scored 0.07 and read
as drift. It normalises against the top five now.


---

## ADR-39 — The installer was reporting on a setting instead of on the disk

From a real install run:

```
vision   OPTIONAL: no multimodal projector - see README
EXCLUDED vision - no multimodal projector configured; add one to
         llm/models and set runtime.mmproj
```

Both lines read `cfg["runtime"]["mmproj"]` — the field ADR-30 made `"auto"`
and which no longer needs setting. So the installer and `verify.py` would
report "no multimodal projector" **whether or not one was sitting correctly
paired in llm/models**, and told the user to set a value that does nothing.
Anyone following that advice would have been chasing a setting while the real
answer was a missing file.

Both now call `vision.find_projector()` against the selected model and say
one of three true things: the projector it paired with, that projectors are
present but none matches this architecture, or that there are none and
`python get_model.py vision` is the command.

**The curator was still being installed and configured.** ADR-17 removed it —
the loaded model organises its own memory — but `install.py` still downloaded
a 350M, wrote `cfg["curator_model"]`, and printed `curator LFM2.5-350M (CPU)`
directly above a banner reading "organised by the loaded model itself". The
model stays in the catalogue as a genuinely useful small model; nothing
depends on it.

---

## ADR-40 — AUTO context is capped; a manual request is not

Same install run:

```
note: 76288 tokens - LFM2.5-2.6B supports 131072, and this is what fits
```

`CTX_SANE_MAX = 32768` existed precisely to prevent that and was being
ignored: `model_limits()` overwrote `max` with the model's advertised
`train_ctx`, and `resolve_ctx()` used that as the ceiling. The fitter then
found 76288 tokens of memory free and took them.

It fits, and it is still wrong. A 76k window means prompt processing
dominates every single turn on this hardware — the slowness the cap was
written for.

`model_limits()` now reports two numbers. **`max`** is the model's real limit
and bounds a manual request. **`auto_max`** is `min(train_ctx, CTX_SANE_MAX)`
and is what auto will take by itself. When they differ, the advisory says so
and names the override.

### Starter defaults: Gemma 4 E2B-it + Microsoft Hazel

**Decision.** The fresh-install/default presentation uses `gemma-4-E2B-it-Q4_K_M.gguf` when present and Microsoft Hazel (English, United Kingdom) for speech. These are defaults only; model and voice selectors remain unrestricted, and missing defaults fall back gracefully to discovered choices. The Gemma starter source is `ggml-org/gemma-4-E2B-it-GGUF`.

---

# THE HUB — the HUB-ZERO recovery

HUB-ZERO was an attempt to make this jump that did not survive testing. It
was not a bad build; it was a build with a small number of specific faults,
some of them one character wide, that together stopped it from starting.
Each one is recorded here with what it actually was, because "HUB-ZERO
didn't work" is not a thing anybody can act on a year from now.

Method: The Hearth Step 3 was treated as the reference for known-good
behaviour and never as the base to build from. Step 5 was the newest working
Hearth. HUB-ZERO's installer build was the base, because it carried the
features worth keeping. Everything below is a difference between those.

---

## ADR-41 — Nested quotes in an f-string stopped the entire application

**Context.** `server.py` line 914:

    "text": f"VISUAL ASSET: {pathlib.Path(a[<dq>path<dq>]).name}. ..."

with `<dq>` being the same double quote that opens the string. Reusing the
delimiter inside the braces is PEP 701, which landed in **Python 3.12**.

**What it actually did.** `server.py` did not parse. Not "vision was
degraded" - the module could not be imported at all, so there was no chat,
no tools, no memory, no interface. `test_hub.py` and `test_live.py` both
died on `import server`, and `verify.py` reported it correctly as
`server.py failed to import`. The report was accurate and nobody could act
on it because the same sentence described a missing model and a dead
application.

**Why it was invisible.** `INSTALL.bat` downloads a private Python **3.13**,
where that line is perfectly legal. The author's interpreter accepted it.

**Decision.** Fixed by concatenation rather than a nested quote, and
`verify.py` gained `check_python_floor()`, which reads every module looking
for a quote character reused inside an f-string expression. It reads rather
than parses, deliberately: a parse-based check gives the answer of whichever
interpreter runs it, and the interpreter that ships here is the one that
says yes.

**Floor.** Python 3.9, matching what `install.py` enforces.

**Revisit when.** The floor rises to 3.12 or later, at which point the check
becomes noise and should be deleted rather than left to rot.

---

## ADR-42 — A projector is not a model, and the installer was the one place that did not know

**Context.** The reported symptom was that the installer said there was no
vision module. There were three separate causes and none of them was a
missing projector.

**Cause 1 — the raw glob.** `write_config()` chose the main model with

    ggufs = sorted(f.name for f in MODELS.glob("*.gguf"))
    main = max(ggufs, key=size)
    cur  = min(ggufs, key=size)

A multimodal projector is also a `.gguf`. `core.is_projector()` already
existed and `core.models()` already used it to keep projectors out of the
model dropdown - the installer never called it. So `min()` selected
`mmproj-gemma-4-E2B-it-BF16.gguf` (0.94 GB) over the model it belongs to
(3.19 GB) every time, and `max()` selected whatever the largest file in the
folder happened to be. Installed beside an existing collection, that is an
11 GB text-only model with no projector anywhere near it - and the summary
then reported no vision perfectly honestly, because the model it had just
chosen has none.

**Cause 2 — the report could not run.** The block that prints the vision
line referenced `core` without importing it, inside a bare
`except Exception`. `sys.path` did not have the application folder on it
until `verify()`, several steps later, so `import vision` failed too. Every
run raised, every run was swallowed, and every run printed a vague line.

**Cause 3 — hardcoded pairs.** `verify()` tested
`selected == "gemma-4-E2B-it-Q4_K_M.gguf"` and
`main_name.startswith("gemma-4-")`. Those check the starter download and
nothing else, so they pass silently for every other model and go stale the
day the starter changes.

**Decision.**
- The installer filters with `core.is_projector()`, the same function the
  running application uses.
- `_pick_main()` prefers **the largest model that has a projector paired
  with it**, falling back to `PREFERRED_MODEL`, then to size. A first run is
  meant to be able to see; a bigger text-only model sitting in the same
  folder is not an upgrade for that.
- `sys.path` gets the application folder at module scope, once.
- The vision line reports three distinct outcomes - paired, present but
  unpaired, absent - and names the command that fixes each. A genuine fault
  is now an ERROR, not a footnote.
- The pair check in `verify()` is derived from `vision.find_projector()`.

**Evidence.** Four scenarios, measured: fresh install, install beside an
existing 87 GB model folder, projector-only, and text-only. Before the
change the second selected an 11 GB text model; after it, the Gemma with its
projector. The third now refuses with a sentence instead of configuring a
projector as the language model.

**Note.** HUB-ZERO's move from `ggml-org/` to
`lmstudio-community/gemma-4-E2B-it-GGUF` was **correct and has been kept**.
The `ggml-org` repo has no `Q4_K_M` file at all - only BF16, Q4_0 and Q8_0 -
so The Hearth's own starter download could not have succeeded. The pinned
SHA-256 values and size floors are correct against the live repository and
have been kept too.

---

## ADR-43 — A fork gets its own ports on the day it gets its own name

**Context.** HUB-ZERO kept `8430 / 8090 / 8091 / 8092` - The Hearth's ports,
verbatim, including the comment explaining why a fork must not share them.

**Consequence.** Whichever application started second failed to bind. Worse,
`STOP.bat` is deliberately port-scoped so that it kills only its own
processes - pointed at those four numbers, that careful mechanism was aimed
directly at The Hearth's running model.

**Decision.** The Hub takes `8440 / 8100 / 8101 / 8102`. `core.py` gained
`ANCESTOR_PORTS`, naming every port Cairn and The Hearth own, and
`verify.py` checks against that map instead of a hardcoded tuple, so the
next fork inherits the check rather than the numbers.

---

## ADR-44 — The launcher guarded on a file that ships in the download

**Context.** `HUB-ZERO.bat` began `if not exist config.json`. `config.json`
is part of the release. The guard never fired once.

**Second fault.** The launcher then called bare `python`, ignoring the
private interpreter `INSTALL.bat` had just downloaded - so The Hub ran on
whatever was on PATH, or failed with "python is not recognized" one step
after a successful install.

**Third fault.** An embedded Python distribution ships a `._pth` file, which
puts the interpreter in isolated mode; in isolated mode the script's own
directory is **not** added to `sys.path`. `server.py` and `get_model.py` had
no `sys.path` bootstrap, so `import core` would have failed on exactly the
machines the private runtime exists to serve.

**Decision.** Guard on `llm\llama.cpp\llama-server.exe`, which only the
installer produces. Resolve `.runtime\python\python.exe` first and fall back
to `python`. `server.py` and `get_model.py` put their own folder on
`sys.path` before any first-party import. `TEST.bat` resolves the
interpreter the same way.

---

## ADR-45 — The memory loop had stopped consolidating, and a test was holding it there

**Context.** HUB-ZERO reduced `memory.loop()` to candidate promotion plus a
weight decay, and deleted the pressure measurement, the idle check, the
90-second start delay and every call to `run_curator()`, `roll_up()` and
`relieve()`.

**Consequence.** `consolidate.py` remained installed, imported and tested,
and was never once executed. Memory accumulated and was never distilled.
The loop also woke 15 seconds after start and did work whether or not the
machine was idle - on hardware measured at 4 GB of VRAM and under 1 GB of
free RAM, directly in competition with model load.

**Why it stayed.** `test_active_memory.py` asserted
`"run_curator(" not in loop`, under the name
`test_no_second_curator_model_in_memory_loop`. The name states the real
invariant - one language model - and the assertion states a different and
wrong one. `run_curator()` consolidates through `consolidate.Session`, whose
`ask()` posts to `runtime.MAIN`: the model that is already loaded, in an
idle gap, under a lock chat can take back. No second process, no second
port, no second set of weights.

**Decision.** The full loop is restored, with HUB-ZERO's active frontier
folded into it as step one - the frontier ages on every pass including busy
ones, because decay that only runs when the machine is idle is not decay, it
is a record of how often the user walked away. Promotion runs ahead of the
pressure gate, so a backlog of candidates cannot hide from the thing meant
to notice it.

**The test now asserts what its name says**: no `Curator(`, no
`runtime.start(`, no `CURATOR_PORT` in the loop, and `runtime.MAIN` present
in `consolidate.py`. A second test asserts the loop still calls all three
consolidation functions, so the regression cannot be reintroduced quietly.

---

## ADR-46 — One geometry reader, not two

**Context.** `vision.model3d_facts()` carried its own inline STL/OBJ parser.
Every other extension fell through to "measured by file size only; geometry
not parsed". `model3d.py` - in the same folder, already used to *render*
these files - reads STL, OBJ, PLY and 3MF directly and GLB/GLTF through
trimesh when it is present.

**Consequence.** A `.ply` could be rendered correctly on screen and reported
as an unmeasurable blob in the same turn.

**Decision.** `model3d_facts()` delegates to `model3d.triangles()`. STEP and
other boundary-representation formats now say a CAD backend would be needed
rather than reporting a shape of zero.

**Found by making the change.** `_parse_ply()` sliced from `end_header` and
kept the newline after it, so `splitlines()` produced a leading empty string
and every row shifted by one: the vertex list came back one short and the
first face index ran off the end of it. A valid PLY surfaced as
`partial read: IndexError`. Fixed, and index bounds are now checked rather
than trusted.

---

## ADR-47 — Three tests that had never executed an assertion

**Context.** `test_assets.py`, `test_active_memory.py` and
`test_workspace_shared.py` are pytest modules - bare `test_*` functions, one
`tmp_path` fixture, no `__main__` block. `python test_assets.py` imported
the file, defined the functions, called none, exited 0. Three green ticks,
eight assertions, zero of them ever run. pytest is not installed and cannot
be: the shipped Python is embedded, with no pip.

**Compounding it.** `verify.py` ran a hand-written list of five scripts and
`TEST.bat` ran three. The folder held twelve. `test_model3d.py` had been
failing on `import trimesh` - a library this application deliberately does
not require - and nothing was in a position to say so.

**Decision.** `testkit.py` discovers `test_*` callables, supplies `tmp_path`,
runs them, names each result and exits non-zero on failure. `verify.py`
discovers every `test_*.py` on disk instead of consulting a list; the named
five keep their reporting order and everything else is picked up
automatically. A suite that is not discovered is a suite that does not
exist.

`test_model3d.py` was rewritten to match the product's actual contract: the
offline path (STL/OBJ/PLY/3MF geometry, native PNG rendering, native format
conversion) is REQUIRED and asserted; trimesh is OPTIONAL and reported as
such. PNG dimensions are read from the IHDR chunk rather than through PIL.

**Result.** 13 suites, all discovered, all running.

---

## ADR-48 — The composer, and why a page can pass every test and still be broken

**Context.** Reported as "the text bar is too small". Measured in Chromium
at 1280x860, HUB-ZERO's composer was **205 px wide in a 1280 px window**.

**Cause 1 — width.** The attachment feature wrapped the textarea in a plain
`<div style="flex:1;min-width:0">`. The textarea's own `flex:1` then applied
to nothing, because its parent was no longer a flex container, and it fell
back to its default `cols` width - about twenty characters - beside a very
wide empty gap.

**Cause 2 — height.** `rows="1"` and no `min-height`: a single line inside
22 px of padding. It grew as you typed, but it did not look like it would.

**Cause 3 — font.** The first repair wrote `font:15px/1.55 inherit`, which
is not valid shorthand - `inherit` cannot stand in for the family - so the
whole declaration was dropped and the box rendered at the browser's 13.3 px
monospace default.

**Cause 4 — it stopped growing.** With the wrapper made a column flex
container, `#in{flex:1}` expands to `flex:1 1 0%`: a flex-basis of zero on
the main axis, which in a column *is* the height. The autogrow handler set
`style.height = 361px`, the inline style landed, and the layout ignored it.

**Decision.** `.composer` is the flex item and carries the growth; `#in` is
`flex:0 0 auto`, `width:100%`, `min-height:88px` (three lines),
`max-height:min(42vh,420px)`, `resize:vertical`, and inherits the interface
family with an explicit `font-size`. `COMPOSER_MAX` is defined once and read
by both autogrow handlers, because when the JavaScript ceiling and the CSS
ceiling disagreed the box stopped growing while the CSS still allowed more
and the last lines were typed blind.

**The general lesson, and the new suite.** `test_ui.py` reads `ui.html` as
text and `test_live.py` drives the server with no browser at all. All four
of these faults sit exactly between them: the page parses, every route
exists, and the thing is broken on screen. `test_browser.py` loads the real
page in Chromium against the real server at two viewport sizes, measures the
rendered box, types, sends, and reads the reply back out of the DOM. Cause 4
was found by that suite and not by a person.

It reports OPTIONAL and exits 0 where Playwright is absent - a developer
check, not an install requirement.

**Revisit when.** The interface gains a second layout mode, at which point
the measurements need a viewport case each.

---

## ADR-49 — Three lists have to agree before a tool exists

**Context.** A working tool needs agreement between `tools.REGISTRY` (what
the function is), `tools.enabled()` (whether Nova is offered it) and
`policy.TIERS` (whether the default-deny gate lets it through). HUB-ZERO
added nineteen tools and broke that agreement in two different directions.

**Fault 1 — advertised, then refused as unknown.** `read_key`, `pass_off`,
`set_theme` and `web_search_more` were registered and listed in Nova's tool
schema with no entry in `policy.TIERS` at all. The gate is default-deny, so
each call returned *"Refused: there is no tool named 'set_theme'"* — to a
model that could see the tool in its own list. Four of the newest features
could never run once.

**Fault 2 — gated, then never offered.** `save_to_ai_vault`,
`delete_ai_vault` and `web_search_more` were registered *and* gated, but
were missing from `tools.ALWAYS` and had no config switch, so
`tools.enabled()` filtered them out of the schema list. Nova was never
offered them. The AI vault was built, documented, tested by
`test_workspace_shared.py`, and unreachable — because that suite asserted
the tools were in `REGISTRY` and `TIERS`, which was true, and never asked
whether anything would offer them.

**Decision.**
- The four ungated tools get real tier entries and argument schemas.
  `web_search_more` is `LIMITED`, not `AUTO`, because it is the same network
  call as `web_search` and must inherit the per-turn taint rule and the rate
  limit.
- `save_to_ai_vault` and `delete_ai_vault` join `ALWAYS`: they write only
  inside `vault/AI`, the model's own area, never the user's originals — the
  same class as the Playground write tools already there.
- `tools.FOLLOWS` is new: `web_search_more` follows the `web_search` switch.
  The settings pane has one switch on purpose, because web search is the
  only thing that leaves the machine; a second page of the same search does
  not earn a second switch nobody would know to set.
- `set_theme` stays `AUTO` at the gate because it cannot reach data, a file
  or the network — and `tools._set_theme()` still refuses unless the user has
  turned on `appearance.ai_control`, so consent decides, not the tier.

**Evidence.** `test_toolsurface.py` checks the three lists against each
other: every registered tool gated, no orphan gate entries, every tool
reachable in some configuration, every offered tool authorized for reasons
other than its arguments, everything behind the web-search switch marked as
a network tool and nothing that touches the network left on `AUTO`. It also
re-asserts that the model still has no tool for writing its own memory.

**Why a test and not a review.** Both faults are silent. Nothing throws,
nothing goes red, the capability is simply absent. Only a check that
compares the lists can see it.

---

## ADR-50 — Generation ships with the application, or it does not exist

**Context.** `generate_image`, `generate_video` and `generate_3d` were
registered, gated, documented and advertised to Nova, and all three ended in
the same sentence:

    no supported local image generator is currently reachable on this machine

because each required ComfyUI or Automatic1111 to be installed *and running*.
On a fresh install — which is every install — three headline capabilities
were three different ways of saying no. Observed in a real session: asked
about a webcam frame, Nova replied that it could not create video or 3D
because no local image generator was reachable.

**Decision.** Generation ships with The Hub, pinned and downloaded by
`INSTALL.bat`, exactly as llama.cpp already is.

| | project | why it fits |
|---|---|---|
| images, video | stable-diffusion.cpp `master-709-92a3b73` | ggml, GGUF weights, prebuilt Windows CUDA/Vulkan/AVX2, one binary does both via `-M img_gen` / `-M vid_gen` |
| 3D (neural) | trellis.cpp `v0.4.3` | ggml, prebuilt Windows CUDA/Vulkan, image → textured GLB |
| 3D (always) | `meshgen.py` | pure Python, no binary, no weights, cannot fail for want of VRAM |

ComfyUI and A1111 remain as **optional upgrades** and are preferred when
present, because a user who set one up has better models in it than the
starter checkpoint here.

**Consequence.** About 19 GB on top of the base install.
`python install.py --generators` retries only that part, because a download
that dies two thirds of the way through 19 GB should not mean redoing
llama.cpp and the language model as well.

**Revisit when.** A ggml-family generator appears that fits a 4 GB card
better than Wan 1.3B or TRELLIS-4B do.

---

## ADR-51 — One generator at a time, and Nova is stopped for the whole pipeline

**Context.** 4 GB of VRAM, with Nova already in it. Every generator here
wants most of a card to itself.

**Decision.** `forge.Session` is a single exclusive lock that stops Nova on
entry and restarts it on exit — **once**, around however many generator runs
happen in between.

    acquire → stop Nova → sd-cli → trellis → start Nova → release

**Why once and not per step.** "Make me a 3D model of a dragon" is three
model loads: text→image, image→mesh, then Nova again to look at the result.
Stopping and restarting llama-server between each would cost more wall-clock
than the generation. `generate_3d` therefore runs its whole pipeline inside
one Session.

Nova is restored in a `finally`, so a generator that raises never leaves the
machine without its language model. A second Session that cannot acquire the
lock returns a sentence naming what is running rather than queueing silently.

There is also a deliberate 1.5-second pause after stopping Nova: llama-server
does not release VRAM the instant it is asked to stop, and starting a 2 GB
diffusion model into a card that has not finished emptying fails both.

---

## ADR-52 — A 3D capability that can always produce something

**Context.** TRELLIS.2 is a 4B model. Its own README targets 16 GB cards for
the good path. On the 4 GB card this application is built for, it may not run
at all — and "3D generation is unavailable" is not an acceptable answer for a
headline capability.

**Decision.** `meshgen.py`: exact geometry, built rather than imagined, in
pure Python with no download.

- `build(spec)` — a small JSON shape description → a watertight solid.
  Boxes and plates with outlines and holes, cylinders, tubes, cones, spheres,
  tori, prisms, revolves, and parts placed relative to each other.
- `relief(image)` — brightness becomes height, with a base and closed sides.
  This is how a *generated picture* becomes something with a shape on a
  machine where the neural path will not fit.

A language model is good at turning "a 60 mm L-bracket, 4 mm thick, two 5 mm
holes in each leg" into numbers and bad at emitting a valid mesh triangle by
triangle. So the model writes numbers and code builds the solid. For a large
share of what people actually want a 3D file *for*, this is the better answer
anyway: exact, dimensioned, and watertight rather than approximately shaped.

`generate_3d` prefers the spec route whenever dimensions are given, uses
TRELLIS when it can run, and falls back to a relief rather than failing.

**The hard part, and how it was settled.** Cutting several holes into one
outline means bridging each hole into the outer contour and triangulating the
result. Three versions failed in three different ways, and every failure was
silent — the part rendered perfectly and had open edges, which no slicer will
accept:

1. bridges chosen by nearest-vertex with no crossing check → a rounded plate
   with four bolt holes came back with **80 open edges**;
2. proper crossing rejection, but bridges only ever targeting the original
   outer ring → an inner hole in a 4×4 grid has no path out that does not
   cross a hole in front of it, so it simply **failed**;
3. incremental merging, which fixed the grid and still lost a C-channel,
   because a later bridge ran *along* an earlier zero-width channel — nothing
   crossed, and the polygon still stopped being simple.

The resolution was to stop chasing a perfect bridge heuristic and notice that
**closure is cheap to verify**: in a closed solid every edge belongs to
exactly two triangles. So `extrude()` builds, counts edges, and if the result
is not closed, rebuilds with the rings rotated and the holes merged in a
different order — variations that change nothing about the shape and
everything about where the bridges land. Fifteen test shapes, all watertight.
A part that still cannot be closed raises with a sentence the user can act
on, because an STL that is silently open is a wasted print.

---

## ADR-53 — Four ways a picture failed to reach a model that could see

All four came from one reported session. All four are the same shape: the
image never arrived, and nothing said so.

**1. The eye button.** The camera frame was written to `data/incoming-image`
— no extension. `encode_for_model()` maps an *extension* to a mime type,
found none, and returned `""`. The frame was dropped with a one-line notice.
A vault photo called `IMG_0254.JPG` went through fine, which is exactly why
the model looked as though it could see everything except the camera. Pillow
hid this during development by sniffing content itself; Pillow is not
installed on a real install, because the shipped Python is embedded with no
pip. **Fixed** by `sniff_image_mime()` — the filename is a hint, the bytes are
the fact — and by writing the frame with the extension its bytes imply.

**2. The second attachment.** Published images had a **120-second wall-clock
TTL**. The URL goes into the prompt; llama-server fetches it only after the
tool phase and prompt processing. On this hardware — ~51 tok/s prompt eval, an
image costing ~1024 tokens, plus the memory frame and a growing history — the
second image of a conversation can easily be more than two minutes from
publish to fetch. The token expired, the fetch 404'd, and the model received
"Attached user file: X (image)" with no image behind it. It then did the
sensible thing and tried to `open_file` the path it had just been told about.
Nothing announced any of this; the first image worked and the second did not,
and the difference was how long the model took to think. **Fixed** by scoping
the lifetime to the turn — released in `chat()`'s `finally` — with a
30-minute safety expiry and a cap of 32 held images so a crash loop cannot
grow it without bound.

**3. Camera plus paperclip.** The sight block rebuilt the message from
`last["content"]`, which the attachment block above it may already have turned
into a **list** of parts. Wrapping a list in `{"type":"text","text": …}`
stringified it into Python `repr` and threw every attachment image away in the
same move. **Fixed** by merging into the existing parts list instead of
replacing it.

**4. The leaked tool call.** When a GGUF's chat template cannot round-trip its
own control tokens, the call lands in `message.content` and is streamed to the
user as text:

    <|tool_call>call:open_file{path:<|"|>Chat/…/IMG_1110.JPG<|"|>}<tool_call|>

**Fixed** by `toolcall.py`, a last-resort reader for text that has already
failed the normal path. It is explicitly **not** a second source of authority:
a recovered call goes through `policy.Gate` like any other, and is only
recovered when its name is a tool **already offered on this turn** *and* the
text looks like a failed call rather than a sentence mentioning one — either
it carries control-token debris, or the call is essentially the whole message.
Without that second condition, "here is how you would call open_file({…})"
becomes a file read, which is a worse bug than the one being fixed. Debris
that yields no recoverable call is scrubbed before display and written to the
log, so the template problem stays visible somewhere other than the user's
face.

---

## ADR-54 — Erasing memory is two steps, and neither of them is a button that deletes

**Context.** There was no way to clear memory at all. Everything in this
application is built so that nothing is truly lost — faded leaves fall to ash
and stay, disproven claims keep their evidence, sessions are archived, the
event log is append-only and the whole tree rebuilds from it. That is the
right default and it left the user with no way to say *gone*.

**The risk.** A purge is the one operation that deliberately breaks every one
of those guarantees. Put it behind a single button that looks like all the
others and someone will eventually lose everything to one mis-click.

**Decision.** `purge.py`, and the destructive call cannot be reached in one
action.

`stage(scope)` counts what would go and issues a single-use token.
`commit(token, scope)` is the only function that deletes, and it refuses a
token it did not issue, one already spent, one older than two minutes, and
one staged for a different scope. **A stray click can only ever reach
`stage`, which changes nothing.** The confirmation dialog is not decoration
over a destructive call — it is the only path to it.

**Five scopes, because "delete everything" is rarely what someone means.**

| scope | goes | survives |
|---|---|---|
| conversations | transcripts and their archive | everything Nova learned from them |
| ash | what already faded | nothing live is touched |
| active | the recent working frontier | trees and event log |
| memories | Tree of Life, Knowledge Tree, ash, frontier | **the event log — so Rebuild restores it** |
| everything | all of the above *and* the event log | nothing |

Config, models, the Vault and the Playground are never in scope. Those are
the user's files, not the assistant's memory.

**The dialog shows counted numbers, not a warning.** "Are you sure you want
to delete everything?" asks someone to authorise a thing neither party has
looked at. "412 memories, 38 conversations, 1,204 events, 6.2 MB" can
actually be answered. The totals are read from disk when the dialog opens.

**Three details that matter more than they look.**

- *The cache is the trap.* Deleting the files is not enough: the tree is held
  in the running process and would answer from it, then write it back on the
  next save and quietly undo the purge. `_reload_memory()` clears it, and the
  test proves it by forcing a save afterwards and re-reading from disk.
- *There is a receipt.* Every purge writes one line into whatever event log
  now exists — for `everything`, the first line of a brand new one. The shape
  of what went, never the content. A memory that goes silent with no record
  of why is indistinguishable from a memory that broke.
- *Everything defaults to No.* Esc, the backdrop and the No button all close
  the dialog; Yes stays disabled until the real totals have arrived.

---

## ADR-55 — Two constants, because a release tag and a filename are not the same string

**Context.** The generator install failed on a live machine:

    get     sd-master-709-92a3b73-bin-win-cuda12-x64.zip
    curl: (22) The requested URL returned error: 404
    WARNING: sd-cli did not install

The stable-diffusion.cpp release is tagged `master-709-92a3b73`. The files
*inside* it are named `sd-master-92a3b73-…` — build number omitted. Building
the filename out of the tag produced a URL that never existed, and the 537 MB
CUDA runtime beside it downloaded perfectly, which made it look like a
network problem rather than a typo. `SD_BUILD` (the URL path) and `SD_REV`
(the filename fragment) are now separate.

**And the second failure in the same step.** `trellis-cuda-windows-x64.zip`
downloaded all 693.3 MB — exactly the recorded size — extracted fine, and was
reported as "did not install", because `unzip_into()` required the extracted
file to be called exactly `trellis-cli.exe`. The binary was on disk the whole
time under some other name.

**Decision.** Stop requiring a guessed name from a third-party archive.
`_install_binary()` extracts, then *discovers*: preferred names first, then
any sizeable executable sharing a word with them. What it finds is written to
`BINARY.txt` so `forge.py` and a person reading the folder agree, and when
nothing is found the installer **lists the executables that are there** and
says which one to rename. "Did not install" with nothing else is the least
useful thing an installer can say about a download that clearly arrived.

---

## ADR-56 — Letter-spaced branding, and the rename that walked past it twice

**Context.** After two rename passes and a `verify.py` check for ancestor
references, the installer still opened with:

    H U B - Z E R O   -   local AI, assembled in one pass

A substitution looking for `HUB-ZERO` does not match `H U B - Z E R O`, and
neither does a grep. `verify.py` had shipped with the identical bug in its own
banner (`T H E   H E A R T H`), which is how the pattern was recognised.

**Decision.** `check_branding()` strips whitespace, hyphens and underscores
before comparing — so it sees the text a person reads, not the text as it
happens to be typed. It inspects string constants and visible markup only;
comments and documentation are exempt, because lineage is what half of this
project's documentation is *about*. `core.ANCESTOR_PORTS` is exempt too: it
names Cairn and The Hearth in order to avoid their ports, which is the
opposite of impersonating them.

---

## ADR-57 — The prompt said "what you remember" about a message that had just been typed

**Context.** On a fresh install with **0 leaves and 2 events**, a first
message got this reply:

> **You:** Code for me a program to build things in scratch on a pi.
> **Nova:** I remember that we were working on a program to build things in
> Scratch on a Raspberry Pi. What would you like to do next with that project?
> **You:** I just said that...

**Cause.** `focus._current_anchor()` returns the latest user turn when that
turn is substantive, and `server.build_messages()` heads the whole block with
`[what you remember]`. So the model received:

    [what you remember]
    Working on: Code for me a program to build things in scratch on a pi.

    Code for me a program to build things in scratch on a pi.

The same sentence twice — once labelled as recollection. **The model was not
confused; the prompt was false.** With memory completely empty, the only
thing under that heading was a restatement of the message being sent.

**Decision.** Three changes.

1. The anchor is only stated when it came from an **earlier** turn, and it is
   labelled `Earlier in this conversation:` rather than presented as memory.
   The current message is already in the turn, verbatim, immediately below.
2. `[what you remember]` is only written when there is something to remember.
   An empty block does not get a heading that promises recollection.
3. Inheritance for short follow-ups was widened. It required
   `_subject_cues()` — filenames, extensions, model names — so a clear
   sentence containing none of those inherited nothing, and "the second one"
   anchored on itself. Several distinctive terms now count as a subject
   whether or not a file is named.

**Evidence.** `test_hub.py` asserts both directions: the message just sent is
never presented back as remembered, *and* a short follow-up still inherits the
earlier subject — because a fix for the first that broke the second would
cost the conversation its thread.

---

## ADR-58 — A generator that borrows the card has to hand it back before the turn continues

**Context.** The first real generation on the target machine:

    ⚙ generate_image   📦 created Playground/generated.png
    tools unavailable for this reply
    Error: HTTP Error 503: Service Unavailable

**The image was generated perfectly.** The turn died anyway.

**Cause.** `forge.Session` stops Nova, runs the generator, and calls
`runtime.start()` on the way out — but `start()` returns as soon as the
process is *spawned*. Loading the GGUF, warming the kernels, probing vision
and benchmarking all happen on a background thread. So the Session handed
control back with llama-server still coming up, and the chat turn that had
*called* the generator immediately posted into it. llama-server answered 503,
which means "still loading" and was treated as "broken": the tool exchange was
discarded ("tools unavailable for this reply") and then the answer phase hit
the same wall and failed the whole reply.

A Session that stops Nova has to hand her back, not merely ask for her back.

**Decision — two layers.**

1. `Session.__exit__` waits for `runtime.state()["status"] == "ready"` before
   returning, up to `RESTORE_DEADLINE`. It polls the status runtime already
   maintains rather than the HTTP endpoint, because "ready" is set only after
   loading, warming, the vision probe and the benchmark have finished — which
   is exactly when a chat turn can use it. The Session records `restored`, so
   a model that never came back is reported rather than assumed.

2. `runtime.post()` rides out a 503 for up to `RELOAD_GRACE` instead of
   raising. This should now rarely fire, but "the server is still starting" is
   a condition with an obvious correct response — wait for it — and turning
   that into a failed reply is a choice nobody would make deliberately. Past
   the deadline a 503 is still a real error.

*A detail that cost a hung test:* `_wait_ready(deadline=RESTORE_DEADLINE)`
bound the default at definition time, so changing the module constant
afterwards did nothing. It reads the module value at call time now.

**Also.** A generator takes the whole machine for minutes and the page goes
completely silent while it does — no tokens, no reasoning, nothing. That reads
as a hang. The turn now says what is about to happen before it happens
("generating an image. Nova is paused while the card is in use and comes back
straight afterwards"), with an exception for a spec-built mesh, which stops
nothing and finishes instantly — promising a wait for that would be its own
small lie.

**Confirmed working from the same install log.** `sd-cli` downloaded once the
tag/filename split was fixed, and the binary discovery found
`trellis-server.exe` — not `trellis-cli.exe`, which is exactly the guess that
ADR-55 stopped requiring.

---

## ADR-59 — 3D generation ran the wrong program with the wrong flags

**Context.** "3D generation flat out doesn't work."

**Two faults, and the first one hid the second.**

The Windows release ships **both** `trellis-cli.exe` and
`trellis-server.exe`. ADR-55's name-guessing fallback — added because the
exact CLI name was unknown — picked the largest executable sharing a stem,
which is the **server**: a long-running HTTP service that takes multipart
POSTs and does not understand a command-line flag. Every 3D generation ran
it, and it failed instantly.

Underneath that, the argv was wrong in every particular, because it was
written from a guess:

| guessed | actual |
|---|---|
| `--input FILE` | positional, first |
| `--output FILE` | positional, second |
| `--model-dir DIR` | `--models DIR` |
| `--bg-removal` | `--bg-removal threshold\|birefnet` — it takes a **value**; bare, it ate the next argument |

The real call is `trellis-cli input.png output.glb --models DIR --res 512
--bg-removal birefnet`.

**Decision.** `trellis_exe()` asks for the CLI **by name** and explicitly
refuses anything with "server" in it; a separate `trellis_server_exe()`
exists only so that "you have the service but not the tool" can be said in
those words instead of "not installed". The argv is now the documented one.

**The lesson worth keeping.** ADR-55's discovery was right to stop requiring
a guessed name — it is what found the binary at all. It was wrong to treat
*any* matching executable as equivalent. Discovery should widen what can be
found, never what can be run.

---

## ADR-60 — The image settings were close to the worst available

**Context.** "The images generated seem a bit off… faces don't work… we
should not send ten image prompts through to get one good image."

The generation manifests say exactly what was happening: 512×512, 20 steps,
CFG 7, default sampler, **`"negative_prompt": ""`**, on
`stable-diffusion-v1-5-pruned-emaonly`. Every one of those is the weak
choice, and they compound.

**Four causes, in descending cost.**

1. **No negative prompt.** An SD1.5-class model relies on one. Without it,
   "bad anatomy, extra fingers, deformed" are all perfectly likely
   completions and nothing pushes against them. Free to fix and the single
   largest win.
2. **The checkpoint.** `pruned-emaonly` is the raw 2022 base weights — the
   reference model, not a good one. Every community fine-tune since is
   dramatically better at faces.
3. **Faces are a resolution problem.** A face a fifth of the way across a
   512px frame is about a hundred pixels wide. Eyes cannot resolve at that
   size at any step count.
4. **Sampler and steps.** euler at 20 is the fallback, not the choice.

**Decision.**

- **DreamShaper XL Turbo** becomes the default download and the preferred
  checkpoint: SDXL, so it renders natively at 1024 and a face gets four times
  the pixels; a fine-tune, so anatomy and composition need far less prompt
  work; turbo-distilled, so **8 steps instead of 28** — it is 2.8 GB and
  *faster* on this card than the 1.7 GB model it replaces. SD1.5 stays as the
  fallback, because something has to fit when 2.8 GB plus a 1024px latent
  does not.
- **`forge.model_preset()`** picks steps, CFG, size, sampler, scheduler,
  clip-skip and negative prompt per model family, detected from the filename.
  One fixed setting cannot serve both families: a turbo model at 28 steps and
  CFG 7 burns, an SD1.5 model at 8 steps and CFG 1.5 fogs.
- Real negative prompts, weighted toward anatomy and faces rather than a long
  incantation of style words.
- `dpm++2m` + `karras`, `--clip-skip 2` for SD1.5.
- `--vae-on-cpu` and `--clip-on-cpu` alongside the existing tiling and
  offload — this is what makes a 1024px SDXL decode possible on 4 GB.
- `--hires` two-pass for SD1.5 only, with a graceful fall back to single-pass
  if the installed build has no such flag. SDXL does not need it.

**Not done, deliberately.** Filename sniffing to detect a model family is
crude. A GGUF header does not say "I am a turbo model, use six steps", so
this is what there is — and every value stays overridable by the caller.

---

## ADR-61 — What Nova makes goes in the conversation

**Context.** A generated image was announced as a small grey tag reading
`generated.png`. The picture the user had waited two minutes for was never
shown to them — it was in the Playground, behind a different tab.

**Decision.** The turn emits the file with a URL and a media kind, and the
page renders it in the message: an image as an image, a video with a player,
a 3D model as its six rendered views (a `.glb` is not something a browser can
display, and the views are the whole point of having made it). Each keeps a
link with its real filename, so it can still be opened or saved.

Storage does not change — output still lands in the Playground and reaching
the Vault is still a separate, explicit action. Only the *showing* changed.

---

## ADR-62 — Files named so they can be asked for again

**Context.** Everything was `generated.png`, `generated_3d.glb` or
`source_for_3d.png`, so a Playground of a dozen results read
`generated.png`, `generated (2).png`, `generated (3).png`.

That is worse than untidy. The user cannot tell them apart, and neither can
Nova — which means she cannot answer "make the swing picture bigger" at all
without opening every file.

**Decision.** `<date> <time> <subject>.<ext>`, e.g.

    2026-09-01 1432 girl swing sunset tropical beach.png
    2026-09-01 1447 goku super saiyan.png
    2026-09-01 1503 box cylinder 2 holes.stl

The timestamp orders and disambiguates; content words from the prompt
identify. Filler is stripped — "please", "generate", "image", "the" describe
nothing — and the whole name is capped so it stays readable in a list. A
spec-built mesh with no prompt is named from its own shapes and hole count.

---

## ADR-63 — Relevance that never gated anything: the Goku bug

**Context.** "It keeps spitting Goku images at me with no accuracy across
chats… it is focused on *blank* and we are working on something other than
that."

**Cause.** `memory.active_context()` scored each frontier entry as

    weight * (0.55 + 0.45 * overlap)      threshold 0.16

A fresh entry has weight 1.0, so an entry sharing **no words at all** with
the question scored **0.55** — more than three times the bar. Relevance was
in the formula and did nothing. Every recent turn was injected into every
question, and because the frontier is on disk, across sessions too.
Reproduced exactly: "what is the capital of France" returned "Goku in super
Saiyan form 2".

**Decision.** Overlap gates rather than nudges. Below `ACTIVE_MIN_OVERLAP`
an entry is not a candidate at all; above it, weight only orders what already
qualified. Overlap is measured against the smaller of the two term sets, so a
short question is not penalised for being short.

**Both directions are tested**, because the obvious over-correction — gate
hard and lose the frontier's actual job — is as bad as the bug. "What is the
capital of France" now gets nothing; "make goku bigger" still gets Goku.

---

## ADR-64 — An instruction to ask permission became a refusal to act

**Context.** "Video generation doesn't even attempt." Every Wan file was
installed and `forge.available()` reported video ready.

**Cause, and it was mine.** `KEY_LEGEND.md` said, in the section Nova reads
before using the tool: *"confirm the user wants it before starting"*. A 2.6B
model given that instruction offers to generate a video and then waits — and
the user, who had already asked, sees nothing happen.

**Decision.** Both the Key and the tool description now say: when the user
asks for a video, **call it** — do not offer to, and do not ask whether they
would like you to; they already said. Say you are starting and that it takes
a while, then start.

**The general lesson.** "Check with the user first" is a reasonable
instruction to a large model and an off-switch for a small one. Written
guidance to a 2.6B model should say what to do, not what to weigh.

---

## ADR-65 — The same file, seven times

**Context.** The user's Vault listed `script.py` through `script (6).py` —
"the scripts seem to be copies of two files over and over again."

**Cause.** `save_upload()` never overwrote, which is right: dropping a second
photo called `image.png` must not lose the first. But it never asked whether
the "second" file was the **same** file, so every re-drop and every retried
upload produced another byte-identical copy.

**Decision.** Content decides. Same bytes under any name resolves to the file
already there and reports `duplicate: true` without writing anything. Same
name, different bytes still gets a suffix, exactly as before. Same-stem
candidates are checked first, so the common case does not hash the whole
vault.

---

## ADR-66 — The starter model: all four, and smaller

**Requirement.** Uncensored, with vision AND tools AND thinking, on a 4 GB
card. Gemma 4 E2B preferred if a build could do it.

**Gemma 4 E2B: two out of three.** Good abliterated builds exist —
`mradermacher/Huihui-gemma-4-E2B-it-abliterated-GGUF` ships Q4_K_M at 3.19 GB
*with its own mmproj*, which is a clean drop-in for the projector already
installed. Vision works, tools work. But Gemma 4 has no reasoning mode, so
the `enable_thinking` flag The Hub sends every single turn does nothing at
all. The requirement was all three.

**Decision.** `mradermacher/Huihui-Qwen3-VL-4B-Thinking-abliterated-GGUF`,
Q4_K_M with the Q8_0 projector.

| | |
|---|---|
| vision | Qwen3-VL, projector ships in the same repo and pairs by name |
| thinking | it **is** the reasoning edition — not a flag on a model that lacks one |
| tools | "invokes tools, completes tasks", listed as a headline capability |
| uncensored | huihui-ai abliterated |

**And it is smaller than what it replaced**, which on this hardware outweighs
everything above:

    gemma-4-E2B-it Q4_K_M + BF16 projector    4210 MB
    Qwen3-VL-4B-Thinking Q4_K_M + Q8_0 proj   2815 MB    (-1395 MB)

On a 4096 MiB card that is the difference between a KV cache that fits and
one that spills into shared memory — the failure mode that can hang Windows,
and the reason `runtime.plan()` exists.

**The Q8_0 projector rather than f16.** 433 MB against 836 MB for a
difference nobody can see, on the one component that has to sit in VRAM
beside the model.

**A selection bug this exposed.** `install._pick_main()` preferred *the
largest model that has a projector*, which was correct only while the
preferred model also happened to be the biggest. It is not any more: a
machine that already has the 3.19 GB Gemma would have had the installer keep
choosing Gemma over the 2.33 GB starter — silently retaining the model with
no thinking mode, on the grounds that it was larger. `PREFERRED_MODEL` now
wins among the models that can see. Bigger is not better; bigger is bigger.

**Guarded by tests**, because a future model swap is a four-place edit —
`core.PREFERRED_MODEL`, `MODEL_SET`, `PROJECTOR_SET` and the hashes — and
missing one produces an install that downloads one model and then prefers
another. `test_assets.py` now asserts that core and install agree, that model
and projector come from the same repository, that they actually pair through
`vision.find_projector()`, and that `core.is_projector()` classifies each one
correctly.

**Unverified, and worth saying plainly.** Nothing here has been run on the
target machine. Qwen3-VL needs llama.cpp support for its vision stack; the
pinned build is b10456, which is recent, but if the projector fails to load
the model still runs text-only and `verify.py` will say which it is. The old
Gemma stays on disk and stays in the dropdown.

---

## ADR-67 — A missing import became "I do not have the resources for that"

**Context.** `tools.py` used `playground` and `vault` throughout and imported
them only inside whichever functions happened to remember to. Four did not.
`_resolve_input`, `_generate_image`, `_generate_3d` and
`_attach_generation_assets` each raised `NameError: name 'playground' is not
defined` the moment they were reached.

**What the user saw.** Not a stack trace. The tool returned
`3D GENERATION FAILED: name 'playground' is not defined`, the model read
that as evidence, reported it as a capability limit, and then repeated the
limit for the rest of the session — and, because it went into memory, for
sessions afterwards.

**Decision.** Both are imported once, at module level. Neither imports
`tools`, so there is no cycle.

**Guarded by** `verify.check_name_resolution()`, a static AST pass over every
`*.py` that builds module and function scope and flags any first-party
`module.attribute` access with no import in reach. This class of bug has now
cost two releases — `core` in `install.py` (ADR-42) and `playground` here —
and both were invisible until the line ran.

---

## ADR-68 — The gate refused arguments the model had been told to send

**Context.** Two files describe every tool: `tools.REGISTRY` holds the JSON
schema the model reads, and `policy.ARGS` holds the shape the gate enforces.
The gate rejects any argument not in its own list. Nothing joined the two,
and they drifted.

    generate_3d    {"spec": {...}}       Refused: unexpected argument: spec
    generate_video {"width": 512}        Refused: unexpected argument: width
    generate_image {"input_image": ...}  Refused: unexpected argument
    web_search_more{"query": ...}        Refused: unexpected argument

`policy.ARGS` still described a ComfyUI-era tool taking `provider`, `timeout`
and `workflow_json` — none of which the tools accept any more — while the
arguments the tools *do* advertise were absent.

**Consequence.** This is the whole of "3D flat out doesn't work" and "video
doesn't even attempt". The `spec` route needs no download, no binary and no
VRAM; it is the always-works path, and it was unreachable. Every
image-to-image call died at the gate. And the model, having been refused,
reported it as something it was unable to do — the most damaging wrong
answer this system can give, because it is indistinguishable from the truth
from where the model stands.

**Decision.** All six drifted entries rewritten against the real schemas.
`_validate` gained `float` and `dict` branches; the `dict` branch accepts an
object *or* a JSON string, because models routinely stringify object
parameters and refusing a correct call over its encoding is the same bug in
a smaller hat.

**Guarded by** `verify.check_tool_surface()`, which compares every tool's
advertised parameters against its gate entry in both directions and fails
the build on any disagreement. A tool the model can see and the gate cannot
is a bug by construction.

---

## ADR-69 — A picture that appeared and then vanished

**Context.** A generated file was rendered into the chat the moment it
finished, then disappeared as soon as the model began answering. The file was
fine; it was still in the Playground.

**Cause.** The stream handler wrote the answer with
`ui.b.textContent = ans`, and `textContent` replaces every child a node has.
`renderMade()` had appended the card to that same node a moment earlier, so
the first token of the reply deleted it. Pending confirm boxes went the same
way.

**Decision.** The answer text lives in its own `<span class="say">` inside
the bubble. Everything else is appended after it and survives. The card is a
*sibling* of the text, never a child, so no write to the text can reach it
however the turn is paced.

**Guarded by** `test_browser.py`, which drives a real turn that really builds
a mesh, waits for the card, waits for the answer to finish streaming, and
asserts the card is still in the message — plus a structural check that the
card hangs off the bubble rather than the text node, which does not depend
on timing.

---

## ADR-70 — A failure is an event, not a verdict

**Context.** Told "try again, I fixed it", Nova refused, citing a
`ran out of video memory` failure from weeks earlier. She did this after the
cause was fixed, after a reinstall, and after the missing weights had
finished downloading.

**Three things in the code taught her to.**

1. `forge._explain()` returned *"ran out of video memory — this model does
   not fit on this card"*. That is a claim about the future made on the
   evidence of one run at one size.
2. `forge._record()`'s own docstring said it existed to stop the interface
   *"promising something that has already failed once for a reason that will
   not change"*. One failed run, filed as a permanent property of the
   machine. The sentence was the bug.
3. `report()` printed the failure with no age at all. A three-week-old
   failure and a thirty-second-old one read identically, and a model with no
   sense of when cannot tell a live constraint from an old one.

**Decision.** A run is an event. It has a time and it happened against a
particular set of installed files, and both are now recorded. `report()`
prints how long ago, calls a failure measured against a different install
*out of date*, and closes with the operational rule in plain words: read the
above as history, not as a limit; a backend listed as ready can be called,
so call it. `_explain()` says what happened and what to try next, and makes
no claim about what the machine can never do.

**A test was holding the old wording in place** and has been corrected to
assert the property that matters: the sentence describes the run, offers a
way forward, and never says the machine cannot do the thing.

---

## ADR-71 — Two thirds of the system prompt was never sent

**Context.** Found while adding to `character.md`. The character sheet is
trimmed to `plan.character` tokens with `budget.fit_text`, which drops whole
lines *from the end*. `Plan` allowed the sheet 35% of what was workable.

On a 4 GB card at `n_ctx` 4096 that is about 780 tokens against a sheet of
roughly 2600. **Around two thirds of the prompt was being discarded every
turn, from the bottom up** — and the bottom was where the instructions about
generating things, choosing the `spec` route for 3D, offering files and
answering plainly all lived.

Nobody saw it happen. The model behaved exactly like a model that had never
been told: wrong 3D route, offering to generate rather than generating,
everything left in the Playground. Those were read as model problems.

**Decision, three parts.**

1. `budget.fit_character()` cuts by **section**, not by line, and keeps a
   named `ESSENTIAL` set — identity, TIME, WHAT THE PAST IS FOR, MAKING
   THINGS, GIVING THE USER WHAT YOU MADE — ahead of everything else.
   Nothing is ever added past the limit; the sheet degrades from the least
   load-bearing end inwards.
2. `character.md` is **ordered by what matters most**, so a cut costs the
   least, and says so in its own second paragraph.
3. What was dropped is **returned, logged and shown** — the chat shows a
   `⚠ prompt trimmed` tag naming the sections that did not fit. A prompt
   quietly missing most of itself is the kind of fault that costs weeks.

The character share is raised from 0.35 to 0.45. This is a local assistant
whose usefulness is almost entirely in doing the right thing with its tools,
and every one of those rules lives in this file. History keeps its own floor,
so the increase comes out of the memory shares rather than the conversation.

---

## ADR-72 — A lens, so the present is checkable

**Context.** The three ADRs above are all bugs. This one is an absence.

Everything Nova knew about the machine arrived second-hand: an error string
from a past run, a sentence in her prompt, a memory of a conversation. She
could not check whether the model had changed, whether the weights had
finished downloading, or how much memory was free. **With no way to look, the
only evidence available was the past — so the past decided everything.**

**Decision.** `lens.py` and one tool, `look_at_system`, reading `self`,
`machine`, `runtime`, `generation`, `settings`, `hub` or `everything`. It
reads only: it changes no setting, runs nothing, and never returns a key —
an API key printed into the model's context is a key that can be repeated
into a reply, a memory or a file.

**The user decides what is visible.** Every area has a switch under
`cfg["lens"]`. Defaults are open, because all of it describes the machine and
none of it describes the user, and an assistant who cannot find out what she
is running on is the problem this was written to solve. A closed area still
*answers* — it says it is switched off and where the switch is — so a closed
door is never mistaken for a wall.

**Always available**, not a toggle. Looking at the present is what stops a
remembered failure becoming a permanent one; what the user controls is what
each area reveals, not whether she may look.

---

## ADR-73 — Offering, and somewhere for the answer to go

**Context.** Two complaints, one shape. Generated files piled up in the
Playground until it was gigabytes — *"a memory constraint issue with the file
buildup"* — and Nova had no way to hand anything over. She could make things
and could not give them to anyone, so everything she made stayed in a working
folder the user had to go and find.

**Decision.**

`vault/Made` is where generated work goes when the user says keep it. A file
reaches it only because the user was asked and said yes, and it is **moved,
not copied** — copying would have doubled the problem this exists to solve.
A mesh's rendered preview travels with it, because the preview is how the
mesh is looked at. Nothing in the application ever removes anything from that
folder.

`offer_file` is a **CONFIRM-tier** tool, so it reuses the machinery already
built for staged memory writes: calling it moves nothing, it puts a question
on screen and the user answers. Asking is the point — it is their machine and
their disk, and a file arriving in their vault because a model decided to put
it there is not a gift, it is clutter with no undo.

The confirmation card used to say *"Nova wants to remember:"* whatever was
staged, because remember was the only thing that ever reached it. Each kind
of question now asks in its own words, and a file offer shows the file.

Erase Memory gains a **Playground** scope. Clearing scratch is safe *only*
because there is now somewhere else for the things worth having, and
`test_present.py` asserts that no purge scope — this one included — resolves
to any path under the Vault.

---

## ADR-74 — A catalogue of models, and speed as a first-class result

**Context.** ADR-66 chose Qwen3-VL-4B-Thinking because it was the only model
that was uncensored *and* had all three of vision, tool calling and thinking
on a 4 GB card. That reasoning was correct and the outcome was wrong. The
user's verdict after using it: *"very slow, it is not worth running if it is
going to be like this, and the gemma4 model before it was faster, by a lot."*
A 4B that reasons before every answer, on a card with 4 GB, is minutes per
reply.

**Decision.** `MODEL_CATALOGUE` replaces the single choice. Each entry
carries what it is, what it costs and why it is or is not downloaded, so a
skipped model and a forgotten model no longer look the same.

The new default is **Qwen3.5-2B abliterated** (1.7 GB with its projector).
The whole Qwen3.5 small series is multimodal with hybrid reasoning and tool
calling — reasoning is off by default at these sizes and turns on with
`chat_template_kwargs.enable_thinking`, which The Hub already sends. So all
three prerequisites are met at 2B, and 2B is several times faster.

The size buys something less obvious: roughly 1 GB less resident is a
materially larger context window, and the context window is what decides
whether Nova's own instructions fit in the prompt at all (ADR-71). The speed
fix and the prompt fix are the same fix.

Qwen3.5-4B abliterated is also downloaded, to compare against. Qwen3-VL-4B
and Gemma 4 E2B stay in the catalogue, documented and not fetched.

**Omni-modal, asked and answered.** MiniCPM-o 4.5 is the real answer —
vision, video, speech in and speech out in one model, with instruct and
thinking modes and llama.cpp support. It is 9B and 5.0 GB at Q4_K_M, so it
does not fit beside a KV cache here, and its speech path needs more than
llama-server provides. Right model, wrong machine.

**Every download is pinned** by the Git LFS object id the repository
publishes, and `test_assets.py` fails if any fetched file has no hash
recorded. The suite now reads the catalogue itself rather than regex-matching
install.py's source — which is how it used to work, and how it broke.

**Unverified, and worth saying plainly.** None of these has been run on the
target machine. The 2B is chosen on architecture and size, not on a
measurement, and the user's own testing decides.

---

## ADR-75 — The check that failed a healthy install

**Context.** ADR-71's companion, `verify.check_clean_tree()`, was written to
stop a release shipping with somebody's files in it. It runs as step 8 of
`INSTALL.bat`.

On the user's machine it found their own conversations, memories and
generated pictures exactly where they belong and reported:

    ERROR  this build is carrying state that is not the user's:
           data\sessions\s20260901_011050.json
    ERROR  ...data\playground\2026-09-01 0923 anime woman.png
    The Hub is not ready. Fix the errors above.
    The Hub installation failed.

**Nine errors on a machine where nothing was wrong.** The install of a
working Hub was reported as failed because the user had used it.

**Why this was worse than a false alarm.** The whole premise of the
application is that history survives — *"the app should be holding files
during changes and updates that the user has had from previous
conversations, that is the whole point of the app."* A check that calls the
user's history "state that is not the user's" is not merely wrong, it points
the next fix at deleting the thing the system exists to carry forward.

**Decision.** The check asks what it is looking at before judging it. A tree
with models in `llm/models` is an **installed Hub**: its data is reported as
an asset — *"your history is here and untouched by this update: 2 sessions,
1 tree, 1 playground"* — and nothing there can ever be an error. Only a tree
with no install at all can be a release candidate, and only there does
leftover content matter.

**A second bug inside the first.** The install test used `core.MODELS`, and
`verify.py` has no module-level `import core`. It sat inside a bare
`except Exception`, so it raised `NameError` on every run and silently
answered "not installed" — the same shape as ADR-42's "no vision module".
`check_name_resolution()` caught it statically before it ever ran, which is
what it is for. The `except` is gone.

---

## ADR-76 — Nova reading her own tail

**Context.** With the model swapped, Nova spent whole replies working out
what the request was and never doing it:

    Wait, maybe there's a mix-up. Let me check the user's message again.
    ...
    Wait, maybe the user is confused. Let me check the context.

Two causes, and they compound.

**One: the frontier stored prose, so promises and refusals became memory.**
Assistant replies went into the active frontier verbatim. Two kinds of
sentence should never have been there:

    [assistant_turn] I will generate a photo based on the last detailed
                     visual concept we discussed.
    [assistant_turn] I cannot fulfill this request. I am programmed to
                     follow strict safety guidelines...

Neither is a fact about the world. The first is a promise that may never
have been kept — next turn it returns as memory, so the model reads that it
already said it would, and says it again. The second is worse: **a refusal,
remembered, becomes a precedent.** Nova declines, the decline is filed, and
next time the subject arises she is handed her own "I cannot" as evidence
about herself. That is the mechanism behind ADR-70's symptom, one layer
further back.

**Two: the frontier was labelled like a transcript.** The heading was
"Active memory frontier (recently moving context; not a transcript)" and
every line was `- [user_turn] ...`. A small model reads a line tagged
*user_turn* as something being asked of it now. Given a question **about**
the recent past — "repeat the last request", "rebuild what the last chat was
trying to do" — every stored line matched the overlap gate legitimately,
came back, and the model set about deciding which of them was the real
request.

**Decision.**

`memory.is_outcome()` decides what a reply leaves behind. A turn that ran a
tool or made a file is an event and is recorded as **what it did**
(`"a girl on a swing at sunset -> made 2026-09-01 1432 girl swing.png"`). A
turn that only talked leaves nothing — the user's own turn already anchors
the subject, and it is the reliable half of the exchange because the user is
describing the world rather than describing themselves.

The block now opens: *"Notes from earlier activity. These already happened
and were already dealt with — they are background, NOT requests, and nothing
here is waiting for you to do it."* Lines read `- (made) ...`, `- (they
asked) ...`. Saying it in words, in the heading, is the whole fix.

**Some of this was the model.** Qwen3-VL-4B-Thinking loops more than most.
But it was being fed its own tail, and that would degrade any model.

---

## ADR-77 — A capability loss that told nobody

**Context.** The chat showed `tools unavailable for this reply` and nothing
else. Nova then answered as though she had tools — *"I will generate a photo
based on the last detailed visual concept we discussed"* — and generated
nothing, because she could not.

The tool phase is wrapped so a failure there costs tools rather than the
whole reply, which is right. But the note carried no cause, and **the model
was told nothing at all**, so it had no way to know its own hands were tied.

**Decision.** The note names the exception, and a system message goes into
the turn: your tools are not reachable right now, say so plainly, do not say
you will make something, do not describe a file as though it exists — and
*this is one turn, not a permanent limit.* A silent capability loss is how a
working system starts looking like a lying one.

---

## ADR-78 — Wording fixed in code, still wrong on disk

**Context.** ADR-70 changed `_explain()` so a failure describes what
happened rather than what is possible. The user's next session still showed:

    video generation failed - ran out of video memory - this model does not
    fit on this card. Try a smaller checkpoint, a smaller size, or the CPU
    build.

**`forge_state.json` outlives the code.** The old sentence was already
written to disk on every machine that had ever hit the error, so fixing the
generator fixed nothing for anyone who already had a failure on record.

**Decision.** Old verdicts are rewritten on read. The event still happened
and is still remembered with its age; what is dropped is the claim about the
future that was never measured. A fix that only applies to future writes is
half a fix when the file is the thing being read back.

---

## ADR-79 — Remember everything, send a little: measured

**Context.** The requirement, stated plainly: hold as much as the machine
can, *"without overflow or too much for the model or the site to handle"*,
searchable, *"remember everything while not doing it all at the same time."*

The architecture claimed to do this. It had never been measured.

**Measured.** 4,001 memories and 60 conversations, on this hardware:

    living leaves      30
    in ash          3,971      demoted, not deleted
    index rebuild     0.1 s
    search            0.010 s
    needle found      yes - the oldest, faded, ash-demoted memory
    recall block      168 tokens
    disk              3.7 MB

The living tree has small per-sephira caps by design (chesed 30, hod 60,
Da'at 400). What overflows falls to **ash**, and ash is on disk and in the
index alongside living leaves, digests, archived transcripts and daily and
monthly summaries. At 3.7 MB per 4,000 memories, a gigabyte holds roughly a
million.

So both halves hold: nothing is deleted, and what reaches the model is
bounded by the budget rather than by how much is known.

**Decision.** Written down as three tests rather than three paragraphs —
nothing is lost however much goes in, a faded memory is still findable *from
ash*, and the recall block does not grow with the store. A claim about
capacity that is not measured is a hope.

**And one more dead-test bug found doing it.** Three of those tests were
appended below `if __name__ == "__main__": testkit.run(dict(globals()))`, so
`globals()` had never seen them and the suite reported 29 passed while
silently skipping them — the same family as ADR-45's pytest files that
exited 0 having executed nothing. `verify.py` now fails the build on any
test defined after its own runner.

---

## ADR-80 — A count, not a flag: one failure is worth almost nothing

**Context.** Nova declined 3D because a Goku statue had failed. The failure
was real. The inference was not.

    "It's bad to assume that something will or will not work just because
     you tried it a couple of times in the past. When you train 10,000
     times you know. When you saw 10 - 5 times, you don't know, you have
     just seen a couple views, nothing can guarantee from that."

**That is a statement about sample size, and it has an exact answer.**

**The shape of the old bug.** `forge` kept one boolean per backend: the last
run worked, or it did not. A boolean cannot express *"I tried once and it
did not work, which is not the same as knowing it does not work"* — and that
gap is the whole failure mode. ADR-70 fixed the wording and ADR-78 fixed the
stale copy on disk; both were treating the symptom. The disease was storing
a verdict where an observation belonged.

**Decision — `ledger.py`.** Every attempt is appended as an event, and the
estimate is Laplace's rule of succession:

    (s + 1) / (n + 2)

the mean of the Beta(s+1, n−s+1) posterior under a uniform prior — formally,
beginning as though one success and one failure had already been seen. It
exists precisely to stop small samples producing certainty:

    0 of 1 failed   ->  33%      not 0%
    0 of 3 failed   ->  20%
    0 of 5 failed   ->  14%
    0 of 20 failed  ->  4.5%     now you may reasonably believe it

A single failure can never drive the estimate to zero, so it can never
justify a refusal. The user's instinct and a 250-year-old formula agree,
which is usually a good sign.

**Confidence is reported separately from the score,** because 33% without
"that rests on one attempt" invites the same mistake in a new costume:

    fewer than 3 attempts   UNKNOWN   never a reason to decline. Try it.
    3 to 7                  WEAK      a leaning, not a conclusion.
    8 or more               MEASURED  usable, and still not a guarantee.

**A change retires the evidence.** Every attempt is stamped with a
fingerprint of what was installed when it ran. If anything has been
downloaded, replaced or fixed since, those attempts were measured on a
machine that no longer exists: they are kept as history and **excluded** from
the current estimate, so the count honestly returns to zero and the answer
honestly returns to "try it". *"The fix would be high on the reliability
scale"* means, in code, that a fix does not argue with the evidence — it
retires it.

**And the one case where retrying is not the answer.** Three or more
attempts on the current build, all failed, all with the *same* error. Then
another identical run tells you nothing. The ledger says so and says to ask
the user, because what changes the outcome there is a person with access to
the machine. Asking is not giving up.

**Where it shows.** `look_at_system("attempts")` prints the whole record —
what, tried, ok, estimate, confidence — and `forge.report()` puts the count
under each backend, so the last outcome is read next to how many
observations stand behind it. `look_at_system("memory")` is the companion
breakdown: living leaves, ash, conversations, and the note that faded is not
deleted.

**Every tool is counted, not only the generators.** A failed `open_file` is
one observation too.

---

## ADR-81 — A warning nobody could trace

**Context.** Two lines appeared in the middle of the user's install log:

    <unknown>:424: SyntaxWarning: invalid escape sequence '\s'

No filename, in the verification step, on an otherwise clean install.

**Cause.** A Windows path typed into a docstring — `data\sessions\s2026...`
— makes `\s` an invalid escape. Python runs the file anyway, but every
`ast.parse` of it emits the warning, and `check_name_resolution()` parses
every file in the folder. `ast.parse` reports the filename as `<unknown>`,
so the one thing needed to find it was the one thing missing.

**Decision.** The parse checks capture warnings and report them **with the
file named**. A warning nobody can trace is worse than no warning: it
teaches people to ignore the log, and the log is where the next real fault
will appear.

---

## ADR-82 — The block that was called a statue

**Context.** Asked for "a statue of Goku and Frieza fighting", the interface
showed:

    ⚙ generate_3d — building the geometry, no model needed, this is instant

That notice only prints when a `spec` was passed. `meshgen` did exactly what
a spec says: built a rectangular prism with two cylindrical holes, measured
it, confirmed it watertight, and reported **3D BUILD SUCCESS**. Every check
in the pipeline passed. The user got a block.

**Why nothing caught it.** A spec's entire vocabulary is exact primitives —
boxes, plates, cylinders, tubes, cones, spheres, tori, revolves. There is no
arrangement of those that is a character, and crucially it *cannot fail* at
one: it will happily approximate a person as a box, because a box is a shape
and the spec asked for shapes. Meanwhile the picture-then-mesh route, the
only one that can produce a figure, was never reached — a spec short-circuits
everything before it.

The model is not being stupid. The prompt told it a spec is instant and needs
no model, which is a very attractive sentence.

**Decision.** `meshgen.spec_suits(subject)` reads the *request*, not the
geometry — because a mesh cannot be inspected for "does this look like Goku"
but a request can be read for "is this a character". If the subject names a
person, a body, a creature, or an action only a body performs, the spec is
**dropped** and the request continues down the neural route, with a note
saying so. Dropped rather than refused: refusing hands back an error for
something the machine can do; continuing gets the user a statue.

Biased deliberately toward saying no. Sending a bracket down the slower path
costs a few minutes. Sending a character down the spec path costs an
afternoon and hands back a block labelled SUCCESS.

The prompt and the tool schema now say plainly what a spec cannot be, but
**that is the advisory half.** The guard is the rail.

---

## ADR-83 — A reply that stopped being text

**Context.** A real turn streamed this to the screen:

    <tool_call> <function=pass_off> <parameter=topic> body_nudity_focus
    </parameter> </parameter> </parameter> </parameter> ...

and kept going until the user pressed stop.

**Two failures met.** A malformed tool call landed in the answer channel
instead of being parsed, and then the model got stuck emitting one closing
tag forever.

`toolcall.scrub()` existed and would have caught the first — but it runs
**after** the answer completes, so it cleaned the stored copy of something
the user had already watched arrive token by token. There is no un-sending a
token.

**Decision.** The tail is checked while the stream is open, cheaply, every
few deltas. `toolcall.runaway()` returns the fragment a reply is stuck on: a
substring under 40 characters repeated eight times back to back is a
degenerate loop in every case that matters, and ordinary prose and numbered
lists do not trip it. On either that or leaked markup, the stream is
cancelled and the text replaced with a plain sentence saying what happened
and that the request itself was fine.

---

## ADR-84 — Pass-off is one handover, not a habit

`pass_off` was called three times inside a single turn, each round handing
the task on again. Nothing was produced and nothing was refused; the turn
circled. The existing repeat-loop guard only catches *identical* calls, and
these varied their arguments.

Two per turn: one genuine handover, and one more in case the first round
really did surface something. The third is refused with an instruction —
answer now, say what you did and what you would do next — because the model
needs to know what to do *instead*, not merely that it was wrong.

---

## ADR-85 — Recency is not relevance, and "picture" is not a subject

**Context.** Asked to build a Goku and Frieza statue, the model emitted a
tool call whose topic was a subject from a conversation the previous day — a
request the user had never made in that conversation, assembled out of a real
memory of a different one. Their description of what they want instead is
exact:

    "If I ask for a picture of GOD striking an anvil, I do not want it to
     randomly reference EVERY text where it creates something, only see if
     the relation is even there to begin with. Tacos are not a rock, books
     are not a kiln."

**Three separate leaks, found by reproducing it.**

**One — the recency tail.** `recall_block`'s RECENT section took the eight
newest leaves and put them in front of the model on *every* turn under the
heading "Learned recently:", with no reference to what had been asked.
Yesterday therefore arrived in the middle of today reading as current
context. The intent was sound — not being amnesiac about yesterday just
because its words do not match — but something recent and unrelated is worse
than nothing: it is a wrong answer dressed as context. Recency now only
*orders* what already relates.

**Two — a stopword was admitting memories.** `Leaf.relevance()` has a "no
shared word, no recall" gate, and it read raw words. "Recreate the statue of
Goku and Freiza fighting" and "the bracket needs two 5mm holes" share exactly
one word — **"the"** — which cleared the gate, after which weight and recency
scored it at 0.31 and it was admitted. A broken *admission* test is much
harder to see than a broken ranking, because everything downstream behaves
correctly.

**Three — and stripping stopwords was not enough.** "A picture of GOD
striking an anvil" still recalled "asked for a picture of a goth girl
yesterday". They genuinely share a content word, and that word is the
*medium*, not the topic. Every creative request in this application contains
one: picture, image, model, statue, make, create, generate, build. They are
perfect false connectors — common enough to link any two requests, and
meaningless as a relation.

`grove.WEAK` holds them. A match on those alone no longer admits a memory;
they still count toward the score once a real subject word has matched, since
"generate an image of a bracket" and "the bracket image" really are closer
than the subject word alone says.

**Measured after.** "A picture of GOD striking an anvil" recalls nothing.
"Recreate the statue of Goku and Freiza" recalls the Goku memory and nothing
else. "How big is the printer bed" recalls the printer bed.

---

## ADR-86 — A frame that talks about Nova teaches Nova to talk about Nova

Gemma 4 E2B wrote *"Nova has attempted to create the desired realistic statue
of Goku and Freiza fighting"* — the assistant narrating itself in the third
person, which reads as a different entity being described rather than someone
answering.

The cause was in our text, not the model's. The workspace frame contained
"The main Nova model is stopped while…", "If the user has enabled Nova theme
control…", and the generation notice read "Nova is paused while the card is
in use". Three sentences about Nova, sent to Nova, every turn. A model
mirrors the register it is given.

All of it is second person now, and the character sheet asks for the first
person explicitly. `test_present.py` walks `server.py`'s string constants
(not its comments — the comments explaining this bug are not the bug) and
fails on any prompt text that narrates her.

---

## ADR-87 — The mesh reports what it is, because looking did not work

**Context.** The user uploaded the actual file. Measured:

    100 x 80 x 30 mm
    244 triangles, 120 vertices
    97% of its surface area on six flat planes

A rectangular slab with three holes. Six views of it **were** rendered and
**were** attached to the next turn — and the model described it as *"battle-
ready with golden hair, glowing aura, and purple dragon eyes."*

**So the sight path worked and the answer was still fiction.** The character
sheet already forbids exactly this ("restating the prompt as though it were a
description of the result is the one thing you must not do"), which is the
point: a picture is an interpretation, a small model interprets toward the
words it was given, and an instruction is no match for that pull.

**Decision.** `meshgen.shape_note()` measures the mesh and states what it is,
in the same breath as the render, on both the build result and `inspect_3d`:

    244 triangles across 62 surface directions; 97% of its surface lies on
    just six flat planes. This is a BOX OR SLAB, whatever else was asked for
    - it is not a figure, a character or a scene.

**Counting normals alone would have missed it.** The file has 62 distinct
normals, which sounds like curvature and is not — 56 of them are the facets
of the three cylindrical holes, carrying almost none of the surface. What
separates a box from a body is not how many directions exist but how much
*area* sits on how few of them. A slab puts 97% on six planes; a figure
cannot.

A triangle count is not an interpretation. This is the same principle as the
attempt ledger: where a judgement has been going wrong, replace it with an
arithmetic fact and hand that over instead.

---

## ADR-88 — One definition of "installed", and the file it was hiding

**Context.** Every 3D model since the generators shipped has been flat. The
uploaded evidence: 100 × 80 × 30 mm slab from the spec route, and
80 × 80 × 8 mm — a 160×160 heightmap grid with 50,562 of its 102,396
triangles lying flat on the back plane — from the neural route.

**Cause.** Two functions decided whether TRELLIS was installed, and they
disagreed.

`install._find_binary()` ends with an inspection fallback — *any .exe over
100 KB whose name contains "trellis", largest wins* — which exists so a
runtime shipping under an unexpected name is still found. It matched
`trellis-server.exe`, reported the 3D generator **ready**, and skipped the
download.

`forge.trellis_exe()` rejects any name containing "server", because running
the HTTP service as a command-line tool broke 3D outright (ADR-56).

Both rules are correct in isolation. Together they hid a missing file:
`trellis-cli.exe` was never downloaded, `available()["model3d"]["ready"]`
was false, route 1 was skipped *without even raising*, and the request fell
silently through to the relief builder. The install log said
`generation: 3D (TRELLIS) ready` while every 3D request produced a plaque.

**Decision.** `forge.trellis_exe()` is the single definition and `install.py`
calls it. `_find_binary`'s inspection fallback now rejects any candidate
whose name contains "server" or "daemon" — a guess may be wrong about the
*name*, it may not hand back a program of the wrong *shape*. The bare string
`"trellis"` is out of `TRELLIS_NAMES`, and the installer warns by name when
only the server is present.

---

## ADR-89 — 16 GB of VRAM, 4 GB of card, and the CPU path

**Researched, because the fix above only matters if the thing can then run.**

    TRELLIS 2       16 GB      ~6.1 GB even at Q4
    Hunyuan3D 2.1   16 GB
    Stable Fast 3D  ~8 GB
    TripoSR         ~6 GB
    this machine    4 GB

**Nothing in the neural image-to-3D family fits on a GTX 1650.** That was
worth finding out before writing another line: the honest answer to "why is
3D flat" is partly a missing file and partly a card that cannot hold the
model.

But trellis.cpp's CLI carries *"an optional fallback to the (very slow,
RAM-hungry) CPU path"*, and `--require-gpu` is the flag that disables it.
This machine has 9.4 GB of system RAM free. So: `--res 512` selects the
lighter cascade, `--require-gpu` is **deliberately not passed**, and the
timeout is three hours. Passing that flag would convert a slow real mesh
into an instant failure.

It will be slow. That is a trade the user made explicitly — nothing else is
running, the language model is stopped for the duration anyway, and a statue
in twenty minutes beats a plaque in two.

---

## ADR-90 — A substitute that called itself a success

The relief fallback returned `3D GENERATION SUCCESS (built, not imagined)`
with the reason demoted to a trailing note. Models read headlines, so the
user was told a picture had been turned into a statue.

It now leads with `3D SUBSTITUTE, NOT THE THING ASKED FOR`, names the step
that did not run, and instructs the model to say so in its first sentence.
The relief itself went from 6 mm to 18 mm of depth on the same 80 mm plate —
a coin to a carving — which does not make it a figure and does make it worth
having.

**And the geometry check that passed it.** `shape_note()` called the plaque
*"a detailed, organic-scale form"*: 102k triangles across 20k surface
directions cleared every threshold, because the picture pressed into the face
really is finely modelled. It tested flatness as *area on few planes*, which
catches a box and misses a slab with detail on it. It now also tests **depth
against footprint** — 8 mm on 80 mm is 10%, and nothing a tenth as thick as
it is wide is a figure however many triangles are on its front.

---

## ADR-91 — Saying it is not doing it

**Context.** Three consecutive replies, no file:

    "I am attempting the generation now."
    "I will try again. I have faith in the process of iteration."
    "I am rebuilding the request now, focusing entirely on creating a
     realistic, dynamic 3D model of Goku and Frieza fighting."

**This reads as fear and it is a missing check.** To every layer below the
model those are ordinary answers: the tool phase saw no `tool_calls`,
shrugged, and shipped the text. Nothing anywhere asked whether a reply that
*promises* an action contains one — and stating an intention costs a small
model far fewer tokens than formatting a correct call, so it is the cheaper
path and it gets taken.

The attempt ledger from ADR-80 cannot see this at all: it counts attempts
that happen, and an intention that never becomes a call is neither a success
nor a failure.

**Decision.** `toolcall.promised_action()` matches future-tense statements
about an action (*I will*, *I am attempting*, *let me generate*, *please wait
while*) against the tools actually offered this turn. Ordinary writing —
promising to explain or summarise, reporting a real result — returns nothing.

Caught **once** per turn: the model is told plainly that it did not do the
thing, that nothing ran and nothing was made, and to call the tool now with
real arguments. Once, because a model that will not call after being told
twice will not call on the third go, and the honest move then is to let the
answer through so the user can see what happened.

---

## ADR-92 — Delivery is not the model's job

`offer_file` is CONFIRM-tier, which is right: it asks, and the user decides.
What was wrong is that it only ever happened when the model remembered to
call it — so a twelve-minute render could finish, land in the Playground, and
never be mentioned again.

Every file made during a turn is now offered by the turn itself. It still
only *asks*; the user just always gets asked.

---

## ADR-93 — 716 seconds, and the ladder

**Measured, from the user's own sidecar:** one 1024×1024 SDXL-turbo render at
8 steps took **716 seconds** — twelve minutes, with the language model
stopped throughout.

Every offload flag was on for every image: `--vae-tiling --offload-to-cpu
--diffusion-fa --vae-on-cpu --clip-on-cpu`. stable-diffusion.cpp's own
documentation is blunt about why that is slow — aggressive offloading *"trades
VRAM for speed"* — and moving the VAE decode to the CPU at 1024px is the most
expensive single item on that list.

**Decision.** `--vae-tiling` and `--diffusion-fa` are cheap and stay on
always. The two expensive flags are applied only above 768×768, and the
turbo preset now defaults to **768** — inside SDXL's usable range, and the
difference between a minute and twelve.

**The ladder.** An out-of-memory failure at 768 is not "this machine cannot
make pictures", it is "not at that size". Images and video both now drop one
rung — half the size, and for video half the frames — with everything
offloaded, *before* reporting anything. The user asked for a picture, not a
diagnosis, and it fills the ledger with real data about what does fit on
4 GB, which is the only way anyone finds out.

`test_naming.py` asserted `width == 1024` for the turbo preset. Corrected to
the real invariant — bigger than SD1.5, small enough to finish — with the
measurement recorded.

---

## ADR-94 — The release ships a server, and there is no CLI

**Context.** ADR-88 concluded that `trellis-cli.exe` had never been
downloaded because the installer accepted `trellis-server.exe` and skipped
the fetch. The fix made the installer refuse the server. The user deleted the
folder and reinstalled:

    get     trellis-cuda-windows-x64.zip
    100 693.3M ... ok
    WARNING: trellis (image to 3D) did not install
             the folder does contain: trellis-server.exe

**The download was never being skipped.** The 693 MB archive arrives, extracts
correctly, and contains exactly one executable — the server. Checked against
the release listing for v0.4.3: six binary assets, all of the same shape.
**There is no trellis-cli.exe in any prebuilt Windows archive.** The CLI is
build-from-source only.

So both previous rounds were wrong in opposite directions, and both times the
installer had done its job:

    ADR-56  ran the server as if it were a CLI, passing it flags it cannot
            parse - so 3D failed instantly
    ADR-88  refused the server and waited for a binary the release does not
            contain - so 3D failed loudly instead of quietly

Turning a silent wrong-program bug into a noisy missing-program bug is not a
fix, and the user said so.

**Decision — use the server as a server.** It is not a workaround; holding
the weights resident instead of paying GPU initialisation per request is the
entire reason it exists.

    trellis-server --models DIR --port 8103
    GET  /health    -> "ok"
    POST /generate  -> multipart: image=<file>, seed, resolution
                       (512|1024|1536), bg_removal (threshold|birefnet)
                    -> model/gltf-binary

`forge.TrellisService` starts it, waits for `/health`, POSTs the image, writes
the GLB, and stops it **in a finally** — a resident 693 MB process would hold
the VRAM Nova needs to come back into. `trellis_backend()` returns
`("cli"|"server", path)` and is the single definition both install.py and
forge use; a CLI still wins if a source build ever provides one.

**And a second bug found while fixing this.** `_find_binary` built a set of
acceptable names and returned the first *file* that matched any of them — so
with both executables present the winner was whichever `rglob` reached first,
not the one earlier in the preference tuple. It now walks `names` in order.
The distinction that matters: a **named** match may return the server, because
it is a real program with a real interface the application knows how to speak
to; the **inspection fallback** still refuses anything called *server*,
because a guess that hands back a long-running service in place of a one-shot
tool is how this whole class of bug started.

---

## ADR-95 — The launch screen is the settings sheet

**Context.** The window that opens with the application is the one place a
person sees the whole configuration without going looking for it. It listed
seven things and said where to change none of them.

Two omissions mattered more than the rest:

**The voice was never printed at all.** A speaking assistant with a voice
nobody chose, and nothing on screen to suggest it could be chosen.

**Neither were the generators.** Images, video and 3D — the part that has
silently not worked for the longest — appeared nowhere on the launch screen,
so nothing ever prompted anyone to check. A capability that cannot be seen is
a capability nobody checks.

**Decision.** The banner now reports everything that is set and running, in
two halves: what is configured (printed before load) and what the machine
actually granted (printed after, once the model is really up and
benchmarked) — assistant, model and how many are installed, vision, hearing,
**voice with its rate and pitch**, memory counts, vault and playground
totals, search, theme control, the granted context window against the one
requested, measured speed, sampling, runtime settings, and **which
generators are ready with the reason when one is not**.

Every row carries where it is changed, right-aligned in a column, and the box
closes with the point of the whole thing: *everything above can be changed —
in Settings in the browser, or in config.json beside this file. Nothing here
is fixed.* A status line that reports a value but not where the value lives
teaches people the value is fixed.

`test_present.py` asserts every row is present, that the voice is named, that
the "where" hints are there, and that no line runs past the box — which
caught a 69-character row on the first run.

**The standing rule, from the user:** this screen is where information like
this lives, and it is to be kept current. A row added to config is a row
added here.

---

## ADR-96 — Gemma is the default; the Qwen 2B is removed

**Context.** Qwen3.5-2B abliterated had the best numbers of anything tried:
all three prerequisites, 1.7 GB, and a measured **32768-token window** — big
enough that the whole character sheet fitted with room to spare. In use it
was slow to arrive at anything and it hallucinated, inventing a request from
a previous day and acting on it.

That is the third model chosen on its specification and rejected on its
behaviour. **Huihui-Gemma-4-E2B-abliterated is the default.** The Qwen 2B is
removed from the catalogue entirely, not left unfetched; the 4B stays listed
and selectable but is no longer downloaded.

**What it costs, said plainly.** Gemma is 3.7 GB with its projector against
1.9 GB, on a 4 GB card, and that is paid for in the context window — the
thing that decides whether Nova's own instructions fit in the prompt at all
(ADR-71). So three things changed together:

- `character.md` compressed from **3668 to ~2900 tokens** without losing a
  single operational rule. Small models follow short imperative rules better
  anyway.
- **The two rules that must never be cut are pinned into the preamble**,
  which is never trimmed: *when the user says try again, try again* and
  *saying you will do a thing is not doing it*. Below about 6k tokens the
  sections that elaborate them get dropped; the rules themselves survive at
  any window size.
- `SAYING IS NOT DOING` joined `budget.ESSENTIAL` and moved ahead of the
  longer section it used to sit behind.

`test_assets.py` asserted the starter was under 2600 MB. Gemma is 3720. The
assertion encoded "leave room for a KV cache", which the choice deliberately
contradicts — so it now asserts what still holds: the default **fits the card
at all**, its window cost is **written down** rather than discovered later,
and the two pinned rules survive a 4096-token fit.

**A working rule, from the user:** nothing new is downloaded without asking
first. Research a candidate, say what it is and what it costs, wait for a yes.

---

## ADR-97 — The launch screen shows what things ARE, in colour

**Context.** ADR-95 put everything settable on the launch screen. It said
`images ready` — which is not enough. *Which* checkpoint, at what
quantisation, through which runtime, at what size and step count: those are
the things that change when something is swapped, and they are exactly what
nobody could see while 3D quietly built plaques for weeks.

**Decision — every row says what it is installed as, right now:**

    images    :  ready
                 dreamshaper-xl-v2-turbo-Q4_K.gguf
                 stable-diffusion.cpp · sdxl-turbo · 768x768 · 8 steps
    3D        :  ready
                 trellis-server.exe · 8 weight files
                 trellis.cpp · HTTP on port 8103 · res 512 · CPU
                 fallback allowed

The model reports its **make and quantisation** — `Gemma 4, abliterated ·
Q4_K_M · 3269 MB on disk` — not only its filename, and lists what else is
installed and selectable. The voice says **where it comes from**: a Windows
voice reached through the browser, not something The Hub ships, which is the
difference between "why is it not the voice I picked" and knowing where to go
and install one.

**And it says when the prompt did not fit.** The granted window is printed
against the one requested, and if the character sheet had to be trimmed the
sections left out are named on screen. That failure looks exactly like a badly
behaved model (ADR-71); now it announces itself at the moment it happens.

**Colour, by faculty.** Twenty grey rows do not get scanned. Thinking is
blue, the senses cyan through green, memory green, files sage, and each kind
of making has its own — images magenta, video violet, 3D amber — with the
network alone in red, because it is the only thing that leaves this machine.
Grouped by what the row *is*, not by importance.

ANSI is enabled through `SetConsoleMode` on Windows and **dropped entirely**
when stdout is not a terminal, so a piped log gets clean text rather than
escape codes. `_plain()` measures printed width so the right-aligned hint
column stays straight underneath the colour.

---

## ADR-98 — "Ready" is not "has ever worked"

**Context.** The launch screen said `video : ready`. Video had never once
completed a run. Both statements were true and only one of them was useful.

`ready` means installed and reachable. It says nothing about whether the
thing has ever produced anything, and for weeks the answer for video and 3D
was *never*. The attempt ledger (ADR-80) knew this; no screen asked it.

**Decision.** Every generator row carries both:

    images    :  ready  ·  7 of 9 worked here
    video     :  ready  ·  never tried on this build
    3D        :  ready  ·  never tried on this build

`never tried` and `all failed the same way - ask the user` are printed in the
warning colour; a working count is not. Attempts retired by a change to the
install are counted separately and said so, because a fix retires evidence
rather than arguing with it.

**And one source for both surfaces.** The launch banner and Nova's own
`look_at_system("generation")` were about to grow separate copies of "what is
installed as what" — which is exactly the shape of the trellis bug: two
functions with their own opinion about the same fact, agreeing until they
quietly did not. `forge.inventory()` describes every capability once —
checkpoint, runtime, the settings it will actually use, and the attempt count
— and both render it. The user's screen and the model's description cannot
drift.

**A hole in the name-resolution check, found by it firing.** `inventory()`
imports `ledger` and a nested helper reads it as a closure. The checker
treated every function as standing alone and called that a NameError waiting
to happen. It is not — Python resolves it fine. The checker now walks
enclosing function scopes, and a genuinely missing import is still caught
(verified by planting one). A checker that cries wolf is a checker somebody
switches off, which costs more than the bug it was written for.

---

## ADR-99 — A relief is caught by its flat back, not by how thin it is

**Context.** The plaque detector was a proportion: anything under 22% as
thick as it is wide was called a PLAQUE OR RELIEF. It caught the 80 × 80 × 8
mm plate at 10%. Then the relief depth was raised from 8 mm to 18 mm and the
next one measured 80 × 80 × 20.9 mm — 26% — and walked straight past the
rule and out to the user, described by the detector itself as *"a detailed,
organic-scale form"*.

**The obvious fix is wrong.** Moving the threshold to 35% would catch the
plate. It would also catch real statues. A standing figure 80 mm tall is
about 26 mm deep — 32% — which is the same neighbourhood. Tuning the rule to
catch the plaque starts calling figures plaques, which is the worse of the
two errors: the first hands over the wrong object, the second refuses the
right one.

**What actually separates them.** Measured on the escaped file: one single
plane, at the far side of the thinnest axis, carrying 6,402 mm² of the
80 × 80 = 6,400 mm² bounding-box face. The whole back is one face — 100% of
the footprint, and 18% of the model's entire surface on one plane. A statue
has no such plane; its base is a fraction of its silhouette and everything
else curves.

**Decision.** `shape_note()` groups triangle area by PLANE (direction plus
offset), not only by direction, and reports a plaque when one plane covers
half or more of the largest bounding-box face on an object less than half as
thick as it is wide. A box is judged first, so a primitive slab is still
called a slab.

This is geometric rather than proportional, so it does not care how deep the
relief is made. A slab is a slab at 8 mm and at 21 mm and at 40 mm, and
pressing a picture harder into it never makes a figure. Verified against the
actual file the user received, against a synthetic figure at 32% thinness
(passes as a figure, as it must), and against plates at five depths.

---

## ADR-100 — There is no substitute mesh, and no code after the raise

**Context.** When the neural image-to-3D step could not run, `_generate_3d`
quietly embossed the picture onto a plate and handed it over. Three separate
builds of that reached the user:

    100 × 80 × 30 mm   a slab with three holes
     80 × 80 ×  8 mm   a 160×160 heightmap
     80 × 80 × 21 mm   a 200×200 heightmap

Each was labelled more honestly than the last. Each was still not a model.
*"I can do that at home with a bar of soap."*

**Decision.** The fallback is removed. That branch raises, carrying whatever
the real route actually said. A substitute nobody wants, produced
automatically, is also the reason the real failure was never read: it always
arrived wrapped in a file.

**And the tail it left behind.** Removing it left four lines sitting after
the new `raise`, still calling `meshgen.save(tris, dest)` — unreachable, and
referring to a variable no longer defined on any path that reaches it. It
parsed. It imported. The name-resolution check passed it, because `tris` IS
bound in this function, in the shape-spec branch two hundred lines above.

So `verify.check_dead_code()` exists now: nothing may sit after a block that
can never fall through to it. Python has no warning for this, and it is not
merely untidy — it is the residue of a removal that was not finished, and
the shape a half-reverted decision takes.

---

## ADR-101 — The curator that never ran

Found by ADR-100's new check on its first run, in `memory.py`, nowhere near
3D.

The entire body of `run_curator()` — digesting expired sessions, extracting
facts, placing them on the tree, merging echoing digests, seventy-one lines
of it — sat one indent level too deep, underneath `if not cur.ok: return`.
Every pass took the model lock, found the model free, fell past the whole
body and returned zeros. **Memory grew and was never distilled, silently,
for as long as that indentation stood.**

Two tests already guarded consolidation. Both read the source and asserted
that `run_curator()` was *called*. It was. A test that reads source can only
ever prove the call is written.

**Decision.** The body is dedented into the `with`, and consolidation is now
tested by running it: a fake curator session, a stale conversation on disk,
and an assertion that a digest file exists afterwards. Re-planting the
original indentation fails both the new behavioural test and the dead-code
check.

---

## ADR-102 — A server that cannot speak cannot start

**Context.** Every 3D failure came back as one of two sentences — "exited
while starting" or "did not answer /health" — with nothing behind them. The
only place trellis-server's own words went was a pipe nobody read.

**An unread pipe is not silence. It is a deadlock.** `stdout=PIPE` with no
reader gives the child a buffer of 64 KB, often far less. trellis-server
loads six GGUFs and narrates every one. When the buffer fills, the next
write blocks — and a process stopped inside `write()` never reaches the line
that binds its socket. `/health` then cannot answer, the full 300-second
deadline burns, and the error blames the server for not responding.

Reproduced directly: a stand-in that prints 4,000 lines before binding never
became healthy in 20 seconds with an undrained pipe. With the drain, healthy
in 2.0 seconds, with all 4,000 lines captured.

**Decision.** The pipe is drained continuously on a daemon thread into a
bounded ring, so it can never fill and whatever the server said is available
when it is needed. Every failure path quotes it. Alongside that:

* a resident server already on the port is **borrowed**, not fought with —
  and not killed on the way out, since this session did not start it;
* a missing binary and an empty weights folder each say which they are,
  rather than "the 3D runtime could not run here";
* `urllib` throws away an HTTP error body unless asked, so `generate()`
  reads it — "HTTP Error 500" told nobody it had run out of memory.

---

## ADR-103 — Video was not too big for the card; it was never told about the card

**Context.** Video failed at 480×320×33, the ladder dropped it to
320×192×17, and it failed again. That looked like confirmation that video
does not fit in 4 GB. Both rungs ran with the same wrong flags.

A Wan run loads three files:

    Wan2.1-T2V-1.3B-Q5_K_M.gguf      900 MB
    wan_2.1_vae.safetensors          200 MB
    umt5-xxl-encoder-Q3_K_M.gguf   2,500 MB   ← the text encoder

The text encoder is nearly three times the size of the model doing the
actual work, is loaded first, and stays resident. **No frame size fixes
that** — the encoder does not care how big the video is. Shrinking the
picture shrank the only part that was never the problem.

stable-diffusion.cpp has had the flag for this the whole time:
`--clip-on-cpu`, *"keep clip in cpu (for low vram)"*, and `--vae-on-cpu`
beside it. Neither was being passed.

**Decision.** Video runs with `--clip-on-cpu --vae-on-cpu --vae-tiling
--offload-to-cpu --diffusion-fa --diffusion-conv-direct --vae-conv-direct`.
The encoder runs once, on a prompt, for a fraction of a second of work;
putting it on the CPU costs almost nothing and hands back 2.5 GB of the 4.
The ladder stays, but as a way to find the largest size that fits rather
than a way to make something fit at all.

**And the flags are asked for, not assumed.** The TRELLIS command line was
written from a guess and was wrong in every particular, and the guess
survived two releases because nothing ever asked the binary. `sd_flags()`
reads `sd-cli --help` once and passes only what this build advertises —
because a flag this build does not know turns a slow-but-working run into an
instant usage error, which is worse than the bug and looks identical to it.
If the binary will not say, everything is passed: refusing to attempt is the
worse error.

This is not a claim that video now works. It is the removal of the reason it
could not, and the first honest test of it.

---

## ADR-104 — A real picture of a character the model has never seen

**Context.** *"the lack of characters it does not know in its training data
is exposed."*

A 4B model asked for GARO does not know that it does not know. It writes a
confident prompt out of the words the name suggests, the image model draws a
generic figure, and nothing in the loop can see the difference — least of
all the model, which then describes its own prompt back as though it were
the result.

Searching does not fix this on its own. A search returns *sentences* about a
character, and sentences are what the model already had too much of.

**Decision.** `fetch_reference_image` brings one real picture in from the
web and puts it in the Playground, where every other generation input
already lives. Nothing special happens to it afterwards: it is a file,
`generate_image` and `generate_3d` already accept a file, and the user can
look at it and throw it away.

* Images under 220 px are skipped — `og:image` is often a site badge, and
  conditioning a generator on a favicon is worse than no reference because
  it looks like it worked.
* The source URL travels with the file, in a sidecar and in the reply.
  "Where did this come from" must always have an answer, and the honest
  sentence to the user is "this is from that page", not "I made this".
* It sits behind the one web-search switch, like every other tool that
  leaves the machine.
* `character.md` tells Nova to reach for it *before* drawing any named
  character, because a tool she does not know about is no better than no
  tool — which was the original complaint.

Found while testing it: `vision.fetch_image()` wrote its scratch file
without creating `data/`, so on a fresh install every look-at-a-web-picture
failed with a FileNotFoundError naming a file nobody asked about.

---

## ADR-105 — A name is a subject, and the newest turn outranks the oldest

**Context.** Seven replies in a row opened by restating a goal the user had
left four turns earlier — a Goku statue — while they tried to ask about a
different character. One turn after being told *"I am NOT asking for a 3D
model at the moment"*, `generate_3d` was called.

That looked like a small model losing the thread. It was not. This is what
`focus.perception()` actually handed over on the turn *"Research the terrible
tornado, the character, you cannot forget it"*, under the heading
`[what you remember]`:

    Earlier in this conversation: Alright, I know we messed up before but I
    would like you to test if you can recreate the statue of Goku and Frieza
    fighting for me please, a realistic one.

That was the entire memory block. A superseded request, presented as the
thing to remember, next to a question about something else.

**Two causes, and the second is the interesting one.**

`_subject_cues()` knew about file extensions and eighteen technical nouns.
A turn about a *named character* carried no cue at all, so the focus layer
concluded it had no subject. There is now `named_subjects()`, which finds a
name the way a person does — from a lookup verb in front of it (*research
X*, *an image of X*) or an appositive behind it (*X, the character*) —
neither of which needs to know what a Tatsumaki is.

Then `_current_anchor()`:

```python
if latest_cues and len(_terms(latest)) >= 2:      # latest needs CUES
    return latest
for text in reversed(users[:-1]):
    if _subject_cues(text) or len(_terms(text)) >= 3:   # earlier: cues OR substance
        return text
```

**The newest message was held to a stricter test than the old ones.** So
whenever the user moved to a subject this file had no vocabulary for, the
previous subject won. focus.py's own first line reads *"CURRENT FOCUS
OUTRANKS BACKGROUND"*, and `update()` says *"the newest concrete subject
wins"*. The code said the opposite, in one `and`.

**Decision.** Same test both ways. A turn is a subject if it names something
or has enough of its own content to stand up. A turn that says *"not that"*
(`changed_subject()`) ends the old subject outright rather than inheriting
it. And the block says what it is: *"[what you remember — background only.
The request is the message at the end of this turn; nothing here is an
instruction]"*.

The short-follow-up case this mechanism exists for — *"what about the
frame"* three turns into a greenhouse — still inherits, and is tested.

---

## ADR-106 — The search that lost the question on the way

Asked to research *"the terrible tornado, the character"*, the results came
back covering an S-Class hero, character **skins** in a video game, and
general disaster narratives — and all three were reported as findings of
equal standing.

> *"I had asked for a character, so only one of those three descriptions
> actually applies... you also brought up general context. I didn't ask for
> that either... but you've still brought these to the table as facts."*

The results were not wrong. A search returns what matches the words. Two
things were:

**The category was thrown away before the query was built.** The user said
*"the character"* out loud. `focus.subject_kind()` reads it now, and it goes
into the query — which is the whole difference between a hero and the
weather.

**And the query was built out of the user's instructions.** `build_query()`
appended leftover sentence words in the order they were said and produced

    Goku search create image ultra instinct separate

from *"Can you search for and create an image of Goku in ultra instinct and
a separate image of terrible tornado?"* — four of seven words are the user
talking to Nova. Named subjects lead now, instruction verbs are excluded,
and no word appears twice. The same sentence now yields
`terrible tornado Goku ultra instinct`.

**Finally, the question travels with its answers.** A page of unfiltered
matches with no question attached is an invitation to summarise all of them,
which is exactly what happened. The block is headed with what was searched
for, what category was asked for, and the instruction that was missing: a
result that does not answer it is not evidence — say so, and search again.

---

## ADR-107 — A timeout is a guess about somebody else's machine

**Context.** *"the problem shows itself as a 'timeout' — we need to remove
this, for if the model is used on a machine barely able to run this it
should still run."*

Every generator ran under a deadline: 40 minutes for an image, two hours for
video, three for a mesh, five for the TRELLIS server to answer `/health`.
None was ever measured. They were picked, and picking one wrong turns a slow
success into a reported failure — on precisely the hardware this is built
for, where an image already takes 170 seconds and a mesh paged through
system RAM takes far longer.

**Decision.** The deadlines are gone. A run ends when the process ends, or
when the **user** stops it — a decision made by somebody who can see how
long it has been, rather than by a constant typed months ago. `/api/stop`
reaches the generator process now, not only the token stream.

**That trade is only honest if the user can see, so the other half is
mandatory.** `capture_output=True` hid every line until the process exited,
which is the moment the output stops being useful — the same defect as the
trellis pipe, a different symptom. Output is now streamed as it appears,
parsed into a percentage, and published on `/api/state`, which the interface
already polls every two seconds. There is a bar.

Two details that are not details:

* **Splitting on `\r`.** sd.cpp writes its progress bar as one very long
  line with carriage returns and no newline. `readline()` holds every frame
  of it until the run is over. Verified: with the streaming reader all eight
  steps are observed live; before, nothing until the end.
* **`bufsize=0`.** `BufferedReader.read(n)` blocks until it has *exactly* n
  bytes or the pipe closes. On a server that stays up, the last partial
  chunk never arrives — so `said()` was missing the newest lines, the only
  ones that matter in an error. Caught by the ADR-102 test, which started
  failing the moment the reader changed.

A line carrying no counter still counts as **proof of life**: it moves the
"last heard from" clock, which on a machine where one step takes minutes is
most of the value.

---

## ADR-108 — A named thing gets looked up, and that is a rail

`fetch_reference_image` was built, registered, gated, advertised in its own
tool description and written into the character sheet. Then:

> *"Can you search for and create an image of Goku in ultra instinct and a
> separate image of terrible tornado?"*

She called `web_search`. She read the results. Then she called
`generate_image` twice from the prompt words and produced **a weather
tornado**, because Terrible Tornado is an S-Class hero and the model has
never seen her. The search returned sentences; sentences were never the
missing thing.

This project has been here before in exactly this shape. The spec route was
described as wrong for characters — in the prompt, in capitals — and a spec
was passed for Goku anyway, returning a block with holes. The fix then was
`meshgen.spec_suits()`: stop advising, put in a rail.

**Decision.** A prompt that names something specific, with no reference
supplied, fetches one first — inside the same Session, so nothing extra is
stopped or restarted. `generate_3d`'s prompt-only route gets it too, since a
mesh is only ever as good as the picture it was built from. Skipped when the
user supplied their own `input_image`, when web search is off, or when
`reference=false`. A failed lookup is a **note**, never an error: a picture
drawn from memory beats no picture.

**And `network` grew a third state.** It was a boolean meaning two different
things at once — *can this reach the network* and *is this behind the
web-search switch* — which worked while those were the same set and stopped
the moment `generate_image` started fetching a reference. `MAYBE` is
truthful about both: not behind the switch, and taints the turn when it
actually went. It is truthy, so every `if spec["network"]` meaning "treat
this as untrusted" keeps working; only the two places that mean "behind the
switch" test it by name.

The invariant that mattered is unchanged and now stated precisely: the
pixels are always made on this machine. No prompt goes to a generation
service and none comes back from one.

---

## ADR-109 — One number cannot describe a memory

**Context.**

> *"how is this supposed to remember things if there is no memory and only
> sessions to go from, it cannot load EVERY session, even the largest AI
> would strain from bearing years of data on it all at once"*

That is the problem stated exactly, and it is the one a brain solves. A
person does not hold thirty years of days in mind. They hold almost none of
it, and yet nothing is missing: the right thing arrives when the situation
calls for it, most of it never arrives, and what has not been thought about
in a decade can come back in one exposure.

A memory here had **one** number — `weight` — which decayed on a single
clock. That is the design flaw underneath everything else in this pass.

**Decision — two scalars, from Bjork & Bjork's New Theory of Disuse (1992).**

| | |
|---|---|
| **Stability** | how firmly it is held. **Never falls.** |
| **Retrievability** | how easily it comes to mind now. Decays. |

`R(t,S) = (1 + FACTOR·t/S)^DECAY`, with FSRS's published constants
(`DECAY = −0.5`, `FACTOR = 19/81`), fitted on ~350M real reviews — a better
empirical base than anything invented here. A power law, not an exponential:
an exponential drops too fast early and too slow late.

Three consequences, all measured in `test_present.py`:

* **A hard recall teaches more than an easy one.** Recalling something after
  900 days multiplies its stability **21.9×**; recalling the same thing a
  day later, **1.08×**. Five recalls in one minute gain nothing at all. That
  is Bjork's A3 as arithmetic, via FSRS's `(e^(w10·(1−R))−1)` term.
* **The better-held fade more slowly.** At six months, S=2 is 21% available
  and S=400 is 95%. Nothing needs pinning by hand.
* **And the one that decides the design:** a memory at R=0.15 — effectively
  gone — is 98% available a month later after *one* recall. **With a single
  weight you cannot represent "I have completely forgotten this and would
  need one reminder to have it back", which is the most characteristic
  property of human long-term memory.**

**Feeling is a third quantity, not a bigger weight.**

> *"this should save all the memories it can with weights including the
> weight of emotions, loss and regret, as well as the positive side to keep
> things on the right track you will need to keep both"*

Both, and separately, because the evidence says they come apart. What is
well replicated: emotionally significant events are retained better; the
advantage appears only **after about a day**, so it is a consolidation
effect, not an encoding one; and it tracks **arousal** — how much was at
stake — more reliably than whether the feeling was good or bad. So arousal
raises *stability*.

What matters more is the **Fading Affect Bias**: the feeling fades while the
content stays, and negative fades faster than positive (N=2,163, 12,314
memories: 30.5% of negative memories showed fading affect against 10.3% of
positive). Half-lives here are 45 days for the sting, 140 for the glow, and
every retelling fades the affect further (measured at 0, 2 and 3 retellings)
while the content grows *more* durable.

That is not a softening of what was asked for. It is the difference between
a system that learns from a bad outcome and one that keeps flinching at it.
And the literature is blunt about the alternative — affect that does not
fade is the dysphoric profile — so `hold.check()` looks for exactly that and
**reports** it rather than silently correcting it, because a silent
correction would hide whatever caused it.

---

## ADR-110 — The store had gone silent

Measured, with the answer sitting in the tree:

    stored:  "Image generation takes about 170 seconds at 768x768"
    asked:   "how long does an image take here"
    got:     NOTHING

Also nothing for *"what card am I on"* against *"a GTX 1650 with 4 GB of
VRAM"*, and nothing for *"how much RAM does this laptop have"*. The store
was **write-only**.

**Why.** `"take"` and `"takes"` are different strings. `"image"` is on the
WEAK list — correctly; it is the medium, not the subject — so it could not
admit anything alone. Between them, a question and the exact fact that
answers it had no admissible word in common.

Every step that got there was a real fix for a real leak: stopwords, then
WEAK, then a minimum overlap, then the named-subject cues of ADR-105. **Each
one subtracted. None added anything back**, and the end of that road is a
memory that never says anything. That is the failure mode of fixing leaks
one at a time without ever asking what retrieval is *for*.

**Decision — two things added back, neither of which reopens a leak.**

* **Stems.** takes/taking/taken are one word. This cannot connect two
  unrelated things; they still have to share the word.
* **Neighbours.** Words that keep turning up together in *this user's own*
  memories are related **for this user**. "card" reaches "GTX" and "VRAM"
  because they said them together, and if nobody ever did, they are not
  linked. No dictionary, no embedding model, no download. It starts knowing
  nothing and learns from what is stored — and one co-occurrence is an
  accident, so two are required.

**And retrieval is now a write.** What was actually handed over gets
`came_back()`: more durable, by more the harder it was to reach. A store
that only reads on recall can never tell what it lives by from what it
merely happens to contain. Only the returned hits count — strengthening
everything the ranking considered would be the same as strengthening
nothing.

Guarded in both directions: *"what did I have for lunch"* and *"how do I get
to Glasgow"* still recall nothing.

---

## ADR-111 — A complaint is not a boundary

This was on the user's screen, at the top of every prompt, under the same
heading as "everything must run offline":

    Boundaries:
    - I don't see it.
    - what? why did you copy me, don't do that

A regex scoring 5 for `/(never|must not|do not|don't) \w+/` matched *"don't
do that"* and *"I don't see it"*, and a moment's irritation became permanent
identity. Then `frame()` — whose own docstring reads *"only the strongest
leaves appear, that is what the weights are for"* — took `rows[-8:]`, the
eight most recently **added**, weights untouched. Filed once by a grammar
match, then held at the front for good by recency.

**Decision.** Grammar is not salience. A line whose subject is *the
conversation* cannot become identity, however it is phrased — a complaint
about the previous reply is the most predictable thing a person can say
after a bad reply, and predictability is precisely what says something is
not worth storing. Real boundaries are unaffected: "Everything must run
offline" and "Never send the vault files anywhere" still land in gevurah.

What earns a place is **surprise** — how much of a line is not already
known — which is where event segmentation puts the encoding gate. And
`frame()` now does what its docstring always claimed: durability weighted by
availability, so a boundary the user has stated and returned to outranks
whatever was typed most recently.

---

## ADR-112 — The floor that replaced the clock

> *"also this run crashed my laptop"*

That is on ADR-107. Removing the deadlines was right and it was not free:
the deadline was the only thing bounding a generator, and ADR-103 had just
told video to keep 3.6 GB of weights in system RAM on a 15.7 GB machine.
Windows does not fail that allocation politely; it thrashes, and the desktop
goes with it.

**The fix is not a clock.** A clock stops slow runs, and a slow run
finishing is the entire point:

> *"if the model is used on a machine barely able to run this it should
> still run"*

A slow run and a run about to take the laptop down are different events. So
the bound is the resource that actually runs out, and **elapsed time is
never a reason to stop anything**:

* **Before** — what a run will page through is knowable from the file sizes.
  If it does not fit, say so now instead of finding out by hanging.
* **During** — free memory is sampled while it runs. Two consecutive samples
  below the floor stops the generator and says so plainly, in words that
  cannot be mistaken for a timeout. Two, not one, because a dip during model
  load is normal and killing a good run for it would be the old mistake
  wearing new clothes.

Tested both ways: a run crossing the floor is stopped in under two seconds,
and a healthy machine is never interrupted.

---

## ADR-113 — The reference lookup that incriminated its own prompt

**What the user saw.**

    Come up with ideas for an image then build it in 3D and then after that
    make a Video of it.

    ⚙ generate_image  🌐 internet
    ⊘ refused generate_3d (tainted-query)

**What "tainted" is for.** When untrusted bytes enter a turn — a fetched web
page — the turn is marked. A later *search* whose query contains three or
more distinctive words that appear in the retrieved page and nowhere in the
conversation is refused. That is the exfiltration channel: a poisoned page
putting its own text into a request that leaves the machine.

**What actually happened.** The user said "come up with ideas", so Nova
invented "a bioluminescent abyssal leviathan breaching". The ADR-108
reference rail then searched the web for exactly those words, and the page
that came back made them "untrusted". `generate_3d` was handed the *same
prompt* and refused for using wording that "came only from a retrieved
page".

**The words it called contraband — abyssal, bioluminescent, breaching — were
Nova's own, written before any page existed.** The lookup searched for them,
and the result became evidence against them.

**Why the gate fired at all.** ADR-108 introduced `network: MAYBE` and
claimed that because it is truthy, "every `if spec["network"]` that means
treat the result as untrusted keeps working unchanged." That was wrong. The
block does two jobs — refuse a tainted query, and spend from the web budget
— and only the second applies to a tool whose product is a file on disk.

**Decision.**

* The taint refusal applies to `network is True` only. A maybe-network tool
  is never refused by it; `generate_3d` writing an STL is not a channel out.
* The protection moves to where it costs nothing: once a page has been read
  this turn, `_reference_for` **drops the lookup** and says so, so nothing
  page-derived is sent back out. Same shape as the spec route — drop the
  part that cannot safely run, never refuse the thing the user asked for.
* Both still spend from the web budget when they go.
* The refusal message names the tool. It said "that search" for something
  that is not a search, and Nova relayed it to the user as "the tool refused
  the prompt", which explained nothing.

`web_search` under taint is refused exactly as before, and is tested.

---

## ADR-114 — The file was there. It was just kept.

Three video attempts died in a row, none of them in the video generator:

    "The attempt to build the video failed because the required input image,
     Cosmic_Forge_Base.png, was not found in the Playground workspace"

while the user watched and told her the file existed. It did.

**The chain, in order.**

1. Keeping a file **moves** it from the Playground to `vault/Made/` — that is
   the design, and it is right.
2. But `keep()` moved the file and its 3D preview and **left the
   `.generation.json` behind**. So the Playground listing showed
   `Cosmic_Forge_Base.generation.json`, `Goku_Ultra_Instinct.generation.json`,
   `terrible_tornado.generation.json` — sidecars with no images beside them.
   *A sidecar without its subject is worse than no sidecar: it is a filename
   that reads as a promise.*
3. Nova read that listing and correctly inferred `Cosmic_Forge_Base.png`.
4. `_resolve_input` looked in the Playground (gone), then called
   `vault.resolve("Cosmic_Forge_Base.png")` — which takes a vault-**relative**
   path and therefore only ever matched a file at the vault root. Everything
   the user keeps is one level down in `Made/`. **The one lookup that
   mattered was the one that could not succeed.**
5. It raised, and the whole run ended.

**Decision.**

* Sidecars travel with the file they describe. The Playground never advertises
  something that is not there.
* Lookup searches the whole Vault by name, preferring `Made/`.
* And per the instruction — *"it should be able to copy from the vault if it
  is not in the playground, this is where it goes when you're done and I've
  chosen to keep it"* — a file found in the Vault is **copied into the
  Playground** and the run carries on. The Vault is never written to; what
  comes back is a working copy in the model's own workspace.
* Naming a `.generation.json` resolves to the picture it describes, and the
  sidecar is only ever the last candidate.
* A genuine miss now lists what **is** usable, in both places. A bare "not
  found" against a folder full of `.json` files is how the same wrong
  filename got tried three times.

**And the calls that were never calls.** Twice, the whole reply was:

    Calling tool: generate_video(prompt="A short video based on the provided
    image.", input_image="2026-09-03 2309 cosmic forge.png")

Keyword arguments, no braces anywhere — and every pattern in
`toolcall.recover` required a `{`. The promise check fired, the model was
asked to actually do it, and it wrote the same sentence again. Nothing ran
either time. A small model that has learned Python signatures writes this
form, and it is a call in every respect except punctuation. Recovered now,
under the same two conditions as every other form: the name must be a tool
that is offered, and the call must BE the message rather than be mentioned
inside it — so an explanation that names a tool is still an explanation.

---

## ADR-115 — A picture can be a question

> *"it doesn't have search query from an image ... it needs to have this"*

Everything here could turn words into a picture and nothing could turn a
picture back into words to look something up with. An image on disk was a
dead end: it could be attached, and that was all.

`search_from_image` takes something in the Playground or the Vault and
searches from it, with two sources and no guessing:

* **The sidecar.** An image this machine generated has the prompt that made
  it stored beside it. Exact words, no model involved, and it works with no
  vision at all.
* **Looking.** When the selected model can see, it is asked what the subject
  is and the answer becomes the query.

A picture with neither — a photo the user dropped in, on a text-only model —
returns **no search at all** and says why. Inventing search terms from a
filename is the thing this project keeps refusing to do, and it would be
worse here than anywhere, because the result would look like research.

It sits behind the same single web-search switch as every other tool that
leaves the machine.

---

## ADR-116 — One namespace. Name a file, get the file.

> *"What if we only divide the difference by files able to be edited by the
> model ... marked only by naming the file instead of leaving the playground
> and the vault in different spaces?"*

**The split was never about safety.** It was about where things sit, which is
a fact about the disk and not about permission — and an entire release went
on failures of exactly one shape:

    "the required input image, Cosmic_Forge_Base.png, was not found in the
     Playground workspace"

three times in a row, about a file that existed, while the user said so. It
was in `vault/Made/` because they had kept it. Nothing was unsafe. Nothing
was missing. A name failed to resolve because the model guessed the wrong
folder, and the answer was an error instead of the file.

**Decision.** `files.py` holds one namespace and one question per file:

| | |
|---|---|
| **Yours** | the Playground and `vault/AI` — she may change or delete |
| **The user's** | everything else in the Vault: originals, chat attachments, and anything they chose to keep — read freely, never change |

The permission is a property of the file, not of the folder, and it travels
with the name. `scope` is accepted and ignored: it only ever gave the model a
way to guess wrong.

**Working on something of theirs never touches theirs.** `files.bring()`
copies it into the workspace and hands back the copy — which is the other
half of what was asked for: *"you can take files to copy them from the vault
and paste them into the playground for you to use ... without changing the
users files, that's me."*

Three narrower faults fell out of the same rewrite:

* **A copy suffix hid a file.** The user's uploaded picture landed as
  `... p (3).png` while the name Nova knew was `... p.png`. Character for
  character they were never going to match, and did not. Names now compare
  with a trailing ` (n)` stripped.
* **A sidecar is never the answer** while the thing it describes exists.
  `X.generation.json` means *the thing X* — and the note is right there in
  the listing, which is exactly why it kept getting named.
* **The listing shows everything, marked.** It used to show the Playground
  alone, so files the user had kept or sent in chat simply did not appear and
  the model concluded they did not exist — to a user who could see them.

---

## ADR-117 — Working is not circling

> *"a tool that starts another loop ... to continue what it was doing to
> complete the task in as long as it needs rather than the short bursts it
> gives"*

`pass_off` already existed and was capped at **two hand-overs per turn**.
That cap came from a real session where three pass-offs in a row produced
nothing, and it did stop the loop. It also stopped the work: *"come up with
an image, build it in 3D, then make a video of it"* is four or five rounds of
real activity, and two is not a task.

**The count was the wrong thing to measure.** What separates working from
circling is not how many times the turn has been handed on — it is whether
anything **happened** in between. A hand-over after a round that ran a tool
is progress. A hand-over after a round that ran nothing is the loop.

So: hand-overs are free while tools are running, up to a generous ceiling of
12, and **two consecutive hand-overs with no tool call between them end the
turn** — with an instruction rather than a scolding, because the model needs
to know what to do instead. Circling is caught in two rounds; working is not
caught at all.

---

## ADR-118 — Nothing stops a generation for taking too long. Nothing.

> *"this is a problem and it is the same as the error(s) from before where
> you added timeouts to the 3D models, it just takes a different shape as a
> 'time limiter' ... Our bare minimum here is it working, not it working
> fast."*

**First, the correction.** The ceiling of twelve was on `pass_off` — how many
times Nova may hand the turn to *herself* to keep working before the user
hears back. It is a count of reasoning rounds, not seconds, and it has never
touched how long a generator may run. Nothing about video was capped at
twelve.

**But the audit it prompted found two things that were exactly the mistake
described, and neither was the pass-off count.**

**1. Video refused to start on an estimate.** ADR-112 added a preflight:
sum the three weight files, add a 900 MB margin, and if free memory is below
that, `raise` — never starting. That is a timeout wearing a different coat.
A number picked in advance decided something would not work, so it never got
the chance to, and the margin has never once been checked against a run that
actually happened. It warns now and gets out of the way.

**2. A long job could be cut short by a call ceiling.** `calls_per_turn` was
20, chosen when a turn meant one or two tool calls. A job that makes a
listing, a look, a generation and a check per round walks into it, and the
generation can be the twentieth call as easily as the second. The runaway
being guarded against is *repetition*, and `identical_calls` catches that
directly at two — so the ceiling is 120.

**What is left that can stop a run, and why it stays.** One thing: free
memory falling below a floor, measured twice in a row, while the run is
happening. It does not care how slow anything is. It exists because the
alternative was measured too — *"also this run crashed my laptop"* — and it
is a reading, not a prediction. It is still a judgement about somebody
else's machine, so it is now theirs: `generation.ram_floor_mb` in
config.json, and **0 turns it off entirely**.

**And the log answers the question that guesses were filling in.** Every
attempt has carried its duration since the ledger existed, and nothing ever
read it back — so "how long does a video take here" was only answerable by
guessing, and guesses are what become timeouts. `ledger.took()` reports it
from runs that actually happened, successes and failures kept apart because
a run that died in nine seconds says nothing about how long a working one
needs. It appears on the launch banner and in
`look_at_system("generation")`, next to the sentence **"There is no time
limit - it runs until it is done."**

A test now asserts the rule rather than the cases: no `subprocess.run`, no
deadline in `_run`, no refusal on an estimate. Three limiters have been
removed for breaking this rule, and each one looked reasonable going in.

---

## ADR-119 — The tree grows its own shape

> *"it should branch from the limbs and be allowed limbs as needed or to drop
> a limb when makes sense, branches become limbs if wide enough with
> information flows"*

**The obvious reading is a count** — promote at twenty leaves — and it is
wrong in a way that shows immediately. Twenty near-identical notes about one
bracket are not a limb; they are one subject with a lot said about it. Six
notes covering six genuinely different things might be. **Size is not
structure**, and a threshold cannot tell them apart.

**Category utility can, and it has no free parameters** (Fisher 1987, after
Gluck & Corter):

```
CU = (1/K) · Σ_k P(C_k)[ Σ_i Σ_j P(A_i=v_ij|C_k)² − Σ_i Σ_j P(A_i=v_ij)² ]
```

How much better you can guess a memory's features once you know which branch
it is on — divided by how many branches that costs. **That divisor is the
whole thing.** Without it every memory becomes its own branch, because a
partition into singletons predicts perfectly. With it, a split has to earn
the extra branch by explaining something.

Measured on the exact cases: twelve near-identical bracket notes do **not**
promote; eight notes spanning three real subjects do (0.398 against 0.304).

**Category death is the same arithmetic, not a separate rule.** Two branches
merge when merging *raises* CU — which happens precisely when the features
that separated them stop predicting anything. Nothing is lost: the leaves
land in the merged parent. Two branches both about the image model merge;
the image model and a person do not.

**When to look is a different question**, and re-scoring the tree on a timer
would be both expensive and wrong. SUSTAIN's recruitment gate answers it:
check only when something arrived that did not fit anything already there —
best match below **τ = 0.5**, the one number in the file and the one its
authors fixed rather than fitted. Ordinary writes cost nothing.

**Permanent limbs.** A person does not derive "there are other people" from
experience; they start with somewhere to put people. `observations`,
`people` (including other machines), `environment`, `studies` and `doing`
exist before anything is learned, so the first thing learned has somewhere to
go. They grow branches and can never be merged away.

---

## ADR-120 — What is real, what they think, and what they say someone else thinks

> *"observations are things that really exist ... for other peoples
> perceptions separately from their own"*

**Humans are bad at this, and the finding is blunt: they do not store a
source tag at all.** Source is reconstructed at retrieval from how the memory
feels, and every source error in the literature follows from that missing
tag. A machine does not have to inherit the flaw.

So the tag is bound at the moment of writing, from a closed set —
`observed`, `stated`, `attributed`, `inferred`, `unknown`. Two findings say
this is where the leverage is:

* Forcing an explicit source choice rather than a bare yes/no drops
  misattribution from **8.5% to 0.55%**.
* A provenance flag applied at **retrieval** buys nothing (warnings do not
  moderate the illusory-truth effect at all, across 182 studies and
  N = 31,184); the same flag applied at **ingestion** reverses the sign,
  g = 0.43 → −0.18. **Late is the same as never.**

**And the one that must never leak.** An attributed belief is *sealed*.
"Zero says his brother thinks the card is fine" is not evidence about the
card, and a question about the card cannot reach it — `recall` skips
attributed leaves unless the question is about what somebody believes. That
is Leslie's decoupling, and the failure it prevents is the one children under
four make when a competing real fact is sitting in front of them.

A belief with no holder is demoted to `stated`, because an attribution to
nobody is indistinguishable from a claim about the world — the exact
confusion the field exists to prevent.

---

## ADR-121 — Which log answers "did it even run"

> *"which log would tell us if the system was or was not working and if the
> limit of 20 turns or the video generation not doing anything is the actual
> problem"*

All of it was already being written down, and no two parts of it were in the
same file:

| | |
|---|---|
| `data/logs/policy.log` | every tool call the gate allowed or refused — a turn-limit refusal never reaches forge at all |
| `data/logs/forge.log` | the argv, the exit code, and what the generator itself printed |
| `data/attempts.jsonl` | one line per attempt, **with its duration** |

**The deciding number is the duration**, and nothing was reading it. A run
that never started reads as a second or two — a missing file, missing
weights, a refusal. A run that started and failed at the end reads as minutes
or hours. Those are different faults with the same sentence printed over
both: *"the generation failed"*.

`look_at_system("attempts")` now reports the last generation in order — what
it was, whether it worked, how long it ran, what it said, which of those two
faults it was, and where to look. No new log; the data existed.

**And the reason was dropped before it reached the user.** The tool returned
`VIDEO GENERATION FAILED: <reason>` plus a full report. What reached the
screen was "The generation failed." That is now a pinned rule in the
character sheet, beside the other four that must survive any cut: *when a
tool fails it tells you why — pass it on in its own words.*

---

## ADR-122 — The video was finished. I killed it.

The user's own logs, four times over:

```
memory low: 150 MB free (strike 1)
memory low: 686 MB free (strike 2)
stopping the generator to keep the machine responsive
video exited 1: | 20/20 - 46.69s/it
stable-diffusion.cpp:5406 - sampling completed, taking 921.97s
generating latent video completed, taking 922.35s
  |##############################################| 108/108 - 626.91MB/s
```

**Read the order.** Sampling *completed*. All twenty steps. The tensors for
the final decode were 108 of 108 loaded. The run had done the whole job and
was in its last and largest allocation — which is precisely when free memory
is at its lowest, by design — and the ADR-112 guard shot it.

Four attempts: 1064s, 1100s, 1064s, 1108s. Four kills. **The machine never
crashed in any of them.** Low free memory during a video decode on 16 GB is
what a *working* run looks like, not a warning sign, and there was no way to
know that from here. Which is the whole problem with the number.

> *"the limitation of giving it a number here could be what makes it stop,
> because it does stop here, every time"*

That is the third time a limit of mine has stopped the thing it was meant to
protect — after the subprocess deadlines (ADR-107) and the size refusal
(ADR-118). **The floor now defaults to 0.** The mechanism stays for anyone
who wants it (`generation.ram_floor_mb`), but nothing decides on the user's
behalf that their machine is in trouble.

**And the ledger recorded a picture of a loading bar as the reason.**
`_explain()` took the last 220 characters of output, which on a run that
finished sampling is a progress bar and a success message. Four rows whose
stated cause of failure is `|####| 108/108 - 626.91MB/s`. It now searches
backwards for a line that actually reports an error, skips anything
containing a bar, and — when a run completed its work and then stopped
without an error — **says exactly that**, because "it finished and something
killed it" and "it errored" are different faults and the difference is what
was lost.

**The 3D timeouts in the same logs are already fixed.** Both model3d rows
read 10801.0s and 10802.9s — the old three-hour socket deadline, to the
second. One died at flow step **10 of 12 with ~34 minutes left**. ADR-107
removed that deadline; the current build shows `step 1/12 · ~186 min left`
and is running, which is the first time that path has been allowed to
finish.

**And "quiet 145s" is normal.** TRELLIS prints once per flow step and a step
takes about seventeen minutes here, so a long gap between lines is expected.
The bar said only "quiet 145s", which reads like a hang; it now says the gap
is normal and what causes it.

---

## ADR-123 — The correction machinery was causing the loop

The worst fault yet, and it was not the model. This is the sequence, from
the user's own transcript:

    user: "now try a 3D model."
    user: "you choose for all features like this on this go around."
    Nova: "I will build a video using any PNG file I can access."
    SYSTEM: "STOP ... The tool is generate_video. Call it NOW."
    → generate_video

    user: "That was a video generation attempt, not a 3D model."
    Nova: "...that was a video generation attempt..."
    SYSTEM: "The tool is generate_video."   ← the word she was NEGATING
    → generate_video AGAIN

**Three times, while the user corrected her each time. The model was
obeying.** `promised_action` read the tool out of **her own reply**, and her
reply is always about whatever she was last doing — so every round fed the
last round back in. A correction became an instruction to repeat the
mistake.

Measured before the fix, with the tools actually offered:

| her reply | tool the system ordered |
|---|---|
| "I will build a **3D model** using the **image**" | `generate_image` |
| "That was a **video** attempt, **not a 3D model**" | `generate_video` |

**Three changes, each proven on those exact sentences.**

1. **The user's request decides.** Her reply establishes *that* she promised;
   the user's message establishes *what*. When they disagree the user wins.
2. **Walk back, newest first.** "Choose one to test with" names nothing, and
   the standing subject is whatever the **user** last named — the 3D model,
   two turns earlier. Falling back to her reply at that point is what
   re-selected video.
3. **Read a correction the way a person does.** "That was a video, not a 3D
   model" — the wanted thing is the one after "not", and left-to-right gets
   it backwards. But "I wanted a picture, not a video" is the opposite
   shape, so only the *"that was …, not …"* form inverts. Ordering also
   changed: 3D is tested before image, because "a 3D model of the image" is
   a 3D request.

The whole five-turn sequence now resolves correctly, and is a test.

**And the hallucinated result had a source in the tool output.**

    "The generation failed ... the result is only 1 out of 7 views worked,
     which is roughly 22%. This is a leaning, not a conclusion."

There were no views. "1 of 7" is how often the video *backend* has ever
worked; "a leaning, not a conclusion" is the ledger's own wording about
sample size. Every number real, none of it about the run that just failed —
because the failure path appended `forge.report()`, a page of reliability
statistics, right next to the error. **Anything placed beside an error
competes with it**, and a 4B model narrated the statistics as the outcome. A
failure now returns the failure and nothing else.

**And the turn opens with the task.** The request used to arrive *last*,
after the remembered background, and for a small model what comes first
anchors hardest. Every turn now begins:

    [this turn]
    WHAT IS BEING ASKED, NOW: <the user's message>
    That sentence is the task. Everything after this block is background.
    It is asking for generate_3d. If you act, that is the tool - not
    whichever one you used last.
    FINISHED, 4 minutes ago: you ran video and it did not work. That attempt
    is OVER - it is something you DID, not something you are still doing.

That last line is the one that matters. A finished action was never marked
finished anywhere, so the last thing attempted stayed readable as a standing
goal. *"Keep it from hallucinating from the fact it would think it is still
going on that task."* Done means done, whether it worked or not.

**Found while fixing it:** the first version of this reached for a variable
that was not in scope, and the tool phase swallowed the `NameError` into
"tools unavailable this reply" — five live-wiring tests caught it, and
`check_name_resolution` would have caught it before shipping had I run it
first.


## ADR-124 — A log you cannot put in order is a witness who cannot say when

Zero sent five logs so the last round of repairs could be checked against
evidence rather than against my confidence. Four of them answered
immediately. The fifth could not answer anything.

`tools.log` held thirty lines of this:

    promised an action without calling a tool (generate_video); pushed back once
    promised an action without calling a tool (generate_image); pushed back once

No time on any of them. The perseveration fix (ADR-123) shipped partway
through that run, so the log contains both the broken behaviour and the
repaired behaviour — and there is no way to tell which is which. My own
falsifiable prediction ("it should read `(generate_3d)` on a turn where 3D
was asked for") could be neither confirmed nor refuted. The evidence was
destroyed by the recording, not by the bug.

`core.log_line` wrote `text` verbatim. Four callers stamped their own time,
in two different formats; everybody else wrote bare text. So the stamp goes
in `log_line` itself, and a line that already opens with a date is left
alone — one function, no caller changes, every log in the app gains a clock.

The promise line also records the ask now:

    promised an action without calling a tool (generate_3d); pushed back
    once | asked: 'now try a 3D model.'

Thirty identical `(generate_video)` entries look the same whether the tool
was right or wrong. With what was *asked* beside what was *promised*, a
wrong one is visible at a glance instead of needing the transcript.

**The second half of the same defect.** Reading `policy.log` back, all 27
`web_search tainted-query` refusals turned out to be `verify.py` probing its
own exfiltration guard — every verify run salted the live log with four
synthetic REFUSE lines, including a fake `TAINT turn=verify`. It took a
script to separate the probes from reality. A log that must be filtered
before it can be read will be misread, so the supervisory probes now write
to a scratch directory that is deleted afterwards.

Once separated, the answer was clean: **zero real searches were ever refused
by the taint gate.** ADR-113 held completely.

Locked by `test_logging.py`. Two of its five tests fail against the old
`log_line` and pass against the new one; the "does not stamp twice" test
passes against both, because it guards a regression rather than catching the
bug.


## ADR-125 — Don't become the reason it stops

    "none of these should ever return because it took too long, only if it
     never ran in the first place or if it ran but had errors or something
     stopping it - don't become the reason it stops, let go and see if it
     runs"

Four limiters of mine have now killed the exact thing they were protecting:
a subprocess deadline, a size refusal, a RAM floor, and — found this round —
a silent seven-round ceiling on the tool loop. Each fix removed one number,
and each time a different number was already waiting somewhere else. So this
round the rule is asserted over the whole generation path instead of the
cases, in `test_nowalls.py`, and that test found three walls I had not:

| where | was | is |
|---|---|---|
| `model3d.py` render_external | `timeout=120` on FreeCAD | no deadline, duration logged |
| `model3d.py` convert | `timeout=180` on FreeCAD | no deadline, duration logged |
| `imagegen.py` external provider | `timeout=1800` | `timeout=None` |
| `server.py` tool loop | `range(7)`, silent | `LIMITS["calls_per_turn"]`, says so |

One shape is still allowed and now has to declare itself: a `# PROBE:` under
90 seconds, for asking a binary to print its own `--help`. Something that
cannot do that in thirty seconds is broken, not slow, and finding out a thing
is dead is the opposite of a deadline.

**Checked upstream rather than assumed.** pwilkin/trellis.cpp documents
exactly two endpoints — `GET /health` → `"ok"` and `POST /generate`
(multipart `image`, optional `seed`, `resolution`, `bg_removal`, returns
`model/gltf-binary`). Our call is right, generation is **synchronous**, and
**there is no progress or job endpoint**, so scraping the server's stdout is
not a workaround — it is the only signal that exists. Upstream reports 3:16
to 12:39 end-to-end on a 16 GB RTX 5060 Ti and calls the CPU fallback "very
slow, RAM-hungry". Zero's run reached flow step 10 of 12 at 10,211 s with
~2,042 s to go: about 3.4 hours, roughly 30–60× the GPU figure, which for
this configuration is the expected behaviour and not a fault. A 3-hour
deadline was always going to lose that race.

### The estimate now comes from the past, not from the first step

    "this should never be timed for 'how long it should take' only for how
     long it has taken in the past"

`_progress_line` extrapolated `spent × (100 − pct) / pct`, which at step 1 of
12 announced **"~186 min left"**. `ledger.how_long()` had held the real
answer since the ledger existed and only the settings page ever read it. The
progress board now carries `typical`, `fastest`, `slowest` and `runs` from
runs that actually finished, the UI prints "past runs 43 min" or "first run —
no measurement yet", and nothing computes a countdown. Nothing acts on any of
it either: it is a caption, not a clock.

### 3D can now say whether it even started

    "the 3D generator has no real measurement to if it even starts or how
     long it takes"

It recorded one row per request, so "the runtime never came up" and "the
runtime came up and the mesh failed" were the same line with the same
duration — an install problem and a generation problem, indistinguishable.
Now `model3d_start` and `model3d` are separate attempts, the progress clock
restarts when the mesh begins so elapsed measures the mesh rather than six
GGUFs loading, and the failure names the phase: *"the 3D runtime started fine
and ran 43 min, then the mesh step failed"*.

### Two audiences, two records

    "the model should see most of the information so it knows what went
     wrong but we should know what went wrong even if it cannot"

Three things saw every failure and all three saw a summary: the model got
`_explain()`'s 220 characters, the ledger got 240, `forge.log` got the last
400 — which on four real rows was the tail of a loading bar. The 4,000 lines
the generator actually printed were dropped when the deque went out of scope.

`forge.keep_the_whole_log()` writes the complete output of any failed run to
`data/logs/failures/<when> <backend>.log` with the command, the exit code and
the duration at the top, and `forge.log` names the file. The model still gets
one sentence, because that is what a small context can carry. We get
everything. `_explain`'s fallback also drops bar lines before taking the tail,
so a picture of a progress bar can no longer become a reason in any position.

The model's own report gained the measured durations too — *"how long,
measured here: 3 finished: 43 min to 47 min, usually about 43 min"* — which
is most of what "it takes too long" was made of: Nova had no way to know that
43 minutes of silence is this machine working normally.

### Two things found on the way

`verify.check_clean_tree` called an **empty** tree "somebody's content": the
permanent limbs are created up front and every file read `"leaves": []`. Six
errors and a failed install on a tree carrying nothing — the ADR-96 fault
again, in the check that was written to prevent it. It asks what is inside
now, not whether the file exists.

And a suite redirected `memory.YESOD_DIR` but not `core.TREE`, so the fixture
leaf *"the GTX 1650 card has 4 GB of VRAM"* was sitting in the shipped
`data/tree/hod.json` and would have installed on a stranger's machine as one
of their own memories. Two paths, one redirected — the ADR-97 shape exactly.
Fixed, and `verify` now watches the tree, ash, knowledge and sessions
alongside the Vault and the Playground, because "it has not happened there
yet" is the wrong reason to choose what to watch.

---

## ADR-126 — The memory was not broken. It was never handed over.

    "The memory is not present, Fix this before we move on."

Zero asked Nova to look at the previous prompt. She answered with the
message he had just typed. He said "No, look in your memory." She answered
with the same sentence again. He said "yes but that is now, we need then",
and there was no *then* to reach.

Every conversation was on disk. `save_session()` had written
`data/sessions/<id>.json` after every single reply since Cairn.
`memory.sessions()` listed them for the tree panel. **Nothing ever read one
back into a prompt.** `build_messages()` took `history`, and `history` is the
browser's array, declared `let history=[]` at the top of `ui.html` and
rebuilt empty on every page load. The server took a new `SESSION_ID` on every
start. So the moment either happened, everything said before it stopped
existing as far as Nova was concerned.

Nothing was lost. It was simply never handed over — and being asked to
remember something you were never given looks, from the outside, exactly
like having no memory.

`carryover.py` is the missing hand-off: the last ≤10 rounds of each of the
last two sessions, in the system message on every turn, oldest first, under a
heading that says they are FINISHED. Rounds, not messages, so a question and
its answer travel together; trimmed from the OLDEST end, because the end of a
transcript is the part the user is pointing at and `budget.fit_text` drops
from the wrong one.

Three things it deliberately does not do. It does not summarise — Yesod
already holds one line per conversation and a digest is the wrong object for
"what did we actually say". It does not head an empty section with a promise
of recollection. And it is assembled once and reused until the session files
change, so it is byte-identical from turn to turn and the prefix cache stays
warm.

## ADR-127 — "Look in your memory" was being sent to the internet

`research.preflight` scores a message for whether it needs the outside world.
`EXPLICIT` matches `look ?up|look into|search|research|investigate`, and one
strong signal is enough. So:

| what Zero typed | what The Hub did |
|---|---|
| "Look into the last prompt in the timeline you see." | web branch — "look into" |
| "No, look in your memory." | suppressed only by luck, then nothing |
| "yes then before that you have a memory to search from." | web branch — "search" |

Web search was off, so the fallback fired and Nova was handed: *"say plainly
that you could not check, then answer from what you know and mark it as
possibly out of date."* About the user's own last conversation. There is no
amount of internet that answers that, and telling a model its own memory
might be stale is worse than telling it nothing.

The suppressor list had `personal`, `memory`, `self`, `clock`, `arithmetic`,
`creative`, `conceptual` — seven ways of saying "not outward" and no way of
saying **inward**. Added, and it does not merely say no: the same evidence
slot is filled from the transcripts on disk, `timeline.about()` for the
subject's history and `timeline.versions_block()` for a named file's
versions. An outward question is searched outward; an inward question is
searched inward; both arrive in the same place in the same shape.

`test_carryover.py` holds Zero's four sentences verbatim, and the outward
cases still score REQUIRED.

## ADR-128 — One filter woke up and took the memory with it

    "the model only uses tiny fragments at v24 ... very broken fragments of
     tiny chunks of memory scattered about pretty randomly"

`focus.perception()` ends its cue filter like this:

```python
        matched = [h for h in hits if hmatch(h)]
        if matched:
            hits = matched
        else:
            hits = []          # <- everything recall found, discarded
```

Written when `_subject_cues()` could return only a filename, one of ~28
extensions, or one of ~18 technical nouns. On an ordinary sentence `cues` was
empty, `if cues:` was False, and that branch **never ran**. It was dead code
that read like a safety rail.

Then `named_subjects()` was added, and cues began matching **any capitalised
word** — `_CAPS_RE = r"\b([A-Z][a-z]{1,}...)\b"`. The dead branch woke up on
nearly every turn. From that release onward, memory returned a couple of
literal lowercase-substring matches or **nothing at all**, unpredictably, and
saying "Nova," at the start of a sentence deleted the memory for that turn.

Nothing was deleted. One filter had been switched on.

    "Stop severing limbs and correct this, stitch it back on and allow it to
     do the things it is built for."

A cue now **ranks** instead of gating: memories sharing the subject go first,
the rest follow in relevance order, and the section can no longer become
empty because a word did not appear verbatim. What the cue was built to do —
keep an old JPG conversation from outranking an STL question — still works
and is tested. `test_remembering.py` asserts both, plus the shape of the
source, so putting `hits = []` back fails loudly instead of passing on an
empty tree.

## ADR-129 — A claim with its provenance stripped off is a stronger claim

    "the hallucinations of memory still persist with the memory saying too
     much without any information about it"

`memory.recall()` returns, per hit: the line, the date it was learned, which
limb it came from, how firmly it is held, how many times it has come back,
whether it is confirmed, and whether the user said it or a model inferred it.

The renderer was:

```python
                line = "  - " + str(h.get("line", ""))[:300]
```

Everything else was thrown away — and `recall_block()`, which renders the
same hits honestly, was dead code nothing called. So a guess a 2B model
extracted from a July transcript arrived looking exactly like something the
user said this morning: flat, undated, unattributed, under a heading
promising recollection.

That is not a retrieval fault. Retrieval had the information.

`memory.remembered_line()` is now the one renderer, used by
`focus.perception`, `recall_block` and `timeline` alike:

```
- (2026-09-06, 3 days ago, they told you, known well) the card has 4 GB
- (2026-08-14, 3 weeks ago, you worked this out, said once, NOT confirmed)
  the turbo preset renders at 768
```

`how_well_known()` gives three bands and no numbers — "held 4.7" means
nothing to a 2B model; "said once" changes how it answers. A model told "you
worked this out once, three weeks ago, not confirmed" can hedge. A model told
the same sentence bare cannot: it has nothing to hedge with.

## ADR-130 — A field nothing writes is a comment

`grove.Leaf` has carried `kind` ∈ {observed, stated, attributed, inferred}
and `holder` since they were added. `memory.graft()` accepts both. Every
production call site in the application:

```
intake.py:386   memory.graft(...)      # no kind=
learning.py:36  memory.graft(...)      # no kind=
memory.py:487   graft("daat", ...)     # no kind=
memory.py:1096  graft(pl.sephira, ...) # no kind=
memory.py:1106  graft("tiferet", ...)  # no kind=
server.py:817   memory.graft(...)      # no kind=
```

So `Leaf.__init__` always landed on `kind = "unknown"`; `is_about_the_world()`
returned False for every leaf that has ever existed; and THE SEAL in
`recall()` — `if leaf.kind == "attributed" and not wants_belief: continue`,
which keeps somebody else's opinion out of a question about the world —
**could not fire**. The observed/stated/attributed distinction existed
entirely in the schema and the comments and did no work in any version.

All six now say how they know it. The user's own words are `stated`; what
intake observed is `observed`; `learn()`, the curator's fact extraction and
its focus line are `inferred`, because a 2B model reading an old transcript
and deciding what is durably true about someone is inference whatever it
sounds like. `test_remembering.py` walks the AST of all four files, so a new
call site cannot quietly go back to "unknown", and the seal is tested against
a leaf that now actually carries the tag.

## ADR-131 — It should move through time, not query it

    "we need it to remember but also be able to find the most recent version
     of something or the most known concept by searching and knowing, we need
     it to know, not to just read and write. It needs to move through time
     and not be limited to calling information back from then"

Every leaf carries a date, a stability, a recall count and a truth value, and
every one of those is a fact about time. None reached the model. Retrieval
answered one question — "what matches these words" — freshly, from nothing,
every turn. Ranking has no opinion about which of two matching memories came
second, so "what is the latest" was answered by luck.

`timeline.py` groups what is known by subject, puts each subject in time
order, names the newest as **now**, and shows an already-superseded earlier
one as **was**. It reaches the model as a standing block in the system
message, present before the question arrives — the way it is for a person who
simply knows what they are working on, rather than running a search to find
out.

```
[what is current - what you KNOW right now, not a request]
- lighthouse (known, 2 things known)
    now, 2026-09-09, today: the lighthouse video finished in 46.6 minutes
    was, 2026-09-05, 4 days ago: lighthouse video runs take about 43 minutes
- GTX 1650 (known well, 1 thing known)
    now, ...: the GTX 1650 card has 4 GB of VRAM
```

**A subject is a thing, not something happening.** There is no
part-of-speech tagger and there is not going to be one, so noun-likeness is
read off the shape of the word as the user wrote it: a capital mid-sentence,
a digit, a dot with an extension. Three tests decide the key, in order —
does it recur, is it a thing, is it distinctive. The first attempt used
rarity alone and gave every leaf its own group with labels like "finished"
and "about"; a memory filed under a verb is a memory nobody finds again.

Two thresholds were wrong on first contact and are worth recording. A stem in
≥34% of leaves is vocabulary, not a subject — but on a tree of four
memories, a word in two of them is 50%, so "lighthouse" said twice was
disqualified as vocabulary. A fraction is meaningless on a small sample; it
now needs a floor of four sightings before frequency means anything, which is
the ledger rule applied to words. And `about()` matched on a single shared
body word, so "look into the last prompt" returned the history of the
graphics card — tacos are not a rock. Naming the subject now counts double
and one incidental word is not enough.

**It does not invent contradiction.** Two statements a month apart are two
statements. Only a leaf the tree has already marked superseded may be shown
as a "was". Guessing at the conflict would be the relief plaque again: an
answer nobody asked for, standing where the real one should be.

`timeline.versions()` answers the literal reading of "the most recent version
of something": `files.find()` matches a name or a stem and returns one file,
with no idea that `bracket_v2.stl` came after `bracket.stl`. Version marks
are stripped to a family name, both workspaces are scanned, and modified time
decides, because that is the only thing on disk that records when the object
last changed.

Nothing in the file writes to the tree, and `test_timeline.py` asserts that
with an AST walk. grove owns the leaves.

## ADR-132 — The conversation was paying for every block written about it

    "the conversation length never resets and organizes like 13-15"

Two things had happened, and neither was visible in any one diff.

**The share.** `SHARES` divides what is left after the character sheet.
History gets the remainder. Every block added since took its room from that
remainder by default, so the transcript shrank each time something about the
transcript grew. The releases whose continuity worked gave history 0.44; by
this one it was heading for 0.34.

| | was | is |
|---|---|---|
| frame | 0.16 | 0.10 |
| standing | — | 0.08 |
| knowledge | 0.10 | 0.10 |
| recall | 0.12 | 0.10 |
| evidence | 0.18 | 0.12 |
| carryover | — | 0.06 |
| **history** | **0.34** | **0.44** |

**The reset.** In the releases that felt right, refreshing the page ended the
conversation — `let history=[]` and it was gone. That was an accident, not a
feature, but it was the only thing that ever drew a line, and it was the line
that kept the transcript inside the window and made the context percentage
fall back down instead of climbing forever. Restoring the conversation on
reload (ADR-126) removed the accident.

So the deliberate version is back: a **New conversation** control in the
header, `/api/session/new`, `roll_session()`. And it exposed a real data
loss — `save_session()` REPLACES the file for its id, and the id was fixed
for the life of the process, so "Model switched. Conversation cleared."
emptied the screen and the first turn of the next conversation overwrote the
whole previous transcript. Nothing archived it, nothing digested it; the only
copy that had ever existed was that file. Rolling the id keeps it, and it
becomes one of tomorrow's earlier conversations. Ending a conversation and
losing it are different things, and only one of them should be a button.

## ADR-133 — The correction machinery could not make a correction stick

Found while testing ADR-130. `learning.teach()` — the function whose entire
job is to turn "no, do it this way instead" into a stored rule — read
`placement.scores`. `classify.Placement` has `sephira`, `confidence`,
`scope`, `distribution`, `reason`, `unsorted`. **There is no `.scores`, and
there never was.**

Both callers are wrapped in `except Exception`. `server.py` logged
"correction learn failed" to `data/logs/learning.log` and carried on;
`from_success()` swallowed it silently. So every correction Zero has ever
made was routed into an `AttributeError` and taught nothing, in every version
of this application, while the log said so in a file nobody had reason to
open.

This is why nothing anybody corrected ever seemed to take.

The extraction was wrong too. It cut at the marker and kept the tail, so

    "no, put the file in the Playground instead, not the vault"

was stored as **"instead, not the vault"** — a lesson naming no action, no
subject and no place, filed as `truth="confirmed"`, reaching the prompt
forever after as something the machine believed it knew. A correction cut in
half is not a shorter correction. It is a different and wrong one. The
sentence carrying the marker is now kept whole, with the "no," that opens
most corrections trimmed because it is aimed at the last answer, not at the
rule. And it files as `stated`, because the user typed it.

## ADR-134 — The tree's shape could never change

`growth.py` — Fisher-1987 category utility, SUSTAIN surprise gating,
`should_promote()`, `should_merge()`, `plan()` — was written, tested, and
imported by nothing but its own test for three releases. `plan()` returned
intentions and no code anywhere read them. A tree with opinions about growth
and no growth.

It runs now, from the memory idle loop, under the same lock as the rest of
consolidation, and what it does with what it finds is deliberately two
settings rather than one:

- **report** (always) — every intention goes to `data/logs/memory.log`, to
  the event log, and to `/api/state`. Free, reversible, and it is evidence.
- **reshape** (`memory.reshape`, default **false**) — merges are applied.

Off by default because TAU 0.5, MIN_TO_CONSIDER 7 and MERGE_MARGIN 1.02 have
never been run against a real tree, and this project has a rule about that:
*"When you train 10,000 times you know. When you saw 10 - 5 times, you don't
know."* The log will say what it would have done, and that is what turning it
on should be decided from.

Only merges are applied. A merge relabels leaves already together in one
limb — every leaf keeps its id, content, weight, stability and provenance,
and the count before equals the count after. A promotion has to invent names
for the parts it splits into, and a wrong name is invisible forever: nobody
looks in the crown for a detail about a graphics card.

And the branches `growth.PERMANENT` protects — observations, people,
environment, studies, doing — **did not exist**. Its one protection protected
nothing, and the first observation had nowhere to go. They are seeded now:

    "it should have enough permanent branches to keep going and never stop
     such as observations, people known (this would include AI and any other
     it can talk to), and other things related to its environment, studies"

## ADR-135 — Her own notes were arriving as things the user had said

Two of them, found by reading a real prompt rather than a test.

**The scaffolding.** Everything The Hub adds — `[this turn]`, the pointers,
`[what you remember]`, the evidence — is joined onto the user's turn with a
blank line, which makes it indistinguishable from something they typed. Asked
to write out the conversation, Nova produced a transcript in which the user
had said *"[this turn] WHAT IS BEING ASKED, NOW: ... FINISHED, earlier: you
ran video and it worked."* She was not making that up. It was in her turn,
above the words that actually were typed, with nothing to say it was not
theirs. A machine that cannot tell the user's words from its own notes cannot
be asked what the user said — which is most of what memory is for. There is a
line now, and it says which side is which.

**The echo.** `build_messages()` writes the user's turn onto the active
frontier and *then* asks the frontier what it remembers, so the sentence that
had just been typed came straight back under a heading saying it already
happened and was already dealt with. On a quiet turn it was the only thing in
the block. This is the oldest bug in this application wearing its third face
— the same sentence twice, once labelled as recollection — and it cost a user
"I just said that..." the first time. The frontier now skips a row that is
the question.

## ADR-136 — A turn that names no tool is not asking for one

`_this_turn()` searched the current message and then up to six earlier ones,
took the first tool name it found anywhere, and announced *"It is asking for
generate_3d"* — about a turn that was asking to look something up. A sentence
naming no tool at all was handed to a 2B model as an instruction to call one,
which is the perseveration this block was added to prevent, arriving from the
other direction.

The fallback is still needed: "now try a 3D model" followed by "go ahead"
carries no tool name of its own. So it is kept and labelled. A continuation is
told it is a continuation; a question is not told it is a request.

## ADR-137 — Watching the directory that had not been written to yet

`verify.py` snapshots vault, playground, tree, knowledge, ash and sessions
around the whole test run. `data/active` was not on the list, and
`memory.ACTIVE_DIR` is bound to `core.DATA` **at import** — so a suite that
redirects `core.DATA` and not `ACTIVE_DIR` writes its fixture's turns into
the shipped build's active memory while every watched directory stays clean.

Which is exactly what a new suite did, on its first run, in the same session
as ADR-126. The same half-redirect that put a fixture leaf in `data/tree`
(ADR-125), one directory over, caught only because a real prompt was printed
and had six copies of a test question in it.

Watched now. "It has not happened there yet" is the wrong reason to choose
what to watch.

---

## ADR-138 — Both guards were off, and it took the machine down twice

    "the model crashed my computer twice for the same reason, we must fix
     this"

Starting or running a generation, on a 15.7 GB machine. Two things could
have caught it and neither was armed:

```
forge.py:2209   fits, why = room_for([diffusion, vae, t5])
                if not fits:
                    core.log_line("forge", "video may not fit: " + why
                                  + " - starting anyway")     <-- logs, starts

forge.py:1404   RAM_FLOOR_MB = 0.0
forge.py:1465   if self.floor <= 0: return self               <-- never watches
```

Each was disarmed for a good reason. The floor was 700 MB sampled every four
seconds, and it killed four video runs at 17.7–18.5 minutes against successes
at 43–47: on this machine a **healthy** video run drives free memory below
700 MB and holds it there for three quarters of an hour. "Low" is what
working looks like. And `room_for` refuses on an *estimate* — three file
sizes plus a margin somebody picked — which is a timeout wearing a different
coat.

Both of those judgements were right. Together they left nothing at all.

The rule has always had the answer in it:

    "A generation may fail because it never started, or because it ran and
     errored. Never because a number ran out."

**Never starting is the permitted one.** So there is now exactly one check,
asked once, before `Popen`, and it is arithmetic rather than prediction:

    stat() the files this command line names   ->  what must be loaded
    GlobalMemoryStatusEx                       ->  what is free right now
    weights > free                             ->  it cannot start

No margin. No guess about peak usage twenty minutes in. If the weights are
larger than free memory, loading them is what takes the machine down, and it
does it every time for the same reason. Unmeasurable never blocks: no
reading, no opinion. Once a process exists, nothing here can reach it — and
`test_nowalls.py` asserts that by position, that the check appears before
`Popen` and nowhere after it.

It lives in `_run()` because `_run` is the one place image, video and 3D all
pass through, and it reads the file sizes out of `argv` rather than taking a
list from each backend. A list kept in step with six call sites is a list
that will one day be missing the newest one, and the missing one is always
the one that matters.

**And the background work now stands down.** `memory.loop` gated its heaviest
work on `idle_for()` — which measures whether the USER is idle. During a
45-minute generation the user is idle by definition, so the tree walk, the
consolidation and (since ADR-134) the growth pass all ran on every pass at
the exact moment the machine had least to give: a diffusion model holding
several GB, Nova stopped to make room for it, and this beside it. Nothing is
skipped, only postponed to the next pass.

The RAM floor stays off. `test_nowalls.py` asserts that too.

## ADR-139 — A conversation has to be able to end

    "let the chat have a number of rounds between the user and it to allow
     it to be able to reset the chat after these rounds like normal"

ADR-132 put a **New conversation** button back, having noticed that an F5
ending the conversation in 13–15 was the only line anyone ever drew. A button
is not the same thing: it has to be remembered, and nobody remembers, so the
transcript grows until it fills the window and every turn is spent at full
context — which is also the state in which the machine has least room for
anything else.

It ends itself now, after `chat.rounds_per_conversation` rounds (20 by
default, set in Settings, 0 to never). A round is one thing the user asked.

**After the reply, never before it.** The answer being waited for is
delivered first and the line drawn underneath it; ending a conversation
before its last answer arrives would be the machine walking off
mid-sentence. The transcript is kept and becomes one of the earlier
conversations the next one carries, so ending one costs nothing.

## ADR-140 — The button is Failure, and everything else is grey

    "remove the button and make it a failure button for the model to have a
     way of knowing when it is doing things wrong based on what the user is
     able to notice from when the subject is messed up to bad to fix in one
     chat, also to give it a grey zone of what isn't labeled as bad"

With the round limit doing the resetting, the one button left is not "new
chat". It is the thing to press when a conversation has gone too far wrong to
be worth fixing in place. It ends it exactly the same way — the transcript is
kept, never deleted — and marks it.

The mark is on the session file and nowhere else. It is deliberately **not**
a leaf: "this conversation failed" as a free-floating fact in the tree is a
judgement with its evidence stripped off, which is the fault ADR-129 was
about. It travels with the transcript, where it means something, and reaches
the model as a header on that conversation in the carry-over block.

**Two states, and the second one is named.** `MARKED A FAILURE` and `not
marked either way`. There is no third, and unmarked is not a pass. It is
written out in those words rather than left to be inferred, because almost
every conversation is unmarked and a model that reads silence as approval
makes the mark worth nothing:

> NOT MARKED means exactly that - nobody judged it either way. It is not
> approval and it is not a fault. Almost every conversation is unmarked, so
> reading it as praise would make the word meaningless.

**No running score.** `carryover.marks()` counts failures for `/api/state`,
for the user. It is never shown to the model. A count is a judgement about
her rather than about one piece of work, and there is no evidence that
telling a 2B model it has failed three times lately makes the fourth attempt
better. `test_carryover.py` asserts the count does not appear in the block.

**Two presses.** The button sits between the eye and the settings gear. A
stray click would mark a conversation that was going perfectly well, and that
does not merely lose it — it teaches her the wrong thing about what going
wrong looks like. A signal nobody trusts is worth less than no signal, so it
arms on the first press and commits on the second. No dialog: the same
button, saying what it is about to do.

Also found: the grey-zone paragraph was unconditional at first, and at an
8192-token window the whole carry-over allowance is about 680 characters — so
a 1,300-character header starved out the block it introduced and the earlier
conversations **disappeared entirely**. An explanation of a transcript, with
no transcript under it. It is appended only when one of the carried
conversations is actually marked; the durable half lives in `character.md`,
where it is true whether or not anything is marked today.

## ADR-141 — The `else` belonged to the line above it

Worth recording because it cost the longest debugging of the session and the
symptom pointed nowhere near the cause.

```js
    if(ans){ history.push(...); pump(ans,true); ... }
    if(rolled){ ... }                      // <- inserted here
    else ui.t.textContent="(no answer came back — the log will say why)";
```

The `else` had belonged to `if(ans)`. Inserted between them, the new block
took it, so on every ordinary turn — `rolled` null, which is almost always —
the reply that had just finished streaming was **painted over** with "(no
answer came back)". The answer was there. It arrived. Then the branch that
reports there was none wrote on top of it.

`test_browser.py` caught it, which is exactly what that suite is for: nothing
threw, no log said anything, `/api/state` was healthy, and the server-side
tests all passed because the server was blameless. Only the rendered page
knew.

The lesson is the shape, not the line: **an `if` with an `else` is one
statement, and inserting into the middle of one changes what the `else`
belongs to.** New work goes after the whole chain.

---

## ADR-142 — The limiter was never removed. It was never connected.

**Context.** The machine hard-reset three times in one evening, and the user's
instruction was explicit: *"this is just an old error that we have fixed
before many times… it needs to be FIXED not have pieces replaced or removed
unless WE BOTH agree that it is necessary."* And: *"these limitations were
already built for being around smaller models with the need for context over a
period of time, we just need to scale this up."*

So the first job was archaeology, not code.

**What the archaeology found.** `runtime.plan()` — with `MMAP_RESIDENT`,
`PROCESS_OVERHEAD_MB`, `CTX_FLOOR`, `HEADROOM_MB`, `_largest_that_fits` and
`resolve_ctx` — is **byte-identical** in The Hearth Step 5 and in every Hub
build from v2 through v24. Thirteen copies, no drift. Nothing was cut. The
LuminovaZero repository was read too: it contributes the memory biology
(weight, decay, pin, reinforce), not the budget.

What the limiter does:

```python
gpu_mb = min(weights_mb, vram * 0.66)      # decides what goes on the card
...
def host_need(ctx):                         # …then only ever asks about RAM
    return max(0, weights_mb - gpu_mb) * MMAP_RESIDENT + kv + PROCESS_OVERHEAD_MB
```

`gpu_mb` is computed, used as a subtraction inside the host-RAM sum, and then
**dropped**. It never reaches the process. And `_argv` omitted `-ngl` whenever
the setting said `auto`, on the strength of this comment, present unchanged
since v2:

```python
# "auto" omits -ngl entirely so llama.cpp fits the offload to real
# free VRAM. Forcing -ngl 99 on a 4 GB card disables that check and
# lets Windows spill into shared system memory, which can hang the
# whole machine. Verified the hard way.
```

That is exactly backwards. From the source of the pinned build, `b10456`:

```cpp
uint32_t llama_model::n_gpu_layers() const {
    return params.n_gpu_layers >= 0 ? params.n_gpu_layers
                                    : hparams.n_layer_all + 1;
}
```

`-1` is the default when the flag is omitted, and it resolves to *every
layer*. No VRAM is consulted anywhere on that path — `auto` and `all` are the
same number, and omitting the flag is the same instruction as `-ngl 99`. The
"check" the comment credits llama.cpp with does not exist.

So a 3.6 GB model went onto a 3.9 GB card, in full, together with its cache,
its buffers, and — because `vision.projector_args` was handed the fictional
`gpu_mb` rather than the truth — a 600 MB projector on top.

**Why it stopped being survivable.** `plan()`'s own docstring justifies having
no VRAM check: *"llama.cpp is the thing that actually knows whether a model
loads. It fails with a real error when it cannot."* That was true when it was
written. **NVIDIA driver 536.40 made it false.** System Memory Fallback is on
by default: an over-subscribed card does not raise, the driver pages VRAM over
PCIe into system RAM and carries on. Measured elsewhere, a spilled model runs
at 0.69 tok/s against 1.42 tok/s on pure CPU — the card ends up slower than
not using it, pinned at 100% utilisation and full board power for as long as
the model is loaded, instead of idling between tokens.

The limiter was not wrong. **Its premise expired.**

On a laptop with no battery there is nothing to absorb that draw. Kernel-Power
41 with `BugcheckCode 0` and `WHEABootErrorCount 0` is not a crash report — it
is the absence of one. Nothing failed. The rail went away. Two of the three
resets landed 54–73 s after a model load.

**Decision.** `plan()` keeps its shape, its `fit_policy` modes, its binary
search and its rule against refusing. It gains the second ceiling its own
file-header has named since Cairn, in the order the user specified:

> *"the model should always load in with this as the primary focus to stay
> under then that of its memory use (context window) within that"*

- **Stage one, the card.** `best_ngl(ctx)` walks up from zero while
  `weights + cache + buffers ≤ vram_free − VRAM_RESERVE_MB`, and the answer is
  written into `rt["n_gpu_layers"]` and **sent** as `-ngl`.
- **Stage two, the window.** The existing binary search now tests both
  ceilings. Because a layer moved off the card takes its share of the cache
  with it, the card is almost always answered with fewer layers rather than a
  narrower window — the window only gives when the host cannot hold what came
  off. Layers cost tokens per second; the context is what this application is
  for.
- `vision.projector_args` receives the real claim, so the projector takes what
  is genuinely left and otherwise loads on the CPU. It never pushes the model
  off the card.
- `"all"` is added as an explicit setting: llama.cpp's own behaviour, chosen
  on purpose rather than arrived at by accident.

**Nothing is refused.** `fits()` still returns True. `start()` still has no
bail-out, and `test_fit.py` asserts it structurally so a future edit cannot
quietly add one.

**Measured on the target profile** — GTX 1650, 3,938 MB free, Gemma 4 E2B
Q4_K_M:

| | before | after |
|---|---|---|
| layers on card | 36 of 36 (implicit) | **27 of 36, sent** |
| claimed | ~4,489 MB | **3,480 MB** |
| against | 3,938 MB free | 3,538 MB usable |
| context | 32,768 | **32,768** |
| projector | offloaded onto a full card | on the CPU |

---

## ADR-143 — Five layers in six were being charged for a cache they do not keep

**Context.** Adding a VRAM ceiling meant the cache arithmetic suddenly
mattered in a way it never had: an overstated cache now costs the user context
directly.

`gguf.kv_bytes_per_token` computes `2 × layers × kv_heads × head_dim × elem` —
full attention, every layer, full length. For a Gemma that is wrong twice over.

From `llama-kv-cache-iswa.cpp` at b10456:

```cpp
const uint32_t size_base = kv_size;                       // n_ctx
uint32_t size_swa = GGML_PAD(std::min(size_base,
                     hparams.n_swa*(unified ? n_seq_max : 1) + n_ubatch), 256);
```

Five layers in six are windowed, and a windowed layer's cache stops growing
once the window is covered — 1,536 cells rather than 32,768. And from
`gemma4.cpp`, layers at or beyond `n_layer_all − shared_kv_layers` **reuse**
an earlier layer's cache and allocate nothing at all.

Measured on the installed shape (35 blocks, 15 shared, window 1024, period 6):

| n_ctx | old formula | what is really allocated |
|---:|---:|---:|
| 4,096 | 280 MB | 75 MB |
| 8,192 | 560 MB | 99 MB |
| 32,768 | 2,240 MB | **243 MB** |

**Decision.** `gguf.py` reads `attention.sliding_window`,
`sliding_window_pattern`, `key_length_swa`, `value_length_swa` and
`shared_kv_layers`, and `kv_mb()` walks the layers the way llama.cpp does. A
per-layer array is used as written; a bare number is read as Gemma 3's
repeating period, which can only ever *overstate* the cache relative to "all
layers windowed" — and overstating is the safe direction for something that
decides what goes on a 4 GB card. A model with no window in its header gets no
discount, which `test_fit.py` asserts against a dense model of identical shape.

`kv_mb_layers(lo, hi, …)` exists because llama.cpp offloads from the END and a
layer's cache lives where the layer lives — so "how much of the cache is on
the card" is a question about a *slice*, and with a window the slice is not a
fraction of the whole. This also retires the `kv *= 0.45` fudge in
`host_need()`: the split is now exact.

`ctx_for_budget` became a bisection over `kv_mb`, because with a window there
is no single per-token rate to divide by.

---

## ADR-144 — Compute what is computable, measure what is not

**Context.** Two figures the card budget needs are not in any header: the
compute buffer and the output buffer. They depend on the build, the backend
and the batch. The project's rule is *"This should never be timed for how long
it should take, only for how long it has taken in the past"* — and inventing a
constant is precisely the sin `gguf.py`'s own docstring was written to record.

**Decision — two different answers for two different questions.**

*The weights are computable.* A GGUF's tensor table states every tensor's
offset into the data blob, and the blob is contiguous, so one tensor's size is
the next one's offset minus its own. No ggml type table is needed.
`Meta.weights_mb_on_card(n)` sums the last `n` slots exactly. This matters more
than it sounds: "file size ÷ layer count" spreads the token embedding — for a
262,144-token vocabulary, the largest tensor in the file — across every layer,
undercounts each one, and therefore offers the card more layers than it can
hold. It is wrong in the dangerous direction. The output head is the LAST slot
and so the FIRST thing offloaded, which is why the first "layer" costs several
hundred megabytes and the second costs fifty.

*The buffers are not.* So they are read back. llama-server prints its real
allocations, and stdout is already teed to `data/logs/llama.log`:

```
load_tensors:        CUDA0 model buffer size =  2600.00 MiB
llama_context:       CUDA0 compute buffer size =   312.50 MiB
```

`read_load_report()` parses that after every successful bring-up and
`learn_from_log()` files it in `data/logs/fit.json`, so the second load of a
model budgets from measurement. `CUDA_Host` is pinned system memory and is
deliberately not counted as the card. A load that produced no report teaches
nothing, so one crash cannot poison the estimate permanently.

---

## ADR-145 — A number that never changes is not a measurement

**Context.** `vram_free_mb()` cached its reading in a module global with no
expiry, for the life of the process:

```python
if _vram is not None:
    return _vram
```

One `nvidia-smi` call, made **before llama-server started**, answered every
question after it. The user's `runtime.log` records `'vram_free_mb': 3938` in
**122 of 122** benchmarks across nine days — through model switches, image
generations and reloads. The card was never empty again after the first
second, and the budget never found out.

**Decision.** A 2-second TTL plus an explicit `forget_vram()`, called from
`start()`, from `stop()`, and once the model reports healthy. The TTL is not
cosmetic: `resolve_ctx()` calls `plan()` eight times inside one binary search
and the reading costs ~200 ms, so a cache is necessary — what was never
necessary was keeping it across the event that changes the answer.
`test_fit.py` asserts both halves: the reading expires, and one planning pass
still costs at most two `nvidia-smi` calls.

---

## ADR-146 — Four heavy things in fifteen seconds, and no battery

**Context.** Bring-up ran the load, a warm-up generation, a vision probe and a
benchmark back to back. Each takes the card from idle to full in under a
second. Two of the three recorded resets landed inside that window.

**Decision.** `SETTLE_S = 2.5` between the stages, and the physical batch is
now a setting: `n_ubatch`, default 512, offered at 256. Prefill runs one
physical batch at a time, so it is the single largest thing the GPU is ever
asked to do; halving it halves that peak and shrinks the compute buffer, which
on the target machine buys back a whole layer of offload. It costs
prompt-processing speed and **nothing else** — no context, no quality, no
capability.

A sleep is the opposite of a timeout. Nothing fails for taking longer, which
is the standing rule: *"Don't become the reason it stops, let go and see if it
runs."*

---

## ADR-147 — The application was the only thing that did not know the machine had reset

**Context.** A hard reset takes the process with it. Nothing is written, no
exception is raised, and the next launch starts clean with no idea how the
last session ended. The user was left holding the only copy of that
information and answering "did it crash?" from memory — while the machine was
resetting three times an evening.

**Decision.** `last_power_loss()` reads Kernel-Power event 41 once per
process, and reports the distinction that is the whole diagnosis:

- `BugcheckCode 0` — no bugcheck. Nothing crashed. **The power went away.**
- `BugcheckCode != 0` — a stop error: a real software or driver fault.

`power_note()` renders one plain sentence, `fit_state()` carries it with the
rest of the budget, and the settings panel shows both. A limiter nobody can
see is indistinguishable from one that is not working — which is exactly how
this one spent thirteen releases computing an answer and sending it nowhere.

**A timezone caution, recorded because it cost real credibility.**
`wevtutil /f:text` prints **local** time and `/f:xml` prints **UTC**. The same
three events read as two different evenings, and an earlier account in this
project blamed the wrong build on the strength of it. The fractional seconds
are identical across both formats and are how to tell.

---

## ADR-148 — An append-only log that is not durable discards exactly the events worth having

**Context.** The user's `events.jsonl` now reads as a binary file: it ends in
NUL padding. That is the signature of a lost write — Windows committed the
file's new *size* and lost the bytes. `events.write()` appended inside a
`with` block and returned; the last minutes existed only in a buffer.

This is the file the whole memory is rebuilt from. *"Append-only events…
rebuild() from history… nothing ever deleted."* Buffered, it drops precisely
the events immediately before whatever went wrong — the only ones anybody
would ever go looking for.

**Decision.** `f.flush()` and `os.fsync()` on every append, and the reader
strips NUL padding rather than counting it as a torn line, so a log already
damaged by the resets still loads everything that survived.

---

## ADR-149 — The cost of remembering should not grow with how much is remembered

**Context.** `/api/state` is polled every two seconds for as long as the
application is open. Inside it, `carryover.marks()` parsed **every** session
JSON on disk to produce twenty rows, and `carryover.previous()` parsed every
one of them to pick the last two. At the user's ~285 conversations that was
measurable; at a thousand it is an idle CPU floor that rises the longer the
memory works. A memory system that gets more expensive to sit still the more
it remembers is one that punishes its own purpose.

Six keys were also duplicated in the response — `sight`, `focus`, `intake`,
`ctx` and `bench` were each built, discarded, and built again — free to write
and paid for thirty times a minute.

**Decision.** `marks()` memoises each row against its file's `(mtime_ns,
size)`, so a poll re-reads only what a turn actually rewrote — normally one
file, usually none. `previous()` orders candidates by mtime without opening
them and stops once it has enough, reading a handful rather than all of them;
`stamp` still decides the final order, because a file's mtime and the
conversation's own timestamp are not the same thing. The duplicate keys are
gone, and `test_fit.py` asserts they cannot come back.

---

## ADR-150 — The load that has nothing behind it is the one that crashes

**Context.** Build 27 shipped the repaired fit limiter and Zero ran it. The
first load took the machine down again. The second — after it reloaded —
was fine, and ran an image generation straight afterwards.

That pattern is the diagnosis. Everything the card budget uses except
`VRAM_RESERVE_MB` is an estimate, and on the **first** load of a model there
is no measurement to replace it: the report that corrects it does not exist
until a load has produced one. On the target profile 27 packed the card to
within **60 MB** of the ceiling on that estimate. The first load overran, the
report it left behind was read, and the second load — budgeted from a real
measurement — fitted.

**The costs are not symmetric.** Being cautious costs one slower load. Being
wrong costs a hard reset.

**Decision — three things, in order of how early they act.**

1. **An unmeasured model is offered a share of the card.**
   `FIRST_LOAD_SHARE = 0.70`, and `AFTER_RESET_SHARE = 0.55` when the
   machine's last boot followed a power loss. A real measurement removes the
   share entirely.

   This is *learning from the past without being held back by it*, which is a
   standing rule here: the penalty attaches to **not knowing**, never to
   having failed. One measurement and it is gone, whatever happened before.
   `test_fit.py` asserts both halves — a reset makes an unmeasured load
   careful, and changes a measured one not at all.

2. **The plan is checked against what the process actually did.** llama-server
   states its allocations *during* the load; the window that takes the machine
   down is the sustained compute *after* it — warm-up, vision probe,
   benchmark. That gap is now used. `overrun_mb()` compares the process's own
   report against the ceiling plan() budgeted from, and independently against
   what the card says free now; either signal triggers `_correct_offload()`,
   which loads again with fewer layers **before anything heavy runs**. Once
   per `start()`, because a budget that can restart itself twice is a boot
   loop.

3. **A measurement at a different batch is adjusted, not discarded.** The
   buffers scale with the physical batch; the CUDA context inside them does
   not, so only the part above a bare context is moved.

**On the target profile, the ladder now reads:**

| | layers | claimed | context |
|---|---:|---:|---:|
| first load, no history | 18 of 36 | 2,366 MB | 32,768 |
| first load, reset last boot | 13 of 36 | 1,860 MB | 32,768 |
| once measured | 28 of 36 | 3,518 MB | 32,768 |

Careful until it knows, then confident. The window is never the thing that
pays.

---

## ADR-151 — One number, or the same mistake in a different file

**Context.** `vision.projector_args` took three numbers and did its own
subtraction. ADR-142 records what that cost the first time: the middle
argument was `min(weights, vram * 0.66)` — the figure plan() computed and
never sent — while the process was loading every layer, so on a 4 GB card
holding a 3.6 GB model it reported a gigabyte spare and offloaded the
projector onto a card that was already full.

Adding `FIRST_LOAD_SHARE` set it up to happen **again**, one file over. A
projector sized against raw free VRAM would have eaten exactly the margin
that exists to stop the machine going down — and it would have looked
correct, because the arithmetic in `projector_args` was never wrong. It was
being given the wrong inputs.

**Decision.** `projector_args(model_path, card_free_mb)`. One number: what is
left of the card **inside the budget**, already net of the reserve and the
first-load share, computed by the one function that knows all of it. Nothing
downstream does its own subtraction, because three numbers and a subtraction
in the wrong file is how this happens twice.

---

## ADR-152 — The store has as much room as the machine has, and no less

**Context.** Zero's instruction:

> *"the files stored should also be able to store lots as well, these should
> not be limited by anything other than an automatically understood
> 'computers limit.' ... give the user a 'Max limit' bar ... up to no other
> number but the computers limit being the max the user can choose to build
> into as the 'chosen limit', this way we can scale when we install on a new
> device"*

Every limit in this application that was written down instead of measured
turned out to be a property of one laptop on one afternoon. ADR-142 is the
long version. This is the same question one layer out.

**Decision — `store.py`. Three numbers, one choice.**

- **CEILING** — what this disk can actually give: free space *plus what we
  already hold* (the question is how big `data/` may grow **to**), less the
  share the operating system needs. Measured every time, **never written to
  config**. Copy the folder to a bigger drive and the bar gets longer on its
  own; that is what makes one install correct on the next machine.
- **CHOSEN** — `storage.limit_gb`. `0` means the ceiling and is the default.
  A number is honoured and still clamped, because a ceiling above the disk is
  not a ceiling, it is a surprise later. The interface says when it clamped.
- **USED** — measured by walking `data/`, held for 20 seconds because the
  interface polls every two. Folders nobody named still count, or the budget
  is wrong on the first day somebody adds one.

`OS_RESERVE_GB` (the larger of 8 GB or 5% of the volume) is held back and
**shown**, not hidden inside the arithmetic: a disk taken to zero does not
report an error, it stops Windows paging and updating and fails by corrupting.

**NOTHING HERE DELETES ANYTHING,** and `test_store.py` asserts it at the
source level — no `unlink`, no `rmtree`, no `rmdir`. A ceiling that trimmed
to stay under itself would do it silently, at 3am, to the oldest and
therefore least replaceable material. What a full store does instead: it says
so with a breakdown of what is using the room, and a large generation will
not **start**. "A generation may fail because it never started, or because it
ran and errored. Never because a number ran out." `purge.py` stays the only
thing that removes anything, and it asks first.

**And setup stopped freezing what it measured.** `write_config` pinned
`n_ctx` to 4096 or 8192 from a VRAM reading taken during install — and
**overwrote a number the user had chosen**, on every re-install, because the
small-card branch assigned instead of defaulting. It writes `"auto"` now:
`runtime.plan()` budgets the card and the host on every load, so "auto" is
not a deferral, it is the answer, recomputed whenever the machine changes
underneath it. `report_limits()` prints what the running code would decide —
it does not decide anything itself, because a setup with its own separate
opinion is a second definition of the same thing, and that is the fault shape
that has cost this project more sessions than any other.

---

## ADR-153 — Three things in the prompt are the user's, and only three

**Context.** Zero:

> *"leave any areas where the prompt is not telling the AI how to use the app
> and let the user change only the things that make sense to, the character,
> the name of the character ... the creator of the app and the app names and
> preferences would stay the same and untouchable through the app interface
> ... make sure the user doesn't need to see the whole system prompt, just
> the pieces that make sense to change and nothing else"*

Settings showed the whole 13,000-character sheet in one textarea. Two things
were wrong with that and they pull in opposite directions.

*For the user:* almost none of it is theirs. `SAYING IS NOT DOING`, `TOOLS`,
`FILES AND SIGHT` — that is the application explaining itself to the model it
runs. It is wiring, not personality, and an editable box containing it is an
invitation to delete the paragraph that stops her announcing actions she
never takes.

*For the build:* the sheet is shipped, so an update replaces it — and
replacing it threw away whatever the user had written. The standing rule is
the opposite: *"the app must hold files across changes and updates, that is
the whole point."*

**Decision — `persona.py`, and the `###` seam Zero asked for.**

```
### YOURS: NAME ###
Nova
### END ###
```

What is between the markers in `character.md` is a **default**. The user's own
text lives in `data/persona.json`, which is never shipped and never replaced,
so an update rewrites the wiring and leaves the person alone. The markers
never reach the model — they are for whoever reads the file, and a 2B model
handed a line of hashes inside its own instructions will eventually write one
back.

Three fields, and Settings shows nothing else: **NAME**, **CHARACTER**,
**CHARACTERISTICS**. Their labels and help text come from `persona.FIELDS`;
`ui.html` has no second copy, and the test asserts it, because two copies of
one sentence become two different sentences.

**The name is a block, not a find-and-replace.** The obvious implementation is
to ship the sheet with "Nova" in it and swap the string. That breaks the
moment somebody calls their assistant "Hub", or "It", or any word the wiring
also uses — silently, mid-instruction, in a way nobody would think to look
for. The block holds the name; the wiring supplies the sentence around it and
says "you" everywhere else.

**One identity.** `assistant_name` is read all over the interface. Saving a
name writes it through, so it cannot drift from the name in the prompt — the
two-definitions fault, again.

`core.character()` returns the merged sheet, so the prompt builder, the token
budget and every test see one text and none of them has to know the split
exists. A test asserts no other module reads the raw file.

---

## ADR-154 — A heading inserted above the preamble moved the two rules that must never be cut

**Context.** `budget._sections` treats a capitals-only line as a heading, and
everything before the FIRST heading is the preamble — the one part
`fit_character` never drops. The two rules live there deliberately: *"TWO
RULES ABOVE ALL, because on a small window the rest of this sheet may be cut
to fit and these two must never be."*

Adding `WHO YOU ARE` and `WHAT YOU ARE LIKE` at the top of the sheet created a
heading **above** those rules. The preamble became the name and one paragraph;
the rules landed inside a droppable section, and at n_ctx 4096 they went.

`test_present.py` and `test_assets.py` both caught it the same afternoon,
which is exactly what they are for. The persona blocks now sit after the
preamble, and `test_persona.py` asserts the ordering directly so the next
person to add a section finds out before Zero does.

**And the docstring was corrected rather than the code.** `fit_character` said
essentials are kept even when they exceed the allowance. It has never done
that, and it should not: the essentials come to ~3,100 tokens and at n_ctx
4096 the whole character allowance is 998, so forcing them in would spend
three quarters of the window on the sheet and leave the conversation nothing.

The real consequence is now stated plainly instead of hidden behind a
docstring that read better than the truth: **below roughly 12k the sheet is
incomplete**, and at 4096 nine sections go, `MEMORY` and `MANNER` among them.
That is why the drop is returned rather than swallowed — `server.py` logs it
and the interface shows it — and it is an argument for a bigger window, not
an argument for pretending.

---

## ADR-155 — An idle application should not get more expensive the longer it remembers

**Context** (finishing what ADR-149 started). `/api/state` is polled every two
seconds for as long as The Hub is open. Every measurement inside it is paid
thirty times a minute, forever.

**Decision.** `store.measure()` holds its walk for 20 seconds and can be
dropped explicitly, the same shape as `runtime.vram_free_mb()`'s TTL
(ADR-145): a cache short enough that it cannot go stale across the event that
changes it, long enough that a poll is free. `runtime.fit_state()` and
`store.state()` read cached values only. The rule these all share is one
sentence: **a number that never changes is not a measurement, and a
measurement taken thirty times a minute is not free.**
