"""
vision.py - letting Nova actually see, offline, with whatever is loaded.

WHY THE OLD ONE DID NOT WORK
----------------------------
`vision.enabled` was a toggle in config. Turning it on did nothing, because
nothing checked whether the loaded model could see, and nothing converted a
file into something a model could look at. A switch with no wire behind it.

Luminova's sight system had the lesson already, written in its own comments:
the wrong input size yields *a fluent description of nothing*. Vision fails
SILENTLY. A model handed an image it cannot process does not error - it
describes a plausible image. So capability is never assumed here. It is
probed, once, when the model loads, the same way the context window is.

THE TWO LAYERS
--------------
1. WHAT THE MACHINE CAN READ WITHOUT A MODEL. Dimensions, dominant colours,
   brightness, aspect, layout, embedded text, geometry, duration. This is
   deterministic, works on every model including ones with no eyes at all,
   and costs nothing. It is also the part that does not lie: a colour
   histogram is measured, not described.

2. WHAT THE MODEL CAN SEE. If the loaded model has vision - llama.cpp with
   an mmproj projector - the image goes to it as well, and its description
   is added to the measurements rather than replacing them.

Layer 1 always runs. Layer 2 runs when it can. The answer says which
happened, so a description is never mistaken for a measurement.

FORMATS
-------
    images    PNG, BMP, GIF decoded in pure Python; JPEG/WEBP via Pillow if
              it is installed, header-only if not
    PDF       text extracted from FlateDecode streams, stdlib zlib only
    text      md, txt, csv, json, code - read directly
    3D        STL and OBJ - triangle count, bounding box, real dimensions
    video     MP4/MOV container metadata; frames if ffmpeg is on PATH

Everything here is offline. Nothing in this file opens a socket.
"""
from __future__ import annotations

import base64
import json
import re
import shutil
import struct
import subprocess
import threading
import time
import uuid
import zlib
from pathlib import Path

import core
import events

# What the probe found out about the model that is loaded now.
_cap = {"checked": False, "sees": False, "hears": False, "thinks": False,
        "why": "not checked yet", "projector": "", "build": "",
        "via": ""}          # "" | "native"

# llama-server currently has builds where base64 data URIs in the OpenAI
# /v1/chat/completions endpoint fail before mtmd ever sees the image. The
# documented endpoint accepts image_url URLs, so The Hub publishes images to
# its own loopback HTTP endpoint instead. This also makes the capability probe
# exercise the exact same transport as real image turns.
_IMAGE_LOCK = threading.RLock()
_IMAGE_TOKENS: dict[str, tuple[bytes, str, float]] = {}

# A WALL CLOCK IS THE WRONG LIFETIME FOR THIS.
#
# This was 120 seconds, and it was a race the slow machine loses.
#
# The sequence is: publish the image, put its URL in the prompt, send the
# prompt, wait for the tool phase, wait for prompt processing, and only THEN
# does llama-server fetch the URL. On the measured hardware - ~51 tok/s of
# prompt eval, an image costing about 1024 tokens, plus the memory frame and
# a growing history - the second image of a conversation can easily be more
# than two minutes from publish to fetch. The token expired first, the fetch
# 404'd, and the model received the sentence "Attached user file: X (image)"
# with no image behind it. Which is precisely what it then acted on: it tried
# to call open_file on the path it had just been told about.
#
# Nothing announced the failure. The first image of a session worked, the
# second did not, and the difference was how long the model took to think.
#
# So: images live until the turn that published them is finished
# (release_turn), with a long safety expiry for the case where a turn dies
# without releasing, and a hard cap on how many are held so a crash loop
# cannot grow this without bound.
_IMAGE_TTL = 1800.0           # 30 minutes - a backstop, not a schedule
_IMAGE_MAX = 32              # newest kept if something forgets to release


def publish_image(data: bytes, mime: str = "image/jpeg") -> str:
    """
    Publish image bytes on The Hub's loopback endpoint for llama-server.

    The URL stays valid until release_turn() is called or the safety expiry
    passes - never on a timer short enough to race prompt processing.
    """
    token = uuid.uuid4().hex
    with _IMAGE_LOCK:
        now = time.time()
        for k, (_, _, born) in list(_IMAGE_TOKENS.items()):
            if now - born > _IMAGE_TTL:
                _IMAGE_TOKENS.pop(k, None)
        _IMAGE_TOKENS[token] = (bytes(data), mime, now)
        while len(_IMAGE_TOKENS) > _IMAGE_MAX:
            oldest = min(_IMAGE_TOKENS, key=lambda k: _IMAGE_TOKENS[k][2])
            _IMAGE_TOKENS.pop(oldest, None)
    return f"http://127.0.0.1:{core.UI_PORT}/api/vlm-image/{token}"


def release_turn() -> int:
    """
    Drop every published image. Called when a chat turn finishes.

    The model has already looked by then; holding the bytes longer only
    costs memory. Returns how many were released, for the log.
    """
    with _IMAGE_LOCK:
        n = len(_IMAGE_TOKENS)
        _IMAGE_TOKENS.clear()
    return n


def published_count() -> int:
    with _IMAGE_LOCK:
        return len(_IMAGE_TOKENS)


def publish_file(path: Path) -> str:
    """Publish a local image file briefly for llama-server to fetch."""
    path = Path(path)
    data = path.read_bytes()
    mime = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".gif": "image/gif",
        ".webp": "image/webp", ".bmp": "image/bmp",
        ".tga": "image/tga",
    }.get(path.suffix.lower(), "application/octet-stream")
    return publish_image(data, mime)


def serve_image(token: str):
    """Return (bytes, mime) for a short-lived VLM image token, or None."""
    with _IMAGE_LOCK:
        item = _IMAGE_TOKENS.get(token)
        if not item:
            return None
        data, mime, born = item
        if time.time() - born > _IMAGE_TTL:
            _IMAGE_TOKENS.pop(token, None)
            return None
        return data, mime

MAX_SEND_PX = 1024          # longest edge sent to a model
SAMPLE_GRID = 24            # colour sampling resolution

# Every image costs context. llama.cpp's own per-batch ceiling for image
# encoding is 1024 tokens and a dynamic-resolution model can spend all of it
# on one picture, so the prompt budget reserves that rather than discovering
# it when the request is rejected.
IMAGE_TOKENS = 1024


# ═══════════════════════════════════════════════════════════════════════════
# §1  THE PROJECTOR
#
# A vision model in llama.cpp is TWO files:
#
#     llama-server -m model.gguf --mmproj mmproj-model.gguf
#
# The projector encodes an image into embeddings the language model can read.
# It is trained against ONE architecture. A projector from another model does
# not degrade gracefully - it is rejected, or it produces embeddings the
# model cannot interpret. Confirmed on the llama.cpp tracker: an InternVL3
# projector was tried against gemma3, gpt-oss and qwen3.6, and none of them
# would accept an image.
#
# So: a model has sight if and only if a MATCHING projector is on disk. There
# is no configuration that changes this and no flag that works around it.
# ═══════════════════════════════════════════════════════════════════════════

# Quant tags. A projector named only with one of these carries no model
# identity at all - unsloth ships literally `mmproj-F16.gguf`, because the
# REPOSITORY named the model and the filename never had to.
QUANT_ONLY = re.compile(
    r"^(mmproj|projector|proj)?[-_.]*"
    r"(f16|f32|bf16|fp16|fp32|q\d[_a-z0-9]*|iq\d[_a-z0-9]*|model)?"
    r"[-_.]*(mmproj|projector|proj)?$", re.I)


def _is_generic(proj: Path) -> bool:
    """True when the filename says nothing about which model it belongs to."""
    return bool(QUANT_ONLY.match(proj.stem.strip()))


def find_projector(model_path: Path) -> Path | None:
    """
    The mmproj file that belongs to this model, or None.

    Matched by name overlap, because the quantisation suffix often differs
    between the pair:
        gemma-3-4b-it-Q4_K_M.gguf  +  mmproj-gemma-3-4b-it-Q8_0.gguf

    There is deliberately NO fallback to "the only projector present". The
    wrong projector is worse than none: it either fails the load outright or
    it loads and the model describes noise, which looks like a model that
    sees badly rather than a mismatch.
    """
    try:
        folder = model_path.parent
        stem = model_path.stem.lower()
        cands = [q for q in folder.glob("*.gguf")
                 if "mmproj" in q.name.lower() or "-proj" in q.name.lower()]
        if not cands:
            return None

        # Quantisation tags and generic words are NOT evidence of a pair.
        # Scoring on them matched Qwen3.5's projector to Llama-3.1, because
        # both filenames contain "uncensored" and "q4" - two tokens, enough
        # to clear the bar, and completely wrong. Only distinctive tokens
        # count: the model family and its size.
        NOISE = {"mmproj", "proj", "projector", "gguf", "model", "instruct",
                 "it", "chat", "uncensored", "abliterated", "obliterated",
                 "f16", "f32", "bf16", "fp16", "fp32", "q2", "q3", "q4", "q5",
                 "q6", "q8", "iq2", "iq3", "iq4", "k", "m", "s", "l", "xs",
                 "xl", "ud", "0", "1", "text", "vision", "vl"}

        def tokens(name: str) -> set:
            n = re.sub(r"(mmproj|-proj|\.mmproj)[-_]?", "", name.lower())
            return {x for x in re.split(r"[-_.]", n)
                    if len(x) > 1 and x not in NOISE}

        want = tokens(model_path.stem)

        def score(q: Path) -> int:
            return len(tokens(q.stem) & want)

        # 1. an exact convention: <model-stem>.mmproj.gguf
        twin = folder / (model_path.stem + ".mmproj.gguf")
        if twin.exists():
            return twin

        # 2. name overlap - handles mmproj-gemma-3-4b-it-Q8_0.gguf
        best = max(cands, key=score)
        if score(best) >= 2:
            return best

        # 3. A GENERIC name, in a folder of its own.
        #
        # unsloth ships `mmproj-F16.gguf` - no model name, because the repo
        # supplied it. Loose in a folder of seven models that is genuinely
        # ambiguous and pairing it would be a guess. But inside a folder
        # holding exactly ONE model, it is not ambiguous at all: it came with
        # that model.
        siblings = [q for q in folder.glob("*.gguf") if q not in cands]
        generic = [q for q in cands if _is_generic(q)]
        if generic and len(siblings) == 1 and siblings[0] == model_path:
            return generic[0]
        return None
    except Exception:
        return None


def projector_args(model_path: Path, card_free_mb: float) -> list:
    """
    The llama-server flags for loading this model with sight. [] if none.

    Multimodal does NOT require a GPU. llama.cpp offloads the projector to the
    GPU by default and --no-mmproj-offload keeps it in system memory, which is
    what a 4 GB card mostly occupied by the model needs.

    ONE NUMBER: how much of the card runtime.plan() left unspent. Not the free
    VRAM, not the model's share, not a reserve to subtract here - the amount
    this projector may actually use, already net of everything.

    It used to take three numbers and do its own arithmetic, and the middle
    one was a fiction: `min(weights, vram * 0.66)`, the figure plan() computed
    and never sent to llama-server, while the process was in fact loading
    every layer. On a 4 GB card holding a 3.6 GB model that reported roughly a
    gigabyte spare, so the projector was offloaded onto a card that was
    already full. The sum was always the right sum; it was being given the
    wrong inputs.

    Three numbers and a subtraction in the wrong file is how that happens
    twice. The second time would have been the first-load safety margin: a
    projector sized against raw free VRAM would have eaten exactly the margin
    that exists to stop the machine going down.

    The model comes first. If what is left will not hold the projector, the
    projector loads on the CPU - it is slower to look at a picture and nothing
    else changes. It never pushes the model off the card.
    """
    proj = find_projector(model_path)
    if proj is None:
        return []
    args = ["--mmproj", str(proj)]
    need_mb = proj.stat().st_size / 1048576.0
    if card_free_mb < need_mb * 1.3:
        args.append("--no-mmproj-offload")
        core.log_line("runtime",
                      f"projector {proj.name} ({need_mb:.0f} MB) stays on the "
                      f"CPU: the budget leaves {card_free_mb:.0f} MB of the "
                      f"card unspent once the model is in")
    return args


# ═══════════════════════════════════════════════════════════════════════════
# §2  CAPABILITY - asked of the server, then proved
# ═══════════════════════════════════════════════════════════════════════════

def probe(base: str, model_path: Path = None) -> dict:
    """Read the capability of the ONE model currently loaded.

    Vision is not an optional helper service. It belongs to the selected main
    model. llama-server exposes the authoritative multimodal capability in
    /props and /v1/models. We deliberately do not launch another VLM and we
    do not downgrade a working VLM to measurements because a synthetic probe
    happened to fail. Real image requests are the proof; errors are surfaced.
    """
    global _cap
    import urllib.request
    out = {"checked": True, "sees": False, "hears": False, "thinks": False,
           "why": "", "projector": "", "build": "", "via": ""}

    def get(path):
        with urllib.request.urlopen(base + path, timeout=8) as r:
            return json.loads(r.read().decode())

    try:
        props = get("/props")
        out["build"] = str(props.get("build_info") or "")
        mods = props.get("modalities") or {}
        if isinstance(mods, dict):
            out["sees"] = bool(mods.get("vision"))
            out["hears"] = bool(mods.get("audio"))
        tmpl = str(props.get("chat_template") or "")
        caps = props.get("chat_template_caps") or {}
        out["thinks"] = bool(caps.get("supports_reasoning")) or \
            "<think>" in tmpl or "reasoning_content" in tmpl
        if out["sees"]:
            out["why"] = "the loaded model reports multimodal vision"
    except Exception as e:
        out["why"] = f"/props unreadable: {str(e)[:80]}"

    if not out["sees"]:
        try:
            for m in (get("/v1/models").get("data") or []):
                arch = m.get("architecture") or {}
                mods = arch.get("input_modalities") or []
                if "image" in mods or "vision" in mods:
                    out["sees"] = True
                    out["why"] = "/v1/models reports image input"
                    break
        except Exception:
            pass

    if model_path:
        proj = find_projector(Path(model_path))
        if proj:
            out["projector"] = proj.name
            if not out["sees"]:
                out["why"] = (f"matching projector {proj.name} is present on disk, "
                              "but the loaded server did not report vision; check "
                              "the model load log")
        elif not out["sees"] and not out["why"]:
            out["why"] = "this selected model has no matching multimodal projector"

    out["via"] = "native" if out["sees"] else ""
    _cap = out
    core.log_line("runtime", f"vision capability: {out}")
    return out

def capability() -> dict:
    return dict(_cap)


def _solid_png(w: int, h: int, rgb: tuple) -> bytes:
    """A valid PNG with no dependencies. Used for the capability probe."""
    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6))
            + chunk(b"IEND", b""))


# ═══════════════════════════════════════════════════════════════════════════
# §3  IMAGES - measured first, described second
# ═══════════════════════════════════════════════════════════════════════════

# Colour naming by HUE, not by distance in RGB.
#
# The first version picked the nearest entry in an RGB table, and called
# (200,40,40) "brown" - because brown sits closer to it in RGB space than
# pure red does. That is arithmetically true and completely wrong: nobody
# looking at that swatch says brown. RGB distance does not match how people
# see colour, and a measurement that reports the wrong word is worse than no
# measurement, because it reads as confident.
#
# Hue, saturation and value separate the three questions a person actually
# answers: which colour is it, how strong is it, how light is it.

HUES = [(14, "red"), (38, "orange"), (68, "yellow"), (160, "green"),
        (195, "teal"), (255, "blue"), (320, "purple"), (345, "pink"),
        (360, "red")]


def _hsv(r: int, g: int, b: int) -> tuple:
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if d == 0:
        h = 0.0
    elif mx == r:
        h = (60 * ((g - b) / d)) % 360
    elif mx == g:
        h = 60 * ((b - r) / d) + 120
    else:
        h = 60 * ((r - g) / d) + 240
    return h, (0.0 if mx == 0 else d / mx), mx


def name_colour(rgb: tuple) -> str:
    h, s, v = _hsv(*rgb)
    if v < 0.14:
        return "black"
    if s < 0.12:
        return ("white" if v > 0.88 else "light grey" if v > 0.62
                else "grey" if v > 0.32 else "dark grey")
    base = next(name for edge, name in HUES if h <= edge)
    # Dark low-saturation orange and red are what people call brown, and
    # that is the one place the plain hue name is not what anyone would say.
    if base in ("orange", "red") and v < 0.55 and s > 0.3:
        return "brown"
    if base == "red" and v > 0.85 and s < 0.45:
        return "pink"
    if v < 0.46:
        return "dark " + base
    if v > 0.85 and s < 0.35:
        # Low-saturation warm pale tones read as cream, not "pale orange".
        return "cream" if base in ("orange", "yellow") else "pale " + base
    return base


def image_facts(path: Path) -> dict:
    """
    Everything measurable about an image, without a model and without lying.

    Pillow is used when present because it reads every format. When it is
    not, PNG/BMP/GIF are decoded here in pure Python and JPEG falls back to
    its header, which still gives real dimensions. Missing Pillow degrades
    the answer; it never fabricates one.
    """
    f = {"kind": "image", "name": path.name,
         "size_mb": round(path.stat().st_size / 1048576, 3)}
    px = None
    try:
        from PIL import Image                                  # noqa
        with Image.open(path) as im:
            im = im.convert("RGB")
            f["width"], f["height"] = im.size
            small = im.resize((SAMPLE_GRID, SAMPLE_GRID))
            px = list(small.getdata())
            f["reader"] = "Pillow"
    except Exception:
        got = _decode_basic(path)
        if got:
            f.update(got)
            px = got.pop("_px", None)
            f.pop("_px", None)

    if not f.get("width"):
        f["note"] = "dimensions unreadable without Pillow"
        return f

    f["aspect"] = _aspect(f["width"], f["height"])
    f["orientation"] = ("square" if f["width"] == f["height"]
                        else "landscape" if f["width"] > f["height"]
                        else "portrait")
    if px:
        f.update(_colour_report(px))
    return f


def _aspect(w: int, h: int) -> str:
    from math import gcd
    g = gcd(w, h) or 1
    a, b = w // g, h // g
    if a > 40 or b > 40:
        return f"{w/h:.2f}:1"
    return f"{a}:{b}"


def _colour_report(px: list) -> dict:
    """Dominant colours, brightness, contrast and how busy the image is."""
    if not px:
        return {}
    buckets = {}
    lum = []
    for r, g, b in px:
        buckets[(r // 32, g // 32, b // 32)] = buckets.get((r // 32, g // 32, b // 32), 0) + 1
        lum.append(0.2126 * r + 0.7152 * g + 0.0722 * b)
    # Group by COLOUR NAME, not by bucket. A gradient fills a dozen adjacent
    # buckets that are all recognisably one colour, and reporting "navy 2%,
    # navy 2%, purple 2%, purple 2%" describes the histogram rather than the
    # image. Merging by name reports what a person would actually say.
    n = len(px)
    named = {}
    for (br, bg, bb), c in buckets.items():
        rgb = (br * 32 + 16, bg * 32 + 16, bb * 32 + 16)
        nm = name_colour(rgb)
        e = named.setdefault(nm, {"count": 0, "r": 0, "g": 0, "b": 0})
        e["count"] += c
        e["r"] += rgb[0] * c; e["g"] += rgb[1] * c; e["b"] += rgb[2] * c
    dom = []
    for nm, e in sorted(named.items(), key=lambda kv: -kv[1]["count"])[:4]:
        c = e["count"]
        rgb = (e["r"] // c, e["g"] // c, e["b"] // c)
        share = round(100 * c / n)
        if share >= 3 or not dom:
            dom.append({"colour": nm, "hex": "#%02x%02x%02x" % rgb,
                        "share": share})
    avg = sum(lum) / n
    spread = (sum((x - avg) ** 2 for x in lum) / n) ** 0.5
    return {
        "dominant_colours": dom,
        "brightness": ("very dark" if avg < 40 else "dark" if avg < 90
                       else "mid" if avg < 165 else "bright" if avg < 215
                       else "very bright"),
        "contrast": ("flat" if spread < 25 else "moderate" if spread < 60
                     else "high"),
        "busy": ("plain" if len(buckets) < 8 else "simple" if len(buckets) < 30
                 else "detailed" if len(buckets) < 120 else "very detailed"),
    }


def _decode_basic(path: Path) -> dict:
    """PNG, BMP and GIF without any third-party library. JPEG header only."""
    data = path.read_bytes()
    try:
        if data[:8] == b"\x89PNG\r\n\x1a\n":
            w, h = struct.unpack(">II", data[16:24])
            depth, ctype = data[24], data[25]
            out = {"width": w, "height": h, "reader": "built-in PNG"}
            if depth == 8 and ctype in (2, 6):
                out["_px"] = _png_pixels(data, w, h, 4 if ctype == 6 else 3)
            return out
        if data[:2] == b"BM":
            w, h = struct.unpack("<ii", data[18:26])
            return {"width": abs(w), "height": abs(h), "reader": "built-in BMP"}
        if data[:6] in (b"GIF87a", b"GIF89a"):
            w, h = struct.unpack("<HH", data[6:10])
            return {"width": w, "height": h, "reader": "built-in GIF"}
        if data[:2] == b"\xff\xd8":
            i = 2
            while i < len(data) - 9:
                if data[i] != 0xFF:
                    i += 1
                    continue
                m = data[i + 1]
                if m in (0xC0, 0xC1, 0xC2, 0xC3):
                    h, w = struct.unpack(">HH", data[i + 5:i + 9])
                    return {"width": w, "height": h,
                            "reader": "built-in JPEG header",
                            "note": "install Pillow for colour analysis of JPEGs"}
                i += 2 + struct.unpack(">H", data[i + 2:i + 4])[0]
    except Exception:
        pass
    return {}


def _png_pixels(data: bytes, w: int, h: int, ch: int) -> list:
    """Inflate and unfilter a PNG, then sample it down to the colour grid."""
    idat = b""
    i = 8
    while i < len(data) - 8:
        ln = struct.unpack(">I", data[i:i + 4])[0]
        tag = data[i + 4:i + 8]
        if tag == b"IDAT":
            idat += data[i + 8:i + 8 + ln]
        elif tag == b"IEND":
            break
        i += 12 + ln
    raw = zlib.decompress(idat)
    stride = w * ch
    out, prev = [], bytearray(stride)
    pos = 0
    rows = []
    for _ in range(h):
        if pos >= len(raw):
            break
        ft = raw[pos]; pos += 1
        line = bytearray(raw[pos:pos + stride]); pos += stride
        for x in range(len(line)):
            a = line[x - ch] if x >= ch else 0
            b = prev[x]
            c = prev[x - ch] if x >= ch else 0
            if ft == 1:
                line[x] = (line[x] + a) & 255
            elif ft == 2:
                line[x] = (line[x] + b) & 255
            elif ft == 3:
                line[x] = (line[x] + (a + b) // 2) & 255
            elif ft == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                line[x] = (line[x] + (a if pa <= pb and pa <= pc
                                      else b if pb <= pc else c)) & 255
        rows.append(bytes(line))
        prev = line
    if not rows:
        return []
    for gy in range(SAMPLE_GRID):
        row = rows[min(len(rows) - 1, gy * len(rows) // SAMPLE_GRID)]
        for gx in range(SAMPLE_GRID):
            o = min(w - 1, gx * w // SAMPLE_GRID) * ch
            out.append((row[o], row[o + 1], row[o + 2]))
    return out


def url_for_model(path: Path) -> str:
    """Return a short-lived loopback URL that llama-server can fetch."""
    path = Path(path)
    # Normalize formats first, because the browser/vault may contain formats
    # the llama.cpp decoder does not accept directly. Reuse the exact bytes
    # produced by encode_for_model rather than creating a second conversion
    # pipeline.
    uri = encode_for_model(path)
    if not uri or "," not in uri:
        return ""
    head, b64 = uri.split(",", 1)
    try:
        raw = base64.b64decode(b64, validate=True)
    except Exception:
        return ""
    mime = head[5:].split(";", 1)[0] if head.startswith("data:") else "image/jpeg"
    return publish_image(raw, mime)


def sniff_image_mime(data: bytes) -> str:
    """
    The image format according to the file's own first bytes.

    Filenames lie and sometimes are not there at all. Every format below is
    one llama.cpp's decoder accepts, so a positive answer here is also a
    promise that the bytes can be sent.
    """
    if not data:
        return ""
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if data[:2] == b"BM":
        return "image/bmp"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:2] in (b"P1", b"P2", b"P3", b"P4", b"P5", b"P6"):
        return {b"P1": "image/x-portable-bitmap",
                b"P4": "image/x-portable-bitmap",
                b"P2": "image/x-portable-graymap",
                b"P5": "image/x-portable-graymap"}.get(
                    data[:2], "image/x-portable-pixmap")
    return ""


def extension_for_mime(mime: str) -> str:
    """The file extension that belongs to an image mime type, with the dot."""
    return {"image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
            "image/gif": ".gif", "image/bmp": ".bmp", "image/webp": ".webp",
            "image/tga": ".tga"}.get((mime or "").strip().lower(), "")


def encode_for_model(path: Path) -> str:
    """
    Return an image data URI in a format llama.cpp can actually decode.

    Prefer JPEG for large photographic images and PNG otherwise. Pillow is
    used when available because it can convert WEBP/AVIF/SVG and camera formats
    into something the multimodal endpoint accepts. The fallback only passes
    formats known to be accepted by llama.cpp's image decoder.
    """
    path = Path(path)
    supported = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tga",
                 ".ppm", ".pgm", ".pbm"}
    try:
        from PIL import Image
        import io
        with Image.open(path) as im:
            has_alpha = "A" in im.getbands()
            im = im.convert("RGBA" if has_alpha else "RGB")
            if max(im.size) > MAX_SEND_PX:
                s = MAX_SEND_PX / max(im.size)
                im = im.resize((max(1, int(im.width * s)),
                                max(1, int(im.height * s))), Image.LANCZOS)
            buf = io.BytesIO()
            if has_alpha:
                im.save(buf, format="PNG", optimize=True)
                mime = "image/png"
            else:
                im.save(buf, format="JPEG", quality=85, optimize=True)
                mime = "image/jpeg"
            return "data:" + mime + ";base64," + base64.b64encode(
                buf.getvalue()).decode()
    except Exception as e:
        # THE GATE THAT DROPPED THE CAMERA FRAME.
        #
        # This rejected anything whose EXTENSION was not recognised, before
        # the byte-sniffing fallback below could get a look. The camera frame
        # is written by server.py and has no extension at all, so on any
        # machine without Pillow - which is every real install, the shipped
        # Python being embedded with no pip - the frame was refused here and
        # the eye button did nothing at all. A vault photo called
        # IMG_0254.JPG sailed through, which is why the model looked like it
        # could see everything except the camera.
        #
        # The filename is a hint. The bytes are the fact.
        if (path.suffix.lower() not in supported
                and not sniff_image_mime(path.read_bytes()[:32]
                                         if path.is_file() else b"")):
            core.log_line("runtime",
                          f"cannot encode {path.name} for a VLM: not a "
                          f"recognised image by name or by content ({e})")
            return ""

    data = path.read_bytes()
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
            "gif": "image/gif", "bmp": "image/bmp", "tga": "image/tga",
            "ppm": "image/x-portable-pixmap", "pgm": "image/x-portable-graymap",
            "pbm": "image/x-portable-bitmap"}.get(
                path.suffix.lower().lstrip("."), "")
    if not mime:
        # ASK THE BYTES.
        #
        # This returned "" for anything without a recognised extension, and
        # that is exactly what the camera produced: server.py wrote the frame
        # to data/incoming-image - no suffix at all - so the fallback found no
        # mime, returned "", and the frame was dropped with a one-line notice.
        # A vault photo called IMG_0254.JPG went through fine, which is why
        # the eye button looked broken while the model could obviously see.
        #
        # Pillow hid it during development by sniffing content itself. Pillow
        # is not installed on a real install - the shipped Python is embedded,
        # with no pip - so the fallback IS the path on the user's machine.
        mime = sniff_image_mime(data)
    if not mime:
        return ""
    return f"data:{mime};base64," + base64.b64encode(data).decode()


# ═══════════════════════════════════════════════════════════════════════════
# §4  DOCUMENTS - PDF text without a third-party library
# ═══════════════════════════════════════════════════════════════════════════

def pdf_text(path: Path, limit: int = 12000) -> dict:
    """
    Pull readable text out of a PDF using nothing but zlib.

    Most PDFs store page content as FlateDecode streams, and text sits in
    Tj and TJ operators between BT/ET. That covers the ordinary case - a
    written document. It does NOT cover a scanned page, which is an image
    of text and has no text objects at all; that case is reported honestly
    rather than returned as an empty success.
    """
    data = path.read_bytes()
    out = {"kind": "pdf", "name": path.name,
           "size_mb": round(len(data) / 1048576, 3)}
    out["pages"] = len(re.findall(rb"/Type\s*/Page[^s]", data)) or None

    chunks = []
    for m in re.finditer(rb"stream\r?\n(.*?)endstream", data, re.S):
        blob = m.group(1)
        try:
            blob = zlib.decompress(blob)
        except Exception:
            try:
                blob = zlib.decompressobj().decompress(blob)
            except Exception:
                continue
        if b"BT" not in blob:
            continue
        text = []
        for tm in re.finditer(rb"\((?:\\.|[^\\()])*\)|<[0-9A-Fa-f\s]+>", blob):
            tok = tm.group(0)
            if tok.startswith(b"<"):
                hx = re.sub(rb"\s", b"", tok[1:-1])
                try:
                    text.append(bytes.fromhex(hx.decode()).decode(
                        "utf-16-be", "ignore"))
                except Exception:
                    pass
            else:
                s = tok[1:-1]
                s = re.sub(rb"\\([nrt])", lambda m: {b"n": b"\n", b"r": b"\r",
                                                     b"t": b"\t"}[m.group(1)], s)
                s = re.sub(rb"\\(.)", rb"\1", s)
                text.append(s.decode("latin-1", "ignore"))
        if text:
            chunks.append(" ".join(text))
        if sum(len(c) for c in chunks) > limit:
            break

    body = re.sub(r"[ \t]{2,}", " ", "\n".join(chunks)).strip()
    if body:
        out["text"] = body[:limit]
        out["chars"] = len(body)
    else:
        out["text"] = ""
        out["note"] = ("no text objects found - this is most likely a scanned "
                       "PDF, which is an image of text. Its pages would need "
                       "to be looked at rather than read.")
    return out


def text_facts(path: Path, limit: int = 12000) -> dict:
    txt = path.read_text(encoding="utf-8", errors="replace")
    out = {"kind": "text", "name": path.name, "chars": len(txt),
           "lines": txt.count("\n") + 1, "text": txt[:limit]}
    if path.suffix.lower() == ".md":
        heads = re.findall(r"^#{1,6}\s+(.+)$", txt, re.M)
        if heads:
            out["headings"] = heads[:24]
    return out


# ═══════════════════════════════════════════════════════════════════════════
# §5  GEOMETRY AND VIDEO
# ═══════════════════════════════════════════════════════════════════════════

def model3d_facts(path: Path) -> dict:
    """
    How big the thing actually is, in the units it was saved in.

    A 3D model has no appearance until it is rendered, but it does have real
    measurements, and those are usually what someone wants: how big is it,
    how detailed, will it fit on the bed.

    This used to carry its own inline STL/OBJ reader - two formats, and every
    other extension fell through to "measured by file size only; geometry not
    parsed". model3d.py, which ships in this same folder and is already used
    to RENDER these files, reads STL, OBJ, PLY and 3MF directly and GLB/GLTF
    through trimesh when it is installed. Parsing a file one way to draw it
    and a different, weaker way to describe it is how a GLB ends up rendered
    correctly on screen and reported as an unknown blob in the same turn.
    One reader.
    """
    out = {"kind": "model3d", "name": path.name,
           "size_mb": round(path.stat().st_size / 1048576, 3),
           "format": path.suffix.lower().lstrip(".").upper()}
    try:
        import model3d
        tris = model3d.triangles(path)
        if tris:
            lo = [min(pt[i] for tri in tris for pt in tri) for i in range(3)]
            hi = [max(pt[i] for tri in tris for pt in tri) for i in range(3)]
            dims = [round(hi[i] - lo[i], 3) for i in range(3)]
            n = len(tris)
            out["triangles"] = n
            out["dimensions"] = {"x": dims[0], "y": dims[1], "z": dims[2],
                                 "units": "as saved by the source tool "
                                          "(STL/OBJ/3MF are usually mm; "
                                          "CAD exports may differ)"}
            out["longest_edge"] = max(dims)
            out["detail"] = ("coarse" if n < 2000 else "moderate"
                             if n < 50000 else "fine" if n < 400000
                             else "very fine")
            return out
        # STEP and other boundary-representation formats are not meshes.
        # Say that, rather than reporting a shape of zero.
        out["note"] = ("no triangles could be read from this format on this "
                       "machine; a CAD backend (FreeCAD) or trimesh would be "
                       "needed to measure it")
    except Exception as e:
        out["note"] = f"partial read: {type(e).__name__}: {str(e)[:80]}"
    return out


def video_facts(path: Path) -> dict:
    """
    Container metadata always; a real frame when ffmpeg happens to be there.

    ffmpeg is not required and not installed by The Hub. If it is on PATH
    a middle frame is pulled so the model can actually look at the video;
    if it is not, the duration and dimensions still come from the MP4 atoms.
    """
    out = {"kind": "video", "name": path.name,
           "size_mb": round(path.stat().st_size / 1048576, 3)}
    try:
        data = path.read_bytes()[:2_000_000]
        m = re.search(rb"mvhd", data)
        if m:
            o = m.end() + 12
            scale, dur = struct.unpack(">II", data[o:o + 8])
            if scale:
                out["seconds"] = round(dur / scale, 1)
        t = re.search(rb"tkhd", data)
        if t:
            o = t.end() + 74
            w, h = struct.unpack(">II", data[o:o + 8])
            if w and h:
                out["width"], out["height"] = w >> 16, h >> 16
    except Exception:
        pass
    if shutil.which("ffmpeg"):
        out["frame_available"] = True
    else:
        out["note"] = ("ffmpeg is not on PATH, so only container metadata "
                       "was read. No frame could be looked at.")
    return out


def grab_frame(path: Path, at_seconds: float = None) -> Path | None:
    """One frame to a temp PNG, if ffmpeg is available."""
    if not shutil.which("ffmpeg"):
        return None
    dest = core.DATA / "frame.png"
    at = at_seconds if at_seconds is not None else 1.0
    try:
        subprocess.run(["ffmpeg", "-y", "-ss", str(at), "-i", str(path),
                        "-frames:v", "1", "-vf", "scale=1024:-1", str(dest)],
                       capture_output=True, timeout=45)
        return dest if dest.exists() else None
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════
# §6  ONE ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

def read_any(path: Path) -> dict:
    """Measure whatever this is. Never calls a model."""
    sfx = path.suffix.lower()
    import vault
    kind = vault.media_kind(sfx)
    if kind == "image":
        return image_facts(path)
    if sfx == ".pdf":
        return pdf_text(path)
    if kind == "text":
        return text_facts(path)
    if kind == "model3d":
        return model3d_facts(path)
    if kind == "video":
        return video_facts(path)
    return {"kind": kind, "name": path.name,
            "size_mb": round(path.stat().st_size / 1048576, 3),
            "note": "no reader for this format; only its name and size are known"}


def describe_facts(facts: dict) -> str:
    """
    Measurements, in plain language. No model involved, always true.

    Split out of describe() so the side-car path can use exactly the same
    text - the measurements are the part that does not depend on anything
    having eyes, and they should read identically whether a model described
    the picture or nothing did.
    """
    lines = [f"{facts.get('name','file')} - {facts.get('kind', 'file')}, "
             f"{facts.get('size_mb', 0)} MB"]
    if facts.get("width"):
        lines.append(f"  {facts['width']}x{facts['height']} px, "
                     f"{facts.get('orientation','')}, aspect {facts.get('aspect','')}")
    if facts.get("dominant_colours"):
        cols = ", ".join(f"{c['colour']} {c['hex']} ({c['share']}%)"
                         for c in facts["dominant_colours"])
        lines.append(f"  colours: {cols}")
        lines.append(f"  {facts.get('brightness','')}, "
                     f"{facts.get('contrast','')} contrast, {facts.get('busy','')}")
    if facts.get("dimensions"):
        d = facts["dimensions"]
        lines.append(f"  {d['x']} x {d['y']} x {d['z']} {d['units']}, "
                     f"{facts.get('triangles',0):,} triangles, "
                     f"{facts.get('detail','')}")
    if facts.get("seconds"):
        lines.append(f"  {facts['seconds']}s"
                     + (f", {facts.get('width')}x{facts.get('height')}"
                        if facts.get("width") else ""))
    if facts.get("headings"):
        lines.append("  headings: " + " / ".join(facts["headings"][:8]))
    if facts.get("pages"):
        lines.append(f"  {facts['pages']} page(s), "
                     f"{facts.get('chars',0):,} characters of text")
    if facts.get("note"):
        lines.append(f"  note: {facts['note']}")
    if facts.get("text"):
        lines.append("\n--- text in the file ---\n" + facts["text"][:8000])
    return "\n".join(lines)


def describe(path: Path, question: str = "", base: str = None) -> str:
    """
    Look at one thing. Measurements first, description second, labelled apart.

    Routing lives in look(): the main model sees it natively, or the side-car
    describes it, or neither can and the measurements stand alone and say so.
    """
    return look(Path(path), question, base or "")["text"]



def _ask_model(base: str, image: Path, prompt: str) -> str:
    import urllib.request
    try:
        body = {"messages": [{"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url",
             "image_url": {"url": url_for_model(image)}}]},
        ], "max_tokens": 420, "temperature": 0.2, "stream": False}
        req = urllib.request.Request(base + "/v1/chat/completions",
                                     data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json"},
                                     method="POST")
        with urllib.request.urlopen(req, timeout=240) as r:
            d = json.loads(r.read().decode())
        return (d["choices"][0]["message"].get("content") or "").strip()
    except Exception as e:
        core.log_line("runtime", f"vision look failed: {e}")
        return ""


# ═══════════════════════════════════════════════════════════════════════════
# §6  EVERY SOURCE OF AN IMAGE, NOT JUST FILES
#
# A model with eyes should be able to look at whatever is in front of it.
# There were three sources it could not reach:
#
#   the camera      the app grabbed a frame but gated it on config.runtime
#                   .mmproj, which is a path someone had to type. The probe
#                   knows the real answer now, so the camera asks the probe.
#   web results     a search returned text and threw the pictures away, so
#                   a page that IS a picture came back empty
#   pasted images   nothing accepted one at all
#
# All three end up in the same place: bytes, measured by §2, then shown to
# the model by §5 if it can see. One path, three doors.
# ═══════════════════════════════════════════════════════════════════════════

IMG_IN_PAGE = re.compile(
    rb'<img[^>]+src=["\']([^"\']+\.(?:png|jpe?g|gif|webp))["\']', re.I)
OG_IMAGE = re.compile(
    rb'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']', re.I)


def images_on_page(html: bytes, page_url: str, limit: int = 3) -> list:
    """
    The pictures a retrieved page is actually about.

    og:image first, because that is the one the page's author nominated as
    representing it. Then inline images in document order. Tracking pixels
    and spacers are filtered by extension and by the obvious name patterns
    rather than by fetching them to find out.
    """
    from urllib.parse import urljoin
    found, seen = [], set()
    for m in OG_IMAGE.finditer(html or b""):
        found.append(m.group(1).decode("utf-8", "ignore"))
    for m in IMG_IN_PAGE.finditer(html or b""):
        found.append(m.group(1).decode("utf-8", "ignore"))
    out = []
    for u in found:
        if any(bad in u.lower() for bad in
               ("pixel", "spacer", "tracking", "1x1", "avatar", "icon",
                "logo", "sprite", "badge")):
            continue
        full = urljoin(page_url, u)
        if full in seen:
            continue
        seen.add(full)
        out.append(full)
        if len(out) >= limit:
            break
    return out


def fetch_image(url: str, timeout: float = 20.0, max_mb: float = 12.0):
    """
    Pull one image so it can be looked at.

    This is the only function in this file that opens a socket, and it only
    runs on a URL that came back from a search the user switched on. It is
    capped by size and by content type, because a "photo" that turns out to
    be a 400 MB file is how a look at a picture becomes a hung application.
    """
    import urllib.request
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "TheThe Hub/1.0 (local assistant)"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = (r.headers.get("Content-Type") or "").lower()
            if not ctype.startswith("image/"):
                return None, f"not an image ({ctype[:40]})"
            size = int(r.headers.get("Content-Length") or 0)
            if size and size > max_mb * 1048576:
                return None, f"too large ({size/1048576:.1f} MB)"
            data = r.read(int(max_mb * 1048576) + 1)
        if len(data) > max_mb * 1048576:
            return None, "too large"
        dest = core.DATA / ("web" + (".png" if "png" in ctype else ".jpg"))
        # A FRESH INSTALL HAS NO data/ YET, and a missing parent turns "look
        # at this picture" into FileNotFoundError pointing at a scratch file
        # nobody asked about.
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        return dest, ""
    except Exception as e:
        return None, str(e)[:90]


def look_at_url(url: str, base: str = None, question: str = "") -> str:
    """One image from the web, measured then described. Used by search."""
    path, why = fetch_image(url)
    if path is None:
        return f"could not look at {url[:80]}: {why}"
    facts = image_facts(path)
    out = [f"image from {url[:90]}",
           f"  {facts.get('width','?')}x{facts.get('height','?')} px, "
           f"{facts.get('orientation','')}"]
    if facts.get("dominant_colours"):
        out.append("  colours: " + ", ".join(
            f"{c['colour']} ({c['share']}%)" for c in facts["dominant_colours"]))
    if base and _cap.get("sees"):
        said = _ask_model(base, path, question or
                          "Describe this image and read out any text in it.")
        if said:
            out.append("  seen: " + said)
        else:
            out.append("  (the loaded vision model did not return a description)")
    elif facts.get("kind") == "image":
        why = _cap.get("why") or "the selected model has no vision"
        out.append("  (measured only - the selected model is text-only): " + why)
    else:
        out.append("  (measured only - the loaded model has no vision)")
    return "\n".join(out)


def look_at_bytes(data: bytes, name: str = "image", base: str = None,
                  question: str = "") -> str:
    """An image handed straight in - a camera frame, or something pasted."""
    suffix = ".png" if data[:8] == b"\x89PNG\r\n\x1a\n" else ".jpg"
    dest = core.DATA / ("incoming" + suffix)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return describe(dest, question, base)


def decode_data_uri(uri: str):
    """`data:image/jpeg;base64,...` to bytes. What a browser canvas sends."""
    try:
        head, b64 = uri.split(",", 1)
        if "base64" not in head or not head.startswith("data:image/"):
            return None
        return base64.b64decode(b64)
    except Exception:
        return None


# ═══════════════════════════════════════════════════════════════════════════
# §7  NATIVE-ONLY ROUTING
#
# There is deliberately NO second VLM. The selected main model is either
# multimodal (with its matching projector loaded) or text-only. This keeps
# exactly one language model on the device and makes the user's model choice
# authoritative.
# ═══════════════════════════════════════════════════════════════════════════


def look(image: Path, question: str, main_base: str) -> dict:
    """Measure a file and report whether the selected model can see it.

    For a native VLM the actual pixels are attached by the caller. We never
    manufacture a second model or a prose substitute.
    """
    image = Path(image)
    facts = read_any(image)
    measured = describe_facts(facts)

    if facts.get("kind") == "video":
        frame = grab_frame(image, (facts.get("seconds") or 1.0) / 2.0)
        if frame is not None:
            facts["frame_path"] = str(frame)
            measured += "\n\n--- representative frame ---\n" + describe_facts(image_facts(frame))

    if _cap.get("sees"):
        # A 3D model is not directly an image input to llama.cpp. Render the
        # actual geometry into a compact multi-angle image and attach that
        # image to the same native VLM turn. Geometry facts remain separate.
        if facts.get("kind") == "model3d":
            try:
                import model3d
                preview = model3d.preview_for(image)
                if preview is not None:
                    facts["preview_path"] = str(preview)
                    facts["preview"] = preview.name
            except Exception as e:
                core.log_line("vision", f"3D preview failed for {image.name}: {e}")
        return {
            "text": ("[MACHINE FILE FACTS — NOT THE VISUAL CONTENT]\n" + measured +
                     "\n\n[VISUAL CONTENT]\nThe actual visual representation for this exact file is attached separately to the turn. "
                     "Use the attachment to identify what the object/image contains; do not infer appearance from the machine facts above."),
            "via": "native", "facts": facts}
    why = _cap.get("why") or "the selected model has no vision"
    if facts.get("kind") in ("image", "video"):
        measured += ("\n\nNothing could look at this image because the selected "
                    "model is text-only. Select a model marked VISION to use visual understanding. " + why)
    return {"text": measured, "via": "measured", "facts": facts}

