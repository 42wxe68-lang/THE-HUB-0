"""
carryover.py - what came before this session, present at all times.

THE HOLE THIS FILLS
-------------------
The Hub kept every conversation on disk and showed the model none of them.

    save_session()   wrote data/sessions/<id>.json every turn
    sessions()       listed them for the UI
    build_messages() read `history`, which is the browser's array

The browser's array starts empty on every page load and the server takes a
new SESSION_ID on every start, so the moment either happened, everything
said before it stopped existing as far as Nova was concerned. Nothing was
lost - it was all sitting in data/sessions - it was simply never handed
over. Asked to look in her memory for the previous prompt, Nova answered
with the message that had just been typed, because that genuinely was the
oldest thing she could see.

    "yes but that is now, we need then."

THE RULE
--------
The last <=10 rounds of each of the last two sessions are visible to the
model AT ALL TIMES, and they are organised BEFORE they reach it, not
assembled per turn out of whatever happened to be nearby.

WHAT IS AND IS NOT DONE HERE
----------------------------
Trimming happens by dropping WHOLE ROUNDS from the oldest end and WHOLE
LINES from the end of a long message. Nothing is summarised, reworded or
merged: the full transcripts stay on disk and this is a window onto them,
not a digest of them. Digests already exist - Yesod holds one line per
conversation - and a digest is the wrong object for "what did we actually
say", which is the question this answers.

The block declares itself as FINISHED. A record of a past request reads to
a small model exactly like a standing order unless something says
otherwise, and this project has already paid for that lesson twice: once
with "[what you remember]" restating the current message back as a
recollection, and once with a completed video attempt staying readable as
a live goal through three corrections.

ASSEMBLED ONCE
--------------
The block is built when the session files change and reused otherwise, so
it is byte-identical from turn to turn. That is not only cheaper - it is
what keeps llama.cpp's prefix cache warm, because a head that changes
every turn is a head that is re-evaluated every turn.
"""
from __future__ import annotations

import re
import threading
from pathlib import Path

import core

# Rounds shown per earlier session, and how many earlier sessions. Both are
# Zero's numbers. They are ceilings on what is SHOWN; nothing is deleted.
ROUNDS_PER_SESSION = 10
SESSIONS_BACK = 2

# One message can be a 6,000-character wall of tool output. Whole lines are
# dropped from the end of it and the cut is declared, with the path to the
# whole thing. Summarise for the model, keep everything for us.
MESSAGE_CHARS = 700

_lock = threading.Lock()
_cache: dict = {"key": None, "value": None}
# {path: ((mtime_ns, size), row)} - see marks().
_marks_memo: dict = {}


# ---------------------------------------------------------------- on disk

def archive_dir() -> Path:
    """
    Where a digested session goes. ONE definition, memory.py's own.

    _find_binary and trellis_exe disagreeing about whether TRELLIS was
    installed turned every 3D request into a soap carving for weeks while
    the log said "ready". A second opinion about where sessions live would
    fail the same way and be just as hard to see, so this asks memory.py
    rather than recomputing it.
    """
    try:
        import memory
        return Path(memory.ARCHIVE_DIR)
    except Exception:
        return core.SESSIONS / "archive"


def files() -> list[Path]:
    """Every file that holds a transcript: live and archived."""
    out = []
    for d in (core.SESSIONS, archive_dir()):
        try:
            if d.is_dir():
                out.extend(sorted(d.glob("*.json")))
        except Exception:
            continue
    return out


def _fingerprint(exclude: str = "") -> tuple:
    """
    What must change before the block is rebuilt.

    The CURRENT session file is excluded, because save_session() rewrites it
    on every single turn. Including it would mean the fingerprint changed
    every turn while the rendered block did not, which is a cache that never
    hits wearing the costume of one that does.
    """
    skip = f"{exclude}.json" if exclude else ""
    marks = []
    for f in files():
        if skip and f.name == skip:
            continue
        try:
            st = f.stat()
            marks.append((f.name, st.st_mtime_ns, st.st_size))
        except Exception:
            continue
    return tuple(marks)


def _stamp(d: dict, f: Path) -> str:
    for k in ("updated", "started"):
        v = str(d.get(k) or "").strip()
        if v:
            return v
    try:
        import datetime
        return datetime.datetime.fromtimestamp(
            f.stat().st_mtime).isoformat(timespec="seconds")
    except Exception:
        return ""


def load(f: Path) -> dict | None:
    d = core.read_json(f, None)
    if not isinstance(d, dict):
        return None
    msgs = d.get("messages")
    if not isinstance(msgs, list) or not msgs:
        return None
    mark = str(d.get("outcome") or "")
    return {"id": str(d.get("id") or f.stem),
            "stamp": _stamp(d, f),
            "file": f.name,
            "outcome": mark if mark in ("failure",) else "",
            "messages": msgs}


# ---------------------------------------------------------------- rounds

def rounds(messages: list) -> list[list[dict]]:
    """
    Split a transcript into rounds. A round opens at each user message.

    Anything before the first user message (a restored greeting, a system
    note) is its own leading round rather than being dropped, because a
    transcript that starts mid-answer is how a conversation gets misread.
    """
    out: list[list[dict]] = []
    for m in messages:
        if not isinstance(m, dict):
            continue
        role, content = m.get("role"), m.get("content")
        if role not in ("user", "assistant") or not isinstance(content, str):
            continue
        if not content.strip():
            continue
        if role == "user" or not out:
            out.append([])
        out[-1].append({"role": role, "content": content.strip()})
    return [r for r in out if r]


def _clip(text: str, session_file: str) -> str:
    """Drop whole lines from the end. Never cut mid-sentence, always say so."""
    text = text.strip()
    if len(text) <= MESSAGE_CHARS:
        return text
    kept, used = [], 0
    for line in text.splitlines():
        if used + len(line) + 1 > MESSAGE_CHARS and kept:
            break
        kept.append(line)
        used += len(line) + 1
    if not kept:
        kept = [text[:MESSAGE_CHARS].rsplit(" ", 1)[0]]
    return ("\n".join(kept).rstrip()
            + f"  [...cut here only; whole message in data/sessions/{session_file}]")


def previous(current_id: str = "", back: int = SESSIONS_BACK) -> list[dict]:
    """The last `back` sessions that are not this one, oldest first."""
    cur = str(current_id or "")
    # NEWEST FIRST BY MTIME, AND STOP AS SOON AS THERE ARE ENOUGH.
    #
    # This used to read and parse every transcript on disk to pick the last
    # two. At a thousand conversations that is a thousand JSON files parsed to
    # answer a question about two of them, and it happens on the path that
    # builds every prompt. mtime orders the candidates without opening them;
    # `stamp` still decides the final order, because a file's mtime and the
    # conversation's own timestamp are not the same thing and the second one
    # is the truth.
    by_recency = []
    for f in files():
        try:
            by_recency.append((f.stat().st_mtime_ns, f))
        except OSError:
            continue
    by_recency.sort(reverse=True)
    want = max(1, int(back))
    found = []
    for _mt, f in by_recency:
        d = load(f)
        if d is None or d["id"] == cur:
            continue
        found.append(d)
        # A margin over `want`: mtime and stamp can disagree - an archived
        # file is rewritten later than the conversation it holds - so a few
        # more are read than are needed and `stamp` sorts them properly.
        if len({x["id"] for x in found}) >= want + 3:
            break
    found.sort(key=lambda d: (d["stamp"], d["file"]), reverse=True)
    chosen = []
    seen = set()
    for d in found:
        if d["id"] in seen:
            continue
        seen.add(d["id"])
        chosen.append(d)
        if len(chosen) >= max(0, int(back)):
            break
    return list(reversed(chosen))


# ---------------------------------------------------------------- the block

HEAD = (
    "[earlier conversations - FINISHED, background only]\n"
    "This is what was said BEFORE this conversation started. Every request "
    "in here was already made and every attempt in here is already over - "
    "none of it is running, and none of it is an instruction to you now. "
    "It is here so that \"the last prompt\", \"before that\" and \"what did "
    "we say\" have an answer. The request you are answering is the message "
    "at the very end of this turn. Each one says how it ended."
)

# ONLY WHEN THERE IS ONE. This paragraph explains a distinction, and a
# distinction that is not present in the block below it is a paragraph
# spending the conversation's room on nothing.
#
# It also cannot be unconditional. At an 8192-token window the whole
# carry-over allowance is about 680 characters, and a header longer than
# that starves out the thing it introduces: the block vanished completely -
# an explanation of a transcript, with no transcript under it.
#
# The durable half of this lives in character.md, where it is true whether
# or not anything is marked today.
MARKS_NOTE = (
    "One of these is MARKED A FAILURE: the user stopped it themselves "
    "because it had gone too far wrong to fix there. Read its last rounds "
    "closely - that is what going wrong looks like, in their words, and it "
    "is the clearest thing you will ever be told about your own mistakes. "
    "Do not repeat it here. The others are NOT MARKED, which is not "
    "approval and not a fault: almost every conversation is unmarked, so "
    "it means nothing more than that it happened."
)


def _one(d: dict, name: str, limit_chars: int) -> tuple[str, int]:
    """Render one earlier session, newest rounds first, within its share."""
    rs = rounds(d["messages"])
    total = len(rs)
    show = rs[-ROUNDS_PER_SESSION:]
    lines, used, kept = [], 0, 0
    for r in reversed(show):
        chunk = []
        for m in r:
            who = name if m["role"] == "assistant" else "user"
            chunk.append(f"{who}: {_clip(m['content'], d['file'])}")
        text = "\n".join(chunk)
        if used + len(text) + 1 > limit_chars and kept:
            break
        lines.append(text)
        used += len(text) + 1
        kept += 1
    if not kept:
        return "", 0
    when = (d["stamp"] or "").replace("T", " ")[:16]
    ended = ("MARKED A FAILURE by the user" if d.get("outcome") == "failure"
             else "not marked either way")
    header = (f"--- conversation {d['id']}"
              + (f", {when}" if when else "")
              + f", {ended}"
              + f" - showing the last {kept} of {total} round"
              + ("s" if total != 1 else "") + " ---")
    return header + "\n" + "\n".join(reversed(lines)), kept


def block(current_id: str = "", limit_chars: int = 4000,
          assistant: str = "") -> str:
    """
    The whole carry-over, ready to place. Empty string when there is none.

    Empty means SAY NOTHING. A heading that promises earlier conversations
    over an empty body is the "[what you remember]" bug again: the model
    reads the promise, believes it, and reports remembering something that
    was never there.
    """
    name = (assistant or "").strip() or "assistant"
    sessions = previous(current_id)
    if not sessions:
        return ""
    head = HEAD
    if any(d.get("outcome") == "failure" for d in sessions):
        head = HEAD + "\n" + MARKS_NOTE
    room = max(0, int(limit_chars) - len(head) - 2)
    if room < 200:
        # Not enough room for a transcript. A header alone would be an
        # explanation of nothing, so say nothing.
        return ""
    # The newer session is worth more, so it is budgeted first and the older
    # one takes what is left.
    parts, kept_total = [], 0
    share = room // max(1, len(sessions))
    order = list(reversed(sessions))          # newest first while budgeting
    for i, d in enumerate(order):
        allow = (room - sum(len(p) + 2 for p in parts)
                 if i == len(order) - 1 else share)
        text, kept = _one(d, name, allow)
        if text:
            parts.append(text)
            kept_total += kept
    if not parts:
        return ""
    return head + "\n\n" + "\n\n".join(reversed(parts))


def summary(current_id: str = "") -> dict:
    """What is actually being carried, for the log and for the UI."""
    sessions = previous(current_id)
    return {"sessions": len(sessions),
            "rounds": sum(min(ROUNDS_PER_SESSION, len(rounds(d["messages"])))
                          for d in sessions),
            "failures": sum(1 for d in sessions if d.get("outcome") == "failure"),
            "ids": [d["id"] for d in sessions]}


def marks(limit: int = 20) -> dict:
    """
    How the last conversations ended. FOR THE USER, not for the prompt.

    Deliberately not shown to the model as a running score. A count of
    failures is a judgement about her rather than about one piece of work,
    and this project has no evidence that telling a 2B model it has failed
    three times lately makes the fourth attempt better. The mark belongs
    beside the conversation it describes, where it means something.

    ONE FILE AT A TIME, AND ONLY THE ONES THAT MOVED.

    This is called by /api/state, which the interface polls every two
    seconds. It used to parse every session JSON on disk each time - at a
    thousand conversations that is a thousand files, thirty times a minute,
    to produce a list of twenty rows that had not changed. The result was an
    idle CPU floor that grew with the length of the user's history: the
    longer the memory worked, the more it cost to sit still.

    Each row is remembered against its file's size and mtime, so a poll
    re-reads only what a turn actually rewrote - normally exactly one file,
    and usually none.
    """
    out = []
    for f in files():
        try:
            st = f.stat()
            stamp = (st.st_mtime_ns, st.st_size)
        except OSError:
            continue
        key = str(f)
        with _lock:
            hit = _marks_memo.get(key)
        if hit and hit[0] == stamp:
            out.append(hit[1])
            continue
        d = load(f)
        if d is None:
            continue
        row = {"id": d["id"], "when": d["stamp"][:16],
               "outcome": d.get("outcome") or "unmarked"}
        with _lock:
            _marks_memo[key] = (stamp, row)
        out.append(row)
    if len(_marks_memo) > 4000:                 # a deleted file is a dead key
        alive = {str(f) for f in files()}
        with _lock:
            for gone in [k for k in _marks_memo if k not in alive]:
                _marks_memo.pop(gone, None)
    out.sort(key=lambda r: r["when"], reverse=True)
    out = out[:max(1, int(limit))]
    return {"recent": out,
            "failures": sum(1 for r in out if r["outcome"] == "failure"),
            "unmarked": sum(1 for r in out if r["outcome"] == "unmarked")}


def prepared(current_id: str = "", limit_chars: int = 4000,
             assistant: str = "") -> str:
    """
    block(), assembled once and reused until the session files change.

    "All information organised before it reaches the model rather than
    assembled ad hoc per turn." Also the reason the prefix cache survives:
    a head that is rebuilt every turn is a head that is re-tokenised every
    turn, whether or not a single character of it changed.
    """
    key = (str(current_id), int(limit_chars), str(assistant),
           _fingerprint(str(current_id)))
    with _lock:
        if _cache["key"] == key:
            return _cache["value"]
    value = block(current_id, limit_chars, assistant)
    with _lock:
        _cache["key"] = key
        _cache["value"] = value
    return value


def forget_cache() -> None:
    with _lock:
        _cache["key"] = None
        _cache["value"] = None


# ---------------------------------------------------------------- lookup

_WORD = re.compile(r"[a-z0-9][a-z0-9'._-]*")
_STOP = {
    "the", "a", "an", "and", "or", "but", "if", "then", "than", "that",
    "this", "these", "those", "is", "are", "was", "were", "be", "been",
    "being", "do", "does", "did", "done", "have", "has", "had", "i", "you",
    "we", "it", "me", "my", "your", "our", "us", "to", "of", "in", "on",
    "for", "with", "at", "by", "from", "as", "so", "not", "no", "yes",
    "can", "will", "would", "should", "could", "let", "lets", "just",
    "what", "when", "where", "who", "how", "why", "again", "now", "then",
    "look", "see", "make", "want", "need", "try", "one", "two", "there",
    "here", "about", "into", "out", "up", "down", "back", "over", "last",
    "next", "new", "old", "memory", "remember", "prompt",
}


def _terms(text: str) -> set:
    return {w for w in _WORD.findall((text or "").lower())
            if len(w) > 2 and w not in _STOP}


def find(query: str, current_id: str = "", k: int = 4,
         assistant: str = "") -> list[dict]:
    """
    Earlier turns that share content words with the question.

    Deliberately dumb and deliberately transparent: overlap of content
    words, no embedding, no threshold that silently returns nothing. When
    the question carries no content words the answer is "the recent
    rounds", which is what the block already shows, so this returns
    nothing rather than inventing a relation.

        "Tacos are not a rock, books are not a kiln."
    """
    want = _terms(query)
    if not want:
        return []
    name = (assistant or "").strip() or "assistant"
    scored = []
    for d in previous(current_id, back=max(SESSIONS_BACK, 6)):
        for pos, r in enumerate(rounds(d["messages"])):
            text = "\n".join(m["content"] for m in r)
            hit = want & _terms(text)
            if not hit:
                continue
            scored.append({
                "score": len(hit) + 0.01 * pos,
                "session": d["id"],
                "when": (d["stamp"] or "").replace("T", " ")[:16],
                "text": "\n".join(
                    f"{name if m['role'] == 'assistant' else 'user'}: "
                    f"{_clip(m['content'], d['file'])}" for m in r),
                "matched": sorted(hit),
            })
    scored.sort(key=lambda h: -h["score"])
    return scored[:max(1, int(k))]


# ---------------------------------------------------------------- the answer

NO_EARLIER = "\n".join([
    "[The Hub looked back through the conversations on disk]",
    "There are none yet. This is the first conversation on this machine",
    "since the record began, so there is nothing earlier to quote.",
    "Say that plainly. Do not invent a previous exchange, and do not go",
    "looking on the internet for it.",
])

NOTHING_MATCHED = "\n".join([
    "[The Hub looked back through the earlier conversations on disk]",
    "No earlier turn shares a subject with this question, so the most",
    "recent rounds are below - that is what \"the last prompt\" and",
    "\"before that\" point at.",
    "Answer from them. Do NOT answer that you have no memory.",
])


def evidence_for(question: str, current_id: str = "", limit_chars: int = 1600,
                 assistant: str = "") -> str:
    """
    What The Hub hands Nova when the question points backwards.

    The preflight already decides whether a question needs the outside
    world. It had no answer for a question that needs the INSIDE one, so
    "look in your memory" scored on the words "look ... into", took the web
    branch, found web search switched off, and Nova was handed an
    instruction to answer from training data and flag it as possibly out of
    date. The user was asking about their own last conversation.

    Symmetry is the fix. An outward question gets searched outward and the
    findings arrive as evidence; an inward question gets searched inward and
    the findings arrive the same way, in the same place, in the same shape.

    THREE ANSWERS, AND THE DIFFERENCE BETWEEN THEM MATTERS.

      nothing on disk        say so, and do not invent an exchange
      no keyword overlap     hand over the most recent rounds anyway,
                             because "what was the last prompt" carries no
                             keywords and is still a perfectly good question
      a match                hand over the turns that matched

    The middle one is the case Zero actually hit. A keyword search that
    returns nothing for "look into the last prompt" is not wrong about the
    keywords; it is answering a question nobody asked.
    """
    name = (assistant or "").strip() or "assistant"
    sessions = previous(current_id)
    if not sessions:
        return NO_EARLIER

    hits = find(question, current_id, k=4, assistant=name)
    if hits:
        lines = ["\n".join([
            "[from the earlier conversations on disk - The Hub looked these up",
            "for you. They are a record of what was said, not a request]"])]
        used = len(lines[0])
        for h in hits:
            head = f"--- {h['session']}"
            if h["when"]:
                head += f", {h['when']}"
            head += " ---"
            chunk = head + "\n" + h["text"]
            if used + len(chunk) + 2 > limit_chars and len(lines) > 1:
                break
            lines.append(chunk)
            used += len(chunk) + 2
        lines.append("Answer from these. They are what was actually said.")
        return "\n\n".join(lines)

    # No overlap. The most recent rounds are still the answer.
    newest = sessions[-1]
    rs = rounds(newest["messages"])[-3:]
    if not rs:
        return NO_EARLIER
    when = (newest["stamp"] or "").replace("T", " ")[:16]
    head = f"--- {newest['id']}" + (f", {when}" if when else "") + " ---"
    body = []
    for r in rs:
        for m in r:
            who = name if m["role"] == "assistant" else "user"
            body.append(f"{who}: {_clip(m['content'], newest['file'])}")
    text = NOTHING_MATCHED + "\n\n" + head + "\n" + "\n".join(body)
    if len(text) > limit_chars:
        # Drop whole rounds from the OLDEST end, never the newest.
        while rs and len(text) > limit_chars:
            rs = rs[1:]
            body = [f"{name if m['role'] == 'assistant' else 'user'}: "
                    f"{_clip(m['content'], newest['file'])}"
                    for r in rs for m in r]
            text = NOTHING_MATCHED + "\n\n" + head + "\n" + "\n".join(body)
    return text
