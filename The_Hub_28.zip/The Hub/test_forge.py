"""
test_forge.py - on-device generation: ordering, exclusivity, and honesty.

WHAT THIS GUARDS

Before forge.py, generate_image / generate_video / generate_3d all ended in
"no supported local image generator is currently reachable on this machine",
because every one of them required ComfyUI or Automatic1111 to be installed
AND running. Three headline capabilities, three ways of saying no.

The rules that replaced that, and which are checked here:

  * one generator at a time - the machine has 4 GB of VRAM and Nova is in it
  * Nova is stopped for the WHOLE pipeline and restarted once, not stopped
    and restarted between each step of it
  * Nova comes back even when a generator fails
  * 3D always produces something real, because the built-in geometry path
    needs no binary and no weights
  * a backend that cannot run says why, in words that name the fix

A stub binary stands in for sd-cli and trellis, so the wiring, the ordering
and the argument construction are all exercised without a 19 GB download.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import threading
import time
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

C = {"g": "\033[92m", "r": "\033[91m", "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0}


def check(label, cond, detail=""):
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


TMP = Path(tempfile.mkdtemp(prefix="hub-forge-"))
import core                                                       # noqa: E402
core.DATA = TMP / "data"
core.LOGS = core.DATA / "logs"
core.EVENTS = core.DATA / "events"
core.WRITABLE = (core.DATA, core.LOGS, core.EVENTS)
core.CONFIG = TMP / "config.json"
core.DATA.mkdir(parents=True, exist_ok=True)
core.LOGS.mkdir(parents=True, exist_ok=True)
core.EVENTS.mkdir(parents=True, exist_ok=True)

import events, playground, runtime, forge, meshgen, model3d       # noqa: E402
events.LOG = core.EVENTS / "events.jsonl"
playground.ROOT = core.DATA / "playground"
playground.ensure()

forge.GEN = TMP / "gen"
forge.SD_DIR = forge.GEN / "sd"
forge.TRELLIS_DIR = forge.GEN / "trellis"
forge.MODELS = forge.GEN / "models"
forge.TRELLIS_MODELS = forge.GEN / "trellis-models"
forge._STATE_FILE = core.DATA / "forge_state.json"


# ---------------------------------------------------------------- the stub

STUB = TMP / "stub_generator.py"
STUB.write_text(
    "import sys, struct, zlib, binascii, pathlib\n"
    "a = sys.argv[1:]\n"
    "out = None\n"
    "for i, v in enumerate(a):\n"
    "    if v in ('-o', '--output') and i + 1 < len(a):\n"
    "        out = pathlib.Path(a[i + 1])\n"
    "import os\n"
    "(pathlib.Path(os.environ.get('STUB_LOG', 'last_argv.txt'))).write_text(' '.join(a))\n"
    "if out is None:\n"
    "    sys.exit(3)\n"
    "out.parent.mkdir(parents=True, exist_ok=True)\n"
    "if out.suffix.lower() in ('.png', '.jpg', '.jpeg'):\n"
    "    w = h = 32\n"
    "    row = bytearray()\n"
    "    for x in range(w):\n"
    "        row += bytes(((x * 8) % 256, 60, 120))\n"
    "    raw = b''.join(b'\\x00' + bytes(row) for _ in range(h))\n"
    "    def chunk(tag, data):\n"
    "        return (struct.pack('>I', len(data)) + tag + data +\n"
    "                struct.pack('>I', binascii.crc32(tag + data) & 0xffffffff))\n"
    "    out.write_bytes(b'\\x89PNG\\r\\n\\x1a\\n'\n"
    "                    + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))\n"
    "                    + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b''))\n"
    "else:\n"
    "    out.write_bytes(b'STUBGEN' + b'\\0' * 64)\n"
    "sys.exit(0)\n", encoding="utf-8")


def install_stub(name: str, folder: Path):
    folder.mkdir(parents=True, exist_ok=True)
    launcher = folder / (name + (".cmd" if os.name == "nt" else ""))
    if os.name == "nt":
        launcher.write_text(f'@echo off\n"{sys.executable}" "{STUB}" %*\n')
    else:
        launcher.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{STUB}" "$@"\n')
        launcher.chmod(0o755)
    return launcher


# runtime is stubbed: nothing may actually launch llama-server here
_calls = {"stop": 0, "start": 0, "order": []}
runtime.state = lambda: {"status": "ready", "model": "stub.gguf"}
def _stop():
    _calls["stop"] += 1
    _calls["order"].append("stop-nova")
def _start(model, cfg):
    _calls["start"] += 1
    _calls["order"].append("start-nova")
    return {"ok": True}
runtime.stop = _stop
runtime.start = _start


def main() -> int:
    os.environ["STUB_LOG"] = str(TMP / "last_argv.txt")
    print("\n1. WITH NOTHING INSTALLED, IT SAYS WHAT IS MISSING AND HOW TO FIX IT")
    a = forge.available()
    check("image is not ready and the reason names INSTALL.bat",
          not a["image"]["ready"] and "INSTALL.bat" in a["image"]["why"],
          a["image"]["why"])
    check("video is not ready and says so", not a["video"]["ready"])
    check("neural 3D is not ready and says so", not a["model3d"]["ready"])
    check("the built-in mesh path is ALWAYS ready", a["mesh"]["ready"],
          "this is what stops 3D generation ever being simply unavailable")
    r = forge.report()
    check("the report names every backend", all(
        k in r for k in ("images", "video", "TRELLIS", "built-in")))

    print("\n2. THE BUILT-IN 3D PATH WORKS WITH NO BINARY AND NO WEIGHTS")
    tris = meshgen.build({"parts": [{"shape": "box", "size": [40, 30, 3],
                                     "holes": [{"at": [8, 8], "d": 4}]}]})
    check("a spec builds a closed solid", meshgen.is_closed(tris) == 0,
          f"{len(tris)} triangles")

    print("\n3. ONE GENERATOR AT A TIME")
    install_stub("sd-cli", forge.SD_DIR)
    forge.MODELS.mkdir(parents=True, exist_ok=True)
    (forge.MODELS / "sd-v1-5.q8_0.gguf").write_bytes(b"0" * 2048)
    check("an installed runtime and checkpoint make image generation ready",
          forge.available()["image"]["ready"])

    held = threading.Event()
    released = threading.Event()
    second = {"acquired": None}

    def hold():
        with forge.Session("first") as s:
            held.set()
            released.wait(5)

    t = threading.Thread(target=hold, daemon=True)
    t.start()
    held.wait(5)
    with forge.Session("second", wait=0.2) as s2:
        second["acquired"] = s2.ok
    check("a second Session cannot start while one is running",
          second["acquired"] is False,
          "this is the whole VRAM rule - two generators would not fit")
    released.set()
    t.join(5)
    with forge.Session("third", wait=1.0) as s3:
        check("and it can start once the first finishes", s3.ok)

    print("\n4. NOVA IS STOPPED ONCE FOR A WHOLE PIPELINE, NOT PER STEP")
    _calls["stop"] = _calls["start"] = 0
    _calls["order"] = []
    with forge.Session("pipeline") as s:
        img = s.image(prompt="a dragon", filename="a.png")
        img2 = s.image(prompt="a dragon again", filename="b.png")
    check("two generations, one stop and one start",
          _calls["stop"] == 1 and _calls["start"] == 1,
          f"stop x{_calls['stop']}, start x{_calls['start']}")
    check("and in that order", _calls["order"] == ["stop-nova", "start-nova"],
          str(_calls["order"]))
    check("both images were produced", img.is_file() and img2.is_file(),
          f"{img.name}, {img2.name}")
    check("they landed in the Playground, never the Vault",
          img.parent == playground.ROOT)
    check("each has a manifest saying what made it",
          (img.parent / (img.stem + ".generation.json")).is_file())

    print("\n5. THE SESSION DOES NOT RETURN UNTIL NOVA IS SERVING AGAIN")
    #
    # THE BUG THIS REPRODUCES. runtime.start() spawns the process and returns
    # immediately; loading, warming, the vision probe and the benchmark all
    # run on a background thread. So a Session used to hand control back with
    # llama-server still coming up, and the chat turn that CALLED the
    # generator posted straight into it:
    #
    #     generate_image  ->  created Playground/generated.png
    #     tools unavailable for this reply
    #     Error: HTTP Error 503: Service Unavailable
    #
    # The image was generated perfectly. The turn died because the model
    # needed to describe it was still loading.
    phase = {"status": "stopped", "started_at": 0.0}
    runtime.state = lambda: {
        "status": ("ready" if phase["status"] == "starting"
                   and time.time() - phase["started_at"] > 1.2
                   else phase["status"]),
        "model": "stub.gguf"}

    def _slow_start(model, cfg):
        phase["status"] = "starting"
        phase["started_at"] = time.time()
        return {"ok": True}

    runtime.start = _slow_start
    phase["status"] = "ready"

    t0 = time.time()
    with forge.Session("slow restart") as s:
        s.image(prompt="a dragon", filename="slow.png")
    elapsed = time.time() - t0
    check("the Session waits for the model to finish loading",
          elapsed >= 1.2,
          f"returned after {elapsed:.1f}s - it must not return while the "
          f"model is still coming up")
    check("and it reports that Nova was restored", s.restored is True)
    check("the status really is ready when it returns",
          runtime.state()["status"] == "ready")

    # And when the model never comes back, that is reported rather than
    # pretended away.
    forge.RESTORE_DEADLINE = 1.0
    runtime.state = lambda: {"status": "starting", "model": "stub.gguf"}
    with forge.Session("never comes back") as s2:
        s2.image(prompt="x", filename="nb.png")
    check("a model that never returns is reported, not assumed",
          s2.restored is False)
    forge.RESTORE_DEADLINE = 320.0
    runtime.state = lambda: {"status": "ready", "model": "stub.gguf"}
    runtime.start = _start

    print("\n6. A 503 MID-TURN IS WAITED OUT, NOT TURNED INTO A FAILED REPLY")
    import urllib.error, urllib.request
    calls = {"n": 0}
    real_urlopen = urllib.request.urlopen

    def flaky(req, timeout=None):
        calls["n"] += 1
        if calls["n"] <= 2:
            raise urllib.error.HTTPError(
                "http://x/", 503, "Service Unavailable", {}, None)
        class R:
            def read(self_inner): return b'{"ok": true}'
            def close(self_inner): pass
        return R()

    urllib.request.urlopen = flaky
    real_grace = runtime.RELOAD_GRACE
    runtime.RELOAD_GRACE = 20.0
    try:
        r = runtime.post("http://127.0.0.1:1/", "/v1/chat/completions", {})
        check("post() rides out a loading model instead of raising",
              r.read() == b'{"ok": true}', f"{calls['n']} attempt(s)")
    except Exception as e:
        check("post() rides out a loading model instead of raising", False,
              f"{type(e).__name__}: {e}")

    calls["n"] = 0
    runtime.RELOAD_GRACE = 0.0
    try:
        runtime.post("http://127.0.0.1:1/", "/v1/chat/completions", {})
        check("but a 503 past the deadline is still a real error", False,
              "it swallowed it")
    except urllib.error.HTTPError as e:
        check("but a 503 past the deadline is still a real error",
              e.code == 503)
    urllib.request.urlopen = real_urlopen
    runtime.RELOAD_GRACE = real_grace

    print("\n7. NOVA COMES BACK EVEN WHEN A GENERATOR FAILS")
    _calls["stop"] = _calls["start"] = 0
    try:
        with forge.Session("failing") as s:
            s.image(prompt="x", model="a-model-that-does-not-exist",
                    filename="never.png")
    except Exception:
        pass
    check("Nova was restarted after the failure", _calls["start"] == 1,
          f"stop x{_calls['stop']}, start x{_calls['start']}")

    print("\n8. THE ARGUMENTS ARE THE ONES THE 4 GB CARD NEEDS")
    argv = Path(os.environ["STUB_LOG"]).read_text()
    for flag, why in (("--vae-tiling", "decodes the VAE in tiles"),
                      ("--offload-to-cpu", "keeps weights in RAM until needed"),
                      ("--diffusion-fa", "flash attention"),
                      ("-M", "explicit mode selection")):
        check(f"{flag} is passed ({why})", flag in argv)
    check("img_gen mode for an image", "img_gen" in argv)

    print("\n9. A FAILURE EXPLAINS ITSELF IN WORDS SOMEBODY CAN ACT ON")
    # AND SAYS WHAT HAPPENED, NOT WHAT IS POSSIBLE.
    #
    # This used to assert the words "does not fit on this card" - a claim
    # about the future, made on the evidence of one run at one size. Nova
    # read it back to the user as a permanent limit and refused to try again
    # after the cause had been fixed. The test was holding the wording in
    # place, so it is corrected here to assert the property that actually
    # matters: the sentence describes the run and offers a way forward, and
    # it never says the machine cannot do the thing.
    oom = forge._explain("ggml_cuda: CUDA error: out of memory")
    check("out of memory is translated",
          "video memory" in oom.lower(), oom)
    check("and it says what to try next rather than closing the door",
          any(w in oom.lower() for w in ("smaller", "fewer")), oom)
    check("it makes no claim about what this machine can never do",
          not any(w in oom.lower() for w in
                  ("does not fit", "cannot", "impossible", "unable")), oom)
    check("a missing file is translated",
          "missing" in forge._explain("failed to open model: No such file"))
    check("the last outcome of a backend is remembered",
          isinstance(forge.last_outcome("image"), dict)
          and "ok" in forge.last_outcome("image"))

    print("\n10. VIDEO REFUSES CLEARLY WHEN ITS THREE FILES ARE NOT ALL THERE")
    with forge.Session("video") as s:
        try:
            s.video(prompt="x", filename="v.mp4")
            check("video without its parts is refused", False, "it proceeded")
        except RuntimeError as e:
            check("video without its parts names what is missing",
                  "missing" in str(e).lower(), str(e)[:130])

    shutil.rmtree(TMP, ignore_errors=True)
    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
