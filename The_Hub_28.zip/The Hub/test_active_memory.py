import json
import tempfile
from pathlib import Path

import memory


def test_active_memory_moves_and_is_external(tmp_path):
    old_dir, old_log, old_state = memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE
    memory.ACTIVE_DIR = tmp_path / "active"
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"
    try:
        a = memory.active_move("top.stl convert to obj", kind="user_turn")
        assert a["weight"] == 1.0
        packet = memory.active_context("top.stl convert", 200)
        assert "top.stl" in packet
        assert memory.ACTIVE_LOG.exists() and memory.ACTIVE_STATE.exists()
    finally:
        memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE = old_dir, old_log, old_state


def test_no_second_language_model_in_memory_loop():
    """
    The invariant is ONE language model, not "no consolidation".

    This asserted `"run_curator(" not in loop`, which is a different claim
    and a wrong one: it made the memory loop's own consolidation step a test
    failure, so the loop was cut down to promotion plus decay and
    consolidate.py stopped being reachable at all - installed, imported,
    tested, never run.

    run_curator() consolidates through consolidate.Session, and
    Session.ask() posts to runtime.MAIN - the model that is already loaded,
    in an idle gap, under a lock that chat can take back. No second process,
    no second port, no second set of weights. That is what needs guarding,
    so that is what is asserted.
    """
    text = Path("memory.py").read_text(encoding="utf-8")
    loop = text[text.find("def loop(stop_evt"):text.find("def _has_expired_sessions")]
    assert "Curator(" not in loop, "no separate curator model object"
    assert "runtime.start(" not in loop, "the memory loop must not launch a model"
    assert "CURATOR_PORT" not in loop, "no second server for memory work"

    consolidate_src = Path("consolidate.py").read_text(encoding="utf-8")
    assert "runtime.MAIN" in consolidate_src, \
        "consolidation must run on the already-loaded main model"
    assert "runtime.CUR" not in consolidate_src, \
        "consolidation must not address a second model server"


def test_memory_loop_still_consolidates():
    """The loop that never consolidates is the bug this project already had."""
    text = Path("memory.py").read_text(encoding="utf-8")
    loop = text[text.find("def loop(stop_evt"):text.find("def _has_expired_sessions")]
    for fn in ("run_curator(", "roll_up(", "relieve("):
        assert fn in loop, f"memory loop no longer calls {fn} - memory would grow forever"
    assert "idle_for()" in loop, "consolidation must wait for an idle machine"
    assert "intake.promote()" in loop, "candidates must still be promoted"

def test_an_unrelated_question_gets_no_frontier_at_all(tmp_path):
    """
    THE GOKU BUG. The score was weight * (0.55 + 0.45 * overlap) against a
    threshold of 0.16, so an entry with ZERO overlap scored 0.55 - three
    times the bar. Relevance was in the formula and did nothing: every recent
    turn was injected into every question, across sessions, because the
    frontier lives on disk. Ask about the capital of France after generating
    a picture and the model was handed "Goku in super Saiyan form 2".
    """
    old = memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE
    memory.ACTIVE_DIR = tmp_path / 'active'
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / 'flow.jsonl'
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / 'state.json'
    try:
        memory.active_move('Goku in super Saiyan form 2', kind='user_turn')
        memory.active_move('a girl on a swing at sunset in hawaii',
                           kind='user_turn')
        for unrelated in ('what is the capital of France',
                          'how do I fix the memory purge button',
                          'write me a python script to rename files'):
            packet = memory.active_context(unrelated, 400).lower()
            assert 'goku' not in packet, f'{unrelated!r} pulled in Goku'
            assert 'swing' not in packet, f'{unrelated!r} pulled in the swing'
    finally:
        memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE = old


def test_a_related_question_still_gets_the_frontier(tmp_path):
    """The fix must not cost the frontier its actual job."""
    old = memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE
    memory.ACTIVE_DIR = tmp_path / 'active'
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / 'flow.jsonl'
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / 'state.json'
    try:
        memory.active_move('Goku in super Saiyan form 2', kind='user_turn')
        memory.active_move('a girl on a swing at sunset in hawaii',
                           kind='user_turn')
        assert 'goku' in memory.active_context('make goku bigger', 400).lower()
        assert 'swing' in memory.active_context(
            'change the swing picture', 400).lower()
    finally:
        memory.ACTIVE_DIR, memory.ACTIVE_LOG, memory.ACTIVE_STATE = old


if __name__ == "__main__":
    import sys, testkit
    sys.exit(testkit.run(dict(globals()), "ACTIVE MEMORY - the moving frontier is external state"))
