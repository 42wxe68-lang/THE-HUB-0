"""
forge.py - on-device generation. One generator at a time, in a sensible order.

THE PROBLEM THIS SOLVES

Before this module, generate_image / generate_video / generate_3d all ended in
the same sentence:

    no supported local image generator is currently reachable on this machine

because every one of them required ComfyUI or Automatic1111 to already be
installed and running. On a machine with neither, the three headline
capabilities were three different ways of saying no.

WHAT REPLACED IT

Generation now ships with The Hub, the same way llama.cpp does: pinned
binaries and pinned weights, downloaded by INSTALL.bat, run as a subprocess.

    images   sd-cli  (stable-diffusion.cpp)   -M img_gen
    video    sd-cli  (stable-diffusion.cpp)   -M vid_gen
    3D       trellis (trellis.cpp)            image -> textured GLB
    3D       meshgen (built in)               always available, no download

stable-diffusion.cpp and trellis.cpp are both ggml projects - the same family
as llama.cpp, the same GGUF weights, the same kind of prebuilt Windows binary.
Nothing here needs pip, a Python package, or a server the user has to start.

THE VRAM RULE, AND WHY ORDER MATTERS

This machine has 4 GB of VRAM and Nova is already in it. Every generator here
wants most of a card to itself, so:

    one generator at a time, and Nova is not running while one works.

That is a single lock, not a lock per step. A request like "make me a 3D model
of a dragon" is really three model loads - text to image, image to 3D, then
Nova again to look at the result - and stopping and restarting Nova between
each of them would cost more time than the generation. So a Session stops Nova
once, runs the whole pipeline, and brings Nova back once at the end:

    acquire  ->  stop Nova  ->  sd-cli  ->  trellis  ->  start Nova  ->  release

Nova comes back even if a step raised, and the lock is released even if the
restart fails.

HONESTY ABOUT WHAT THIS MACHINE CAN DO

A GTX 1650 runs SD1.5 comfortably, Wan 1.3B slowly, and a 4B TRELLIS badly or
not at all. So a backend is not "supported" because it is installed - it is
supported when it has actually run here. Every backend records its last
outcome, and `report()` says what is installed, what has run, and what failed
and why. `generate_3d` falls back to the built-in mesh path rather than
failing, so that capability always produces something real.

MODELS ARE DISCOVERED, NOT WHITELISTED

Like llm/models, the generator model folders are scanned. Anything the user
drops in is selectable; the pinned downloads are only the defaults that make a
fresh install work. There is no allow-list and no output filter.
"""
from __future__ import annotations

import collections
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import core
import events
import playground
import runtime

# ---------------------------------------------------------------- layout

GEN = core.ROOT / "llm" / "gen"
SD_DIR = GEN / "sd"                    # stable-diffusion.cpp binaries
TRELLIS_DIR = GEN / "trellis"          # trellis.cpp binaries
MODELS = GEN / "models"                # image / video weights
TRELLIS_MODELS = GEN / "trellis-models"

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
VIDEO_EXTS = {".mp4", ".webm", ".mov", ".mkv", ".gif"}
MESH_EXTS = {".glb", ".gltf", ".obj", ".stl", ".ply", ".3mf"}


def _exe(folder: Path, *names) -> Path | None:
    """
    Find a generator's executable inside its folder, at any depth.

    Three ways, in order of confidence, because these are third-party
    archives whose internal layout is not ours to pin:

      1. BINARY.txt, written by the installer when it found one. The
         installer has already looked; this is it telling us what it saw.
      2. One of the expected names.
      3. Any sizeable executable whose name shares a word with them.

    Requiring an exact guessed name is what made a 693 MB trellis download
    that arrived and extracted perfectly report as "did not install".
    """
    if not folder.is_dir():
        return None

    marker = folder / "BINARY.txt"
    if marker.is_file():
        try:
            named = marker.read_text(encoding="utf-8").strip()
            if named:
                hit = next((q for q in folder.rglob(named) if q.is_file()), None)
                if hit:
                    return hit
        except OSError:
            pass

    wanted = set()
    for n in names:
        wanted.add(n.lower())
        wanted.add(n.lower() + ".exe")
    try:
        files = [q for q in folder.rglob("*") if q.is_file()]
    except OSError:
        return None
    for q in files:
        if q.name.lower() in wanted:
            return q

    stems = {n.lower().split("-")[0] for n in names}
    cands = [q for q in files
             if q.suffix.lower() in (".exe", "")
             and q.stat().st_size > 100_000
             and any(s in q.name.lower() for s in stems)]
    if cands:
        return max(cands, key=lambda q: q.stat().st_size)
    return None


def sd_exe() -> Path | None:
    return _exe(SD_DIR, "sd-cli", "sd", "stable-diffusion")


# THE ONE DEFINITION OF "TRELLIS IS INSTALLED".
#
# There used to be two, and they disagreed.
#
# install.py's _find_binary() ends with an inspection fallback - "any .exe
# over 100 KB whose name contains 'trellis', largest wins" - which exists so
# a runtime shipping under an unexpected name is still found. It picked
# trellis-server.exe, reported the 3D generator READY, and skipped the
# download.
#
# forge's rule rejects any name containing "server", because running the
# HTTP service as a command-line tool broke 3D outright.
#
# Both rules are right on their own. Together they hid a missing file: the
# installer saw a binary and downloaded nothing, the runtime saw nothing and
# fell back to embossing the picture onto an 8 mm slab, and the install log
# said "3D (TRELLIS) ready" while every 3D request produced a plaque.
#
# So there is one function now, here, and install.py imports it. A single
# definition cannot disagree with itself.
CLI_NAMES = ("trellis-cli", "trellis2-cli", "trellis-cpp", "trellis2")


def trellis_exe() -> Path | None:
    """The trellis COMMAND-LINE tool. Never the HTTP server."""
    for name in CLI_NAMES:
        hit = _exe(TRELLIS_DIR, name)
        if hit and "server" not in hit.name.lower():
            return hit
    hit = _exe(TRELLIS_DIR, "trellis")
    if hit and "server" not in hit.name.lower():
        return hit
    return None


def trellis_server_exe() -> Path | None:
    """
    The HTTP service - which turns out to be the ONLY thing that ships.

    Every prebuilt Windows archive for v0.4.3 contains trellis-server.exe and
    no CLI at all. The 693 MB CUDA download extracts to exactly one
    executable. So the previous two rounds of work here were both wrong in
    the same way: the first ran the server as if it were a CLI and passed it
    flags it does not understand; the second refused the server and waited
    for a trellis-cli.exe that the release does not contain and never did.
    The installer downloaded the right file both times.

    The server is not a workaround. It is the interface: it holds the weights
    resident instead of paying GPU initialisation per request, which is the
    reason it exists. It is started for one mesh and stopped again, exactly
    like every other generator here.
    """
    return _exe(TRELLIS_DIR, "trellis-server")


def trellis_backend() -> tuple:
    """
    How image-to-3D can run right now: ("cli"|"server"|"", path_or_None).

    ONE definition, shared with install.py, and it accepts either shape of
    the program. A CLI is preferred if a build ever provides one; the server
    is what is actually on disk.
    """
    cli = trellis_exe()
    if cli is not None:
        return ("cli", cli)
    srv = trellis_server_exe()
    if srv is not None:
        return ("server", srv)
    return ("", None)


class TrellisService:
    """
    trellis-server, up for one request and down again.

        trellis-server --models DIR --port N
        GET  /health    -> "ok"
        POST /generate  -> multipart: image=<file>, and optional text
                           fields seed, resolution (512|1024|1536),
                           bg_removal (threshold|birefnet)
                        -> model/gltf-binary

    Started inside a forge Session, so Nova is already stopped and the card
    is free. Stopped in a finally, because a 693 MB process left running
    would hold the VRAM that Nova needs to come back into.
    """

    def __init__(self, exe: Path, models: Path, port: int | None = None):
        self.exe = Path(exe)
        self.models = Path(models)
        self.port = int(port or core.TRELLIS_PORT)
        self.proc = None
        self.reader = None
        self.borrowed = False        # someone else's server; do not stop it
        self.guard = None
        # 400 lines was sized for a run that fails fast. A 3D run on the
        # CPU path prints once a flow step for three hours and then dies at
        # the end, and the lines that explain WHY are at the end - but so is
        # everything else, and 400 threw away the load and setup messages
        # that say what it was configured to do.
        self.log = collections.deque(maxlen=5000)

    @property
    def base(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    # WHAT THE SERVER SAID, KEPT WHERE IT CAN BE READ.
    #
    # Every 3D failure for weeks came back as one of two sentences - "exited
    # while starting" or "did not answer /health" - with nothing behind
    # them, because the only place the server's own words went was a pipe
    # nobody read. And an unread pipe is not merely uninformative:
    #
    #     stdout=PIPE with no reader is a DEADLOCK, not a silence.
    #
    # A pipe buffer is small (64 KB on Windows, often 4 KB in practice).
    # trellis-server loads six GGUFs and narrates it. Once the buffer fills,
    # the next write blocks, and a process blocked in write() never gets as
    # far as binding a socket. /health is then never going to answer, the
    # 300-second deadline runs out in full, and the message says the server
    # did not respond - which is true, and blames the wrong thing entirely.
    #
    # So the pipe is drained continuously on a daemon thread into a bounded
    # ring. It can never fill, and whatever the server said is available at
    # the moment it is needed.
    def _drain(self) -> None:
        try:
            pending = ""
            while True:
                chunk = self.proc.stdout.read(2048)
                if not chunk:
                    break
                pending += chunk.decode("utf-8", "replace")
                parts = re.split(r"[\r\n]", pending)
                pending = parts.pop()
                for line in parts:
                    if line.strip():
                        self.log.append(line)
                        _progress_line(line)
            if pending.strip():
                self.log.append(pending)
                _progress_line(pending)
        except Exception:
            pass

    def said(self, limit: int = 900) -> str:
        """The last thing the server actually printed, for an error message."""
        text = "\n".join(self.log)
        if not text.strip():
            return "(it printed nothing at all)"
        return text[-limit:]

    def start(self, deadline: float = 0.0) -> None:
        """
        Bring the server up and wait for it to answer.

        NO DEADLINE BY DEFAULT. Loading six GGUFs through system RAM on a
        card that cannot hold them is slow, and 300 seconds was a guess that
        turned a slow start into "did not answer /health" - which the user
        read as a timeout and which was, on this machine, simply impatience.
        The wait ends when the server answers or when it exits. `deadline`
        is honoured when a caller passes one, which is what the tests use.
        """
        # SOMETHING IS ALREADY ON THE PORT.
        #
        # A previous run that was killed rather than stopped leaves a
        # resident server holding both 8103 and the card. Starting a second
        # one produces "address in use" deep in a log nobody reads; asking
        # first turns it into a fact.
        try:
            with urllib.request.urlopen(self.base + "/health", timeout=2) as r:
                if r.status == 200:
                    self.borrowed = True
                    core.log_line("forge",
                                  f"trellis-server already resident on "
                                  f"{self.port}; using it")
                    return
        except Exception:
            pass

        if not self.exe.exists():
            raise RuntimeError(f"{self.exe.name} is not where the installer "
                               f"put it ({self.exe})")
        weights = _scan(self.models, (".gguf",))
        if not weights:
            raise RuntimeError(
                f"no .gguf weights in {self.models} - the 3D models were "
                f"not downloaded, or went to a different folder")

        argv = [str(self.exe), "--models", str(self.models),
                "--port", str(self.port)]
        core.log_line("forge", "trellis-server " + " ".join(argv[1:]))
        try:
            self.proc = subprocess.Popen(
                argv, cwd=str(self.exe.parent),
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                # bufsize=0 MATTERS AND IS NOT A DETAIL.
                #
                # With the default buffering, proc.stdout is a
                # BufferedReader, and BufferedReader.read(n) blocks until it
                # has exactly n bytes or the pipe closes. On a server that
                # stays up, the last partial 2 KB never arrives - so the
                # drain looked like it was lagging when it was really being
                # held by the buffer, and `said()` was missing the newest
                # lines: the only ones that ever matter in an error.
                #
                # bufsize=0 gives a raw reader whose read(n) returns
                # whatever is there now.
                bufsize=0,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError as e:
            raise RuntimeError(
                f"could not run {self.exe.name}: {e}. It is present but the "
                f"system refused to start it - usually a missing runtime DLL "
                f"beside the exe, or the wrong build for this machine.")
        self.reader = threading.Thread(target=self._drain, daemon=True)
        self.reader.start()
        self.guard = _RamGuard(self.proc).start()

        t0 = time.time()
        _progress_start("model3d", "starting the 3D runtime")
        while deadline <= 0 or (time.time() - t0) < deadline:
            if self.proc.poll() is not None:
                time.sleep(0.3)                   # let the drain finish
                raise RuntimeError(
                    f"trellis-server exited after {int(time.time() - t0)}s "
                    f"with code {self.proc.returncode}. "
                    f"It said: {self.said()}")
            try:
                with urllib.request.urlopen(self.base + "/health",
                                            timeout=3) as r:
                    if r.status == 200:
                        core.log_line(
                            "forge",
                            f"trellis-server ready on {self.port} after "
                            f"{int(time.time() - t0)}s")
                        return
            except Exception:
                time.sleep(2.0)
        raise RuntimeError(
            f"trellis-server did not answer /health within {int(deadline)}s "
            f"and is still running. It said: {self.said()}")

    def generate(self, image: Path, out: Path, *, resolution: int = 512,
                 seed: int = -1, bg_removal: str = "birefnet",
                 timeout: int | None = None) -> Path:
        """
        One image in, one mesh out. `timeout=None` means WAIT.

        This was 10,800 seconds, which sounds like generosity and is still a
        guess. A socket read that gives up is indistinguishable to the user
        from a crash, and it was reported as one: "the server log indicates a
        timeout error".
        """
        fields = {"resolution": str(int(resolution)),
                  "bg_removal": str(bg_removal)}
        if int(seed) >= 0:
            fields["seed"] = str(int(seed))
        body, ctype = _multipart(fields, "image", Path(image))
        req = urllib.request.Request(self.base + "/generate", data=body,
                                     headers={"Content-Type": ctype})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
        except urllib.error.HTTPError as e:
            # THE SERVER'S OWN EXPLANATION IS IN THE BODY, and urllib throws
            # it away unless it is asked. "HTTP Error 500" told nobody that
            # it had run out of memory.
            detail = ""
            try:
                detail = (e.read() or b"").decode("utf-8", "replace")[:400]
            except Exception:
                pass
            raise RuntimeError(
                f"trellis-server refused the job: HTTP {e.code}"
                + (f" - {detail.strip()}" if detail.strip() else "")
                + (f". Its log ends: {self.said(400)}" if self.log else ""))
        except urllib.error.URLError as e:
            raise RuntimeError(
                f"lost the connection to trellis-server mid-job ({e.reason}). "
                f"It usually means the process died: {self.said(400)}")
        if not data or len(data) < 1024:
            raise RuntimeError(
                f"trellis-server returned {len(data)} bytes, which is not a "
                f"mesh. Its log ends: {self.said(400)}")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        return out

    def stop(self) -> None:
        g = getattr(self, "guard", None)
        if g is not None:
            g.stop()
        if self.proc is None or self.borrowed:
            return
        try:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=20)
            except Exception:
                self.proc.kill()
        except Exception:
            pass
        self.proc = None

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()
        return False


def _multipart(fields: dict, file_field: str, path: Path) -> tuple:
    """One multipart/form-data body, without pulling in a HTTP library."""
    boundary = "----TheHub" + uuid.uuid4().hex
    nl = b"\r\n"
    parts = []
    for k, v in fields.items():
        parts.append(b"--" + boundary.encode() + nl)
        parts.append(f'Content-Disposition: form-data; name="{k}"'
                     .encode() + nl + nl)
        parts.append(str(v).encode() + nl)
    parts.append(b"--" + boundary.encode() + nl)
    parts.append(
        f'Content-Disposition: form-data; name="{file_field}"; '
        f'filename="{path.name}"'.encode() + nl)
    parts.append(b"Content-Type: application/octet-stream" + nl + nl)
    parts.append(path.read_bytes() + nl)
    parts.append(b"--" + boundary.encode() + b"--" + nl)
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


# ---------------------------------------------------------------- models

def _scan(folder: Path, suffixes=(".gguf", ".safetensors", ".ckpt")) -> list:
    if not folder.is_dir():
        return []
    out = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in suffixes:
            out.append(p)
    return out


def _pick(paths: list, *must_contain, avoid=()) -> Path | None:
    """First file whose name contains every fragment and none of `avoid`."""
    for p in paths:
        n = p.name.lower()
        if all(f.lower() in n for f in must_contain) and not any(
                a.lower() in n for a in avoid):
            return p
    return None


# ═══════════════════════════════════════════════════════════════════════════
#  WHAT A CHECKPOINT NEEDS TO LOOK GOOD
#
#  The first build ran every model the same way: 512x512, 20 steps, CFG 7,
#  default sampler, and NO NEGATIVE PROMPT AT ALL. That is close to the worst
#  configuration available, and it showed - melted faces, spare limbs, and
#  the user reporting "we should not send ten image prompts through to get
#  one good image".
#
#  Four things were wrong, in descending order of how much they cost:
#
#  1. NO NEGATIVE PROMPT. An SD1.5-class model relies on one. Without it,
#     "bad anatomy, extra fingers, deformed" are all perfectly likely
#     completions and nothing pushes against them. This is free to fix.
#
#  2. THE CHECKPOINT. stable-diffusion-v1-5-pruned-emaonly is the raw 2022
#     base weights. Every community fine-tune since is dramatically better
#     at faces, and the good ones are the same size or smaller.
#
#  3. FACES ARE A RESOLUTION PROBLEM. A face occupying a fifth of a 512px
#     frame is about a hundred pixels across - not enough for eyes to come
#     out right at any step count. SDXL renders natively at 1024.
#
#  4. SAMPLER AND STEPS. euler at 20 steps is the fallback, not the choice.
#     dpm++2m with the karras schedule at ~28 is the ordinary good default.
#
#  So: presets per model family, detected from the filename, because a
#  turbo model wants 6 steps at CFG 1.5 and an SD1.5 model wants 28 at CFG 7
#  and running either one at the other's settings produces garbage.
# ═══════════════════════════════════════════════════════════════════════════

# What NOT to draw. Weighted toward anatomy and faces, which are what
# actually goes wrong, rather than a long incantation of style words.
NEGATIVE_SD15 = (
    "lowres, bad anatomy, bad hands, missing fingers, extra fingers, "
    "extra digit, fewer digits, extra limbs, malformed limbs, mutated hands, "
    "poorly drawn hands, poorly drawn face, deformed face, disfigured, "
    "ugly, blurry, out of focus, jpeg artifacts, watermark, signature, text, "
    "cropped, worst quality, low quality"
)

# Turbo and lightning models are distilled to run at very low CFG. A long
# negative prompt at CFG 1.5 does almost nothing and costs encoding time.
NEGATIVE_TURBO = "blurry, lowres, deformed, bad anatomy, watermark, text"


def model_preset(name: str) -> dict:
    """
    Sensible generation settings for this checkpoint, from its filename.

    Filename sniffing is crude and it is what there is: a GGUF header does
    not say "I am a turbo model, use six steps". Getting this wrong is very
    visible - an SDXL turbo model at 28 steps and CFG 7 produces a burnt
    mess, and an SD1.5 model at 6 steps and CFG 1.5 produces fog - so the
    detection is deliberately conservative and every value can be overridden
    by the caller.
    """
    n = (name or "").lower()
    xl = ("xl" in n or "sdxl" in n)
    fast = any(k in n for k in ("turbo", "lightning", "lcm", "hyper", "dmd"))

    if xl and fast:
        # 768, NOT 1024. SDXL turbo is trained at 1024 and renders happily at
        # 768; on a 4 GB card the difference is the whole cost of the run,
        # because 1024 is what forces the VAE onto the CPU. A user who wants
        # 1024 can ask for it and wait.
        return {"family": "sdxl-turbo", "steps": 8, "cfg": 2.0,
                "width": 768, "height": 768,
                "sampler": "euler", "scheduler": "karras",
                "clip_skip": -1, "negative": NEGATIVE_TURBO}
    if xl:
        return {"family": "sdxl", "steps": 26, "cfg": 6.0,
                "width": 1024, "height": 1024,
                "sampler": "dpm++2m", "scheduler": "karras",
                "clip_skip": -1, "negative": NEGATIVE_SD15}
    if fast:
        # LCM is the odd one: it needs its own sampler and CFG near 1.
        lcm = "lcm" in n
        return {"family": "sd15-fast", "steps": 8 if lcm else 10,
                "cfg": 1.5 if lcm else 2.5,
                "width": 512, "height": 512,
                "sampler": "lcm" if lcm else "euler",
                "scheduler": "karras", "clip_skip": 2,
                "negative": NEGATIVE_TURBO}
    return {"family": "sd15", "steps": 28, "cfg": 7.0,
            "width": 512, "height": 512,
            "sampler": "dpm++2m", "scheduler": "karras",
            "clip_skip": 2, "negative": NEGATIVE_SD15}


def image_models() -> list:
    """
    Every checkpoint that can be used for image generation.

    A scan, not a list. Whatever is in llm/gen/models is offered - the pinned
    download is only what makes a fresh install work, exactly like llm/models
    for language models.
    """
    out = []
    for p in _scan(MODELS):
        n = p.name.lower()
        if any(k in n for k in ("umt5", "t5xxl", "clip", "vae", "wan",
                                "encoder", "taesd")):
            continue
        out.append({"name": p.name, "path": str(p),
                    "size_mb": round(p.stat().st_size / 1048576, 1)})
    return out


def video_models() -> list:
    out = []
    for p in _scan(MODELS):
        if "wan" in p.name.lower() and "vae" not in p.name.lower():
            out.append({"name": p.name, "path": str(p),
                        "size_mb": round(p.stat().st_size / 1048576, 1)})
    return out


# ═══════════════════════════════════════════════════════════════════════════
#  WHY VIDEO KEPT RUNNING OUT OF MEMORY, AND IT WAS NOT THE CARD
#
#  The standing belief was that video simply does not fit on a 4 GB card, and
#  the retry ladder was built around that belief: try small, then smaller,
#  then report. It failed at 480x320x33 and again at 320x192x17, which looked
#  like confirmation and was not, because both rungs were run with the same
#  wrong flags.
#
#  A Wan run needs three files. Two of them are small:
#
#      Wan2.1-T2V-1.3B-Q5_K_M.gguf     900 MB
#      wan_2.1_vae.safetensors         200 MB
#      umt5-xxl-encoder-Q3_K_M.gguf   2500 MB   <- the text encoder
#
#  The text encoder is nearly three times the size of the model that does the
#  actual work, it is loaded FIRST, and it stays resident. 2.5 GB of encoder
#  plus a diffusion model plus latents plus compute buffers does not fit in
#  4 GB, and no frame size fixes that, because the encoder does not care how
#  big the video is. Shrinking the picture shrinks the only part that was
#  never the problem.
#
#  stable-diffusion.cpp has a flag for exactly this and it was not being
#  passed:
#
#      --clip-on-cpu    "keep clip in cpu (for low vram)"
#      --vae-on-cpu     "keep vae in cpu (for low vram)"
#
#  The text encoder runs once, on a prompt, for a fraction of a second of
#  work. Putting it on the CPU costs almost nothing and hands back 2.5 GB of
#  the 4. The VAE decode of a video's worth of latents is the other spike, so
#  it goes to system RAM as well, with tiling on top.
#
#  --offload-to-cpu keeps the weights in RAM and pages them in as needed, and
#  the two conv-direct flags cut the working buffers further. None of this
#  makes video fast on this machine. It is the difference between a slow clip
#  and no clip.
# ═══════════════════════════════════════════════════════════════════════════

LOW_VRAM_VIDEO = ["--clip-on-cpu", "--vae-on-cpu", "--vae-tiling",
                  "--offload-to-cpu", "--diffusion-fa",
                  "--diffusion-conv-direct", "--vae-conv-direct"]

_SD_HELP = {"text": None}


def sd_help() -> str:
    """
    What this build of sd-cli says it accepts, read from the binary itself.

    ASKING BEATS ASSUMING, and this project has the scar to prove it: the
    TRELLIS interface was written from a guess and was wrong in every
    particular, and the guess survived two releases because nothing ever
    checked.

    Flags come and go between sd.cpp builds. Passing one this binary does not
    know turns a slow-but-working run into an instant usage error - which
    would be a worse outcome than the bug being fixed, and indistinguishable
    from it in the log.
    """
    if _SD_HELP["text"] is None:
        text = ""
        exe = sd_exe()
        if exe is not None:
            for flag in ("--help", "-h"):
                try:
                    # PROBE: not a generation. This asks the binary to
                    # print its own help text; one that cannot do that in
                    # thirty seconds is not slow, it is broken. Finding out
                    # something is dead is the opposite of a deadline.
                    r = subprocess.run([str(exe), flag], capture_output=True,
                                       timeout=30,
                                       creationflags=getattr(
                                           subprocess, "CREATE_NO_WINDOW", 0))
                    text = ((r.stdout or b"") + (r.stderr or b"")).decode(
                        "utf-8", "replace")
                    if text.strip():
                        break
                except Exception as e:
                    core.log_line("forge", f"sd-cli {flag} failed: {e}")
        _SD_HELP["text"] = text
    return _SD_HELP["text"]


def sd_flags(wanted: list) -> list:
    """Those of `wanted` this build actually advertises. All of them if the
    binary would not tell us, since refusing to try is the worse error."""
    help_text = sd_help()
    if not help_text.strip():
        return list(wanted)
    keep = [f for f in wanted if f in help_text]
    missing = [f for f in wanted if f not in help_text]
    if missing:
        core.log_line("forge", "sd-cli does not advertise: "
                      + " ".join(missing))
    return keep


def _video_parts() -> dict:
    """The three files a Wan video run needs: diffusion model, VAE, T5."""
    files = _scan(MODELS)
    return {
        "diffusion": _pick(files, "wan", avoid=("vae",)),
        "vae": _pick(files, "wan", "vae"),
        "t5": _pick(files, "umt5") or _pick(files, "t5xxl"),
    }


# ---------------------------------------------------------------- backends

_STATE_FILE = core.DATA / "forge_state.json"
_STATE_LOCK = threading.RLock()


# Wording that was written into forge_state.json before ADR-70 and is still
# sitting on every machine that installed an earlier build. The file outlives
# the code, so fixing _explain() fixed nothing for anyone who already had a
# failure on record - Nova went on reading, and quoting, a sentence that says
# the machine cannot do the thing:
#
#   video generation failed - ran out of video memory - this model does not
#   fit on this card. Try a smaller checkpoint, a smaller size, or the CPU
#   build.
#
# Rewritten on read. The event still happened and is still remembered; what
# is dropped is the claim about the future that was never measured.
_OLD_VERDICTS = (
    ("this model does not fit on this card",
     "it did not fit at that size on that run"),
    ("does not fit on this card", "did not fit at that size"),
)


def _load_state() -> dict:
    try:
        d = json.loads(_STATE_FILE.read_text(encoding="utf-8"))
        if not isinstance(d, dict):
            return {}
    except Exception:
        return {}
    for rec in d.values():
        if not isinstance(rec, dict):
            continue
        note = str(rec.get("note") or "")
        for old, new in _OLD_VERDICTS:
            if old in note:
                note = note.replace(old, new)
        if note != rec.get("note"):
            rec["note"] = note
    return d


def _fingerprint() -> str:
    """
    A cheap signature of what is installed for generation right now.

    Its whole job is to date a failure against the machine it happened on. If
    a checkpoint has been added, a binary replaced, or weights finished
    downloading since the last failed run, that run was measured on a
    different machine than the one asking - and saying so is the difference
    between "this cannot work" and "this had not worked yet".
    """
    try:
        parts = []
        for d in (MODELS, TRELLIS_MODELS, SD_DIR, TRELLIS_DIR):
            try:
                for f in sorted(Path(d).rglob("*")):
                    if f.is_file():
                        parts.append(f"{f.name}:{f.stat().st_size}")
            except Exception:
                pass
        import hashlib
        return hashlib.sha1("|".join(parts).encode()).hexdigest()[:12]
    except Exception:
        return ""


def _record(backend: str, ok: bool, note: str = "", seconds: float = 0.0) -> None:
    """
    Remember what happened THE LAST TIME this backend ran on this machine.

    This used to be described as the thing that "stops the interface
    promising something that has already failed once for a reason that will
    not change" - and that sentence was the bug. One failed run was filed as
    a permanent property of the system. Nova read it back, told the user she
    could not do the thing, and went on saying so after the cause had been
    fixed. The user would say "try again, I fixed it" and be told no.

    A run is an event. It has a time and it happened to a particular set of
    installed files. Both are kept here so that report() can say how old the
    failure is and whether anything has changed underneath it since. Nothing
    stored here is permission to refuse; it is context for deciding what to
    try first.
    """
    print_ = _fingerprint()
    # AND INTO THE LEDGER, WHICH COUNTS RATHER THAN FLAGS.
    #
    # This file keeps the LAST outcome. One boolean cannot say "tried once,
    # did not work, which is not the same as knowing it does not work" - and
    # that gap is what let a single failed Goku statue become a standing
    # refusal to attempt 3D at all. ledger.py keeps every attempt and reports
    # a rate with the confidence it deserves, which for one attempt is none.
    try:
        import ledger
        ledger.record(backend, ok, note=note, seconds=seconds, install=print_)
    except Exception as e:
        core.log_line("forge", f"ledger write skipped: {e}")

    with _STATE_LOCK:
        st = _load_state()
        st[backend] = {"ok": bool(ok), "note": str(note)[:300],
                       "seconds": round(float(seconds), 1), "at": time.time(),
                       "install": print_}
        try:
            _STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
            _STATE_FILE.write_text(json.dumps(st, indent=2), encoding="utf-8")
        except Exception:
            pass


def last_outcome(backend: str) -> dict:
    return _load_state().get(backend) or {}


def available() -> dict:
    """What can run right now, and for each thing that cannot, why not."""
    sd = sd_exe()
    tr = trellis_backend()[1]
    imgs = image_models()
    vparts = _video_parts()
    tr_models = _scan(TRELLIS_MODELS, (".gguf",))

    def _why(binary, ok_models, what, hint):
        if binary is None:
            return f"{what} runtime is not installed - run INSTALL.bat"
        if not ok_models:
            return f"{what} runtime is installed but {hint}"
        return ""

    out = {
        "image": {
            "ready": bool(sd and imgs),
            "why": _why(sd, imgs, "the image",
                        "there is no checkpoint in llm\\gen\\models"),
            "models": [m["name"] for m in imgs],
            "last": last_outcome("image"),
        },
        "video": {
            "ready": bool(sd and vparts["diffusion"] and vparts["t5"]
                          and vparts["vae"]),
            "why": _why(sd, vparts["diffusion"] and vparts["t5"] and vparts["vae"],
                        "the video",
                        "the Wan diffusion model, its VAE or the umt5 text "
                        "encoder is missing from llm\\gen\\models"),
            "models": [p["name"] for p in video_models()],
            "last": last_outcome("video"),
        },
        "model3d": {
            "ready": bool(tr and len(tr_models) >= 6),
            "why": _why(tr, len(tr_models) >= 6, "the 3D",
                        "the TRELLIS weights are missing from "
                        "llm\\gen\\trellis-models"),
            "models": [p.name for p in tr_models],
            "last": last_outcome("model3d"),
        },
        # Never unavailable. No binary, no weights, no download - it builds
        # geometry directly, so generate_3d always has something real to
        # return even on a machine where the neural path will not fit.
        "mesh": {"ready": True, "why": "", "models": ["built in"],
                 "last": last_outcome("mesh")},
    }
    return out


def _span(seconds: float) -> str:
    """A duration in words. Same shape as ledger._span, deliberately."""
    sec = max(0.0, float(seconds or 0))
    if sec < 90:
        return f"{sec:.0f}s"
    if sec < 5400:
        return f"{sec / 60:.0f} min"
    return f"{sec / 3600:.1f} hours"


def _ago(when: float) -> str:
    """How long ago, in words, so a failure carries its own age."""
    if not when:
        return "at some point"
    d = max(0.0, time.time() - float(when))
    if d < 90:
        return "moments ago"
    if d < 5400:
        return f"{int(d // 60)} minutes ago"
    if d < 172800:
        return f"{int(d // 3600)} hours ago"
    return f"{int(d // 86400)} days ago"


def inventory() -> list:
    """
    Every generation capability, described once, for everyone who asks.

    THE ONE SOURCE, because two of them is how this session started.

    The launch banner and Nova's own look_at_system("generation") were about
    to grow separate copies of "what is installed as what". That is exactly
    the shape of the trellis bug: two functions with their own opinion about
    the same fact, agreeing until they quietly did not. So there is one, and
    both render it.

    Each entry carries what it IS - checkpoint, runtime, the settings it will
    actually use - and what has HAPPENED: the attempt count, because "ready"
    means installed and reachable and says nothing at all about whether it
    has ever worked. Video reported ready for weeks with zero successful runs
    behind it.
    """
    a = available()
    print_ = _fingerprint()
    try:
        import ledger
    except Exception:
        ledger = None

    def _tried(key):
        if ledger is None:
            return {}
        try:
            return ledger.reliability(key, print_)
        except Exception:
            return {}

    def _starts():
        """Whether the 3D runtime comes up. One definition, shared with
        report() - two of them is how this whole session started."""
        if ledger is None:
            return ""
        try:
            return _starts_line(ledger, print_)
        except Exception:
            return ""

    def _took(key):
        """How long it has really taken, from the runs that happened."""
        if ledger is None:
            return ""
        try:
            return ledger.took(key, print_)
        except Exception:
            return ""

    out = []

    img = _preferred_image_model(image_models())
    pre = model_preset(img["name"]) if img else {}
    out.append({
        "key": "image", "label": "images", "colour": "image",
        "ready": a["image"]["ready"], "why": a["image"]["why"],
        "what": img["name"] if img else "",
        "how": (f"stable-diffusion.cpp · {pre.get('family')} · "
                f"{pre.get('width')}x{pre.get('height')} · "
                f"{pre.get('steps')} steps · no time limit, progress shown"
                if pre else ""),
        "attempts": _tried("image"), "took": _took("image")})

    parts = _video_parts()
    extra = [f"+ {parts[k].name}" for k in ("vae", "t5")
             if parts.get(k) is not None]
    out.append({
        "key": "video", "label": "video", "colour": "video",
        "ready": a["video"]["ready"], "why": a["video"]["why"],
        "what": (parts["diffusion"].name if parts.get("diffusion") else ""),
        "extra": extra,
        # THE FLAGS ARE PART OF WHAT IT IS. The encoder is the biggest of
        # the three files and where it runs decides whether video runs at
        # all, so the banner says where it runs.
        "how": ("stable-diffusion.cpp (Wan) · 480x320 · 33 frames · "
                + ("text encoder + VAE on CPU"
                   if "--clip-on-cpu" in sd_flags(LOW_VRAM_VIDEO)
                   else "all on GPU")
                + " · no time limit, progress shown"),
        "attempts": _tried("video"), "took": _took("video")})

    kind, exe = trellis_backend()
    weights = len(_scan(TRELLIS_MODELS, (".gguf",)))
    out.append({
        "key": "model3d", "label": "3D", "colour": "mesh",
        "ready": a["model3d"]["ready"], "why": a["model3d"]["why"],
        "what": (f"{exe.name} · {weights} weight files" if exe else ""),
        # NO FALLBACK is now a property worth printing. For weeks this said
        # ready, and every request quietly became a plaque instead.
        "how": (f"trellis.cpp · HTTP on port {core.TRELLIS_PORT} · res 512 · "
                f"CPU fallback allowed · no time limit · no substitute"
                if kind == "server"
                else "trellis.cpp · command line · res 512 · no substitute"
                if kind else ""),
        "attempts": _tried("model3d"), "took": _took("model3d"),
        # DID IT EVEN START. Recorded as its own attempt since ADR-125, and
        # said out loud here, because "3D has never worked" and "3D starts
        # every time and the mesh step is what has not finished" send a
        # person - and a model - to two completely different places.
        "starts": _starts()})

    out.append({
        "key": "mesh", "label": "3D shapes", "colour": "mesh",
        "ready": True, "why": "", "what": "meshgen.py · built in",
        "how": "exact solids from dimensions · no weights, no VRAM",
        "attempts": _tried("mesh"), "took": _took("mesh")})
    return out


def tried_note(att: dict) -> str:
    """One short phrase for how much has actually been attempted."""
    if not att:
        return ""
    n, s = att.get("attempts", 0), att.get("successes", 0)
    if not n:
        if att.get("retired"):
            return (f"never tried on this build "
                    f"({att['retired']} older attempt(s) retired)")
        return "never tried on this build"
    if att.get("same_error_every_time"):
        return f"{n} attempts, all failed the same way - ask the user"
    return (f"{s} of {n} worked here"
            + ("" if att.get("confidence") == "measured"
               else f" ({att.get('confidence')})"))


def report() -> str:
    """
    What can run, what happened last time, and HOW LONG AGO that was.

    The age is the point. Without it a three-week-old failure and a failure
    from thirty seconds ago read identically, and a model with no sense of
    when has no way to tell a live constraint from an old one. It read the
    note, believed it described now, and refused. Told "I fixed it", it
    quoted the note back.

    So every past run is stamped with its age, and a run measured against a
    different set of installed files is called stale outright - because it
    was measured on a machine that no longer exists. The closing line says
    the operational rule in plain words, since this text is what the model
    has in front of it at the moment it decides whether to try.
    """
    a = available()
    now_print = _fingerprint()
    try:
        import ledger
    except Exception:
        ledger = None
    lines = ["On-device generation, as of right now:"]
    label = {"image": "images", "video": "video",
             "model3d": "3D (neural, TRELLIS)", "mesh": "3D (built-in geometry)"}
    stale = False
    for key, name in label.items():
        st = a[key]
        last = st.get("last") or {}
        if st["ready"]:
            note = ""
            if last and not last.get("ok"):
                when = _ago(last.get("at", 0))
                if last.get("install") and now_print and last["install"] != now_print:
                    stale = True
                    note = (f"  (it failed {when} - {last.get('note','')[:110]} "
                            f"- but the installed files have CHANGED since, "
                            f"so that result no longer describes this machine)")
                else:
                    note = (f"  (one run failed {when}: "
                            f"{last.get('note','')[:110]})")
            elif last.get("ok"):
                note = (f"  (last run worked, {when_ok(last)})")
            lines.append(f"  {name}: ready - {', '.join(st['models'][:3])}{note}")
            # HOW MANY TIMES, NOT WHETHER. The last outcome above is one
            # observation; this is the count behind it, and the count is
            # what says whether the observation means anything.
            if ledger is not None:
                try:
                    lines.append("      " + ledger.brief(key, now_print))
                except Exception:
                    pass
                # HOW LONG IT ACTUALLY TAKES, IN THE MODEL'S OWN CONTEXT.
                #
                # ledger.took() has existed since the ledger did and only
                # the settings page ever read it. So the model answered
                # "how long does a video take" from nothing, and had no way
                # to know that 43 minutes of silence is this machine
                # working normally rather than this machine being stuck.
                # That is most of what "it takes too long" was made of.
                try:
                    d = ledger.took(key, now_print) or ledger.took(key)
                    if d:
                        lines.append(f"      how long, measured here: {d}")
                except Exception:
                    pass
                if key == "model3d":
                    try:
                        st3 = _starts_line(ledger, now_print)
                        if st3:
                            lines.append(f"      starting up: {st3}")
                    except Exception:
                        pass
        else:
            lines.append(f"  {name}: not available - {st['why']}")
    lines.append("")
    lines.append("One generator runs at a time. Nova is stopped for the "
                 "duration and restarted afterwards, so a generation request "
                 "pauses the conversation rather than competing with it.")
    lines.append("")
    lines.append("READ THE ABOVE AS HISTORY, NOT AS A LIMIT. A line saying "
                 "something failed once is a record of one run at one "
                 "moment. It is not a statement about whether it will work "
                 "now, and it is never a reason to decline. If a backend is "
                 "listed as ready, it is installed and it can be called. "
                 "Call it.")
    if stale:
        lines.append("At least one of those failures was measured before the "
                     "current install. Treat it as out of date and try the "
                     "thing.")
    return "\n".join(lines)


def _starts_line(ledger, print_: str) -> str:
    """
    Did the 3D runtime come up - said separately from whether a mesh got
    built, because they fail for different reasons and get fixed in
    different places.
    """
    d = ledger.how_long("model3d_start", print_) or {}
    if not d.get("runs"):
        d = ledger.how_long("model3d_start") or {}
    if not d.get("runs"):
        return "not measured yet on this install"
    if d.get("worked") and not d.get("failed"):
        return (f"the runtime has come up {d['worked']} time(s), every "
                f"time, in about {ledger._span(d.get('typical') or 0)} - "
                f"so starting up is not the problem")
    if not d.get("worked"):
        return (f"the runtime failed to come up {d['failed']} time(s) - "
                f"nothing has been built because nothing has started")
    return f"the runtime came up {d['worked']} of {d['runs']} time(s)"


def when_ok(last: dict) -> str:
    secs = last.get("seconds", 0)
    return f"{_ago(last.get('at', 0))}, took {secs}s"


# ═══════════════════════════════════════════════════════════════════════════
#  A TIMEOUT IS A GUESS ABOUT SOMEBODY ELSE'S MACHINE
#
#  Every generator ran under a deadline - 40 minutes for an image, two hours
#  for video, three for a mesh - and when the deadline passed the run was
#  KILLED and reported as "timed out". On the machine this is built for, an
#  image already takes 170 seconds and a mesh with the model paged through
#  system RAM can take far longer. The deadline was never measured; it was
#  picked, and picking it wrong turns a slow success into a failure.
#
#  "if the model is used on a machine barely able to run this it should
#   still run"
#
#  So the deadlines are gone. A run ends when the process ends, or when the
#  USER stops it - which is a decision made by somebody who can see how long
#  it has been, rather than by a constant typed months ago.
#
#  That trade is only honest if the user CAN see. A timeout at least said
#  something was wrong; silence says nothing at all. So the other half of
#  this is mandatory, not decoration:
#
#      capture_output=True hides everything until the process exits.
#
#  Same defect as the trellis pipe, different symptom. sd.cpp prints a step
#  counter and a progress bar the whole way through and none of it was read
#  until the run was over, at which point nobody needs it. Now it is streamed
#  as it appears, parsed into a percentage, and published on /api/state,
#  which the interface already polls every two seconds.
# ═══════════════════════════════════════════════════════════════════════════

_PROGRESS = {"backend": "", "what": "", "since": 0.0, "seen": 0.0,
             "pct": None, "step": 0, "total": 0, "line": "",
             # WHAT PAST RUNS ACTUALLY TOOK - not what this one "should".
             #
             #     "this should never be timed for 'how long it should
             #      take' only for how long it has taken in the past"
             #
             # There used to be an `eta` here, extrapolated from the first
             # step: at step 1 of 12 it announced "~186 min left", which was
             # invented, wrong, and read as a countdown to something. These
             # three come from the ledger - runs that really happened on
             # this machine - and are absent until one has.
             "typical": None, "fastest": None, "slowest": None, "runs": 0}
_PROGRESS_LOCK = threading.Lock()

# `N/M` anywhere in a line, and a bare percentage. sd.cpp writes
#     |==================================================| 8/8 - 12.34s/it
# with a carriage return and no newline, so the reader below splits on \r as
# well as \n or nothing would appear until the very end.
_STEP_RE = re.compile(r"(\d{1,6})\s*/\s*(\d{1,6})")
_PCT_RE = re.compile(r"(\d{1,3}(?:\.\d+)?)\s*%")


def progress() -> dict:
    """What the running generator has printed most recently. Read-only."""
    with _PROGRESS_LOCK:
        p = dict(_PROGRESS)
    if p["since"]:
        p["elapsed"] = round(time.time() - p["since"], 1)
        p["quiet"] = round(time.time() - (p["seen"] or p["since"]), 1)
    else:
        p["elapsed"] = 0.0
        p["quiet"] = 0.0
    return p


def _progress_start(backend: str, what: str = "") -> None:
    # Read the measured history ONCE, at the start, outside the lock. A
    # missing or unreadable ledger leaves the fields empty, which the UI
    # renders as "first run" - never as an estimate of zero.
    past = {}
    try:
        import ledger                            # optional, like everywhere
        past = ledger.how_long(backend, _fingerprint())
        if not past.get("worked"):
            past = ledger.how_long(backend)      # any install is still data
    except Exception:
        past = {}
    with _PROGRESS_LOCK:
        _PROGRESS.update({"backend": backend, "what": what or backend,
                          "since": time.time(), "seen": time.time(),
                          "pct": None, "step": 0, "total": 0, "line": "",
                          "typical": past.get("typical"),
                          "fastest": past.get("fastest"),
                          "slowest": past.get("slowest"),
                          "runs": int(past.get("worked") or 0)})


def _progress_clear() -> None:
    with _PROGRESS_LOCK:
        _PROGRESS.update({"backend": "", "what": "", "since": 0.0,
                          "seen": 0.0, "pct": None, "step": 0, "total": 0,
                          "line": "", "typical": None, "fastest": None,
                          "slowest": None, "runs": 0})


def _progress_line(text: str) -> None:
    """
    One line of a generator's output, turned into something a bar can show.

    Deliberately forgiving. A line that carries no progress still counts as
    PROOF OF LIFE - it moves `seen`, which is what tells the user the thing
    is working rather than wedged, and that is most of the value here.
    """
    line = (text or "").strip()
    if not line:
        return
    with _PROGRESS_LOCK:
        _PROGRESS["seen"] = time.time()
        _PROGRESS["line"] = line[-160:]
        step = total = 0
        # LAST match, not first: the bar puts its counter at the end, and a
        # log line may carry a file path or a source line number first.
        for m in _STEP_RE.finditer(line):
            a, b = int(m.group(1)), int(m.group(2))
            if 0 < b <= 100000 and a <= b:
                step, total = a, b
        pct = None
        if total:
            _PROGRESS["step"], _PROGRESS["total"] = step, total
            pct = 100.0 * step / total
        else:
            m = _PCT_RE.search(line)
            if m:
                try:
                    v = float(m.group(1))
                    if 0.0 <= v <= 100.0:
                        pct = v
                except ValueError:
                    pass
        if pct is not None:
            _PROGRESS["pct"] = round(pct, 1)
            # NO ETA IS COMPUTED HERE ANY MORE.
            #
            # It used to be spent * (100 - pct) / pct, which assumes the
            # remaining steps cost what the first one did. For a mesh they
            # do not - TRELLIS spends most of a run in two of twelve flow
            # steps - and at step 1 of 12 that formula announced
            # "~186 min left" on a run that had barely begun. A number that
            # confident and that wrong is worse than no number.
            #
            # What replaced it is on the board already: `typical`,
            # `fastest` and `slowest`, from runs that actually finished.


# ═══════════════════════════════════════════════════════════════════════════
#  THE FLOOR THAT REPLACED THE CLOCK
#
#  Removing the deadlines was right and it was not free. A deadline was the
#  only thing bounding a generator, and when it went, nothing stopped a run
#  that was consuming the machine rather than making progress:
#
#      "also this run crashed my laptop"
#
#  That is on this change. Video was told to keep its 2.5 GB text encoder,
#  its VAE and its weights in system RAM (ADR-103) on a machine with 15.7 GB
#  total, and then given unlimited time to grow into it. Windows does not
#  fail an allocation politely at that point; it thrashes, and the desktop
#  goes with it.
#
#  The fix is NOT a clock. A clock stops slow runs, and a slow run finishing
#  is the entire point of the previous change:
#
#      "if the model is used on a machine barely able to run this it should
#       still run"
#
#  A slow run and a run that is about to take the laptop down are different
#  events and deserve different treatment. So the bound is the resource that
#  actually runs out. Elapsed time is never a reason to stop anything.
#
#  Two gates, both measured:
#
#    BEFORE  - what this run will page through is known from the file sizes
#              on disk. If the machine does not have room for it, say so now
#              rather than finding out by hanging.
#    DURING  - free memory is sampled while it runs. Sustained below the
#              floor, the generator is stopped and told so plainly. Two
#              consecutive samples, because a momentary dip during a model
#              load is normal and killing a good run for it would be the old
#              mistake wearing new clothes.
# ═══════════════════════════════════════════════════════════════════════════

# Windows starts thrashing well before zero. Below this the desktop stops
# responding, which is the thing being prevented.
#
# THE ONE THING THAT MAY STILL STOP A RUN, AND IT IS NOT A CLOCK.
#
# Everything else that could end a generation early has been removed: no
# deadline, no size refusal, no call ceiling that a long job can walk into.
# A run takes as long as it takes.
#
# This one stays because the alternative was measured: "also this run
# crashed my laptop". It does not care how slow a run is - only whether the
# machine is about to stop responding - and it is a floor on FREE MEMORY,
# checked twice in a row, not a prediction made in advance.
#
# AND IT IS OFF, BECAUSE THE LOGS SHOWED IT KILLING FINISHED WORK.
#
# Four video runs on the user's machine, in the user's own log:
#
#     memory low: 150 MB free (strike 1)
#     memory low: 686 MB free (strike 2)
#     stopping the generator to keep the machine responsive
#     video exited 1: | 20/20 - 46.69s/it
#     sampling completed, taking 921.97s
#     generating latent video completed, taking 922.35s
#     |####################################| 108/108 - 626.91MB/s
#
# READ THE ORDER. Sampling COMPLETED. All twenty steps. The tensors for the
# final decode were 108 of 108 loaded. The run had done the whole job and
# was in its last and largest allocation - which is exactly when free memory
# is lowest, by design - and this guard shot it. Every time. 1064s, 1100s,
# 1064s, 1108s, four for four, and the user has never once seen a finished
# video because of it.
#
# The machine did not crash in any of those runs. Low free memory during a
# video decode is what a WORKING run on 16 GB looks like, not a warning
# sign, and I had no way to know that from here - which is the whole
# problem with the number.
#
#     "the limitation of giving it a number here could be what makes it
#      stop, because it does stop here, every time"
#
# That is the third time a limit of mine has stopped the thing it was
# supposed to protect, after the subprocess deadlines and the size refusal.
# So the default is OFF. The mechanism stays for whoever wants it - set
# generation.ram_floor_mb in config.json - but nothing here decides on the
# user's behalf that their machine is in trouble.
RAM_FLOOR_MB = 0.0


def _ram_floor() -> float:
    try:
        v = (core.load().get("generation") or {}).get("ram_floor_mb")
        return max(0.0, float(v)) if v is not None else RAM_FLOOR_MB
    except Exception:
        return RAM_FLOOR_MB

# Sampled every few seconds; two in a row under the floor stops the run.
RAM_SAMPLE_SECONDS = 4.0


def free_mb() -> float:
    """Free physical memory, or -1 when it cannot be read."""
    try:
        import runtime as _rt
        return float(_rt.available_mb())
    except Exception:
        return -1.0


def weights_in(argv) -> float:
    """
    MB of real files named in a command line. Measured, never estimated.

    Taken from argv rather than passed in by each backend, because a list
    that has to be kept in step with six call sites is a list that will one
    day be missing the newest one - and the missing one is always the one
    that matters.
    """
    total = 0.0
    seen = set()
    for a in argv or ():
        t = str(a)
        if t in seen or len(t) < 4:
            continue
        seen.add(t)
        try:
            f = Path(t)
            if f.is_file():
                total += f.stat().st_size / 1048576.0
        except Exception:
            pass
    return total


def enough_room_to_start(argv) -> tuple:
    """
    (ok, why). ARITHMETIC, TAKEN ONCE, BEFORE ANYTHING IS RUNNING.

    THIS IS NOT THE RAM FLOOR COMING BACK. Read this before changing it.

    The floor was 700 MB, sampled every four seconds for the whole run, and
    it killed four video generations at 17.7-18.5 minutes against successes
    at 43-47. It was measuring the wrong thing: on a 15.7 GB machine a
    HEALTHY video run drives free memory below 700 MB and keeps it there for
    three quarters of an hour. "Low" is what working looks like. That guard
    is still off and must stay off.

    This is a different question, asked once, at a different moment:

        can the files it has to load even fit in the memory that is free
        right now?

    Two measurements - stat() on the weights, GlobalMemoryStatusEx on the
    machine - and a comparison. No margin, no guess about peak usage, no
    prediction about what a diffusion run will need in twenty minutes. If
    the weights are larger than free memory, loading them is what takes the
    machine down, and it takes it down every time for the same reason.

        "A generation may fail because it never started, or because it ran
         and errored. Never because a number ran out."

    Never starting is the permitted one, and it is the only one this does.
    Once a run has begun, nothing here can reach it.

    Unmeasurable never blocks: no reading, no opinion.
    """
    try:
        if not (core.load().get("generation") or {}).get("start_check", True):
            return True, ""
    except Exception:
        pass
    # THE SAME QUESTION ABOUT THE DISK, asked the same way: once, before
    # anything starts, and never of something already running. A store that is
    # already at its ceiling has nowhere to put what this would produce, and
    # NOTHING is deleted to make room - see store.py.
    try:
        import store
        if store.chosen_gb() > 0 and store.room_gb() <= 0:
            return False, (
                "the memory store is at its ceiling, so there is nowhere to "
                "put what this would make. Nothing has been deleted - raise "
                "the ceiling in Settings, or erase something from the same "
                "screen.")
    except Exception:
        pass
    want = weights_in(argv)
    have = free_mb()
    if have < 0 or want <= 0:
        return True, ""
    if have >= want:
        return True, ""
    return False, (
        f"this has to load about {want:.0f} MB of weights and there is only "
        f"{have:.0f} MB of memory free, so it cannot start - loading it is "
        f"what takes the machine down. Close what else is open and ask "
        f"again, or ask for a smaller model. Nothing was started and "
        f"nothing was lost.")


def room_for(paths, margin_mb: float = 900.0) -> tuple:
    """
    (ok, why). Whether this run's weights plus a working margin will fit.

    Deliberately crude and deliberately early. The exact peak of a diffusion
    run is not knowable from here; the sum of the files it must hold is, and
    a machine that cannot hold even that will not survive the rest.
    """
    want = 0.0
    for p in paths:
        try:
            if p and Path(p).is_file():
                want += Path(p).stat().st_size / 1048576.0
        except Exception:
            pass
    have = free_mb()
    if have < 0 or want <= 0:
        return True, ""                       # unmeasurable: do not block
    if have >= want + margin_mb:
        return True, ""
    return False, (
        f"this needs about {want:.0f} MB of weights plus room to work, and "
        f"there is {have:.0f} MB free. Close something and try again, or ask "
        f"for a smaller size")


class _RamGuard:
    """Stops the child if the machine is about to run out of memory."""

    def __init__(self, proc, floor_mb: float | None = None):
        self.proc = proc
        self.floor = float(_ram_floor() if floor_mb is None else floor_mb)
        self.tripped = False
        self.low_mb = -1.0
        self._stop = threading.Event()
        self._t = None

    def start(self):
        if self.floor <= 0:
            return self                        # switched off by the user
        if free_mb() < 0:
            return self                        # nothing to measure, no guard
        self._t = threading.Thread(target=self._watch, daemon=True)
        self._t.start()
        return self

    def _watch(self):
        strikes = 0
        while not self._stop.wait(RAM_SAMPLE_SECONDS):
            if self.proc.poll() is not None:
                return
            mb = free_mb()
            if mb < 0:
                return
            if mb < self.floor:
                strikes += 1
                core.log_line("forge",
                              f"memory low: {mb:.0f} MB free "
                              f"(strike {strikes})")
                if strikes >= 2:
                    self.tripped = True
                    self.low_mb = mb
                    core.log_line("forge",
                                  "stopping the generator to keep the "
                                  "machine responsive")
                    try:
                        self.proc.terminate()
                    except Exception:
                        pass
                    return
            else:
                strikes = 0

    def stop(self):
        self._stop.set()


# ---------------------------------------------------------------- the lock

_FORGE_LOCK = threading.Lock()
_BUSY = {"what": "", "since": 0.0}

# How long to wait for the language model to finish loading again after a
# generator has had the card. Loading a 3 GB GGUF on a 4 GB card, warming the
# kernels, probing vision and benchmarking is tens of seconds on this
# hardware and occasionally much longer under memory pressure - so this is
# generous on purpose. runtime's own bring-up deadline is 300s; there is no
# point giving up before it does.
RESTORE_DEADLINE = 320.0


# The Session that currently holds the card, so a stop from the interface
# can reach the process it started. Set under the lock in __enter__, cleared
# in __exit__.
_CURRENT = {"session": None}


def busy() -> dict:
    return dict(_BUSY)


def cancel() -> bool:
    """Stop whatever generator is running, from anywhere. Returns whether
    there was something to stop."""
    sess = _CURRENT.get("session")
    return bool(sess is not None and sess.cancel())


def _wait_ready(deadline: float | None = None) -> bool:
    """
    Block until the language model is serving again. True if it made it.

    Polls the status runtime already maintains rather than hammering the
    HTTP endpoint: "ready" is set only after loading, warming, the vision
    probe and the benchmark have all finished, which is the point at which a
    chat turn can actually use it. Anything earlier and the next request is
    the 503 this exists to prevent.
    """
    # Read the module value at CALL time, not as a default argument. A
    # default is bound when the function is defined, so raising or lowering
    # RESTORE_DEADLINE afterwards - which a test does, and an operator
    # might - would have no effect at all.
    if deadline is None:
        deadline = RESTORE_DEADLINE
    t0 = time.time()
    last = ""
    while time.time() - t0 < deadline:
        try:
            st = runtime.state()
        except Exception:
            return False
        status = st.get("status", "")
        if status == "ready":
            core.log_line("forge",
                          f"Nova is back after {time.time() - t0:.0f}s")
            return True
        if status == "error":
            core.log_line("forge",
                          f"Nova failed to restart: {st.get('detail', '')}")
            return False
        if status != last:
            last = status
            core.log_line("forge", f"waiting for Nova: {status}")
        time.sleep(0.4)
    return False


class Session:
    """
    Exclusive use of the machine for generation.

    Stops Nova on entry and restarts it on exit, ONCE, around however many
    generator runs happen in between. Use it for a whole pipeline:

        with forge.Session("a dragon, 3D") as s:
            png = s.image(prompt="a dragon")
            glb = s.mesh_from_image(png)

    Two stop/start cycles for that would cost more than the generation. Nova
    is restored in a finally block, so a failed step never leaves the machine
    without its language model.
    """

    def __init__(self, what: str = "generating", wait: float = 0.5):
        self.what = what
        self.wait = wait
        self.ok = False
        self.restored = True        # False if Nova did not come back in time
        self._child = None          # the generator process, while one runs
        self._was_running = False
        self._model = None
        self.t0 = 0.0
        self.steps = []

    def __enter__(self):
        self.ok = _FORGE_LOCK.acquire(timeout=self.wait)
        if not self.ok:
            return self
        self.t0 = time.time()
        _BUSY.update({"what": self.what, "since": self.t0})
        _CURRENT["session"] = self
        try:
            st = runtime.state()
            self._was_running = st.get("status") not in ("stopped", "error")
            self._model = st.get("model")
            if self._was_running:
                core.log_line("forge", f"stopping Nova for: {self.what}")
                runtime.stop()
                # llama-server does not release VRAM the instant the process
                # is asked to stop. Starting a 2 GB diffusion model into a
                # card that has not finished emptying is how both fail.
                time.sleep(1.5)
        except Exception as e:
            core.log_line("forge", f"could not stop Nova: {e}")
        events.write("forge.start", what=self.what)
        return self

    def __exit__(self, *exc):
        if not self.ok:
            return False
        try:
            if self._was_running and self._model:
                core.log_line("forge", "restarting Nova")
                try:
                    runtime.start(self._model, core.load().get("runtime", {}))
                    # AND WAIT FOR HER TO ACTUALLY BE BACK.
                    #
                    # runtime.start() returns as soon as the process is
                    # spawned; loading, warming, the vision probe and the
                    # benchmark all happen on a background thread. So this
                    # used to return with llama-server still coming up, and
                    # the chat turn that CALLED the generator carried
                    # straight on and posted to it:
                    #
                    #   generate_image  ->  created Playground/generated.png
                    #   tools unavailable for this reply
                    #   Error: HTTP Error 503: Service Unavailable
                    #
                    # The image was generated perfectly. The turn then died
                    # because the model it needed to describe the image with
                    # was still loading. A Session that stops Nova has to
                    # hand her back, not merely ask for her back.
                    self.restored = _wait_ready()
                    if not self.restored:
                        core.log_line("forge",
                                      "Nova did not come back within the "
                                      "deadline after generation")
                except Exception as e:
                    core.log_line("forge", f"Nova restart failed: {e}")
        finally:
            secs = round(time.time() - self.t0, 1)
            events.write("forge.end", what=self.what, seconds=secs,
                         steps=len(self.steps))
            _BUSY.update({"what": "", "since": 0.0})
            _CURRENT["session"] = None
            _FORGE_LOCK.release()
        return False

    # -------------------------------------------------- running a binary

    def _run(self, backend: str, argv: list, timeout: int = 0) -> tuple:
        """
        Run a generator binary to completion. Returns (ok, output, seconds).

        NO DEADLINE. `timeout` is accepted and ignored so that old call sites
        and old tests keep working; killing a slow run was the bug, and a
        parameter is not the place to leave the temptation lying around.

        The child's output is streamed while it runs, not collected after it
        exits, so the interface can show how far along it is. Splitting on
        \r as well as \n matters: a progress bar is one very long line, and
        readline() would hold every frame of it until the run was over.
        """
        started = time.time()
        pretty = " ".join(str(a) for a in argv[:3]) + " ..."
        core.log_line("forge", f"{backend}: {pretty}")

        # CAN IT EVEN LOAD? Asked here, in _run, because _run is the ONE
        # place image, video and 3D all pass through - so a backend added
        # later cannot be the one that was forgotten.
        #
        # Nova has already been stopped by Session.__enter__ and given time
        # to release, so this reads the memory the run will actually get,
        # not the memory there was before she let go.
        _want, _have = weights_in(argv), free_mb()
        if _have >= 0 and _want > 0:
            core.log_line("forge",
                          f"{backend}: weights {_want:.0f} MB, free "
                          f"{_have:.0f} MB before starting")
        _room, _why = enough_room_to_start(argv)
        if not _room:
            core.log_line("forge", f"{backend}: not starting - {_why}")
            _record(backend, False, _why, 0.0)
            return False, _why, 0.0

        self.steps.append(backend)
        _progress_start(backend, self.what or backend)
        buf = collections.deque(maxlen=4000)
        try:
            proc = subprocess.Popen(
                [str(a) for a in argv],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                cwd=str(core.ROOT), bufsize=0,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as e:
            secs = time.time() - started
            _progress_clear()
            _record(backend, False, f"{type(e).__name__}: {e}", secs)
            return False, f"{type(e).__name__}: {e}", secs

        self._child = proc
        guard = _RamGuard(proc).start()
        try:
            pending = ""
            while True:
                chunk = proc.stdout.read(2048)
                if not chunk:
                    break
                pending += chunk.decode("utf-8", "replace")
                parts = re.split(r"[\r\n]", pending)
                pending = parts.pop()
                for line in parts:
                    if line.strip():
                        buf.append(line)
                        _progress_line(line)
            if pending.strip():
                buf.append(pending)
                _progress_line(pending)
            proc.wait()
            out = "\n".join(buf).strip()
            secs = time.time() - started
            ok = proc.returncode == 0
            if guard.tripped:
                ok = False
                out = (f"stopped to keep the machine usable: free memory "
                       f"reached {guard.low_mb:.0f} MB, below the "
                       f"{guard.floor:.0f} MB floor. This was NOT a "
                       f"timeout and it was not too slow - it was about to "
                       f"take the whole machine down. A smaller size, fewer "
                       f"frames or a smaller checkpoint will fit.\n" + out)
            if not ok:
                kept = keep_the_whole_log(backend, out, argv=argv,
                                          seconds=secs,
                                          code=proc.returncode)
                core.log_line("forge",
                              f"{backend} exited {proc.returncode} after "
                              f"{_span(secs)}: {_explain(out)}"
                              + (f" | full output: {kept}" if kept else ""))
            _record(backend, ok, "" if ok else _explain(out), secs)
            return ok, out, secs
        except Exception as e:
            secs = time.time() - started
            out = "\n".join(buf).strip()
            kept = keep_the_whole_log(backend, f"{type(e).__name__}: {e}\n\n"
                                      + out, argv=argv, seconds=secs,
                                      code="raised")
            core.log_line("forge",
                          f"{backend} raised after {_span(secs)}: "
                          f"{type(e).__name__}: {e}"
                          + (f" | full output: {kept}" if kept else ""))
            _record(backend, False, f"{type(e).__name__}: {e}", secs)
            return False, f"{type(e).__name__}: {e}\n{out[-600:]}", secs
        finally:
            guard.stop()
            self._child = None
            _progress_clear()

    def cancel(self) -> bool:
        """
        THE USER IS THE DEADLINE.

        Removing the timeouts is only defensible if there is still a way to
        stop something - so this is it, and it is a person watching a
        progress bar rather than a constant chosen months ago on different
        hardware.
        """
        proc = getattr(self, "_child", None)
        if proc is None:
            return False
        core.log_line("forge", "generation cancelled by the user")
        try:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except Exception:
                proc.kill()
        except Exception:
            return False
        return True


def keep_the_whole_log(backend: str, output: str, *, argv=None,
                       seconds: float = 0.0, code=None) -> str:
    """
    Write everything a failed generator printed to its own file, and return
    the path.

    WHY THIS EXISTS

        "we should know what went wrong even if it cannot ... 100% or as
         close to a whole 100% as is possible with what we have"

    Three things saw a failure and all three saw a summary of it. The model
    got _explain()'s one sentence (220 characters). The ledger got the same
    sentence truncated to 240. forge.log got the last 400 characters, which
    on four real failures was the tail of a loading bar. The four thousand
    lines the generator actually printed were dropped on the floor when the
    deque went out of scope - so the one moment where the whole story
    existed was the one moment nobody could read it later.

    A summary is a guess about which part mattered, made before anybody has
    read the thing. Make the guess for the model, which has a small context
    and needs one sentence; keep the whole file for us, who do not.

    Failures only. A run that worked has nothing to diagnose.
    """
    try:
        folder = core.LOGS / "failures"
        folder.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y-%m-%d %H%M%S")
        path = folder / f"{stamp} {backend}.log"
        head = [f"backend : {backend}",
                f"when    : {stamp}",
                f"ran for : {_span(seconds)} ({seconds:.1f}s)",
                f"exit    : {code}",
                f"command : {' '.join(str(a) for a in (argv or [])) or '(n/a)'}",
                "",
                "EVERYTHING IT PRINTED, IN FULL, BELOW.",
                "=" * 70, ""]
        path.write_text("\n".join(head) + (output or ""), encoding="utf-8",
                        errors="replace")
        # PRUNE BY COUNT, NEVER BY AGE. The failure worth reading is often
        # the oldest one in a pattern.
        keep = sorted(folder.glob("* *.log"))
        for old_file in keep[:-200]:
            try:
                old_file.unlink()
            except OSError:
                pass
        return str(path)
    except Exception as e:
        core.log_line("forge", f"could not keep the failure log: {e}")
        return ""


def _explain(output: str) -> str:
    """Turn a generator's last words into something a person can act on."""
    low = (output or "").lower()
    if "out of memory" in low or "cuda error" in low or "cudamalloc" in low:
        # Phrased as what happened, not as what is possible. "does not fit on
        # this card" is a claim about the future; the run only measured one
        # size, on one checkpoint, with whatever else was resident at the
        # time. Nova quoted the old wording back to the user as a reason not
        # to try, for weeks.
        return ("ran out of video memory at that size - a smaller size, "
                "fewer steps or a smaller checkpoint usually fits")
    if "no such file" in low or "failed to open" in low or "not found" in low:
        return "a model file it needed was missing or unreadable"
    if "unsupported" in low or "unknown model" in low:
        return "the runtime did not recognise this checkpoint format"
    # THE TAIL IS THE WRONG END OF THE LOG.
    #
    # Taking the last 220 characters recorded this, four times, as the
    # reason a video failed:
    #
    #     |####################################| 108/108 - 626.91MB/s
    #     model_loader.cpp:1229 - loading tensors completed, taking 0.22s
    #
    # That is a progress bar and a success message. The actual event -
    # sampling had completed and something else stopped the run - was
    # further up, and the ledger now holds four rows whose "reason" is a
    # picture of a loading bar.
    #
    # A generator says what went wrong on a line that says so. Look for
    # that line first, from the end backwards, and only fall back to the
    # tail when there is genuinely nothing else.
    lines = [l.strip() for l in (output or "").splitlines() if l.strip()]
    for line in reversed(lines):
        flat = " ".join(line.split())
        if len(flat) < 8 or "|" in flat or "%" in flat:
            continue          # a progress bar is not an explanation
        if re.search(r"(?i)\b(error|failed|fail|assert|exception|cannot|"
                     r"could not|unable|denied|refused|missing|no such|"
                     r"out of memory|abort)\b", flat):
            return flat[:220]
    # Nothing said it failed. Say THAT, rather than quoting the last thing
    # that scrolled past - a run that completed its work and then stopped
    # is a different fault from one that errored, and the difference is
    # exactly what was lost here.
    done = any(re.search(r"(?i)completed|finished|done", l) for l in lines)
    # AND THE FALLBACK TAIL MUST NOT BE A BAR EITHER.
    #
    # Searching backwards for a real error line was half the fix. When there
    # is no error line at all - a run that finished its work and was then
    # stopped by something else - this fell back to the raw tail, which on
    # every one of those four ledger rows was a picture of a loading bar.
    # A bar carries no information in any position, so bar lines are dropped
    # here before the tail is taken.
    plain = [l for l in lines
             if "|" not in l and "#" not in l and "%" not in l
             and not re.match(r"^\s*\[?[a-z]*\]?\s*[\[|#=.\s]*$", l)]
    tail = " ".join(" ".join(plain).split())[-220:]
    if done:
        return ("it ran to the end and then stopped without reporting an "
                "error - the last thing it printed was: " + tail[-140:])
    return tail or "the generator produced no output and no error"


# ═══════════════════════════════════════════════════════════════════════════
#  THE THREE GENERATORS
#
#  Each one is a method on Session so that a caller can chain several inside
#  a single stop/start of Nova. Each returns a Path in the Playground, which
#  is the model-writable workspace - never the Vault, which holds the user's
#  protected originals.
# ═══════════════════════════════════════════════════════════════════════════

def _unique(name: str) -> Path:
    playground.ensure()
    target = playground.ROOT / _clean(name)
    if not target.exists():
        return target
    stem, suf = target.stem, target.suffix
    for i in range(2, 100000):
        cand = target.with_name(f"{stem} ({i}){suf}")
        if not cand.exists():
            return cand
    raise RuntimeError("could not find a free filename in the Playground")


# Words that describe nothing about a picture. Stripped from a generated
# filename so the part that survives is the part that identifies it.
_FILLER = {
    "a", "an", "the", "of", "in", "on", "at", "to", "with", "and", "or",
    "for", "from", "by", "is", "are", "was", "were", "be", "being", "it",
    "its", "this", "that", "there", "here", "very", "really", "quite",
    "some", "any", "more", "most", "into", "over", "under", "out",
    "please", "make", "made", "generate", "generated", "generating",
    "create", "created", "creating", "image", "picture", "photo", "render",
    "rendering", "video", "clip", "model", "3d", "me", "my", "you", "your",
    "can", "could", "would", "should", "want", "need", "show", "give",
}


def _describe(prompt: str, suffix: str, limit: int = 44) -> str:
    """
    A filename that says what the file IS.

    Everything used to be called generated.png, generated_3d.glb or
    source_for_3d.png, so a Playground of a dozen results was
    generated.png, generated (2).png, generated (3).png - unidentifiable to
    the user and, worse, unidentifiable to the model, which then cannot
    refer back to one of them without opening every one.

    A timestamp sorts them and makes them unique; a few content words from
    the prompt say which is which:

        2026-09-01 1432 girl swing sunset tropical beach.png
        2026-09-01 1447 goku super saiyan.png

    Short enough to read in a list, long enough to tell apart, and stable -
    the same prompt at the same minute would still differ by the (2) suffix
    that _unique adds.
    """
    stamp = time.strftime("%Y-%m-%d %H%M")
    words = []
    for w in re.findall(r"[A-Za-z0-9']+", str(prompt or "")):
        lw = w.lower()
        if lw in _FILLER or len(lw) < 2:
            continue
        if lw not in words:
            words.append(lw)
        if len(" ".join(words)) >= limit:
            break
    subject = " ".join(words)[:limit].strip() or "untitled"
    return f"{stamp} {subject}{suffix}"


def _preferred_image_model(models: list):
    """
    Which checkpoint to use when the caller did not name one.

    Was models[0] - alphabetical, which is not a quality ordering by any
    measure. A fine-tune beats the raw 2022 base weights at everything a
    person actually asks for, so if one is present it is the default.
    """
    if not models:
        return None
    def rank(m):
        n = m["name"].lower()
        base = ("stable-diffusion-v1-5" in n or "sd-v1-5" in n
                or "v1-5-pruned" in n)
        xl = "xl" in n
        return (0 if base else (2 if xl else 1), m.get("size_mb", 0))
    return max(models, key=rank)


def _clean(name: str) -> str:
    name = Path(str(name).replace("\\", "/")).name or "generated"
    name = "".join(c if (c.isalnum() or c in "._-() ") else "_" for c in name)
    return name.strip() or "generated"


def _sidecar(target: Path, meta: dict) -> None:
    """What produced this file, beside the file. Nova can read it back."""
    try:
        target.with_name(target.stem + ".generation.json").write_text(
            json.dumps(meta, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass


def _threads() -> int:
    try:
        return max(1, min(8, int(core.load().get("runtime", {})
                                 .get("threads", 4) or 4)))
    except Exception:
        return 4


class _GenMixin:
    # ---------------------------------------------------------- images

    def image(self, *, prompt: str, negative: str | None = None,
              width: int = 0, height: int = 0, steps: int = 0,
              seed: int = -1, cfg_scale: float = 0.0,
              init_image: Path | None = None, strength: float = 0.6,
              model: str | None = None, hires: bool = True,
              filename: str = "") -> Path:
        """
        Text to image, or image to image when init_image is given.

        Every generation setting defaults to the PRESET for the checkpoint in
        use rather than to one fixed number, because the right value differs
        by an order of magnitude between families. A caller that passes a
        value wins; a caller that passes nothing gets settings that suit the
        model actually loaded.
        """
        exe = sd_exe()
        if exe is None:
            raise RuntimeError(
                "the image runtime is not installed. INSTALL.bat downloads "
                "it; llm\\gen\\sd should contain sd-cli.")
        chosen = None
        models = image_models()
        if model:
            chosen = next((m for m in models
                           if model.lower() in m["name"].lower()), None)
        if chosen is None:
            chosen = _preferred_image_model(models)
        if chosen is None:
            raise RuntimeError(
                "there is no image checkpoint in llm\\gen\\models. Any SD or "
                "Flux checkpoint (.gguf or .safetensors) dropped in there is "
                "picked up automatically.")

        pre = model_preset(chosen["name"])
        width = int(width or pre["width"])
        height = int(height or pre["height"])
        steps = int(steps or pre["steps"])
        cfg_scale = float(cfg_scale or pre["cfg"])
        if negative is None:
            negative = pre["negative"]

        out = _unique(filename or _describe(prompt, ".png"))
        argv = [exe, "-M", "img_gen", "-m", chosen["path"],
                "-p", prompt[:2000], "-o", str(out),
                "-W", width, "-H", height,
                "--steps", steps, "--cfg-scale", cfg_scale,
                "-s", int(seed), "-t", _threads(),
                "--sampling-method", pre["sampler"],
                "--scheduler", pre["scheduler"],
                # OFFLOADING BUYS THE ABILITY TO RUN AND COSTS TIME, SO IT
                # IS NOW SPENT IN PROPORTION.
                #
                # Every one of these was on for every image. Measured result:
                # 716 seconds for one 1024px SDXL turbo render at 8 steps -
                # twelve minutes, with the language model stopped throughout.
                # stable-diffusion.cpp's own documentation is blunt about why:
                # aggressive offloading "trades VRAM for speed", and moving
                # the VAE decode to the CPU at 1024px is the most expensive
                # single thing in that list.
                #
                # --vae-tiling and --diffusion-fa are cheap and stay on
                # always: tiling bounds the decode's peak memory, flash
                # attention removes the big intermediate matrices. The two
                # expensive ones are now applied only where the size actually
                # needs them, and _run_image_with_retry below re-adds them
                # and drops the size if the card says no.
                "--vae-tiling", "--diffusion-fa"]
        heavy = (width * height) > (768 * 768)
        if heavy:
            argv += ["--offload-to-cpu", "--vae-on-cpu", "--clip-on-cpu"]
        else:
            argv += ["--offload-to-cpu"]

        if int(pre["clip_skip"]) > 0:
            argv += ["--clip-skip", int(pre["clip_skip"])]
        if negative:
            argv += ["-n", negative[:1200]]
        if init_image is not None:
            argv += ["-i", str(init_image), "--strength", float(strength)]
        elif hires and pre["family"] == "sd15":
            # A face a fifth of the way across a 512px frame is about a
            # hundred pixels wide, which is not enough for eyes whatever the
            # step count. The second pass renders small and then re-denoises
            # at double, which is the standard fix and the reason faces stop
            # melting. Only for SD1.5: SDXL already renders at 1024.
            argv += ["--hires", "--hires-scale", 2.0,
                     "--hires-denoise", 0.45]

        ok, log, secs = self._run("image", argv)
        if not ok or not out.exists():
            # --hires is newer than some builds. If that is what it choked
            # on, the picture still matters more than the second pass.
            if "--hires" in [str(a) for a in argv] and (
                    "unknown" in log.lower() or "unrecognized" in log.lower()
                    or "invalid" in log.lower()):
                core.log_line("forge", "this sd-cli build has no --hires; "
                                       "generating single-pass instead")
                argv = [a for a in argv
                        if str(a) not in ("--hires", "--hires-scale",
                                          "--hires-denoise", "2.0", "0.45")]
                ok, log, secs = self._run("image", argv)
            # THE LADDER. One rung down, then report.
            #
            # An out-of-memory failure at 768 is not "this machine cannot
            # make pictures", it is "not at that size". The user asked for a
            # picture, not for a diagnosis, and one more attempt inside the
            # same request is cheaper than the round trip of explaining and
            # being told to try again. It also fills the ledger with real
            # data about what DOES fit on 4 GB, which is the only way anyone
            # finds out.
            if not ok or not out.exists():
                low = (log or "").lower()
                oom = ("out of memory" in low or "cudamalloc" in low
                       or "cuda error" in low or "alloc" in low)
                if oom and (width > 512 or height > 512):
                    nw, nh = max(512, width // 2), max(512, height // 2)
                    core.log_line("forge",
                                  f"{width}x{height} did not fit; "
                                  f"retrying at {nw}x{nh} fully offloaded")
                    argv2 = []
                    skip = False
                    for a in argv:
                        if skip:
                            skip = False
                            continue
                        if str(a) in ("-W", "-H"):
                            skip = True
                            continue
                        argv2.append(a)
                    argv2 += ["-W", nw, "-H", nh]
                    for flag in ("--vae-on-cpu", "--clip-on-cpu",
                                 "--offload-to-cpu"):
                        if flag not in [str(x) for x in argv2]:
                            argv2.append(flag)
                    ok, log, secs = self._run("image", argv2)
                    if ok and out.exists():
                        width, height = nw, nh
            if not ok or not out.exists():
                raise RuntimeError("image generation failed - " + _explain(log))
        _sidecar(out, {"kind": "image", "prompt": prompt,
                       "negative_prompt": negative, "model": chosen["name"],
                       "preset": pre["family"],
                       "width": width, "height": height, "steps": steps,
                       "seed": seed, "cfg_scale": cfg_scale,
                       "sampler": pre["sampler"], "scheduler": pre["scheduler"],
                       "init_image": str(init_image) if init_image else None,
                       "backend": "stable-diffusion.cpp",
                       "seconds": round(secs, 1)})
        return out

    # ---------------------------------------------------------- video

    def video(self, *, prompt: str, negative: str = "",
              width: int = 480, height: int = 320, frames: int = 33,
              steps: int = 20, seed: int = -1, cfg_scale: float = 6.0,
              init_image: Path | None = None,
              filename: str = "") -> Path:
        """
        Text to video, or image to video when init_image is given.

        Wan needs three separate files - the diffusion model, its VAE and the
        umt5 text encoder - and sd-cli takes them as three flags. Small
        defaults on purpose: 480x320x33 is about a second and a half, and it
        is the difference between a clip that finishes on this card and one
        that does not.
        """
        exe = sd_exe()
        if exe is None:
            raise RuntimeError("the video runtime is not installed - "
                               "run INSTALL.bat")
        parts = _video_parts()
        missing = [k for k, v in parts.items() if v is None]
        if missing:
            raise RuntimeError(
                "video needs three files in llm\\gen\\models and these are "
                f"missing: {', '.join(missing)} (the Wan diffusion model, its "
                "VAE, and the umt5 text encoder)")

        # WILL THIS EVEN FIT. Asked before it is attempted, because the
        # answer is knowable from the file sizes and the alternative is
        # finding out by taking the machine down. Video is the one that
        # does it: the low-VRAM flags move 3.6 GB of weights into system
        # RAM by design.
        # A WARNING, NOT A REFUSAL. This used to raise and never start.
        #
        #     "we are trying to see if its possible in the first place"
        #
        # Refusing on an ESTIMATE is the same mistake as a timeout wearing a
        # different coat: a number picked in advance deciding that something
        # will not work, so it never gets the chance to. The estimate here
        # is the sum of three file sizes plus a margin somebody guessed, and
        # it has never once been checked against a run that actually
        # happened. It has no business ending anything.
        #
        # So it says what it expects and then gets out of the way. The
        # machine still cannot be taken down - the guard inside _run watches
        # real free memory while it runs - but that fires on what is
        # measured, not on what was predicted.
        fits, why = room_for([parts["diffusion"], parts["vae"], parts["t5"]])
        if not fits:
            # Still only a note. This one IS an estimate - a margin somebody
            # picked, added to three file sizes - and an estimate has no
            # business ending anything. The arithmetic that can refuse lives
            # in _run() and compares two measurements with no margin at all.
            core.log_line("forge", "video may be tight: " + why
                          + " - starting anyway")

        out = _unique(filename or _describe(prompt, ".mp4"))
        argv = [exe, "-M", "vid_gen",
                "--diffusion-model", str(parts["diffusion"]),
                "--vae", str(parts["vae"]),
                "--t5xxl", str(parts["t5"]),
                "-p", prompt[:2000], "-o", str(out),
                "-W", int(width), "-H", int(height),
                "--video-frames", int(frames),
                "--steps", int(steps), "--cfg-scale", float(cfg_scale),
                "--sampling-method", "euler", "--flow-shift", 3.0,
                "-s", int(seed), "-t", _threads()] + sd_flags(LOW_VRAM_VIDEO)
        if negative:
            argv += ["-n", negative[:1000]]
        if init_image is not None:
            argv += ["-i", str(init_image)]

        ok, log, secs = self._run("video", argv)
        produced = out if out.exists() else _find_recent(
            playground.ROOT, VIDEO_EXTS | IMAGE_EXTS, self.t0)

        # THE LADDER IS STILL WORTH HAVING - it just is not the main event
        # any more. With the encoder and VAE off the card, what is left that
        # scales with frame size is the diffusion model's own working set,
        # and that one genuinely does get smaller when the picture does.
        #
        # It runs second, after the flags, because a ladder is how you find
        # the largest size that fits, not how you make something fit at all.
        if (not ok or produced is None):
            low = (log or "").lower()
            oom = ("out of memory" in low or "cudamalloc" in low
                   or "cuda error" in low or "alloc" in low)
            if oom and (width > 320 or frames > 17):
                nw, nh, nf = max(320, width // 2), max(192, height // 2), 17
                core.log_line("forge",
                              f"{width}x{height}x{frames} did not fit; "
                              f"retrying at {nw}x{nh}x{nf}")
                argv2, skip = [], False
                for a in argv:
                    if skip:
                        skip = False
                        continue
                    if str(a) in ("-W", "-H", "--video-frames"):
                        skip = True
                        continue
                    argv2.append(a)
                argv2 += ["-W", nw, "-H", nh, "--video-frames", nf]
                ok, log, secs = self._run("video", argv2)
                produced = out if out.exists() else _find_recent(
                    playground.ROOT, VIDEO_EXTS | IMAGE_EXTS, self.t0)
                if ok and produced is not None:
                    width, height, frames = nw, nh, nf

        if not ok or produced is None:
            raise RuntimeError("video generation failed - " + _explain(log))
        _sidecar(produced, {"kind": "video", "prompt": prompt,
                            "negative_prompt": negative,
                            "diffusion_model": parts["diffusion"].name,
                            "width": width, "height": height,
                            "frames": frames, "steps": steps, "seed": seed,
                            "backend": "stable-diffusion.cpp (Wan)",
                            "seconds": round(secs, 1)})
        return produced

    # ---------------------------------------------------------- 3D

    def mesh_from_image(self, image: Path, *, resolution: int = 512,
                        seed: int = -1,
                        filename: str = "") -> Path:
        """
        A picture to a textured mesh, through TRELLIS.

        Raises rather than falling back, because the caller decides whether a
        built-in relief mesh is an acceptable substitute for this - and for
        some requests it is not.
        """
        kind, exe = trellis_backend()
        if not kind:
            raise RuntimeError("the 3D runtime is not installed - "
                               "run INSTALL.bat")
        weights = _scan(TRELLIS_MODELS, (".gguf",))
        if len(weights) < 6:
            raise RuntimeError(
                f"the TRELLIS weights are incomplete - {len(weights)} file(s) "
                f"in llm\\gen\\trellis-models, expected the full set")

        out = _unique(filename or _describe(image.stem, ".glb"))
        # THE INTERFACE, AS IT ACTUALLY IS.
        #
        # This was written from a guess and was wrong in every particular:
        #
        #   guessed                     actual
        #   --input FILE                positional, first
        #   --output FILE               positional, second
        #   --model-dir DIR             --models DIR
        #   --bg-removal                --bg-removal threshold|birefnet
        #                               (it takes a VALUE; bare, it ate the
        #                                next argument)
        #
        #   trellis-cli assets/goblin.png out/goblin.glb
        #
        # birefnet is the better background remover and its weights are part
        # of the set the installer already downloads, so there is no reason
        # to use the threshold fallback here.
        # RES 512, AND NO --require-gpu. BOTH DELIBERATE.
        #
        # trellis.cpp targets 16 GB of VRAM, and the Q4 weights still want
        # about 6 GB. This card has 4. On paper that is the end of the
        # conversation - except the CLI carries "an optional fallback to the
        # (very slow, RAM-hungry) CPU path", and this machine has 9.4 GB of
        # system RAM free.
        #
        # So: --res 512 selects the lighter cascade rather than the 1024 one,
        # and --require-gpu is deliberately NOT passed, which is what leaves
        # the CPU fallback available when the card cannot hold the graph.
        # Passing it would turn a slow real mesh into an instant failure.
        #
        # It will take a long time. That is a trade the user made explicitly:
        # nothing else is running, the language model is stopped for the
        # duration anyway, and a statue in twenty minutes beats a plaque in
        # two.
        # THE SERVER IS THE INTERFACE, because it is what ships.
        #
        # Every prebuilt Windows archive contains trellis-server.exe and no
        # CLI. Two previous attempts here got this wrong in opposite
        # directions - one ran the server with CLI flags it cannot parse, the
        # other refused it and waited for a binary that does not exist - and
        # in between, every 3D request quietly became a flat relief.
        #
        # Up for one mesh, down again in the finally: a resident 693 MB
        # process would hold the memory Nova needs to come back into.
        if kind == "server":
            # TWO PHASES, RECORDED SEPARATELY.
            #
            #     "the 3D generator has no real measurement to if it even
            #      starts or how long it takes"
            #
            # It had one row per request, so "the runtime never came up" and
            # "the runtime came up and the mesh failed" were the same line in
            # the ledger with the same duration. They are completely
            # different faults - one is an install problem, the other is a
            # generation problem - and nothing could tell them apart.
            #
            # model3d_start  did the server answer /health, and after how long
            # model3d        did the mesh get built, and after how long
            t0 = time.time()
            svc = TrellisService(exe, TRELLIS_MODELS)
            started = False
            try:
                svc.start()
                started = True
                up = time.time() - t0
                _record("model3d_start", True, "", up)
                core.log_line("forge",
                              f"3D runtime up in {up:.0f}s; building the mesh "
                              f"now - there is no time limit on this")
                # The clock restarts here so `elapsed` measures the MESH,
                # not the mesh plus however long six GGUFs took to load.
                _progress_start("model3d", self.what or "3D: building the mesh")
                t0 = time.time()
                svc.generate(image, out, resolution=int(resolution),
                             seed=int(seed), bg_removal="birefnet")
                ok, log = True, ""
            except Exception as e:
                if not started:
                    _record("model3d_start", False,
                            _explain(f"{type(e).__name__}: {e}"),
                            time.time() - t0)
                # THE WHOLE REASON, NOT A CATEGORY.
                #
                # This used to keep only type and message, and _explain()
                # then mapped it to a short phrase. Both of those are
                # summaries, and a summary of an error nobody has read yet
                # is a guess. The server's own last words ride along.
                ok = False
                log = f"{type(e).__name__}: {e}"
                whole = (f"{type(e).__name__}: {e}\n\n"
                         + "\n".join(svc.log))
                kept = keep_the_whole_log(
                    "model3d" if started else "model3d_start", whole,
                    argv=[str(exe), "--models", str(TRELLIS_MODELS)],
                    seconds=time.time() - t0, code="raised")
                if svc.log and svc.said(200) not in log:
                    log += f" | server log: {svc.said(600)}"
                core.log_line("forge", "trellis failed - " + log[:1200]
                              + (f" | full output: {kept}" if kept else ""))
            finally:
                svc.stop()
            secs = time.time() - t0
            _progress_clear()
            self.steps.append("model3d")
            if started:
                _record("model3d", ok, "" if ok else _explain(log), secs)
            if not ok or not out.exists():
                if ok and not out.exists():
                    log = ("the server reported success but wrote no file to "
                           f"{out.name}")
                # NAME THE PHASE. "3D generation failed" was true of both an
                # install fault and a generation fault, and the model passed
                # that single sentence on to the user either way.
                phase = ("the 3D runtime never started, so nothing was built"
                         if not started else
                         f"the 3D runtime started fine and ran {_span(secs)}, "
                         f"then the mesh step failed")
                raise RuntimeError(f"3D generation failed - {phase}. "
                                   + log[:900])
        else:
            argv = [exe, str(image), str(out),
                    "--models", str(TRELLIS_MODELS),
                    "--res", int(resolution),
                    "--bg-removal", "birefnet"]
            if int(seed) >= 0:
                argv += ["--seed", int(seed)]
            ok, log, secs = self._run("model3d", argv)
            if not ok or not out.exists():
                raise RuntimeError("3D generation failed - " + _explain(log))
        _sidecar(out, {"kind": "model3d", "source_image": image.name,
                       "resolution": resolution, "seed": seed,
                       "backend": "trellis.cpp", "seconds": round(secs, 1)})
        return out


class Session(Session, _GenMixin):      # noqa: F811  - compose the mixin in
    pass


def _find_recent(folder: Path, exts: set, after: float) -> Path | None:
    """The newest matching file written since `after`. For binaries that
    choose their own output name despite being told one."""
    best, best_t = None, after
    try:
        for p in folder.rglob("*"):
            if p.is_file() and p.suffix.lower() in exts:
                t = p.stat().st_mtime
                if t >= best_t:
                    best, best_t = p, t
    except OSError:
        pass
    return best
