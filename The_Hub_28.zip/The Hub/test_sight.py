"""
test_sight.py - the four ways an image failed to reach a model that could see.

All four were reported from one real session, and all four are the same
shape of bug: the picture never arrived, and nothing said so.

  1. THE EYE BUTTON. The camera frame was written to data/incoming-image with
     no file extension. encode_for_model() maps an EXTENSION to a mime type,
     found none, and returned "" - so the frame was dropped. A vault photo
     called IMG_0254.JPG worked, which is exactly why the button looked
     broken while the model was obviously not blind. Pillow hid it during
     development by sniffing content itself; Pillow is not installed on a
     real install.

  2. THE SECOND ATTACHMENT. Published images had a 120-second wall-clock TTL.
     The URL goes into the prompt and llama-server fetches it only AFTER the
     tool phase and prompt processing - which on this hardware can be more
     than two minutes for a second image in a longer conversation. The token
     expired, the fetch 404'd, and the model got the sentence "Attached user
     file: X (image)" with no image behind it. It then did the sensible
     thing: tried to call open_file on the path it had just been told about.

  3. CAMERA PLUS PAPERCLIP. The camera branch rebuilt the message content
     from last["content"] - which the attachment code above it may already
     have turned into a LIST of parts. Wrapping a list in
     {"type":"text","text": ...} stringified it and threw the attachment
     away.

  4. THE LEAKED TOOL CALL. When a GGUF's chat template cannot round-trip its
     own control tokens, the call lands in message.content and is streamed to
     the user as text:
         <|tool_call>call:open_file{path:<|"|>...<|"|>}<tool_call|>
"""
from __future__ import annotations

import io
import os
import struct
import sys
import tempfile
import time
import zlib
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

C = {"g": "\033[92m", "r": "\033[91m", "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0}


def check(label, cond, detail=""):
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


TMP = Path(tempfile.mkdtemp(prefix="hub-sight-"))
import core                                                       # noqa: E402
core.DATA = TMP / "data"
core.LOGS = core.DATA / "logs"
core.WRITABLE = (core.DATA, core.LOGS)
core.DATA.mkdir(parents=True, exist_ok=True)
core.LOGS.mkdir(parents=True, exist_ok=True)

import toolcall                                                   # noqa: E402
import vision                                                     # noqa: E402


def a_jpeg() -> bytes:
    """A real JPEG, the way a browser canvas produces one."""
    try:
        from PIL import Image
        buf = io.BytesIO()
        Image.new("RGB", (48, 32), (180, 40, 40)).save(buf, "JPEG")
        return buf.getvalue()
    except Exception:
        # Minimal but genuinely JPEG-signatured bytes are enough for the
        # sniffing and extension logic under test.
        return b"\xff\xd8\xff\xe0" + b"\x00" * 128 + b"\xff\xd9"


def a_png() -> bytes:
    import binascii
    w = h = 16
    row = bytearray()
    for x in range(w):
        row += bytes((x * 15 % 256, 90, 30))
    raw = b"".join(b"\x00" + bytes(row) for _ in range(h))

    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", binascii.crc32(tag + data) & 0xffffffff))
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


class NoPillow:
    """Every real install. The shipped Python is embedded, with no pip."""

    def __enter__(self):
        import builtins
        self._real = builtins.__import__

        def blocked(name, *a, **k):
            if name.split(".")[0] == "PIL":
                raise ImportError("No module named 'PIL'")
            return self._real(name, *a, **k)
        builtins.__import__ = blocked
        return self

    def __exit__(self, *exc):
        import builtins
        builtins.__import__ = self._real
        return False


def main() -> int:
    print("\n1. THE CAMERA FRAME, ON A MACHINE WITH NO IMAGE LIBRARY")
    jpg = a_jpeg()
    png = a_png()
    noext = core.DATA / "incoming-image"
    noext.write_bytes(jpg)

    check("the bytes are identified without a filename",
          vision.sniff_image_mime(jpg) == "image/jpeg",
          vision.sniff_image_mime(jpg))
    check("PNG too", vision.sniff_image_mime(png) == "image/png")
    check("and an extension is derived from the type",
          vision.extension_for_mime("image/jpeg") == ".jpg")

    with NoPillow():
        got = vision.encode_for_model(noext)
    check("an extension-less frame still encodes - THE EYE BUTTON BUG",
          got.startswith("data:image/jpeg;base64,"),
          "empty - the frame would be silently dropped" if not got
          else got[:38])

    ext = vision.extension_for_mime(vision.sniff_image_mime(jpg))
    withext = core.DATA / ("incoming-image" + ext)
    withext.write_bytes(jpg)
    with NoPillow():
        got2 = vision.encode_for_model(withext)
    check("and the named path server.py now writes also encodes",
          got2.startswith("data:image/jpeg;base64,"))

    check("something that is not an image is still refused",
          vision.sniff_image_mime(b"this is a text file") == "")

    print("\n2. A PUBLISHED IMAGE OUTLIVES A SLOW TURN")
    vision.release_turn()
    url = vision.publish_image(jpg, "image/jpeg")
    token = url.rsplit("/", 1)[-1]
    check("publishing returns a loopback URL on The Hub's own port",
          f":{core.UI_PORT}/api/vlm-image/" in url, url)
    check("the safety expiry is far longer than a slow prompt",
          vision._IMAGE_TTL >= 900,
          f"{vision._IMAGE_TTL:.0f}s - it was 120s, which a 32k prompt on "
          f"this hardware can exceed before llama-server ever fetches it")
    served = vision.serve_image(token)
    check("it serves", served is not None and served[0] == jpg)
    check("and it serves AGAIN - one fetch does not consume it",
          vision.serve_image(token) is not None)

    for _ in range(40):
        vision.publish_image(png, "image/png")
    check("the number held is capped so nothing grows without bound",
          vision.published_count() <= vision._IMAGE_MAX,
          f"{vision.published_count()} held, cap {vision._IMAGE_MAX}")

    freed = vision.release_turn()
    check("the turn ending releases them all", freed > 0
          and vision.published_count() == 0, f"released {freed}")
    check("and a released token stops serving",
          vision.serve_image(token) is None)

    print("\n3. A LEAKED TOOL CALL IS RECOVERED, NOT SHOWN")
    offered = {"open_file", "clock", "calculator", "web_search", "generate_3d"}
    leak = ('<|tool_call>call:open_file{path:<|"|>'
            'Chat/chat-mti6v7ff/IMG_1110.JPG<|"|>}<tool_call|>')
    name, args, rest = toolcall.recover(leak, offered)
    check("the exact text from the real session is recognised",
          name == "open_file", f"got {name!r}")
    check("and its argument survives intact",
          args.get("path") == "Chat/chat-mti6v7ff/IMG_1110.JPG", str(args))
    check("nothing of it is left to show the user", rest == "")

    for text, label in (
            ('{"name": "clock", "arguments": {}}', "a plain JSON call"),
            ('<tool_call>{"name":"web_search","arguments":{"query":"x"}}</tool_call>',
             "an XML-tagged call")):
        n2, _, _ = toolcall.recover(text, offered)
        check(f"{label} is recovered", n2 is not None, f"got {n2!r}")

    print("\n   ...and ordinary text is left completely alone:")
    for text, label in (
            ("The answer is 42.", "a normal answer"),
            ("You would call open_file with the name of the file you want, "
             "and then read what comes back.", "prose that mentions a tool"),
            ("In Python, sorted({3,1,2}) returns a list.", "unrelated code"),
            ("I will look at that now and tell you what I see.", "plain prose")):
        n3, _, kept = toolcall.recover(text, offered)
        check(f"{label} is not treated as a call", n3 is None and kept == text)

    check("a tool that is NOT offered is never recovered",
          toolcall.recover('{"name":"rm_rf","arguments":{}}', offered)[0] is None,
          "the offered set is the only authority on what exists")

    print("\n4. CONTROL-TOKEN DEBRIS NEVER REACHES THE USER")
    check("debris is detected", toolcall.looks_like_leaked_markup(leak))
    check("clean text is not flagged",
          not toolcall.looks_like_leaked_markup("A perfectly normal reply."))
    scrubbed = toolcall.scrub("Here you go <|channel|> and that is all.")
    check("scrubbing removes the markers and keeps the words",
          "<|" not in scrubbed and "Here you go" in scrubbed, scrubbed)

    import shutil
    shutil.rmtree(TMP, ignore_errors=True)
    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
