"""
testkit.py - run pytest-style test files without pytest.

WHY THIS EXISTS

test_assets.py, test_active_memory.py and test_workspace_shared.py were
written as pytest modules: bare `test_*` functions, some taking a `tmp_path`
fixture, and no `__main__` block. Running `python test_assets.py` therefore
imported the file, defined the functions, called none of them, and exited 0.

Three green ticks that had never executed a single assertion. And pytest is
not installed - The Hub ships a private embedded Python with no pip - so
these files could not run on a real install either.

This is the smallest thing that makes them real: discover the test functions,
give `tmp_path` a temporary directory, run them, report each one by name, and
exit non-zero if any fail. Same output shape as the hand-written suites, so
TEST.bat and verify.py can treat every file the same way.
"""
from __future__ import annotations

import inspect
import os
import sys
import tempfile
import traceback
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

C = {"g": "\033[92m", "r": "\033[91m", "d": "\033[90m", "x": "\033[0m"}


def run(namespace: dict, title: str = "") -> int:
    """Run every test_* callable in `namespace`. Returns a process exit code."""
    tests = [(n, f) for n, f in sorted(namespace.items())
             if n.startswith("test_") and callable(f)]
    if not tests:
        print(f"{C['r']}NO TESTS FOUND{C['x']} - a test file that runs nothing "
              f"is a failure, not a pass.")
        return 1

    if title:
        print(f"\n{title}")
    passed = failed = 0
    for name, fn in tests:
        try:
            params = inspect.signature(fn).parameters
        except (TypeError, ValueError):
            params = {}
        with tempfile.TemporaryDirectory(prefix="hub-test-") as td:
            kwargs = {}
            if "tmp_path" in params:
                kwargs["tmp_path"] = Path(td)
            try:
                fn(**kwargs)
                print(f"  {C['g']}ok{C['x']}    {name}")
                passed += 1
            except Exception as e:
                print(f"  {C['r']}FAIL{C['x']}  {name}")
                tb = traceback.format_exc().strip().splitlines()
                for line in tb[-4:]:
                    print(f"        {C['d']}{line.strip()}{C['x']}")
                failed += 1

    print(f"\n  {passed} passed, {failed} failed")
    return 1 if failed else 0
