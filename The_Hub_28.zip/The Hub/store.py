"""
store.py - how much room the memory has, measured from the machine it is on.

WHY THIS EXISTS
---------------
Everything else in The Hub that had a limit had an INVENTED one. A number
somebody typed while thinking about one particular laptop, which then
travelled to every other machine unchanged and was wrong on all of them. The
fit limiter is the long version of that story (ADR-142): a budget calibrated
for a 4 GB card, shipped as though it were a property of the universe.

Storage is the same question one layer out, and Zero named the rule:

    "the files stored should also be able to store lots as well, these
     should not be limited by anything other than an automatically
     understood 'computers limit.' ... give the user a 'Max limit' bar for
     the memories saved in amount of GB up to no other number but the
     computers limit being the max the user can choose to build into as the
     'chosen limit', this way we can scale when we install on a new device"

So there are exactly three numbers, and only one of them is a choice:

    USED       what data/ actually occupies, measured by walking it
    CHOSEN     the user's ceiling. 0 means "all of it" and is the default
    CEILING    what this computer can actually give, measured from the disk

CHOSEN can never exceed CEILING, and CEILING is never stored - it is measured
every time, because a machine's free space is not a property of the install.
Copy the folder to a bigger drive and the bar gets longer on its own. That is
the whole point: nothing here needs to be told about the new device.

NOTHING HERE DELETES ANYTHING
-----------------------------
This is a budget and a bar, not a reaper. The standing rule in this project is
that a memory that faded still exists - it falls to ash and stays - and the
event log is never trimmed, only rolled. A storage ceiling that deleted to
stay under itself would be the single most destructive thing in the
application, and it would do it silently, at 3am, to the oldest and therefore
most irreplaceable material.

What a full store does instead:

    it says so, with a breakdown of what is actually using the room
    a generation will not START (never a running one - see forge.py)
    purge.py remains the only thing that deletes, and it asks first

"A generation may fail because it never started, or because it ran and
errored. Never because a number ran out." Never starting is the permitted
failure, and it is the only one taken here.

THE OS GETS ITS SHARE FIRST
---------------------------
"What the computer can give" is not the same as "every free byte". Windows
needs room to page and to update, and a disk taken to zero does not report an
error - it corrupts things and stops booting. So the ceiling holds back the
larger of OS_RESERVE_GB or OS_RESERVE_FRACTION of the volume, and says so in
the interface rather than hiding it inside the arithmetic.
"""
from __future__ import annotations

import shutil
import threading
import time
from pathlib import Path

import core

# Held back from the ceiling so the machine still works. Not a margin for The
# Hub - a disk with no free space stops Windows paging and updating, and it
# fails by corrupting rather than by saying anything.
OS_RESERVE_GB = 8.0
OS_RESERVE_FRACTION = 0.05

# Walking data/ costs a stat() per file and the interface polls every two
# seconds. Held briefly, and dropped whenever anything asks it to be.
USED_TTL = 20.0

GB = 1073741824.0

_lock = threading.Lock()
_used = {"at": 0.0, "bytes": 0.0, "parts": {}}

# The folders the budget is about, in the order a person would want to read
# them. Everything under data/ counts; these are the ones worth naming.
PARTS = (
    ("made", "playground", "pictures, video and meshes Nova made"),
    ("conversations", "sessions", "every transcript, live and archived"),
    ("memories", "tree", "the living tree"),
    ("ash", "ash", "what faded - kept, never deleted"),
    ("knowledge", "knowledge", "what was worked out"),
    ("history", "events", "the append-only log everything can be rebuilt from"),
    ("attachments", "chat_attachments", "files brought into a conversation"),
    ("logs", "logs", "what each part wrote down"),
)


# ------------------------------------------------------------------ machine

def machine() -> dict:
    """
    What this computer actually is. Measured, never remembered.

    Called at install to report the machine, and by the interface to draw the
    bar. Nothing here is written to config: a stored measurement is how an
    application ends up describing the laptop it was built on forever.
    """
    out = {"disk_total_gb": 0.0, "disk_free_gb": 0.0, "ram_gb": 0.0,
           "vram_gb": 0.0, "where": str(core.ROOT)}
    try:
        du = shutil.disk_usage(str(core.ROOT))
        out["disk_total_gb"] = round(du.total / GB, 2)
        out["disk_free_gb"] = round(du.free / GB, 2)
    except Exception:
        pass
    try:
        import runtime
        ram = runtime.available_mb()
        if ram > 0:
            out["ram_gb"] = round(ram / 1024.0, 2)
        vram = runtime.vram_free_mb()
        if vram > 0:
            out["vram_gb"] = round(vram / 1024.0, 2)
    except Exception:
        pass
    return out


def os_reserve_gb() -> float:
    """What is held back from the ceiling so the machine keeps working."""
    try:
        total = shutil.disk_usage(str(core.ROOT)).total / GB
    except Exception:
        return OS_RESERVE_GB
    return round(max(OS_RESERVE_GB, total * OS_RESERVE_FRACTION), 2)


def ceiling_gb() -> float:
    """
    THE COMPUTER'S LIMIT. The largest ceiling the user may choose.

    Free space plus what we already hold - because the question is how big
    data/ may GROW TO, not how much more may be added - less the share the
    operating system needs to keep functioning.

    Measured every time. Move the folder to a bigger drive and this grows by
    itself, which is what makes the same install correct on the next machine.
    """
    try:
        du = shutil.disk_usage(str(core.ROOT))
    except Exception:
        return 0.0
    could_hold = (du.free / GB) + used_gb()
    return round(max(0.0, could_hold - os_reserve_gb()), 2)


# ------------------------------------------------------------------- chosen

def chosen_gb(cfg: dict = None) -> float:
    """
    The ceiling in force. `storage.limit_gb`, clamped to what the disk allows.

    0 means "the computer's limit", and is the default, because the user's
    instruction was that nothing should limit this but the machine itself. A
    number is honoured as their decision and still clamped - a ceiling larger
    than the disk is not a ceiling, it is a surprise later.
    """
    cap = ceiling_gb()
    try:
        asked = float(((cfg or core.load()).get("storage") or {}).get("limit_gb") or 0)
    except (TypeError, ValueError):
        asked = 0.0
    if asked <= 0:
        return cap
    return round(min(asked, cap), 2) if cap > 0 else round(asked, 2)


# --------------------------------------------------------------------- used

def forget() -> None:
    """Drop the cached measurement. Anything that writes a lot may call this."""
    with _lock:
        _used["at"] = 0.0


def _walk(folder: Path) -> float:
    total = 0.0
    try:
        for p in folder.rglob("*"):
            try:
                if p.is_file():
                    total += p.stat().st_size
            except OSError:
                continue
    except Exception:
        pass
    return total


def measure(force: bool = False) -> dict:
    """
    {bytes, parts} for data/. Held for USED_TTL seconds.

    The walk is a stat() per file and the interface polls every two seconds,
    so it is cached - but only briefly, and never across a request to forget.
    A number that cannot change is not a measurement (ADR-145).
    """
    with _lock:
        if not force and (time.time() - _used["at"]) < USED_TTL:
            return {"bytes": _used["bytes"], "parts": dict(_used["parts"])}
    parts, total = {}, 0.0
    named = set()
    for label, folder, _why in PARTS:
        d = core.DATA / folder
        size = _walk(d) if d.is_dir() else 0.0
        parts[label] = size
        total += size
        named.add(folder)
    # Anything under data/ that is not one of the named parts still counts -
    # a budget that only measures the folders it knows about will be wrong on
    # the first day somebody adds one.
    try:
        for p in core.DATA.iterdir():
            if p.name in named:
                continue
            size = _walk(p) if p.is_dir() else (
                p.stat().st_size if p.is_file() else 0.0)
            parts["other"] = parts.get("other", 0.0) + size
            total += size
    except Exception:
        pass
    with _lock:
        _used.update({"at": time.time(), "bytes": total, "parts": parts})
    return {"bytes": total, "parts": dict(parts)}


def used_gb(force: bool = False) -> float:
    return round(measure(force)["bytes"] / GB, 3)


def room_gb(cfg: dict = None) -> float:
    """How much the store may still grow. Never negative."""
    return round(max(0.0, chosen_gb(cfg) - used_gb()), 3)


def has_room_for(mb: float, cfg: dict = None) -> tuple:
    """
    (ok, why). Asked ONCE, before something large is started.

    Never asked of something already running. The rule that cost this project
    four finished videos still holds: a generation may fail because it never
    started, never because a number ran out while it was working.
    """
    need = max(0.0, float(mb or 0)) / 1024.0
    left = room_gb(cfg)
    if chosen_gb(cfg) <= 0 or need <= 0 or left >= need:
        return True, ""
    return False, (
        f"this needs about {need:.1f} GB and the memory store has {left:.1f} GB "
        f"left of the {chosen_gb(cfg):.0f} GB ceiling. Nothing has been "
        f"deleted and nothing will be - raise the ceiling in Settings (this "
        f"machine allows up to {ceiling_gb():.0f} GB), or erase something you "
        f"no longer want from the same screen.")


# -------------------------------------------------------------------- state

def state(cfg: dict = None) -> dict:
    """The three numbers and the breakdown, for the bar in Settings."""
    cfg = cfg or core.load()
    m = measure()
    cap, chosen = ceiling_gb(), chosen_gb(cfg)
    used = m["bytes"] / GB
    asked = 0.0
    try:
        asked = float((cfg.get("storage") or {}).get("limit_gb") or 0)
    except (TypeError, ValueError):
        pass
    return {
        "used_gb": round(used, 3),
        "chosen_gb": chosen,
        "ceiling_gb": cap,
        "asked_gb": asked,                 # 0 = following the machine
        "following_machine": asked <= 0,
        "clamped": asked > 0 and cap > 0 and asked > cap,
        "os_reserve_gb": os_reserve_gb(),
        "pct": round(100.0 * used / chosen, 1) if chosen > 0 else 0.0,
        "room_gb": round(max(0.0, chosen - used), 3),
        "parts": [{"name": label, "why": why,
                   "gb": round(m["parts"].get(label, 0.0) / GB, 3)}
                  for label, _folder, why in PARTS
                  if m["parts"].get(label, 0.0) > 0]
        + ([{"name": "other", "why": "anything else under data/",
             "gb": round(m["parts"]["other"] / GB, 3)}]
           if m["parts"].get("other") else []),
        "machine": machine(),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(state(), indent=2))
