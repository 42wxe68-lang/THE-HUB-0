@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title The Hub - One Install
set "ROOT=%~dp0"
set "PYVER=3.13.15"
set "PYDIR=%ROOT%.runtime\python"
set "PYEXE=%PYDIR%\python.exe"
set "PYZIP=%ROOT%.runtime\python-3.13.15-embed-amd64.zip"
set "PYURL=https://www.python.org/ftp/python/3.13.15/python-3.13.15-embed-amd64.zip"

cls
echo.
echo ============================================================
echo   The Hub - ONE INSTALL
echo   Everything needed is downloaded and configured automatically.
echo   No separate asset download step is required.
echo ============================================================
echo.

if not exist "%PYEXE%" (
  echo [1/1] Bootstrapping The Hub private Python runtime
  echo ------------------------------------------------------------
  if not exist "%ROOT%.runtime" mkdir "%ROOT%.runtime"
  echo   get     Python %PYVER% embedded runtime
  curl.exe -L --fail --retry 3 --continue-at - -o "%PYZIP%" "%PYURL%"
  if errorlevel 1 (
    echo.
    echo   ERROR: could not download The Hub's private Python runtime.
    echo.
    pause
    exit /b 1
  )
  if not exist "%PYDIR%" mkdir "%PYDIR%"
  tar.exe -xf "%PYZIP%" -C "%PYDIR%"
  if errorlevel 1 (
    echo.
    echo   ERROR: could not extract the private Python runtime.
    echo.
    pause
    exit /b 1
  )
  if not exist "%PYEXE%" (
    echo.
    echo   ERROR: private Python runtime did not install correctly.
    echo.
    pause
    exit /b 1
  )
)

"%PYEXE%" "%ROOT%install.py"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo.
  echo   The Hub installation failed. Read the messages above.
  echo.
  pause
  exit /b %RC%
)

echo.
echo ============================================================
echo   The Hub is installed and verified.
echo ============================================================
echo.
choice /C YN /N /M "  Launch The Hub now? [Y/N] "
if errorlevel 2 exit /b 0
start "" "%ROOT%HUB.bat"
exit /b 0
