"""
budget.py - nothing goes to the model that will not fit in it.

THE BUG THIS FIXES
------------------
The Hub was assembling a prompt out of six growing pieces and never once
counting them against n_ctx:

    character.md          ~700 tokens, fixed
    the reality frame     up to 2200 chars, grows with memory
    knowledge context     up to 1400 chars
    recall                up to 1600 chars
    conversation history  last 40 messages, 20000 chars EACH
    untrusted search      2500 chars per result block

Two ordinary turns with one long answer and one search result put the prompt
past 8192 tokens, and llama-server answers HTTP 400. The user sees "error:
400" after a couple of tiny conversations. Deleting memories makes it work
again, because the frame shrinks - which looks like a memory bug and is
actually an arithmetic bug.

Memory growing is not the fault. Memory is SUPPOSED to grow. What was
missing is the thing that decides how much of it fits today.

HOW IT WORKS
------------
The window is divided before assembly, not trimmed after:

    n_ctx
      - max_tokens        what the reply needs to be written into
      - SAFETY            chat template, tool schemas, BOS, rounding
      = workable
          |
          +-- character    hard floor: this is identity, it goes in whole
          +-- frame        share, trimmed from the weakest memory up
          +-- knowledge    share
          +-- recall       share
          +-- history      whatever is left, newest first
          +-- evidence     share, and it takes from history if it must

Every section is trimmed by DROPPING WHOLE ITEMS from the least important
end, never by cutting a sentence in half. A truncated memory reads as a
false memory.

COUNTING
--------
`count()` asks llama-server's /tokenize endpoint when it is up, because that
is the real tokenizer and no estimate beats it. When it is not up - during
startup, or for a model that does not expose it - it falls back to a
deliberately pessimistic characters/3.1, so the estimate errs toward sending
too little rather than too much.
"""
from __future__ import annotations

import json
import threading
import urllib.request

import core

# Chat template scaffolding, tool schemas, BOS/EOS, and the fact that no
# estimate is exact. Big enough that being slightly wrong is still safe.
SAFETY = 512
MIN_REPLY = 256

# Shares of what is left after the character sheet. They add to less than 1.0
# on purpose: history gets the remainder, and history is what makes a
# conversation feel like a conversation.
# WHAT THE WINDOW IS SPENT ON, AND WHY HISTORY GETS THE MOST OF IT.
#
# These shares are how much of the conversation survives. The two releases
# whose continuity actually worked gave history 0.44 of what was left after
# the character sheet; adding blocks without taking the room from somewhere
# took it from there by default, and the transcript quietly shrank while
# every block ABOUT the transcript grew.
#
#     "the conversation length never resets and organizes like 13-15"
#
# So history is back to 0.44 and the new sections are paid for out of the
# other blocks, not out of the conversation:
#
#   frame      0.16 -> 0.10   identity. Two short sections, capped anyway.
#   standing        -> 0.08   what is current, by subject. NEW.
#   knowledge  0.10 -> 0.10   the vault catalogue. Unchanged; file work
#                             depends on it being complete.
#   recall     0.12 -> 0.10   retrieval for THIS question.
#   evidence   0.18 -> 0.12   a web result, or an inward lookup.
#   carryover       -> 0.06   the last rounds of the previous sessions.
#                             At 32k that is still around 5,000 characters.
#
# 0.56 spent, 0.44 to the conversation - the number from the releases that
# worked.
SHARES = {"frame": 0.10, "standing": 0.08, "knowledge": 0.10, "recall": 0.10,
          "evidence": 0.12, "carryover": 0.06}
HISTORY_MIN = 0.25          # history never drops below this share
CHARS_PER_TOKEN = 3.1       # pessimistic on purpose

_cache: dict = {}
_lock = threading.Lock()


def count(text: str, base: str = None) -> int:
    """Tokens in `text`. Exact when the server is up, pessimistic when not."""
    if not text:
        return 0
    key = hash(text)
    with _lock:
        if key in _cache:
            return _cache[key]
    n = 0
    # Only consult the real tokenizer for blocks big enough for an estimate
    # to matter. A round trip per short line would add dozens of HTTP calls
    # to every turn to refine a number that is already within a few percent.
    if base and len(text) >= 400:
        try:
            req = urllib.request.Request(
                base + "/tokenize",
                data=json.dumps({"content": text}).encode(),
                headers={"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=8) as r:
                n = len(json.loads(r.read().decode()).get("tokens") or [])
        except Exception:
            n = 0
    if not n:
        n = int(len(text) / CHARS_PER_TOKEN) + 1
    with _lock:
        if len(_cache) > 4000:
            _cache.clear()
        _cache[key] = n
    return n


class Plan:
    """How many tokens each part of the prompt may spend this turn."""

    def __init__(self, n_ctx: int, max_tokens: int, character_tokens: int):
        self.n_ctx = max(512, int(n_ctx))
        # A 1024-token reply requested inside a 2048-token window leaves
        # nothing for the conversation. The reply never takes more than a
        # third of the window, whatever the sampling setting says.
        self.reply = max(MIN_REPLY, min(int(max_tokens), self.n_ctx // 3))
        self.workable = self.n_ctx - self.reply - SAFETY

        if self.workable < 256:
            # The window cannot hold a conversation. Take it out of the reply
            # rather than the memory, and let the caller warn.
            self.reply = max(MIN_REPLY, self.n_ctx // 4)
            self.workable = max(256, self.n_ctx - self.reply - SAFETY)

        # Identity is not negotiable and is not a share. If the character
        # sheet alone is eating the window, that is a fact worth surfacing
        # rather than silently cutting the assistant's own description of
        # itself in half.
        # 0.45, raised from 0.35. This is a local assistant whose usefulness
        # is almost entirely in doing the right thing with its tools, and
        # every one of those rules lives in the character sheet. At 0.35 on a
        # 4 GB card the sheet was cut to under 800 tokens out of 2600 and the
        # instructions about generating, offering and answering plainly were
        # simply never sent. History keeps its own floor below, so this takes
        # from the memory shares rather than from the conversation.
        self.character = min(character_tokens, int(self.workable * 0.45))
        rest = max(0, self.workable - self.character)

        self.frame = int(rest * SHARES["frame"])
        self.knowledge = int(rest * SHARES["knowledge"])
        self.recall = int(rest * SHARES["recall"])
        self.evidence = int(rest * SHARES["evidence"])
        self.carryover = int(rest * SHARES["carryover"])
        self.standing = int(rest * SHARES["standing"])
        self.history = (rest - self.frame - self.knowledge - self.recall
                        - self.evidence - self.carryover - self.standing)
        floor = int(rest * HISTORY_MIN)
        if self.history < floor:
            # Claw back from the least load-bearing section first.
            need = floor - self.history
            # Weakest first. The conversation is never the thing that
            # gives way, and identity is never the first thing to go.
            for name in ("evidence", "knowledge", "carryover", "recall",
                         "standing", "frame"):
                take = min(need, getattr(self, name))
                setattr(self, name, getattr(self, name) - take)
                need -= take
                if need <= 0:
                    break
            self.history = floor

    def as_dict(self) -> dict:
        return {"n_ctx": self.n_ctx, "reply": self.reply,
                "character": self.character, "frame": self.frame,
                "knowledge": self.knowledge, "recall": self.recall,
                "evidence": self.evidence, "carryover": self.carryover,
                "standing": self.standing, "history": self.history}


def fit_text(text: str, limit: int, base: str = None) -> str:
    """
    Trim a block to `limit` tokens by dropping WHOLE LINES from the end.

    Never cuts mid-sentence. A memory that stops halfway through is not a
    shorter memory, it is a different and wrong one.
    """
    if not text or limit <= 0:
        return ""
    if count(text, base) <= limit:
        return text
    lines = text.splitlines()
    out = []
    used = 0
    for line in lines:
        n = count(line + "\n", base)
        if used + n > limit:
            break
        out.append(line)
        used += n
    return "\n".join(out).strip()


# THE CHARACTER SHEET IS NOT ONE BLOCK.
#
# It used to be trimmed with fit_text, which drops whole lines from the end.
# On a 4 GB card at n_ctx 4096 the allowance is around 780 tokens against a
# sheet of nearly 2800, so roughly two thirds of it was silently thrown away
# every turn - from the bottom up, which is where the instructions about
# generating things, offering files and answering plainly all lived.
#
# Nobody saw it happen. The model was simply never told, and behaved exactly
# like a model that had never been told: it used the wrong 3D route, it
# offered to generate rather than generating, and it left everything it made
# in the Playground. Those were read as model problems for weeks.
#
# So the sheet is now cut by SECTION, in the order it is written, and these
# sections go in whatever else does not. They are the ones whose absence is
# a behaviour change rather than a style change.
# MEMORY and MANNER ARE ESSENTIAL, and they were the two most likely to be
# cut. Sections are ranked essentials-first and MEMORY and MANNER are the
# last two written, so on a small window the model received the memory
# blocks while the instructions on how to treat them had been silently
# dropped. Told nothing about provenance, a model reads every remembered
# line as flat fact - which is the over-claiming this release exists to
# fix, arriving by a different door.
ESSENTIAL = ("", "TIME", "WHAT THE PAST IS FOR", "SAYING IS NOT DOING",
             "MAKING THINGS", "GIVING THE USER WHAT YOU MADE",
             "MEMORY", "MANNER")


def _sections(text: str) -> list:
    """Split the character sheet into (heading, body) in written order.

    A heading is a line in capitals on its own. The preamble before the
    first heading has heading "" and is always kept - it is who she is.
    """
    out, head, buf = [], "", []
    for line in (text or "").splitlines():
        t = line.strip()
        if (t and t == t.upper() and t.replace(" ", "").isalpha()
                and 2 <= len(t) <= 40):
            out.append((head, "\n".join(buf).rstrip()))
            head, buf = t, []
        else:
            buf.append(line)
    out.append((head, "\n".join(buf).rstrip()))
    return out


def fit_character(text: str, limit: int, base: str = None) -> tuple:
    """
    Fit the character sheet into `limit` tokens without losing what matters.

    Returns (text, dropped_section_names). Essential sections go in FIRST, in
    written order, and everything else fills what is left.

    They are not, however, kept unconditionally - this docstring used to claim
    they were and the code below has never done it. The essentials come to
    about 3,100 tokens; at n_ctx 4096 the whole character allowance is 998.
    Forcing them in would spend three quarters of the window on the sheet and
    leave the conversation with nothing, which is a worse assistant than one
    missing a section. So the limit is real for every section, and what falls
    out is the least load-bearing end inwards.

    The consequence is worth stating plainly rather than hiding in a
    docstring that reads better than the truth: BELOW ROUGHLY 12k THE SHEET
    IS INCOMPLETE. At 4096 nine sections go, MEMORY and MANNER among them.
    That is why the drop is RETURNED rather than swallowed - server.py logs
    it and the interface shows it - and it is the argument for a bigger
    window rather than an argument for pretending.

    What gets dropped is RETURNED rather than swallowed, so the caller can
    log it and the interface can show it. A prompt quietly missing two thirds
    of itself is the kind of fault that costs weeks.
    """
    if not text:
        return "", []
    if count(text, base) <= limit:
        return text, []

    secs = [(h, b) for h, b in _sections(text)]
    order = {h: i for i, (h, _) in enumerate(secs)}

    def _block(h, b):
        return (h + "\n" + b).strip() if h else b.strip()

    # Priority order: essentials in the order they are written, then
    # everything else in the order it is written. Nothing is ever added past
    # the limit - going over would risk the 400 this module exists to
    # prevent - so on a very small window the sheet degrades from the least
    # load-bearing end inwards, instead of losing its second half whole.
    ranked = ([kv for kv in secs if kv[0] in ESSENTIAL]
              + [kv for kv in secs if kv[0] not in ESSENTIAL])

    keep, dropped, used = [], [], 0
    for h, b in ranked:
        blk = _block(h, b)
        if not blk:
            continue
        n = count(blk + "\n\n", base)
        if used + n <= limit:
            keep.append((h, blk))
            used += n
        else:
            dropped.append(h or "(preamble)")

    keep.sort(key=lambda kv: order.get(kv[0], 0))
    dropped.sort(key=lambda h: order.get("" if h == "(preamble)" else h, 0))
    return "\n\n".join(b for _, b in keep), dropped


def fit_history(messages: list, limit: int, base: str = None) -> list:
    """
    Keep the newest turns that fit, in order, dropping the oldest.

    Whole messages only, and a user message is never kept without room for
    what it was answering unless it is the newest - a dangling assistant
    reply with no question above it reads as the model talking to itself.
    """
    if limit <= 0 or not messages:
        return messages[-1:] if messages else []
    kept, used = [], 0
    for m in reversed(messages):
        text = m.get("content")
        if not isinstance(text, str):
            text = json.dumps(m.get("content"))[:2000]
        n = count(text, base) + 8          # role and delimiters
        if used + n > limit and kept:
            break
        kept.append(m)
        used += n
    kept.reverse()
    if len(kept) > 1 and kept[0].get("role") == "assistant":
        kept = kept[1:]
    return kept or messages[-1:]


def measure(messages: list, base: str = None) -> int:
    """Total tokens in an assembled message list."""
    total = 0
    for m in messages:
        c = m.get("content")
        total += count(c if isinstance(c, str) else json.dumps(c)[:4000], base) + 8
    return total


def report(messages: list, plan: Plan, base: str = None) -> dict:
    used = measure(messages, base)
    return {"used": used, "n_ctx": plan.n_ctx, "reply": plan.reply,
            "headroom": plan.n_ctx - plan.reply - used,
            "pct": round(100.0 * used / max(1, plan.n_ctx), 1)}


def emergency_trim(messages: list, n_ctx: int, reply: int, base: str = None) -> list:
    """
    Last resort, after a 400 came back anyway.

    Halve the conversation history and try once more. The system prompt and
    the newest user message always survive, because without those there is
    nothing to answer.
    """
    # Keep system messages at the FRONT and nowhere else. A template that
    # raises "System message must be at the beginning" will 500 otherwise,
    # and trimming is exactly when that would be hardest to diagnose.
    head = [m for m in messages if m.get("role") == "system"]
    body = [m for m in messages if m.get("role") != "system"]
    head = head[:1]
    while len(body) > 1 and measure(head + body, base) > (n_ctx - reply - SAFETY):
        body = body[len(body) // 2:]
    return head + body
