"""
core.py - paths, configuration, and the sandbox boundary.

Developed from CAIRN's core.py. Every other module imports this. It is the
single authority on where files live and which of them may be written.

The jail rule, unchanged from Cairn: llm/ is readable but never writable.
The Hub cannot alter the model it runs on, and neither can anything the
model asks The Hub to do. Only data/ accepts writes.

WHAT CHANGED FROM CAIRN, AND WHY
--------------------------------
  data/tree        holds a living tree per sephira now, not a flat list
  data/knowledge   new - the Knowledge Tree, carried over from Vera
  data/ash         new - the Tree of Death. Faded leaves fall here and are
                   kept forever. Nothing that was true is ever deleted;
                   only its visibility decays.
  data/events      new - the append-only event log. Every derived structure
                   under data/ can be rebuilt from it.
  ports            all four are The Hub's own, so Cairn and The Hub can
                   run side by side without either one noticing.

The Hub is a different application from Cairn. It shares Cairn's
architecture and none of Cairn's state: its own folder, its own ports, its
own data root, its own models. Nothing here reads anything Cairn owns.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path

APP = "The Hub"
ASSISTANT = "Nova"
VERSION = "1.6-The Hub"
# Preferred starting presentation only. This never restricts model discovery or
# selection: if this file is not installed, The Hub falls back to the first
# available model.
PREFERRED_MODEL = "Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf"
# The previous starter. Still selectable if it is on disk - this names
# what a FRESH install prefers, never what the dropdown permits.
PREVIOUS_MODEL = "Huihui-Qwen3.5-4B-abliterated.Q4_K_M.gguf"
PREFERRED_VOICE = "Microsoft Hazel - English (United Kingdom)"

# ---------------------------------------------------------------- paths

ROOT = Path(__file__).resolve().parent

LLM_DIR = ROOT / "llm"
MODELS = LLM_DIR / "models"
RUNTIME = LLM_DIR / "llama.cpp"
LLAMA_EXE = RUNTIME / "llama-server.exe"

# Hearing. whisper.cpp lives beside llama.cpp under the same read-only rule.
WHISPER_DIR = LLM_DIR / "whisper.cpp"
WHISPER_EXE = WHISPER_DIR / "whisper-server.exe"

DATA = ROOT / "data"
CHAT_UPLOADS = DATA / "chat_attachments"
TREE = DATA / "tree"            # the Tree of Life: ten sephirot, each alive
KNOWLEDGE = DATA / "knowledge"  # the Knowledge Tree: what was worked out
ASH = DATA / "ash"              # the Tree of Death: what faded, kept forever
EVENTS = DATA / "events"        # append-only history; everything else derives
SESSIONS = DATA / "sessions"
LOGS = DATA / "logs"

CONFIG = ROOT / "config.json"
CHARACTER = ROOT / "character.md"
UI_FILE = ROOT / "ui.html"

WRITABLE = (DATA, TREE, KNOWLEDGE, ASH, EVENTS, SESSIONS, LOGS)

# ---------------------------------------------------------------- ports
#
# Three generations of this application can be installed on one machine and
# every one of them must be able to run without noticing the others:
#
#     Cairn        8420 / 8080 / 8081 / 8082
#     The Hearth   8430 / 8090 / 8091 / 8092
#     The Hub      8440 / 8100 / 8101 / 8102   <- here
#
# HUB-ZERO inherited The Hearth's ports verbatim and so could not coexist with
# the application it was forked from: whichever started second failed to bind,
# and STOP.bat reached across and killed the other one's model mid-sentence.
# A fork gets its own ports on the same day it gets its own name.
#
# Nothing here is discovered or guessed: a fixed, declared port is what lets
# STOP.bat kill The Hub's processes and only The Hub's processes.

UI_PORT = 8440
MAIN_PORT = 8100       # the model Nova thinks with      (GPU)
CURATOR_PORT = 8101    # the background memory model     (CPU only)
EAR_PORT = 8102        # whisper.cpp                     (CPU only)
# trellis.cpp ships as an HTTP service, not a command-line tool - the
# prebuilt Windows archive contains trellis-server.exe and nothing else. It
# is started for one request and stopped again, so this port is only in use
# while a mesh is being built.
TRELLIS_PORT = 8103

# Ports owned by the ancestors. Never bound, only checked, so that a collision
# is reported as a collision instead of surfacing as a dead server.
ANCESTOR_PORTS = {8420: "Cairn", 8080: "Cairn", 8081: "Cairn", 8082: "Cairn",
                  8430: "The Hearth", 8090: "The Hearth",
                  8091: "The Hearth", 8092: "The Hearth"}
PORTS = (UI_PORT, MAIN_PORT, CURATOR_PORT, EAR_PORT, TRELLIS_PORT)

# ---------------------------------------------------------------- config

DEFAULTS = {
    "assistant_name": ASSISTANT,
    "model": "",
    "appearance": {"ai_control": False},
    "runtime": {
        # This used to say "raise it only while watching nvidia-smi", because
        # spilling out of VRAM is not an error message, it is a hard reset.
        # That warning was correct and it was aimed at the wrong setting: the
        # context is not what overran the card, the WEIGHTS were, because
        # -ngl was never sent. runtime.plan() now budgets the card and the
        # host together, so this can be raised and read normally again.
        # "auto" = everything the model was trained for, or the largest
        # window that fits in memory now, whichever is smaller. A number here
        # is honoured as a request and still clamped to the model's real
        # limit - asking an 8k model for 32k does not produce 32k.
        "n_ctx": "auto",
        # "auto" = as many layers as the card can hold once the cache and the
        # compute buffers are counted, worked out by runtime.plan() and sent
        # as a real number. It is NOT llama.cpp's own "auto": in b10456 that
        # means every layer, with no VRAM check anywhere on the path, and an
        # over-subscribed card does not fail - the driver pages it over PCIe
        # into system RAM and holds the GPU at full power for as long as it
        # runs. A number here is honoured as your decision.
        "n_gpu_layers": "auto",
        "threads": 6,
        "parallel": 1,
        # The physical batch: how many tokens the GPU is asked to process at
        # once during prefill. This is the peak-power setting. 512 is
        # llama.cpp's default; 256 roughly halves the largest single demand
        # made of the card, costing prompt-processing speed and nothing else.
        # Worth lowering on a laptop running from the adapter alone.
        "n_ubatch": 512,
        "n_batch": 2048,
        "mmproj": "",
        # f16 is the only KV type measured to work on the pinned build. q8_0
        # may or may not have a CUDA kernel in b10456; if it does not,
        # attention silently falls back to the CPU and generation halves in
        # speed with no error at all. Left at f16 until measured here.
        "kv_type": "f16",
        # What happens when a model looks too big for the memory free right
        # now. It is never a refusal: the model you select is the model that
        # loads, and llama.cpp is the only thing qualified to say otherwise.
        #   "adapt"  lower n_ctx so your model fits, and say so   (default)
        #   "warn"   change nothing, just tell you what to expect
        #   "off"    say nothing
        "fit_policy": "adapt",
        # Advisory only. Free memory measured at load time wins over this,
        # because a number written by the installer during one busy moment is
        # not a property of the machine. 0 means measure and do not consult it.
        "ram_budget_mb": 0,
    },
    "hearing": {
        "enabled": False,
        "model": "ggml-base.en.bin",
        "threads": 4,
        "silence_ms": 900,
        "min_speech_ms": 350,
        "auto_send": True,
    },
    # No toggle. Whether the loaded model can see is a property of the
    # model, probed when it loads - the same way the context window is
    # measured rather than declared. A checkbox here only ever produced a
    # switch with no wire behind it.
    "vision": {},
    "sampling": {
        "temperature": 0.3,
        "top_p": 0.95,
        "top_k": 50,
        "min_p": 0.05,
        "repeat_penalty": 1.05,
        # "auto" = a third of the context window, matching the share
        # budget.py already reserves for the reply. The old constant 1024 is
        # what made a thinking model spend its whole allowance reasoning and
        # answer nothing.
        "max_tokens": "auto",
        # Passed as chat_template_kwargs.enable_thinking. Qwen3.5's small
        # models need it to reason at all; models whose template does not
        # mention it ignore it entirely.
        "thinking": True,
        "seed": -1,
    },
    "voice": {
        "enabled": False,
        "name": "",
        "rate": 1.0,
        "pitch": 1.0,
        "barge_in": True,
        "barge_threshold": 0.055,
        "barge_ms": 320,
        "listen": False,
        "auto_send": True,
    },
    # ONE switch. The clock, the calculator, memory search and file reading
    # are not optional: they are how the assistant functions, and a toggle
    # that turns off memory produces an assistant that appears to work and
    # quietly remembers nothing. Web search is a switch because it is the
    # only thing that leaves this machine.
    "tools": {
        "web_search": False,
    },
    "search": {
        "provider": "wikipedia",
        "brave_key": "",
        "tavily_key": "",
    },
    "memory": {
        "expire_days": 10,
        "curator_interval_min": 20,
        "max_digests_per_session": 10,
        "recall_count": 4,
        "autosave_min": 60,
        # Living-tree lifecycle, carried over from Luminova: a leaf loses
        # weight with time and gains it when it is thought about.
        "decay_per_day": 0.02,
        "ash_below": 0.05,
        "prune_interval_h": 24,
        # Let growth.py actually change the tree's shape, instead of only
        # writing down what it would change. Off until the log shows it
        # proposing sensible things on a real tree - "when you saw 10 - 5
        # times, you don't know". Reporting happens either way.
        "reshape": False,
    },
    # HOW LONG A CONVERSATION RUNS BEFORE IT ENDS ITSELF.
    #
    # A conversation that never ends is one conversation forever: the
    # transcript grows until it fills the window, every turn is spent at
    # full context, and nothing ever draws a line. In the releases whose
    # continuity worked, refreshing the page ended it - an accident, but
    # the only line anyone ever drew.
    #
    # Nothing is lost when one ends. The transcript is kept and becomes one
    # of the earlier conversations the next one carries.
    "chat": {
        "rounds_per_conversation": 20,
    },
    # HOW MUCH ROOM THE MEMORY HAS. See store.py.
    #
    # 0 means "whatever this computer can give", measured from the disk every
    # time and never written down - so the same install is correct on the next
    # machine without being told anything about it. A number is honoured as
    # your ceiling and still clamped to what the disk actually allows.
    #
    # Nothing here ever deletes. It is a ceiling and a bar: a full store says
    # so, a large generation will not START, and purge.py stays the only thing
    # that removes anything, with a confirmation screen in front of it.
    "storage": {
        "limit_gb": 0,
    },
    # ARITHMETIC BEFORE A LAUNCH, not a floor during a run. When the
    # weights a generator must load are larger than the memory that is free
    # right now, it cannot work, and loading it is what takes the machine
    # down. Refusing to START is explicitly allowed. Stopping something
    # that is already running is not, which is why ram_floor_mb stays 0.
    "generation": {
        "start_check": True,
        "ram_floor_mb": 0,
    },
}

_lock = threading.RLock()


class Denied(Exception):
    """A path resolved outside its permitted base."""


# ---------------------------------------------------------------- sandbox

def ensure_dirs() -> None:
    for d in WRITABLE:
        d.mkdir(parents=True, exist_ok=True)


def under(base: Path, name: str) -> Path:
    """
    Join ONE untrusted name fragment onto a trusted directory.

    Rejects separators, drive letters, and traversal before joining, then
    verifies the result still sits inside base. Use for anything sourced
    from the UI, a config file, or the model.
    """
    if not name or name in (".", "..") or any(c in name for c in '/\\:*?"<>|'):
        raise Denied(f"illegal name fragment: {name!r}")
    p = (base / name).resolve()
    if not p.is_relative_to(base.resolve()):
        raise Denied(f"escaped {base}: {p}")
    return p


def writable(p: Path) -> Path:
    r = Path(p).resolve()
    for b in WRITABLE:
        if r.is_relative_to(b.resolve()):
            return r
    raise Denied(f"write denied outside data/: {r}")


# ---------------------------------------------------------------- json io

def read_json(p: Path, fallback):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return fallback


def write_json(p: Path, obj) -> None:
    """Atomic write via temp file, so a crash mid-write cannot corrupt memory."""
    p = writable(Path(p))
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def _merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in (over or {}).items():
        if isinstance(base.get(k), dict) and isinstance(v, dict):
            out[k] = _merge(base[k], v)
        else:
            out[k] = v
    return out


# Keys that used to exist and no longer should. A config saved by an
# earlier build still carries them, and a merge that keeps unknown keys
# would quietly restore switches that have been deliberately removed -
# a user upgrading would get clock/calculator/remember toggles back in
# their saved file and wonder why the interface disagrees with it.
_PRUNE_KEYS = {
    "tools": ("clock", "calculator", "remember", "search_memory", "open_file"),
}


def _prune(cfg: dict) -> dict:
    for section, keys in _PRUNE_KEYS.items():
        if isinstance(cfg.get(section), dict):
            for k in keys:
                cfg[section].pop(k, None)
    for gone in ("hub", "knowledge", "curator_model"):
        cfg.pop(gone, None)
    return cfg


def load() -> dict:
    with _lock:
        return _prune(_merge(DEFAULTS, read_json(CONFIG, {}) or {}))


def save(cfg: dict) -> None:
    with _lock:
        CONFIG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def patch(delta: dict) -> dict:
    with _lock:
        cfg = _merge(load(), delta or {})
        save(cfg)
        return cfg


# ---------------------------------------------------------------- discovery

# A multimodal PROJECTOR is a .gguf, but it is not a model and llama.cpp
# refuses it outright:
#
#   error loading model: CLIP cannot be used as main model, use it with
#   --mmproj instead
#   llama_server: exiting due to model loading error
#
# Listing them alongside real models put them in the dropdown, where
# selecting one passed it to -m, killed llama-server on load, and left the
# interface reporting "No connection could be made because the target
# machine actively refused it" - which describes a dead server, not the
# actual fault. Every projector downloaded made the list worse.
PROJECTOR_HINTS = ("mmproj", ".mmproj.", "-mmproj", "mmproj-", "-proj-",
                   "projector")


def is_projector(name: str) -> bool:
    n = name.lower()
    return any(h in n for h in PROJECTOR_HINTS)


def models() -> list[dict]:
    """Selectable language models, with their local vision pairing exposed."""
    if not MODELS.is_dir():
        return []
    out = []
    # Import lazily: vision imports core, so importing it at module load would
    # create a cycle. Projectors stay out of the selectable model list, but
    # every real model tells the UI whether a matching projector is present.
    try:
        import vision
    except Exception:
        vision = None
    for f in sorted(MODELS.glob("*.gguf")):
        if not f.is_file() or is_projector(f.name):
            continue
        proj = vision.find_projector(f) if vision else None
        out.append({
            "name": f.name,
            "size_mb": round(f.stat().st_size / 1048576, 1),
            "vision": bool(proj),
            "projector": proj.name if proj else "",
        })
    return out


def projectors() -> list[dict]:
    """The projectors on disk, for reporting. Never selectable."""
    if not MODELS.is_dir():
        return []
    return [
        {"name": f.name, "size_mb": round(f.stat().st_size / 1048576, 1)}
        for f in sorted(MODELS.glob("*.gguf"))
        if f.is_file() and is_projector(f.name)
    ]


def character() -> str:
    """
    The whole system prompt: the shipped wiring with the user's own words in
    the places character.md marks out for them. See persona.py.

    Imported inside the function because persona imports core, and one of
    them has to go second. Everything that wanted the sheet still calls this
    and none of them has to know the split exists.
    """
    try:
        import persona
        return persona.sheet()
    except Exception:
        pass
    try:
        return CHARACTER.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


# A line that already opens with its own date - policy.py, memory.py and
# research.py stamp their own, in two different formats - is left alone.
# Everything else gets one here.
_ALREADY_STAMPED = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}")


def log_line(name: str, text: str) -> None:
    """
    Append one line to data/logs/<name>.log, stamped with the time.
    Never raises.

    Used by the supervisory layers. A decision nobody wrote down cannot be
    measured later, and unmeasurable decisions are how a safety net quietly
    stops catching anything.

    THE STAMP IS NOT DECORATION. tools.log carried thirty lines reading
    "promised an action without calling a tool (generate_video)" with no
    time on any of them, so there was no way to tell which came before a
    fix and which came after - the log could neither confirm nor refute
    the repair. A log you cannot order is a log you cannot learn from.
    """
    try:
        line = text.rstrip()
        if not _ALREADY_STAMPED.match(line):
            line = f"{time.strftime('%Y-%m-%d %H:%M:%S')} {line}"
        LOGS.mkdir(parents=True, exist_ok=True)
        with (LOGS / f"{name}.log").open("a", encoding="utf-8", errors="replace") as f:
            f.write(line + "\n")
    except Exception:
        pass
