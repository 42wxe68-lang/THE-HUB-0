"""
ledger.py - how many times has this actually been tried?

THE LESSON THIS IMPLEMENTS
--------------------------
    "It's bad to assume that something will or will not work just because
     you tried it a couple of times in the past. When you train 10,000
     times you know. When you saw 10 - 5 times, you don't know, you have
     just seen a couple views, nothing can guarantee from that."

That is a statement about sample size, and it has an exact answer.

WHAT WAS THERE BEFORE
---------------------
forge kept one boolean per backend: the last run worked, or it did not. One
failed attempt set `ok: false`, and that flag was then read back for weeks as
though it described the machine. Nova declined 3D because a Goku statue had
failed once - true, and worth nothing as evidence, because ONE observation
of a thing that sometimes works and sometimes does not tells you almost
nothing about the next time.

A boolean cannot express "I tried once and it did not work, which is not the
same as knowing it does not work." So it gets replaced by a count.

THE MATHS, AND WHY THIS ONE
---------------------------
Laplace's rule of succession. Given s successes in n attempts, the estimate
for the next attempt is

    (s + 1) / (n + 2)

which is the mean of the Beta(s+1, n-s+1) posterior under a uniform prior -
formally, starting as though you had already seen one success and one
failure before you began. It exists precisely to stop small samples
producing certainty:

    0 of 1 failed   ->  33%      not 0%
    0 of 2 failed   ->  25%
    0 of 3 failed   ->  20%
    0 of 5 failed   ->  14%
    0 of 20 failed  ->   4.5%    now you may reasonably believe it

The user's instinct and the 250-year-old formula agree, which is usually a
good sign. A single failure can never drive the estimate to zero, so it can
never justify a refusal.

CONFIDENCE IS SEPARATE FROM THE SCORE
-------------------------------------
The score says how likely; the confidence says how much the score is worth.
Reporting 33% without saying it rests on one attempt invites the same
mistake in a new costume.

    fewer than 3 attempts   UNKNOWN   never a reason to decline. Try it.
    3 to 7 attempts         WEAK      a leaning, not a conclusion.
    8 or more               MEASURED  usable, and still not a guarantee.

A CHANGE RESETS THE EVIDENCE
----------------------------
Every attempt is stamped with a fingerprint of what was installed when it
ran. If anything has changed since - weights downloaded, a binary replaced,
a setting fixed - the old attempts were measured on a machine that no longer
exists. They are kept as history and EXCLUDED from the current estimate, so
the count honestly returns to zero and the answer honestly returns to "try
it". That is what "the fix would be high on the reliability scale" means in
code: a fix does not argue with the evidence, it retires it.

WHEN RETRYING IS NOT THE ANSWER
-------------------------------
Three or more attempts, all failed, all with the SAME error, on the current
build, is the one case where trying again is not useful. The ledger says so
explicitly, and says to ask the user - because at that point the thing that
changes the outcome is a person with access to the machine, not another
identical attempt.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

import core

LEDGER = core.DATA / "attempts.jsonl"
_LOCK = threading.RLock()

# How many attempts before a rate means anything. Chosen to match the lesson
# above rather than to be tidy: below MIN_TO_LEAN you have seen "a couple of
# views" and must say so.
MIN_TO_LEAN = 3
MIN_TO_TRUST = 8

# Attempts older than this stop counting toward the current estimate even on
# an unchanged install. Six weeks - long enough that a machine has usually
# been through a driver update, a reboot and a different set of things
# resident in memory.
STALE_DAYS = 42

MAX_ROWS = 4000          # trimmed from the front; history, not a transcript


def _read() -> list:
    try:
        out = []
        with LEDGER.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        continue
        return out
    except OSError:
        return []


def how_long(what: str, install: str = "") -> dict:
    """
    How long this thing has ACTUALLY taken, from the runs that happened.

    Every attempt has carried its duration since the ledger existed and
    nothing ever read it back - so "how long does a video take here" was
    only ever answerable by guessing, and guesses are what became timeouts.

        "we can find out when it is done when a log shows it"

    Successes and failures are kept apart on purpose. A run that died after
    nine seconds says nothing about how long a working one needs, and
    averaging them together is how a too-short expectation gets built.
    """
    rows = [r for r in _read() if r.get("what") == what
            and (not install or r.get("install") == install)]
    good = sorted(float(r.get("seconds") or 0) for r in rows if r.get("ok"))
    bad = sorted(float(r.get("seconds") or 0) for r in rows
                 if not r.get("ok"))
    out = {"runs": len(rows), "worked": len(good), "failed": len(bad)}
    if good:
        out["fastest"] = round(good[0], 1)
        out["slowest"] = round(good[-1], 1)
        out["typical"] = round(good[len(good) // 2], 1)
    if bad:
        out["longest_failure"] = round(bad[-1], 1)
    return out


def took(what: str, install: str = "") -> str:
    """One sentence about duration, or "" when nothing has ever finished."""
    d = how_long(what, install)
    if not d.get("worked"):
        if d.get("failed"):
            return (f"nothing has finished yet; the longest attempt ran "
                    f"{_span(d['longest_failure'])} before it stopped")
        return ""
    if d["worked"] == 1:
        return f"the one that worked took {_span(d['typical'])}"
    return (f"{d['worked']} finished: {_span(d['fastest'])} to "
            f"{_span(d['slowest'])}, usually about {_span(d['typical'])}")


def _span(seconds: float) -> str:
    s = float(seconds or 0)
    if s < 90:
        return f"{s:.0f}s"
    if s < 5400:
        return f"{s / 60:.0f} min"
    return f"{s / 3600:.1f} hours"


def record(what: str, ok: bool, *, note: str = "", seconds: float = 0.0,
           detail: str = "", install: str = "") -> dict:
    """
    One attempt. Append-only, because an attempt is an event.

    `what` is the thing being attempted, not the subsystem - "generate_3d"
    rather than "trellis" - because that is the granularity a decision is
    made at. `detail` narrows it further when the same tool is used two very
    different ways (a spec-built mesh and a neural one are not the same
    question), and is what makes "the Goku statue failed" stop being
    evidence about every mesh ever.
    """
    row = {"at": time.time(), "what": str(what)[:60], "ok": bool(ok),
           "note": str(note)[:240], "seconds": round(float(seconds), 1),
           "detail": str(detail)[:60], "install": str(install)[:16]}
    with _LOCK:
        try:
            LEDGER.parent.mkdir(parents=True, exist_ok=True)
            with LEDGER.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            rows = _read()
            if len(rows) > MAX_ROWS:
                keep = rows[-MAX_ROWS:]
                LEDGER.write_text(
                    "\n".join(json.dumps(r, ensure_ascii=False) for r in keep)
                    + "\n", encoding="utf-8")
        except OSError:
            pass
    return row


def _current(rows: list, what: str, install: str, detail: str = "") -> list:
    now = time.time()
    out = []
    for r in rows:
        if r.get("what") != what:
            continue
        if detail and r.get("detail") != detail:
            continue
        # Measured on a different install: history, not evidence.
        if install and r.get("install") and r["install"] != install:
            continue
        if (now - float(r.get("at", 0))) > STALE_DAYS * 86400:
            continue
        out.append(r)
    return out


def reliability(what: str, install: str = "", detail: str = "") -> dict:
    """
    What the record actually supports about `what`, said honestly.

    Returns the rule-of-succession estimate, how many attempts it rests on,
    and - the part that matters - a confidence that is allowed to be
    "unknown".
    """
    rows = _read()
    cur = _current(rows, what, install, detail)
    n = len(cur)
    s = sum(1 for r in cur if r.get("ok"))
    score = (s + 1) / (n + 2)          # Laplace's rule of succession

    if n < MIN_TO_LEAN:
        confidence = "unknown"
    elif n < MIN_TO_TRUST:
        confidence = "weak"
    else:
        confidence = "measured"

    fails = [r for r in cur if not r.get("ok")]
    same_error = (
        len(fails) >= MIN_TO_LEAN and s == 0
        and len({(r.get("note") or "")[:60] for r in fails}) == 1)

    ever = [r for r in rows if r.get("what") == what
            and (not detail or r.get("detail") == detail)]
    retired = len(ever) - n

    return {"what": what, "detail": detail,
            "attempts": n, "successes": s, "failures": n - s,
            "score": round(score, 3), "confidence": confidence,
            "same_error_every_time": same_error,
            "attempts_ever": len(ever), "retired": retired,
            "last_note": (fails[-1].get("note") if fails else ""),
            "last_at": (cur[-1].get("at") if cur else 0.0)}


def _pct(x: float) -> str:
    return f"{round(100 * x)}%"


def brief(what: str, install: str = "", detail: str = "") -> str:
    """
    One or two sentences for the model, at the moment it decides.

    Written to be read by something that is about to say "I can't". Every
    branch that is not MEASURED ends by telling it to try.
    """
    r = reliability(what, install, detail)
    n, s, f = r["attempts"], r["successes"], r["failures"]
    label = what + (f" ({detail})" if detail else "")

    if n == 0:
        extra = ""
        if r["retired"]:
            extra = (f" There are {r['retired']} older attempt(s) on record, "
                     f"but they were made before the current install and no "
                     f"longer describe this machine.")
        return (f"{label}: never tried on this build. You have no evidence "
                f"either way, so the only way to find out is to do it. "
                f"Try it.{extra}")

    if r["same_error_every_time"]:
        return (f"{label}: {f} attempts on this build, all failed the same "
                f"way - \"{(r['last_note'] or '')[:110]}\". Repeating it "
                f"identically is unlikely to help. Say what the error is and "
                f"ask the user whether they can fix it, or change something "
                f"about the attempt - a smaller size, fewer steps, the other "
                f"route - and try that.")

    if r["confidence"] == "unknown":
        return (f"{label}: tried {n} time{'s' if n != 1 else ''} on this "
                f"build, {s} worked. That is not enough to know anything - "
                f"the honest estimate is about {_pct(r['score'])}, and it "
                f"rests on {n} observation{'s' if n != 1 else ''}. Not a "
                f"reason to decline. Try it.")

    if r["confidence"] == "weak":
        return (f"{label}: {s} of {n} worked on this build, so roughly "
                f"{_pct(r['score'])}. That is a leaning, not a conclusion - "
                f"a few views of something is not knowing it. Worth trying.")

    return (f"{label}: {s} of {n} worked on this build, about "
            f"{_pct(r['score'])}. Measured, and still not a guarantee "
            f"either way.")


def breakdown(install: str = "") -> str:
    """
    The whole record, one line per thing tried. What the user asked to see.
    """
    rows = _read()
    if not rows:
        return ("Nothing has been attempted yet, so there is no record to "
                "read. Every capability is untested rather than unavailable.")
    kinds = sorted({r.get("what", "") for r in rows if r.get("what")})
    out = ["Attempts on this build (older attempts, made before the current "
           "install, are listed separately as retired - they were measured "
           "on a machine that no longer exists):",
           f"{'what':<20} {'tried':>5} {'ok':>4} {'est':>6}  confidence"]
    for k in kinds:
        r = reliability(k, install)
        note = r["confidence"]
        if r["retired"]:
            note += f", {r['retired']} retired"
        if r["same_error_every_time"]:
            note += ", same error each time - ask the user"
        # No number at zero attempts. The formula happily returns 50% with
        # nothing behind it, and a printed percentage invites exactly the
        # false precision this module exists to prevent.
        est = "-" if r["attempts"] == 0 else _pct(r["score"])
        out.append(f"{k[:20]:<20} {r['attempts']:>5} {r['successes']:>4} "
                   f"{est:>6}  {note}")
    out.append("")
    out.append("Fewer than 3 attempts is UNKNOWN and is never a reason to "
               "decline. 3-7 is a leaning. 8 or more is measured, and still "
               "not a guarantee.")
    return "\n".join(out)


def summary(install: str = "") -> dict:
    """Machine-readable version of breakdown(), for the interface."""
    rows = _read()
    kinds = sorted({r.get("what", "") for r in rows if r.get("what")})
    return {"kinds": [reliability(k, install) for k in kinds],
            "total": len(rows)}
