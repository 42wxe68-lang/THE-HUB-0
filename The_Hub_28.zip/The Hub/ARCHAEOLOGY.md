# ARCHAEOLOGY

What was actually found in Cairn, LuminovaZero and VeraZero, and what The
Hearth takes from each. Written from reading the source, not from
descriptions of the source.

---

## 1. CAIRN — the application

**Read:** `core.py` `runtime.py` `memory.py` `tools.py` `server.py` `ui.html`
`character.md` `config.json` `install.py` `get_model.py` `migrate.py`
`CAIRN.bat` `INSTALL.bat` `MIGRATE.bat` `STOP.bat`

### What it is

A complete, working, single-machine assistant. Standard library only — no
`pip install`, so it runs with the network unplugged. The browser never
touches llama.cpp:

```
browser --HTTP/SSE--> CAIRN (8420) --HTTP--> llama-server (8080)
                                   --HTTP--> curator      (8081)  CPU only
                                   --HTTP--> whisper.cpp  (8082)  CPU only
```

### What is genuinely good, and why

| Thing | Why it survives into The Hub untouched |
|---|---|
| **The sandbox in `core.py`** | `llm/` readable, never writable; `under()` rejects separators and traversal before joining; `writable()` re-checks after resolving. The model cannot alter the model it runs on. |
| **`_argv` built from clamped numbers** | `shell=False` and every value passed through `_clamp`. No string from the model, the network or the browser ever reaches a command line. |
| **Curator on CPU, never given `-ngl`** | A 4 GB card already holds ~2 GB of language model. The background summariser cannot contend for VRAM because it is structurally unable to ask for any. |
| **Prefix-cache-aware prompt order** | Stable memory at the head, volatile recall at the tail. Not a style choice — putting recall at the head forces a full re-prefill every turn. |
| **Search-result spotlighting in `tools.py`** | Untrusted content wrapped in a per-request random nonce. The closing marker cannot be forged because the attacker cannot know the nonce. |
| **Offline memo (`OFFLINE_MEMO`)** | A recent network-layer failure is trusted for 25 seconds, so an offline session does not pay a 7-second timeout on every search. |
| **`_is_offline_error`** | Distinguishes "no internet" from "the API said no". A 401 and a DNS failure need completely different advice. |
| **Atomic `write_json`** | Temp file then rename. A crash mid-write cannot corrupt memory. |
| **Two-tier memory injection** | `front_block` compact and stable; `recall_block` scored and volatile. |
| **Fail-soft tool phase** | If the tool round-trip breaks, the half-built exchange is dropped and the user still gets an answer. |

### What is wrong with it

| Problem | Evidence in the source | Consequence |
|---|---|---|
| **Memory has shape but no biology** | `memory.py` nodes are `{text, tags, created}`. Nothing else. | A fact from day one and one from this morning are indistinguishable. The only way anything ever leaves is falling off a cap. |
| **The cap drops the oldest** | `_put()`: `for n in (t.get(k) or [])[-spec["cap"]:]` | An old fact that gets used constantly is evicted before a new one nobody ever refers to. |
| **Pins are not exempt from the cap** | There are no pins. Everything is equally disposable. | Identity and boundaries evict like anything else. |
| **The curator picks the sephira** | `FACT_SYS` asks a 350M model for `{"keter":[],"chesed":[],...}` | It takes the first branch in the schema. The crown of the tree fills with facts about graphics cards. |
| **`remember` asks the 2.6B model too** | `REGISTRY["remember"]` has a `where` enum of eight Hebrew names | Same failure, one layer up, mid-conversation. |
| **Digested sessions are deleted** | `f.unlink(missing_ok=True)` after the digest exists | The digest is a lossy summary by a 350M model. The transcript was the only copy of what was actually said. |
| **Merged digests are deleted** | `(YESOD_DIR / fn).unlink(missing_ok=True)` | A path records that two moments echoed. Deleting the sources means you can never ask which two. |
| **`kill_orphans` kills by image name** | `taskkill /F /IM llama-server.exe` in `server.py`, and the same in `STOP.bat` | On a machine with both applications, starting one kills the other's model mid-sentence. **This is the single most dangerous thing found.** |
| **No event log** | The tree *is* the memory | If `tree.json` goes wrong, the memory is wrong, and there is nothing underneath to appeal to. |
| **No supervisory layer** | `character.md` says "use web search only when the answer genuinely depends on current information" | An instruction telling the model to notice its own blind spot. It forgets exactly when it is most confidently wrong. |
| **`tools.execute` decides *and* executes** | One function checks the registry, the config, parses args, and runs | No way to ask "would this be allowed?" without running it. |

---

## 2. LUMINOVAZERO — the living memory

**Read:** `tree_of_life.py` (925 lines), `luminova_core_v2_2.py`,
`luminova_core_v-3.2.1.py`, `luminova_core_v3_3.py`, `luminova_core_v4_0.py`

### The actual implementation

```
TreeOfLife
  └── Limb        knowledge | core | reality        (three, hard-asserted)
        └── Branch    named cluster, permanent or budded
              └── Leaf   content, weight, pin, tags, source, timestamps
  └── ActiveTree  the slice held in mind right now
  └── TreePruner  background thread, once a day
```

**The lifecycle, which is the valuable part:**

- `weight` 0.0–1.0 is how alive a leaf is
- `decay(days)` takes weight away — `DECAY_RATE_PER_DAY = 0.02`
- `reinforce(amount)` gives it back, and bumps `accessed_at` / `access_count`
- `pin=True` exempts a leaf from decay entirely
- `is_alive()` → `pin or weight >= MIN_LEAF_WEIGHT` (0.05)
- `relevance(query)` = content overlap ×0.50 + tag overlap ×0.25 + weight
  ×0.15 + recency ×0.10, recency being `exp(-age_days/180)`
- Branches bud when nothing scores above 0.15; branches close when their
  last leaf falls, unless `permanent`
- `ActiveTree.weave()` pulls the top-scoring leaves and reinforces each by
  0.02 — being thought about is a form of use

### What is wrong with it

| Problem | Evidence | Consequence |
|---|---|---|
| **Pruning deletes** | `self.leaves = [l for l in self.leaves if l.is_alive()]` | A memory that faded is gone. There is no ash. |
| **Three limbs, hard-asserted** | `assert name in ("knowledge","core","reality")` | The three-limb model cannot express what kind of memory something is. |
| **Every leaf scores above the cutoff** | `relevance` floors at `weight*0.15 + recency*0.10` ≈ 0.25 for anything recent; `RELEVANCE_CUTOFF` is 0.10 | **Recall returns the most recent memories regardless of subject, and the ranking looks plausible enough to hide it.** |
| **Branch names come from the first word** | `new_name = tags[0] if tags else content.split()[0].lower()` and `_best_branch_for` is called before tags exist | The tree fills with branches called `the`, `a`, `currently`. |
| **`Leaf.from_dict` is `cls(**d)`** | Any unknown key raises `TypeError`, and `load()` swallows it | One added field and an older build reads a whole limb as empty. |
| **Plain `open(path,"w")`** | `_save_limb` | A crash mid-write leaves truncated JSON; `load()` logs and carries on with nothing. |
| **`Lock`, not `RLock`** | `remember()` → `_best_branch_for()` → `relevance()` re-enters | One nested call from a deadlock. |
| **Writes outside the app folder** | `~/luminova/tree`, `~/lumen_nova` | Vera fixed this; the fix is inherited. |

---

## 3. VERAZERO — the knowledge that works

**Read:** `knowledge_tree.py` (1,163 lines), `vera_core.py`, `install.sh`,
`start.sh`, `README.md`

### Why the Knowledge Tree exists separately

This is the finding that mattered most, and Vera's README states it as
measured fact: her tree held **15,224 sight observations against 30
conversations**, and knowledge in the Active Tree sat at **zero**.

The continuous eye planted thousands of observations into `reality/` and
crowded everything else out of the weighting pool. Anything that shares a
relevance pool with a firehose loses.

**So the separation is not tidiness. It is the only thing that keeps
conceptual understanding alive in a system that also perceives.**

### The implementation

```
KnowledgeTree
  └── KnowledgeDomain    math | science | art
        ├── keywords     large curated sets, unigram/bigram/trigram scored
        └── KnowledgeBranch
              └── KnowledgeLeaf   same lifecycle as a Leaf, slower decay (0.015)
```

- `score(query)` = hits / (word_count ** 0.6) — penalises long queries so a
  3-word match in a 3-word question beats one in a 20-word question
- bigrams score 1.5, trigrams 2.0 — "black hole" and "number theory" are
  worth more than either word alone
- `context_for(query)` → **`(domain, text)` tuple**, multi-domain when a
  second scores ≥ 0.65 × primary (so "music theory" gets math + art)
- `grow(query, response, domain)` plants two leaves: the question in
  `questions` as a retrieval anchor, and the response lead in the
  best-matching branch

### The two shape mismatches Vera documented

Both are the kind that fail without raising anything a caller notices:

1. **`context_for()` returns a tuple, not a string.** Passing it through
   whole puts the literal `[None, '']` into the prompt as a system message.
2. **`grow()` takes `domain` as a required positional.** Calling it with two
   arguments raises `TypeError` — which the caller's bare `except` swallows,
   leaving the tree permanently empty *while looking connected*.

Both are now asserted in `verify.py`, so neither can come back quietly.

### What else Vera got right that is inherited

- **Everything inside the app folder.** `memory/` under the run directory,
  nothing written to `$HOME`. Copy the folder and you copy the character and
  its mind together.
- **One message per role**, question **last**. Vera's core had been building
  one concatenated string piped to `ollama run`, so persona, vision, memory
  and question all arrived wearing the same label and the model could not
  tell its own instructions from the user's words.
- **No "use your memory when relevant" in the prompt.** That is a reason,
  not information; it spends tokens every turn describing the plumbing, and
  a small model narrates the instruction back instead of answering.
- **`install.sh` exists because `start.sh` could not know what changed.**
  Vera's launcher pulled `qwen2.5:1.5b` because it was written for core v2.2
  and never updated when v3.3 changed the model — so the model the core
  actually needed was never fetched. The fix was to read the model name
  straight out of the core so the two can never drift again.

---

## 4. WHAT THE HEARTH INHERITS

```
CAIRN                     LUMINOVAZERO              VERAZERO
  sandbox + paths           Leaf/Branch/Limb          Knowledge Tree
  process management        weight/decay/pin          domain routing
  sephirot topology         reinforce-on-use          keyword scoring
  curator pipeline          ActiveTree weave          separation from perception
  prompt cache order        branch budding            self-containment
  spotlighting              daily pruner              one message per role
       |                          |                          |
       +--------------------------+--------------------------+
                                  |
                                  v
                            THE HEARTH
                                  |
        +-------------------------+-------------------------+
        |                         |                         |
   integrated memory        supervisory layer          repairability
   sephirot ARE limbs       preflight / gate /         append-only events
   ash instead of delete    postflight                 rebuild() from history
   deterministic placement  default deny               nothing ever deleted
```

**The one-line version:** Cairn had the shape, Luminova had the biology,
Vera had the separation. The Hub is the first of the three where a
sephira is a living tree, a faded memory still exists, and the model is not
the only thing deciding whether the world needs checking.
