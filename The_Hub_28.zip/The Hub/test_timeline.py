"""
test_timeline.py - it moves through time instead of querying it.

    "we need it to know, not to just read and write. It needs to move
     through time and not be limited to calling information back from
     then"

Retrieval answers "what matches these words". It has no opinion about
which of two matching memories came second, so it can never answer "what
is the latest" - and every version of this application before now answered
that question by ranking, which is to say by luck. These tests are about
the two things ranking cannot do: put one subject in order, and know which
end of that order is now.

They also guard the two ways a subject index goes wrong quietly:

  - filing a memory under a verb, so "the lighthouse video finished in
    46.6 minutes" becomes a subject called "finished" and is never found
    again by anyone asking about the lighthouse;

  - inventing a contradiction between two statements that are simply two
    statements, which is how a memory starts arguing with itself.
"""
from __future__ import annotations

import pathlib
import time

import core
import intake
import memory
import timeline


def _fresh_tree():
    memory._limbs.clear()
    memory._loaded = False
    timeline.forget_cache()


def _redirect(tmp_path):
    old = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
           core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
           memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
           memory.ACTIVE_STATE, intake.CANDIDATES)
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"
    core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"
    core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"
    core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    memory.ARCHIVE_DIR = core.SESSIONS / "archive"
    memory.YESOD_DIR = core.TREE / "yesod"
    memory.ACTIVE_DIR = core.DATA / "active"
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"
    intake.CANDIDATES = core.TREE / "candidates.jsonl"
    core.ensure_dirs()
    _fresh_tree()
    return old


def _restore(old):
    (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
     core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
     memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
     memory.ACTIVE_STATE, intake.CANDIDATES) = old
    _fresh_tree()


def _plant(limb, text, kind="stated", held=5.0, truth="probable"):
    memory.graft(limb, text, kind=kind, stability=held, truth=truth,
                 origin="user")
    time.sleep(0.02)          # so created_at orders them
    timeline.forget_cache()


def _seed():
    _plant("hod", "lighthouse video runs take about 43 minutes",
           truth="superseded")
    _plant("hod", "the GTX 1650 card has 4 GB of VRAM", held=9.0)
    _plant("hod", "the lighthouse video finished in 46.6 minutes", held=6.0)
    _plant("daat", "trellis reached flow step 10 of 12 at 10211 seconds",
           kind="observed", held=4.0)
    _plant("chesed", "they prefer the turbo preset for images")
    _plant("daat", "the turbo preset renders at 768 pixels",
           kind="inferred", held=1.2, truth="uncertain")
    _plant("hod", "bracket_v2.stl is the one they want printed", held=4.0)


# ------------------------------------------------------------- what a subject is

def test_a_subject_is_a_thing_not_something_happening(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        labels = {s["label"].lower() for s in timeline.subjects()}
        for verb in ("finished", "runs", "reached", "prefer", "want",
                     "printed", "renders", "take"):
            assert verb not in labels, \
                f"a memory was filed under the verb {verb!r}: {labels}"
        assert "lighthouse" in labels, labels
        assert "trellis" in labels, labels
    finally:
        _restore(old)


def test_a_pronoun_never_takes_a_subject_from_a_filename(tmp_path):
    """
    "they" appears in more memories than "bracket_v2.stl" does, so a rule
    that only rewards recurrence files a note about a printed part under
    "they". Thing-likeness has to outweigh one more mention.
    """
    old = _redirect(tmp_path)
    try:
        _seed()
        labels = {s["label"].lower() for s in timeline.subjects()}
        assert "they" not in labels, labels
        assert "bracket_v2.stl" in labels, labels
    finally:
        _restore(old)


def test_a_number_is_a_name_or_a_measurement_depending_on_what_precedes_it(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        labels = {s["label"].lower() for s in timeline.subjects()}
        assert "10211" not in labels, "a step count is not a subject"
        assert "768" not in labels, "a pixel size is not a subject"
        assert any("1650" in l for l in labels), \
            "a model number after a name IS a subject: " + repr(labels)
    finally:
        _restore(old)


def test_the_label_is_what_the_user_calls_it(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        labels = {s["label"] for s in timeline.subjects()}
        assert "GTX 1650" in labels, labels
        assert "turbo preset" in labels, labels
    finally:
        _restore(old)


# ------------------------------------------------------------- time

def test_one_subject_is_one_history_in_order(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        sub = next(s for s in timeline.subjects()
                   if s["label"].lower() == "lighthouse")
        assert sub["count"] == 2
        stamps = [e["when"] for e in sub["entries"]]
        assert stamps == sorted(stamps), "entries are not in time order"
        assert "46.6" in sub["current"]["line"], \
            "the newest entry is not the current one"
    finally:
        _restore(old)


def test_now_and_was_are_both_shown_and_labelled(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        block = timeline.standing(3000)
        body = block[block.index("- lighthouse"):]
        first = body.splitlines()[1]
        assert first.strip().startswith("now,"), first
        assert "46.6" in first
        was = [l for l in body.splitlines()[:3] if l.strip().startswith("was,")]
        assert was and "43 minutes" in was[0], body[:400]
    finally:
        _restore(old)


def test_a_contradiction_is_never_invented(tmp_path):
    """
    Two statements about one subject a month apart are two statements.
    Only a leaf the tree ALREADY marked superseded may be shown as a
    "was" - guessing at the conflict is the relief plaque again: an
    answer nobody asked for, standing where the real one should be.
    """
    old = _redirect(tmp_path)
    try:
        _plant("hod", "the kiln reaches cone 6 in about nine hours")
        _plant("hod", "the kiln element was replaced in August")
        block = timeline.standing(3000)
        assert "kiln" in block
        assert "was," not in block, \
            "an unmarked earlier statement was presented as replaced:\n" + block
    finally:
        _restore(old)


def test_how_well_known_is_words_not_numbers(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        for s in timeline.subjects():
            assert s["known"] in ("said once", "known", "known well"), s["known"]
        block = timeline.standing(3000)
        assert "known well" in block
        gtx = next(s for s in timeline.subjects() if "1650" in s["label"])
        assert gtx["known"] == "known well"
    finally:
        _restore(old)


def test_about_gives_the_chronology_newest_last(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        story = timeline.about("what is the latest on the lighthouse video")
        assert "lighthouse" in story.lower()
        assert story.index("43 minutes") < story.index("46.6"), \
            "the history is not in order:\n" + story
        assert "LAST line is what is true now" in story
        assert "was true, later replaced" in story
    finally:
        _restore(old)


def test_about_says_nothing_when_it_knows_nothing(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        assert timeline.about("stoneware glaze chemistry") == ""
        assert timeline.about("") == ""
    finally:
        _restore(old)


# ------------------------------------------------------------- empty

def test_an_empty_tree_makes_no_claims(tmp_path):
    """
    Empty says NOTHING. A heading promising current knowledge over an
    empty body teaches a model with no memory to describe having one -
    the same fault as "[what you remember]" restating the message that
    had just been typed.
    """
    old = _redirect(tmp_path)
    try:
        assert timeline.subjects() == []
        assert timeline.standing(2000) == ""
        assert timeline.prepared(2000) == ""
    finally:
        _restore(old)


def test_a_tight_budget_keeps_the_strongest_and_drops_whole_subjects(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        roomy = timeline.standing(4000)
        tight = timeline.standing(len(timeline.STANDING_HEAD) + 320)
        assert 0 < len(tight) < len(roomy)
        assert tight.startswith(timeline.STANDING_HEAD)
        # whole subjects, never half of one
        for line in tight.splitlines()[len(timeline.STANDING_HEAD.splitlines()):]:
            assert line.startswith("- ") or line.startswith("    "), line
        top = timeline.subjects()[0]["label"]
        assert top in tight, "the strongest subject was the one dropped"
    finally:
        _restore(old)


def test_prepared_is_stable_until_the_tree_changes(tmp_path):
    old = _redirect(tmp_path)
    try:
        _seed()
        timeline.forget_cache()
        first = timeline.prepared(3000)
        assert first
        for _ in range(3):
            assert timeline.prepared(3000) == first
        _plant("hod", "the enclosure fan is a Noctua 120")
        assert timeline.prepared(3000) != first
    finally:
        _restore(old)


# ------------------------------------------------------------- versions

def test_a_version_family_is_one_object():
    for name, fam in (("bracket_v3.stl", "bracket"),
                      ("bracket (2).stl", "bracket"),
                      ("bracket-final.stl", "bracket"),
                      ("bracket.stl", "bracket"),
                      ("Bracket_V12.STL", "bracket"),
                      ("top copy.obj", "top"),
                      ("lighthouse_storm.mp4", "lighthouse_storm")):
        assert timeline.family(name) == fam, (name, timeline.family(name))


def test_the_newest_version_is_the_current_one(tmp_path):
    """
    files.find() matches a name or a stem and returns one file. It has no
    idea that bracket_v2.stl came after bracket.stl, so "open the latest
    bracket" opened whichever one sorted first.
    """
    import playground
    import vault
    old = _redirect(tmp_path)
    # THE VAULT IS REDIRECTED TOO. versions() reads both workspaces, and a
    # suite that redirected core.DATA and forgot vault.VAULT once shipped a
    # build with twenty-nine stray scripts in it. Here it would also have
    # found the vault's own bracket.stl and failed for a reason that had
    # nothing to do with the code under test.
    saved = (playground.ROOT, vault.VAULT)
    try:
        playground.ROOT = core.DATA / "playground"
        vault.VAULT = tmp_path / "vault"
        vault.VAULT.mkdir(parents=True, exist_ok=True)
        playground.ROOT.mkdir(parents=True, exist_ok=True)
        for i, name in enumerate(("bracket.stl", "bracket_v2.stl",
                                  "bracket_v3.stl")):
            f = playground.ROOT / name
            f.write_text("solid\nendsolid\n", encoding="utf-8")
            import os
            os.utime(f, (1000 + i * 100, 1000 + i * 100))
        got = timeline.versions("bracket.stl")
        assert [d["name"] for d in got] == ["bracket_v3.stl", "bracket_v2.stl",
                                            "bracket.stl"], got
        assert timeline.latest("bracket")["name"] == "bracket_v3.stl"
        block = timeline.versions_block("bracket")
        assert block.splitlines()[1].strip().startswith("- bracket_v3.stl")
        assert "current version" in block
        # And the user's own copy is found, and marked as theirs.
        (vault.VAULT / "bracket_v1.stl").write_text("solid\nendsolid\n",
                                                    encoding="utf-8")
        import os
        os.utime(vault.VAULT / "bracket_v1.stl", (900, 900))
        got = timeline.versions("bracket")
        assert [d["name"] for d in got][-1] == "bracket_v1.stl", got
        assert got[-1]["mine"] is False
        assert "the user's" in timeline.versions_block("bracket")

        assert timeline.versions("nothing_like_this.stl") == []
        assert timeline.latest("nothing_like_this.stl") is None
    finally:
        (playground.ROOT, vault.VAULT) = saved
        _restore(old)


# ------------------------------------------------------------- wired in

def test_it_is_actually_in_the_prompt(tmp_path):
    """
    THE growth.py TEST, again. A module that assembles a perfect block
    nobody hands to the model is not a feature.
    """
    import runtime
    import server
    old = _redirect(tmp_path)
    saved = (runtime.health, runtime.live_ctx, runtime.resolve_max_tokens)
    runtime.health = lambda *a, **k: False
    runtime.live_ctx = lambda cfg: 8192
    runtime.resolve_max_tokens = lambda ctx, sampling: 512
    try:
        _seed()
        msgs, last_user, rep = server.build_messages(
            [{"role": "user", "content": "what is the latest on the lighthouse"}],
            core.load(), "")
        system = msgs[0]["content"]
        assert sum(1 for m in msgs if m["role"] == "system") == 1
        assert "[what is current" in system, "the standing block never arrived"
        assert "46.6" in system, "and it arrived with content"
        assert "[where what you know is]" in msgs[-1]["content"]
        assert rep["headroom"] > 0
        assert rep.get("n_ctx") == 8192
    finally:
        (runtime.health, runtime.live_ctx, runtime.resolve_max_tokens) = saved
        _restore(old)


def test_the_conversation_still_gets_the_largest_share():
    """
    Adding blocks without taking the room from somewhere takes it from the
    conversation. That is how continuity was lost one release at a time
    while every block ABOUT the conversation grew.
    """
    import budget
    for ctx in (32768, 15360, 8192, 4096, 2048):
        p = budget.Plan(n_ctx=ctx, max_tokens=1024, character_tokens=3000)
        rest = p.workable - p.character
        assert p.history / max(1, rest) >= 0.43, (ctx, p.as_dict())
        assert p.history > max(p.frame, p.recall, p.evidence, p.standing,
                               p.carryover, p.knowledge), (ctx, p.as_dict())
        total = (p.character + p.frame + p.knowledge + p.recall + p.evidence
                 + p.carryover + p.standing + p.history)
        assert total <= p.workable, (ctx, total, p.workable)


def test_nothing_here_can_run_out_of_time():
    src = pathlib.Path("timeline.py").read_text(encoding="utf-8")
    for banned in ("timeout", "deadline", "signal.alarm", "TimeoutError"):
        assert banned not in src, f"timeline.py has a {banned}"


def test_it_never_writes_to_the_tree():
    """
    Reading what is stored, not deciding what is stored. grove owns the
    leaves; two things that can write them is how a fact ends up with two
    definitions that disagree.
    """
    import ast
    tree = ast.parse(pathlib.Path("timeline.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            fn = node.func
            name = (fn.attr if isinstance(fn, ast.Attribute)
                    else getattr(fn, "id", ""))
            assert name not in ("graft", "forget", "learn", "write_json",
                                "save_limb", "_save"), \
                f"timeline.py writes memory at line {node.lineno}"


if __name__ == "__main__":
    import sys
    import testkit
    sys.exit(testkit.run(dict(globals()), "timeline - knowing, not fetching"))
