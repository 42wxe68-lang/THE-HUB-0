@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title The Hub

REM ---------------------------------------------------------------------
REM  Use the private runtime INSTALL.bat downloaded, and fall back to a
REM  system Python only if it is not there.
REM
REM  This launcher used to call bare `python`, which meant the embedded
REM  interpreter the installer had just placed in .runtime\python was never
REM  used - The Hub ran on whatever Python happened to be on PATH, or on a
REM  machine with none it failed with "python is not recognized" one step
REM  after a successful install.
REM ---------------------------------------------------------------------
set "PY=%~dp0.runtime\python\python.exe"
if not exist "%PY%" set "PY=python"

REM ---------------------------------------------------------------------
REM  Guard on something the INSTALLER produces, not on something shipped
REM  in the download.
REM
REM  The guard was  if not exist config.json  - but config.json is part of
REM  the release, so it always existed and the check never once fired. A
REM  user who skipped INSTALL.bat got a Python traceback about a missing
REM  llama-server instead of the one sentence that tells them what to do.
REM ---------------------------------------------------------------------
if not exist "%~dp0llm\llama.cpp\llama-server.exe" (
  echo.
  echo   The Hub is not set up yet. Run INSTALL.bat first.
  echo.
  pause
  exit /b 1
)
if not exist "%~dp0config.json" (
  echo.
  echo   config.json is missing. Run INSTALL.bat to rebuild it.
  echo.
  pause
  exit /b 1
)

"%PY%" "%~dp0server.py"
echo.
echo   The Hub has closed.
pause
