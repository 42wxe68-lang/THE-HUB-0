"""The Hub local image-generation adapters.

Generation is model-assisted but provider-agnostic. The main Nova model is
stopped before a local image generator is invoked, then restarted afterwards
so the machine runs one major generative model at a time.

Supported adapters when available on the local machine:
- Automatic1111 / Forge-compatible REST API (default port 7860)
- ComfyUI HTTP API (default port 8188) when a usable API workflow is supplied

Outputs are written only to Playground. Saving into Vault is a separate action.
"""
from __future__ import annotations

import base64
import json
import os
import time
import urllib.error
import urllib.request
import urllib.parse
from pathlib import Path

import core
import playground
import runtime


DEFAULT_PORTS = {
    "automatic1111": int(os.environ.get("HUB_A1111_PORT", "7860")),
    "comfyui": int(os.environ.get("HUB_COMFYUI_PORT", "8188")),
}


def _url(host: str, port: int, path: str) -> str:
    return f"http://{host}:{port}{path}"


def _get(host: str, port: int, path: str, timeout: int = 3):
    req = urllib.request.Request(_url(host, port, path), headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def discover() -> list[dict]:
    found: list[dict] = []
    for provider, port in DEFAULT_PORTS.items():
        try:
            if provider == "automatic1111":
                status, body = _get("127.0.0.1", port, "/sdapi/v1/options")
                if status == 200:
                    data = json.loads(body.decode("utf-8", "replace"))
                    ckpt = data.get("sd_model_checkpoint", "")
                    if isinstance(ckpt, dict):
                        ckpt = ckpt.get("title", "")
                    found.append({"provider": provider, "host": "127.0.0.1", "port": port,
                                  "model": str(ckpt)})
            else:
                status, _ = _get("127.0.0.1", port, "/system_stats")
                if status == 200:
                    found.append({"provider": provider, "host": "127.0.0.1", "port": port,
                                  "model": "local ComfyUI"})
        except Exception:
            continue
    return found


def _safe_output(name: str) -> str:
    name = str(name or "generated.png").strip()
    if not name.lower().endswith(".png"):
        name += ".png"
    # only a filename; the Playground owns the path
    return name.replace("/", "_").replace("\\", "_")


def _a1111(provider: dict, prompt: str, negative: str, width: int, height: int,
           steps: int, seed: int) -> tuple[bytes, dict]:
    payload = {
        "prompt": prompt,
        "negative_prompt": negative,
        "width": max(256, min(width, 1536)),
        "height": max(256, min(height, 1536)),
        "steps": max(1, min(steps, 50)),
        "seed": int(seed),
        "batch_size": 1,
        "n_iter": 1,
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(_url(provider["host"], provider["port"], "/sdapi/v1/txt2img"),
                                 data=data, headers={"Content-Type": "application/json"}, method="POST")
    # NO DEADLINE. Half an hour sounds generous and is still a number picked
    # for a machine we cannot see; an external provider on a slow card can
    # exceed it while working perfectly. It waits.
    with urllib.request.urlopen(req, timeout=None) as r:
        obj = json.loads(r.read().decode("utf-8", "replace"))
    imgs = obj.get("images") or []
    if not imgs:
        raise RuntimeError("image generator returned no image")
    raw = base64.b64decode(imgs[0].split(",", 1)[-1])
    return raw, {"provider": provider["provider"], "prompt": prompt, "seed": seed}


def _comfyui(provider: dict, prompt: str, workflow: dict | None) -> tuple[bytes, dict]:
    if not workflow:
        raise RuntimeError("ComfyUI is available, but no API workflow was supplied; provide workflow_json in the tool call")
    # The user/model supplies the graph. We only send it, poll, then retrieve
    # the first produced image. This avoids hard-coding a specific checkpoint.
    client_id = f"hub-{int(time.time()*1000)}"
    payload = json.dumps({"prompt": workflow, "client_id": client_id}).encode("utf-8")
    req = urllib.request.Request(_url(provider["host"], provider["port"], "/prompt"),
                                 data=payload, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=30) as r:
        queued = json.loads(r.read().decode("utf-8", "replace"))
    pid = queued.get("prompt_id")
    if not pid:
        raise RuntimeError("ComfyUI did not return a prompt id")
    deadline = time.time() + 1800
    history = None
    while time.time() < deadline:
        try:
            status, body = _get(provider["host"], provider["port"], f"/history/{pid}", timeout=5)
            history = json.loads(body.decode("utf-8", "replace"))
            if pid in history:
                break
        except Exception:
            pass
        time.sleep(1.0)
    record = (history or {}).get(pid) or {}
    outputs = record.get("outputs") or {}
    for node in outputs.values():
        for img in node.get("images") or []:
            qs = f"?filename={urllib.parse.quote(img['filename'])}&subfolder={urllib.parse.quote(img.get('subfolder',''))}&type={urllib.parse.quote(img.get('type','output'))}"
            status, body = _get(provider["host"], provider["port"], "/view" + qs, timeout=60)
            if status == 200:
                return body, {"provider": "comfyui", "prompt": prompt}
    raise RuntimeError("ComfyUI completed without a retrievable image output")


def generate(*, prompt: str, filename: str = "generated.png", provider: str = "auto",
             negative_prompt: str = "", width: int = 768, height: int = 768,
             steps: int = 20, seed: int = -1, workflow_json: dict | None = None) -> dict:
    prompt = str(prompt or "").strip()
    if not prompt:
        raise ValueError("prompt is required")
    providers = discover()
    if provider != "auto":
        providers = [p for p in providers if p["provider"] == provider]
    if not providers:
        raise RuntimeError("no supported local image generator is reachable (Automatic1111/Forge on 7860 or ComfyUI on 8188)")

    # Prevent Nova's model from occupying the GPU/large-RAM slot while another
    # generative model is doing the image work. Restore it even on failure.
    was_running = runtime.state().get("status") not in ("stopped", "error")
    selected_model = None
    try:
        selected_model = runtime.state().get("model")
    except Exception:
        pass
    if was_running:
        runtime.stop()

    try:
        p = providers[0]
        if p["provider"] == "automatic1111":
            raw, meta = _a1111(p, prompt, negative_prompt, width, height, steps, seed)
        else:
            raw, meta = _comfyui(p, prompt, workflow_json)
        name = _safe_output(filename)
        # Use Playground public write path only; image bytes are written here
        # with a dedicated binary helper below to avoid text/base64 round trips.
        playground.ensure()
        target = playground.resolve(name, must_exist=False)
        if target.exists():
            stem, suf = target.stem, target.suffix
            for i in range(2, 10000):
                candidate = target.with_name(f"{stem} ({i}){suf}")
                if not candidate.exists():
                    target = candidate
                    name = candidate.name
                    break
        target.write_bytes(raw)
        manifest = target.with_name(target.stem + ".generation.json")
        manifest.write_text(json.dumps({**meta, "negative_prompt": negative_prompt,
                                        "width": width, "height": height,
                                        "steps": steps, "generated_at": time.time()}, indent=2),
                            encoding="utf-8")
        return {"ok": True, "name": name, "manifest": manifest.name,
                "provider": meta.get("provider"), "prompt": prompt}
    finally:
        if was_running and selected_model:
            # cfg is passed through core config; use the same runtime settings.
            cfg = core.load().get("runtime", {})
            runtime.start(selected_model, cfg)
