"""
learning.py - The Hub's operational learning layer.

A failure is diagnostic information, not a memory worth teaching Nova forever.
The durable thing is the corrected practice that survives the failure.

Design rule:
  failure/error -> logs + ephemeral outcome
  corrected/successful practice -> classified durable lesson

Lessons use the same Tree of Life as every other memory. They decay normally,
can be reinforced, and can fall to ash. There is no second memory database and
no second model.
"""
from __future__ import annotations

import re

import classify
import events
import memory


def _clean(text: str) -> str:
    t = " ".join(str(text or "").split()).strip()
    return t[:600]


def teach(principle: str, *, tags=None, source: str = "operational_learning",
          origin: str = "system") -> bool:
    """Store a corrected reusable principle through the normal memory router."""
    p = _clean(principle)
    if len(p) < 12:
        return False
    # classify.Placement HAS NO `.scores`. It has `sephira`, `confidence`
    # and `distribution` - and it never had a `.scores`, so this line raised
    # AttributeError on every call this file has ever made.
    #
    # Both callers are wrapped: server.py logs "correction learn failed" and
    # carries on, from_success() swallows it too. So every correction the
    # user ever made - "no, do it this way instead" - was routed here, threw,
    # was written to data/logs/learning.log, and taught nothing. The thing
    # whose entire job is to make a correction stick was the one thing that
    # could not.
    #
    # This is why nothing anybody corrected ever seemed to take.
    placement = classify.place(p)
    dist = getattr(placement, "distribution", None) or {}
    best = max(dist.items(), key=lambda kv: kv[1], default=(None, 0.0))
    sephira = placement.sephira or (best[0] if best[1] > 0 else None) or "chokmah"
    ok = memory.graft(sephira, p, tags=list(tags or [])[:10],
                      source=source, origin=origin, truth="confirmed",
                      kind="stated" if origin == "user" else "inferred")
    if ok:
        events.write("lesson.learned", sephira=sephira, text=p,
                     source=source, origin=origin)
    return ok


def from_success(tool: str, raw: str) -> bool:
    """Promote a reusable rule from a successful operation."""
    t = (raw or "").lower()
    if "success" not in t and "saved" not in t and "rendered" not in t and "edited" not in t:
        return False
    lessons = {
        "copy_to_playground": "Work on a copied file in the Playground; keep the Vault source untouched.",
        "convert_file": "Perform file conversion in the Playground from a working copy; keep the Vault source untouched.",
        "edit_playground": "Modify working files in the Playground rather than editing the Vault source.",
        "save_playground": "Save completed Playground results into the Vault as new files; do not overwrite an existing Vault file.",
        "inspect_3d": "For a 3D asset, inspect the object through its six orthogonal views and use a custom camera angle when a feature remains hidden.",
        "run_playground": "Use the Playground as the executable working area for file transformations; keep source material in the Vault protected.",
    }
    lesson = lessons.get(tool)
    return teach(lesson, tags=[tool, "playground", "workflow"] if lesson else []) if lesson else False


def correction(text: str) -> bool:
    """Turn a direct user correction into the corrected rule, not the old mistake."""
    t = _clean(text)
    low = t.lower()
    # Only learn explicit corrective/directive language; ordinary conversation is left alone.
    if not any(x in low for x in ("instead", "should", "must", "not ", "don't", "do not", "remember")):
        return False
    # KEEP THE SENTENCE, NOT THE TAIL OF IT.
    #
    # This used to cut at the marker and keep everything after it, so
    #
    #     "no, put the file in the Playground instead, not the vault"
    #
    # was stored as "instead, not the vault" - a lesson that names no
    # action, no subject and no place, filed as confirmed, and reaching
    # the prompt forever after as something the machine believes it knows.
    # A correction cut in half is not a shorter correction. It is a
    # different one, and it is wrong.
    #
    # The sentence carrying the marker is kept whole, with the "no," that
    # opens most corrections trimmed off the front because it is aimed at
    # the last answer, not at the rule.
    candidate = t
    for marker in ("instead", "the correct way is", "what it should do is",
                   "it should", "should be", "must", "don't", "do not"):
        idx = low.rfind(marker)
        if idx < 0:
            continue
        start = max((low.rfind(c, 0, idx) for c in ".!?;\n"), default=-1) + 1
        end = min((e for e in (low.find(c, idx) for c in ".!?;\n") if e > 0),
                  default=len(t))
        candidate = t[start:end].strip()
        break
    candidate = re.sub(r"^(?:no+|nope|actually|wait|hold on|hey)\b[\s,:-]*",
                       "", candidate, flags=re.I).strip()
    if len(candidate) < 12:
        candidate = t
    # Require a concrete operational subject.
    if not any(k in low for k in ("vault", "playground", "memory", "model", "voice", "vision", "file", "tool", "context")):
        return False
    # The user typed it, so it is stated - not something Nova worked out.
    return teach(candidate, tags=["correction", "lesson"] if candidate else [],
                 origin="user")
