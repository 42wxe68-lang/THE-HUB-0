"""
test_toolsurface.py - every tool Nova is offered can actually run.

WHY THIS EXISTS

Three separate lists have to agree before a tool works:

    tools.REGISTRY   what the function is
    tools.enabled()  whether Nova is offered it (ALWAYS / a config switch)
    policy.TIERS     whether the default-deny gate will let it through

HUB-ZERO added nineteen tools and got two of those three wrong in
different places:

  * read_key, pass_off, set_theme and web_search_more were registered and
    advertised with NO entry in policy.TIERS. The gate is default-deny, so
    Nova could see them in its own tool list, call one, and be told "there
    is no tool named set_theme".

  * save_to_ai_vault, delete_ai_vault and web_search_more were registered
    AND gated, but left out of ALWAYS with no config key, so enabled()
    dropped them from the schema list. Nova was never offered them at all.
    The AI vault was built, tested, and unreachable.

Both failures are silent. Nothing crashes, no test goes red, the feature is
just not there. So the three lists are checked against each other directly.
"""
from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import policy   # noqa: E402
import tools    # noqa: E402

SEARCH_ON = {"tools": {"web_search": True}, "appearance": {}}
SEARCH_OFF = {"tools": {"web_search": False}, "appearance": {}}


def test_every_registered_tool_is_gated():
    missing = sorted(set(tools.REGISTRY) - set(policy.TIERS))
    assert not missing, (
        f"registered and advertised but not in policy.TIERS, so the "
        f"default-deny gate refuses them as unknown: {missing}")


def test_no_gate_entry_without_a_tool():
    orphan = sorted(set(policy.TIERS) - set(tools.REGISTRY))
    assert not orphan, f"policy entries for tools that do not exist: {orphan}"


def test_every_tool_is_reachable_in_some_configuration():
    never = sorted(set(tools.REGISTRY) - set(tools.enabled(SEARCH_ON)))
    assert not never, (
        f"registered but never offered to Nova in any configuration - "
        f"missing from tools.ALWAYS and from tools.FOLLOWS, with no config "
        f"switch of their own: {never}")


def test_every_offered_tool_is_authorized_by_the_gate():
    gate = policy.Gate()
    refused = []
    for name in tools.enabled(SEARCH_ON):
        d = gate.authorize(name, "{}", SEARCH_ON)
        # Bad or missing arguments are a fine reason to refuse; not existing
        # and not being switched on are not.
        if d.verdict == "refuse" and d.reason in ("unknown-tool", "disabled"):
            refused.append(f"{name} ({d.reason})")
    assert not refused, (
        f"offered to Nova and refused by the gate for reasons that have "
        f"nothing to do with the arguments: {refused}")


def test_only_network_tools_are_behind_the_web_search_switch():
    gained = set(tools.enabled(SEARCH_ON)) - set(tools.enabled(SEARCH_OFF))
    for name in gained:
        assert policy.TIERS[name]["network"], (
            f"{name} appears only when web search is on but is not marked "
            f"as a network tool")
    for name, spec in policy.TIERS.items():
        # MAYBE means "can reach the network, and checks the switch itself".
        # generate_image is the case: with web search off it draws from the
        # prompt alone rather than disappearing, because taking away image
        # generation is not what turning off web search should mean.
        if spec["network"] is True:
            assert name in gained, (
                f"{name} touches the network but is offered even when web "
                f"search is switched off - the one switch must mean it")


def test_network_tools_are_not_auto():
    for name, spec in policy.TIERS.items():
        if spec["network"] is True:
            assert spec["tier"] != policy.AUTO, (
                f"{name} leaves the machine and must not be AUTO - it needs "
                f"the rate limit and the per-turn taint rule that LIMITED "
                f"carries")


def test_the_model_still_has_no_tool_for_writing_its_own_memory():
    """The system records; the model searches. This must stay true."""
    for banned in ("remember", "forget", "write_memory", "graft"):
        assert banned not in tools.REGISTRY, f"{banned} is back in the registry"


if __name__ == "__main__":
    import testkit
    sys.exit(testkit.run(dict(globals()),
                         "TOOL SURFACE - registry, offer and gate agree"))
