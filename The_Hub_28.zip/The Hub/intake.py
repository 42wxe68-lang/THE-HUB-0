"""
intake.py - the gap between something happening and something being remembered.

RULE 1: NOT EVERYTHING BECOMES MEMORY.

Before this file, `graft()` was the front door and anything that reached it
went into the Tree. That is why the Tree filled with "lol ok" and half-formed
sentences and the same fact five times in slightly different words. A memory
system whose intake is "whatever arrived" is a log, not a memory.

    USER / WORLD
          │
          ▼
      INGESTION          observe(): everything, cheaply, with provenance
          │
          ▼
    MEMORY CANDIDATE     scored, deduplicated, held
          │
          ├── discard    chatter, questions, transient state
          ├── temporary  true today, not worth keeping
          │
          ▼
       MEMORY            promoted into the Tree

RULE 2: NOVA DOES NOT DECIDE WHERE MEMORY BELONGS.

Nothing in this file asks the model anything. Candidate scoring is
deterministic - lexical shape, provenance, repetition, specificity - and
placement is `classify.place()`, which has a 68-case suite behind it. The
model can neither choose a sephira nor force a promotion, and that is the
point: a model that files its own memories writes down what it happened to
notice rather than what was said.

RULE 4: TIME MATTERS.

A candidate that restates an existing memory with different content is not a
contradiction. It is a LATER STATE of the same thing. "I use vim" followed
six months later by "I use helix now" is one fact with a history, not two
facts in conflict. Supersession is handled here, at intake, because that is
where both versions are visible at once.

PROVENANCE
Every candidate carries where it came from - which turn, which speaker, which
tool, which file. A memory without provenance cannot be audited, and a memory
system that cannot be audited is one you have to trust rather than check.
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone

import classify
import core
import events

CANDIDATES = core.TREE / "candidates.jsonl"

# A candidate needs this much to be promoted. Deliberately not high - the
# cost of a weak memory is that it fades, and the cost of a missed one is
# that it is gone.
PROMOTE_AT = 0.55
DISCARD_BELOW = 0.20

# Seen this many times across separate turns, promote regardless of score.
# Repetition is the user telling you it matters.
REPEAT_PROMOTES = 2

_lock = threading.RLock()


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ═══════════════════════════════════════════════════════════════════════════
# §1  SCORING - deterministic, explainable, no model involved
# ═══════════════════════════════════════════════════════════════════════════

# Shapes that are never memory, however often they appear.
NEVER = [
    (re.compile(r"^\s*(ok|okay|yes|no|yep|nope|sure|thanks|ty|lol|haha|hm+|"
                r"right|got it|cool|nice|great|k)\b[\s.!?]*$", re.I),
     "acknowledgement"),
    (re.compile(r"^\s*(what|who|when|where|why|how|is|are|do|does|did|can|"
                r"could|would|should|will)\b.*\?\s*$", re.I),
     "a question, not a statement"),
    (re.compile(r"^\s*(continue|go on|more|next|again|keep going|and\?)\b",
     re.I), "an instruction to proceed"),
    (re.compile(r"^\s*(hi|hey|hello|good (morning|evening|night)|bye)\b",
     re.I), "greeting"),
]

# Things that are true right now and not worth keeping.
TRANSIENT = re.compile(
    r"\b(right now|at the moment|currently (?:loading|running|open)|"
    r"today'?s? (?:weather|date)|this (?:second|minute))\b", re.I)

# Signals that something is durable and about the user.
DURABLE = [
    (0.35, re.compile(r"\b(i|my|me|we|our)\b", re.I), "about them"),
    (0.30, re.compile(r"\b(always|never|every|prefer|hate|love|need|must|"
                      r"can'?t|won'?t|refuse)\b", re.I), "a standing rule"),
    (0.25, re.compile(r"\b(am|is|are|was|were|works?|lives?|uses?|builds?|"
                      r"runs?|owns?|has|have)\b", re.I), "a statement of fact"),
    (0.20, re.compile(r"\b\d{2,}\b"), "a specific number"),
    (0.20, re.compile(r"\b[A-Z][a-z]+(?:[- ][A-Z][a-z]+)+\b"), "a proper name"),
    (0.15, re.compile(r"\b(because|so that|which means|the reason)\b", re.I),
     "carries a reason"),
]


def score(text: str, origin: str = "user") -> tuple:
    """
    (0..1, reason). How much this looks like something worth keeping.

    Explainable on purpose. When a memory is wrong, the reason it was kept
    should be readable, not buried in a model's judgement.
    """
    t = (text or "").strip()
    if len(t) < 12:
        return 0.0, "too short to mean anything"
    if len(t) > 600:
        t = t[:600]

    for pat, why in NEVER:
        if pat.match(t):
            return 0.0, why
    if TRANSIENT.search(t):
        return 0.12, "true right now, not worth keeping"

    s, reasons = 0.0, []
    for weight, pat, why in DURABLE:
        if pat.search(t):
            s += weight
            reasons.append(why)

    # Length helps, to a point. One clause is usually a fragment; three
    # sentences is usually a paragraph that should have been split.
    words = len(t.split())
    if 6 <= words <= 40:
        s += 0.15
        reasons.append("a complete thought")
    elif words > 80:
        s -= 0.15
        reasons.append("long enough that it should be split")

    # Provenance. What the user said outranks what a tool returned, and what
    # a tool returned outranks what the model concluded.
    s += {"user": 0.20, "tool": 0.05, "file": 0.05,
          "reflection": -0.05, "web": -0.10}.get(origin, 0.0)

    # It must survive placement. If classify cannot find a home for it, it is
    # not a fact about this person.
    p = classify.place(t)
    if p.unsorted or not p.sephira:
        return min(s, 0.30), f"no clear place for it ({p.reason})"
    s += 0.10 * p.confidence
    reasons.append(f"belongs in {p.sephira}")

    return max(0.0, min(1.0, round(s, 3))), "; ".join(reasons[:4])


# ═══════════════════════════════════════════════════════════════════════════
# §2  CANDIDATES - held, counted, superseded
# ═══════════════════════════════════════════════════════════════════════════

def _key(text: str) -> str:
    """What makes two statements 'the same thing said again'."""
    words = [w for w in re.findall(r"[a-z0-9]{3,}", (text or "").lower())
             if w not in classify.STOP] if hasattr(classify, "STOP") else \
            re.findall(r"[a-z0-9]{4,}", (text or "").lower())
    return " ".join(sorted(set(words))[:8])


def _load() -> list:
    out = []
    try:
        if CANDIDATES.exists():
            for line in CANDIDATES.read_text(encoding="utf-8",
                                             errors="replace").splitlines():
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        continue
    except Exception as e:
        core.log_line("memory", f"candidate load failed: {e}")
    return out


def _save(rows: list) -> None:
    try:
        core.TREE.mkdir(parents=True, exist_ok=True)
        tmp = CANDIDATES.with_suffix(".tmp")
        tmp.write_text("\n".join(json.dumps(r, ensure_ascii=False)
                                 for r in rows) + "\n", encoding="utf-8")
        tmp.replace(CANDIDATES)
    except Exception as e:
        core.log_line("memory", f"candidate save failed: {e}")


def observe(text: str, origin: str = "user", turn: str = "",
            source: str = "") -> dict:
    """
    INGESTION. Something happened; note it and decide later.

    Cheap and total. Everything the user says passes through here, and most
    of it dies here, which is the point - the expensive question of whether
    something is worth remembering is answered against a scored candidate
    rather than against the Tree after the fact.
    """
    t = (text or "").strip()
    if len(t) < 12:
        return {"kept": False, "why": "too short"}

    sc, why = score(t, origin)
    if sc < DISCARD_BELOW:
        events.write("intake.discard", text=t[:160], score=sc, why=why)
        return {"kept": False, "score": sc, "why": why}

    k = _key(t)
    with _lock:
        rows = _load()
        for r in rows:
            if r.get("key") == k:
                # Said again. Repetition is evidence, and a later phrasing
                # is usually the better one.
                if turn and turn not in r.get("turns", []):
                    r.setdefault("turns", []).append(turn)
                r["seen"] = len(r.get("turns", [])) or r.get("seen", 1) + 1
                r["score"] = max(r.get("score", 0), sc)
                r["text"] = t if len(t) >= len(r["text"]) else r["text"]
                r["last"] = now()
                _save(rows)
                return {"kept": True, "repeat": True, "seen": r["seen"],
                        "score": r["score"]}

        rows.append({
            "key": k, "text": t[:600], "score": sc, "why": why,
            "origin": origin, "source": source,
            "turns": [turn] if turn else [], "seen": 1,
            "first": now(), "last": now(), "state": "held",
        })
        _save(rows)
    events.write("intake.candidate", text=t[:160], score=sc, origin=origin)
    return {"kept": True, "score": sc, "why": why}


# Lines whose subject is this conversation rather than the world. These are
# not unimportant - they are how the user steers - but they describe a
# moment, and a moment does not belong in identity.
_ABOUT_US = re.compile(
    r"(?i)\b(you|your|nova|it) (said|copied|repeated|wrote|replied|answered|"
    r"did|keep|kept|stopped|forgot|ignored)\b"
    r"|\b(don'?t|do not|stop) (do|say|repeat|copy|write|talk|keep)\b"
    r"|\b(i (was|am) (saying|asking|telling))\b"
    r"|\b(that('?s| is) not what|why did you|i did ?n'?t ask)\b"
    r"|\b(try again|retry|again please)\b"
    r"|\bi (don'?t|do not) see (it|that|them)\b")


def _about_the_exchange(text: str) -> bool:
    return bool(_ABOUT_US.search(text or ""))


# HOW MUCH WAS AT STAKE, and which way it went.
#
# Arousal - not valence - is what the consolidation literature actually
# supports as a retention signal, so it is what raises stability. Valence
# only decides how fast the FEELING settles afterwards: the sting of a bad
# outcome fades faster than the glow of a good one, with the content of both
# kept. See hold.py.
_HIGH_STAKES = re.compile(
    r"(?i)\b(crash(ed|es)?|broke|broken|lost|losing|destroyed|corrupt(ed)?|"
    r"failed|failure|wasted|ruined|dangerous|never again|hate|furious|"
    r"angry|frustrat\w+|regret|sorry|apolog\w+|urgent|critical|"
    r"important|matters|must|deadline|finally|works?!|working now|"
    r"perfect|excellent|brilliant|love it|thank you|solved|fixed it)\b")
_BAD = re.compile(
    r"(?i)\b(crash(ed|es)?|broke|broken|lost|losing|destroyed|corrupt(ed)?|"
    r"failed|failure|wasted|ruined|dangerous|never again|hate|furious|"
    r"angry|frustrat\w+|regret|sorry|worse|wrong|useless|not a fix)\b")
_GOOD = re.compile(
    r"(?i)\b(finally|works?!|working now|perfect|excellent|brilliant|"
    r"love it|thank you|solved|fixed it|great|nice|better|beautiful)\b")


def _arousal(text: str) -> float:
    """0..1 - how much was at stake, from the user's own words."""
    hits = len(set(m.group(0).lower()
                   for m in _HIGH_STAKES.finditer(text or "")))
    return min(1.0, hits * 0.34)


def _valence(text: str) -> float:
    """-1 loss or regret, +1 something that went right, 0 neither."""
    bad = len(_BAD.findall(text or ""))
    good = len(_GOOD.findall(text or ""))
    if bad == good:
        return 0.0
    return -1.0 if bad > good else 1.0


def promote(force: bool = False) -> dict:
    """
    CANDIDATE -> MEMORY. Deterministic, and it runs without the model.

    A candidate is promoted when it scores well enough, or when it has been
    said in more than one turn. Repetition promotes a weak score because a
    person saying the same thing twice is telling you it matters, whatever
    the wording looked like the first time.
    """
    import memory

    with _lock:
        rows = _load()
    kept, made, dropped = [], [], 0

    for r in rows:
        if r.get("state") != "held":
            kept.append(r)
            continue
        ready = force or r["score"] >= PROMOTE_AT or \
            r.get("seen", 1) >= REPEAT_PROMOTES
        if not ready:
            # Held candidates fade too. A thing mentioned once, months ago,
            # that never came up again was not important.
            from grove import _age_days
            if _age_days(r.get("last", "")) > 30:
                dropped += 1
                events.write("intake.expire", text=r["text"][:160])
                continue
            kept.append(r)
            continue

        prior = _supersedes(r["text"])
        p = classify.place(r["text"])

        # ── IS THIS ABOUT THE WORLD, OR ABOUT THE LAST REPLY ────────────
        #
        #     Boundaries:
        #     - I don't see it.
        #     - what? why did you copy me, don't do that
        #
        # That was on the user's screen, at the top of every prompt, filed
        # under the same heading as "everything must run offline". A regex
        # scoring 5 for /(never|must not|do not|don't) \w+/ matched "don't
        # do that" and "I don't see it", and a moment's irritation became
        # permanent identity.
        #
        # Grammar is not salience. A complaint about the previous reply is
        # the most predictable thing a person can say after a bad reply -
        # and predictability is exactly what says something is not worth
        # storing. Event segmentation puts prediction error at the encoding
        # gate for this reason.
        #
        # So a line that is ABOUT THE CONVERSATION is not a boundary. It
        # can still be kept as an ordinary observation if it earns it; what
        # it cannot do is become identity.
        if p.sephira in ("gevurah", "keter") and _about_the_exchange(
                r["text"]):
            events.write("intake.demote", text=r["text"][:160],
                         was=p.sephira, why="about the exchange, not a rule")
            p.sephira = "hod"

        # ── AND IS ANY OF IT NEW ────────────────────────────────────────
        #
        # Surprise is what earns a place. Something already in the tree in
        # other words is not a new memory; it is the same one, said again,
        # and the tree already has a way to record that.
        try:
            import hold
            known = [l.content for l in memory.all_leaves(memory.RECALLABLE)]
            fresh = hold.surprise(r["text"], known)
            arousal = _arousal(r["text"])
            valence = _valence(r["text"])
            stability = hold.initial_stability(
                surprise_score=fresh, arousal=arousal,
                stated=(r["origin"] == "user"))
        except Exception:
            fresh, arousal, valence, stability = 0.5, 0.0, 0.0, 1.0

        # WHO KNOWS THIS, AND HOW. grove has carried observed / stated /
        # attributed / inferred since it was written, and until now NO
        # production caller ever passed one - so every leaf in every tree
        # was "unknown", the seal in memory.recall() that keeps somebody
        # else's opinion out of a question about the world could never
        # fire, and a line the user typed was indistinguishable from a
        # line a 2B model guessed. Provenance that is never written is a
        # comment, not a field.
        leaf = memory.graft(
            p.sephira or "hod", r["text"],
            weight=min(0.9, 0.5 + r["score"] * 0.4),
            source="experience" if r["origin"] == "user" else "inference",
            origin=r["origin"],
            kind="stated" if r["origin"] == "user" else "observed",
            stability=stability, affect=arousal, valence=valence)
        if leaf is None:
            kept.append(r)
            continue

        r["state"] = "promoted"
        r["promoted_at"] = now()
        made.append({"text": r["text"][:120], "where": p.sephira,
                     "score": r["score"], "supersedes": prior})
        events.write("intake.promote", text=r["text"][:160],
                     where=p.sephira, score=r["score"],
                     seen=r.get("seen", 1), supersedes=prior or "")
        if prior:
            memory.reweight(prior, truth="superseded")

    with _lock:
        _save(kept)
    return {"promoted": len(made), "expired": dropped,
            "held": len(kept), "made": made}


def _supersedes(text: str) -> str:
    """
    RULE 4. Is this a later state of something already known?

    Not a contradiction - a later state. "I use vim" then "I use helix now"
    is one fact with a history. The old leaf is marked superseded rather than
    disproven, so it stays findable as history without being repeated as
    current.

    The test is deliberately narrow: the same SUBJECT with a different
    PREDICATE. Two statements that merely share vocabulary are not versions
    of each other.
    """
    import memory
    subj = _subject(text)
    if not subj:
        return ""
    for hits in memory.tree().values():
        for row in hits:
            if row.get("truth") in ("superseded", "disproven"):
                continue
            if _subject(row["text"]) != subj:
                continue
            if _key(row["text"]) == _key(text):
                return ""            # the same thing, not a new state
            return row.get("leaf_id", "")
    return ""


SUBJECT = re.compile(
    r"\b(?:my|our|the)\s+([a-z][a-z\-]{2,}(?:\s+[a-z][a-z\-]{2,})?)|"
    r"\bi\s+(?:use|prefer|run|work|live|own|build|drive|read|play)\b", re.I)


def _subject(text: str) -> str:
    m = SUBJECT.search(text or "")
    if not m:
        return ""
    return (m.group(1) or m.group(0)).strip().lower()


def held() -> list:
    """Candidates waiting. Visible, so intake can be inspected not trusted."""
    return [r for r in _load() if r.get("state") == "held"]


def stats() -> dict:
    rows = _load()
    h = [r for r in rows if r.get("state") == "held"]
    return {"held": len(h), "promoted": len(rows) - len(h),
            "ready": sum(1 for r in h
                         if r["score"] >= PROMOTE_AT
                         or r.get("seen", 1) >= REPEAT_PROMOTES)}
