"""
tools.py - the tool registry. The model requests; policy.py authorizes.

WHAT CHANGED FROM CAIRN
-----------------------
Cairn's tools.py both decided and executed: execute() checked the registry,
checked the config, parsed the arguments and then ran the thing. That worked,
but it meant the authorisation rules lived inside the module that also did
the work, and there was no way to ask "would this be allowed?" without
running it.

In The Hub the decision is policy.Gate and the work is here. This module
executes what it is handed and does not decide whether it should have been.
execute() is kept as a wrapper so anything expecting Cairn's signature still
works, but the real path is gate.authorize() -> tools.run().

Every call still fails soft: a refusal string goes back to the model rather
than an exception going up, so a bad tool call becomes a correction instead
of a crash.

Web results are untrusted input. They are HTML-stripped, hard-truncated,
and wrapped in a per-request random nonce - spotlighting, per OWASP LLM01
guidance on indirect prompt injection. The closing marker cannot be forged
because the attacker cannot know the nonce. Tool calls are only ever
honoured from the assistant channel, so text living inside a search result
can never enable a disabled tool or trigger a new one.
"""
from __future__ import annotations

import ast
import pathlib
from pathlib import Path
import datetime
import html
import json
import operator as op
import re
import secrets
import socket
import time
import threading
import uuid
import urllib.error
import urllib.parse
import urllib.request

import core
# FIRST-PARTY MODULES, IMPORTED ONCE, AT THE TOP.
#
# These were used all over this file and imported only inside whichever
# functions happened to remember to do it. Four did not, and every one of
# them raised at runtime the moment it was reached:
#
#     3D GENERATION FAILED: name 'playground' is not defined
#
# which the model then reported to the user as a capability limit, and went
# on repeating for the rest of the session. A missing import became "I do not
# have the resources for that".
#
# None of these import tools, so there is no cycle to be careful about.
# verify.py now checks this statically for every module in the folder.
import playground
import vault

UA = "The Hub/1.0 (local personal assistant)"

# A tool cannot decide to phone somewhere new.
ALLOWED_HOSTS = {
    "en.wikipedia.org",
    "api.duckduckgo.com",
    "api.search.brave.com",
    "api.tavily.com",
}

# Short by design. On a dead gateway or captive portal - WiFi connected but
# no route out - urlopen waits the full timeout with no feedback. Two
# providers at 15s each meant a 30-second freeze with Nova looking hung and
# the Stop button useless, because the hang is in the tool phase before
# streaming starts. Seven seconds is enough for a real request and short
# enough that a failure feels like a failure rather than a crash.
NET_TIMEOUT = 7
OFFLINE_MEMO = 25          # seconds to trust a recent offline verdict

_net = {"ok": None, "at": 0.0, "err": ""}
_search_lock = threading.RLock()
_search_cache = {}
_SEARCH_LOG = core.DATA / "research" / "search_log.jsonl"


def net_status() -> dict:
    """Last known connectivity, for the UI. Never probes; only observes."""
    # If the loaded model can see, the pictures a page is about come back
    # with it. A search that returns only text is blind on exactly the pages
    # that are mostly picture - a diagram, a chart, a photo of the thing
    # being asked about.
    try:
        import vision, runtime
        if vision.capability().get("sees") and _last_html:
            base = runtime.MAIN if runtime.health(runtime.MAIN, 0.5) else None
            for u in vision.images_on_page(_last_html, _last_url, limit=2):
                shot = vision.look_at_url(u, base, str(args.get("query", "")))
                if shot and "could not" not in shot[:20]:
                    lines.append("\n" + shot)
    except Exception:
        pass

    return dict(_net)


def _mark(ok: bool, err: str = "") -> None:
    _net.update({"ok": ok, "at": time.time(), "err": err[:120]})


def _is_offline_error(e: Exception) -> bool:
    """
    Distinguish 'no internet' from 'the API said no'.

    A DNS failure, refused connection, or timeout means the network is gone.
    An HTTP 401 or 429 means we got through and the provider objected - very
    different advice for the user.
    """
    if isinstance(e, urllib.error.HTTPError):
        return False
    if isinstance(e, (socket.timeout, TimeoutError, ConnectionError)):
        return True
    if isinstance(e, urllib.error.URLError):
        return isinstance(e.reason, (socket.gaierror, socket.timeout,
                                     TimeoutError, ConnectionError, OSError))
    return False


def believed_offline() -> bool:
    """True only if a recent attempt actually failed at the network layer."""
    return (_net["ok"] is False) and (time.time() - _net["at"] < OFFLINE_MEMO)


def _get(url: str, headers=None, timeout: int = NET_TIMEOUT) -> str:
    host = urllib.parse.urlparse(url).hostname or ""
    if host not in ALLOWED_HOSTS:
        raise ValueError(f"host not on allowlist: {host}")
    req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
        _mark(True)
        return body
    except Exception as e:
        if _is_offline_error(e):
            _mark(False, str(e))
        else:
            _mark(True, str(e))   # we reached the host; it just refused
        raise


_SCRIPTISH = re.compile(
    r"<(script|style|iframe|object|embed|noscript)\b[^>]*>.*?</\1>",
    re.I | re.S,
)


def _strip(s: str) -> str:
    """
    Reduce markup to plain text before anything reaches the model.

    Script and style bodies are dropped whole, not just their tags. The
    model cannot execute JavaScript, but leaving the source in context is
    free injection surface and pure noise in a small model's window.
    """
    s = _SCRIPTISH.sub(" ", s or "")
    s = re.sub(r"<[^>]+>", " ", s)
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


# ---------------------------------------------------------------- calculator

_OPS = {
    ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv,
    ast.Pow: op.pow, ast.Mod: op.mod, ast.FloorDiv: op.floordiv,
    ast.USub: op.neg, ast.UAdd: op.pos,
}


def _eval(n):
    if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
        return n.value
    if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_eval(n.left), _eval(n.right))
    if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
        return _OPS[type(n.op)](_eval(n.operand))
    raise ValueError("unsupported expression")


def calculator(args, cfg):
    """AST whitelist, never eval(). Numbers and arithmetic operators only."""
    expr = str(args.get("expression", ""))[:200]
    if len(expr) > 200 or "**" in expr and len(expr) > 40:
        return "Refused: expression too large."
    try:
        val = _eval(ast.parse(expr, mode="eval").body)
        if isinstance(val, float) and val.is_integer():
            val = int(val)
        return f"{expr} = {val}"
    except Exception:
        return f"Could not evaluate {expr!r}. Numbers and + - * / // % ** only."


# ---------------------------------------------------------------- remember

def search_memory(args, cfg):
    """
    Look through everything The Hub has recorded. The model asks; the
    engine ranks.

    THIS REPLACES `remember`.

    Nova used to decide what was worth keeping and call a tool to write it.
    That put the model in charge of its own memory, which is the wrong way
    round twice: it writes down what it happened to notice rather than what
    was said, and it can write something false into durable storage.

    The system records everything now, without being asked. What Nova gets
    instead is the ability to LOOK - phrases, sentences, words, across living
    memory, faded memory, past conversations and the vault. She does not
    order the results; the engine does.
    """
    import index
    q = str(args.get("query", "")).strip()[:200]
    if len(q) < 2:
        return "Refused: empty search."
    kinds = ()
    scope = str(args.get("scope", "everything")).lower().strip()
    if scope == "memories":
        kinds = ("leaf", "ash")
    elif scope == "conversations":
        kinds = ("digest", "session")
    elif scope == "files":
        kinds = ("file",)
    hits = index.search(q, limit=8, kinds=kinds)
    return index.as_block(q, hits)


def open_file(args, cfg):
    """
    Look at one thing in the vault. Anything - not just text.

    ONE tool, not a family of them. An image, a PDF, an STL, a video and a
    markdown file are all "open this and tell me what is in it" from where
    the user stands, and splitting that into look_at_image / read_pdf /
    measure_model would be four names for one intention and four chances for
    a small model to pick the wrong one.

    What comes back is measured first and described second, and it says
    which is which. Colours, dimensions, geometry and embedded text are
    facts. A model's account of an image is an interpretation, and it is
    labelled as one because a model without working vision does not fail
    loudly - it describes a plausible image that is not there.
    """
    import vault, vision, runtime, playground
    name = str(args.get("name", "")).strip()[:200]
    scope = str(args.get("scope", "vault")).strip().lower() or "vault"
    if not name:
        return "Refused: no filename."
    if scope == "playground":
        path = playground.resolve(name)
        if path is None:
            have = [i["name"] for i in playground.list_files()][:20]
            return (f"There is no {name!r} in the Playground."
                    + (" It holds: " + ", ".join(have) if have else " It is empty."))
    else:
        path = vault.resolve(name)
        if path is None:
            have = [i["name"] for i in vault.listing(refresh_text=False)][:12]
            return (f"There is no {name!r} in the vault."
                    + (" It holds: " + ", ".join(have) if have else " It is empty."))
    base = runtime.MAIN if runtime.health(runtime.MAIN, 0.5) else None
    r = vision.look(path, str(args.get("about", "")).strip()[:200], base)

    # If the loaded model can SEE, hand it the actual picture rather than a
    # paragraph about the picture. A tool result is text, so the file is
    # registered on the turn and the chat path attaches it to the message.
    #
    # Without this a vision model opening a vault image received only
    # measurements and answered, accurately and uselessly: "I would need to
    # see the full image to describe specific subjects or details."
    # Native VLMs should receive the actual pixels, not a prose description.
    # Videos contribute a representative frame; still images contribute
    # themselves. The measurement/description remains in the tool result.
    if r["via"] in ("native", "measured") and vision.capability().get("sees"):
        import policy
        facts = r.get("facts") or {}
        attach_path = None
        label = "image"
        if facts.get("kind") == "video":
            attach_path = Path(facts.get("frame_path", ""))
            if not attach_path.is_file():
                attach_path = vision.grab_frame(path)
            label = "video frame"
        elif facts.get("kind") == "image":
            attach_path = path
        elif facts.get("kind") == "model3d":
            attach_path = Path(facts.get("preview_path", ""))
            label = "multi-angle 3D visual preview"
            if not attach_path.is_file():
                try:
                    import model3d
                    attach_path = model3d.preview_for(path)
                except Exception:
                    attach_path = None
        if attach_path and Path(attach_path).is_file():
            policy.GATE.attach(Path(attach_path))
            return (r["text"] + f"\n\n[the {label} itself is attached to this turn - "
                                "inspect it directly]")
    return r["text"]


# ---------------------------------------------------------------- search

def _wikipedia(q: str, n: int):
    url = ("https://en.wikipedia.org/w/api.php?action=query&list=search"
           f"&format=json&formatversion=2&srlimit={n}&srsearch={urllib.parse.quote(q)}")
    hits = json.loads(_get(url)).get("query", {}).get("search", [])
    return [{
        "title": h.get("title", ""),
        "url": "https://en.wikipedia.org/wiki/"
               + urllib.parse.quote((h.get("title") or "").replace(" ", "_")),
        "snippet": _strip(h.get("snippet", "")),
    } for h in hits]


def _ddg(q: str, n: int):
    url = ("https://api.duckduckgo.com/?format=json&no_html=1&skip_disambig=1"
           f"&no_redirect=1&q={urllib.parse.quote(q)}")
    d = json.loads(_get(url))
    out = []
    if d.get("AbstractText"):
        out.append({"title": d.get("Heading") or q,
                    "url": d.get("AbstractURL", ""),
                    "snippet": d["AbstractText"]})
    for t in (d.get("RelatedTopics") or [])[:n]:
        if isinstance(t, dict) and t.get("Text"):
            out.append({"title": (t.get("Text") or "")[:70],
                        "url": t.get("FirstURL", ""),
                        "snippet": t["Text"]})
    return out[:n]


def _brave(q: str, n: int, key: str):
    url = ("https://api.search.brave.com/res/v1/web/search"
           f"?count={n}&q={urllib.parse.quote(q)}")
    d = json.loads(_get(url, {"X-Subscription-Token": key,
                              "Accept": "application/json"}))
    return [{"title": r.get("title", ""), "url": r.get("url", ""),
             "snippet": _strip(r.get("description", ""))}
            for r in (d.get("web", {}).get("results") or [])[:n]]


def _tavily(q: str, n: int, key: str):
    body = json.dumps({"query": q, "max_results": n,
                       "search_depth": "basic"}).encode()
    req = urllib.request.Request(
        "https://api.tavily.com/search", data=body, method="POST",
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {key}", "User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=NET_TIMEOUT + 5) as r:
            d = json.loads(r.read().decode())
        _mark(True)
    except Exception as e:
        _mark(not _is_offline_error(e), str(e))
        raise
    return [{"title": x.get("title", ""), "url": x.get("url", ""),
             "snippet": _strip(x.get("content", ""))}
            for x in (d.get("results") or [])[:n]]


OFFLINE_MSG = (
    "No internet connection, so web search is unavailable right now. "
    "Everything else still works. Tell the user plainly that you could not "
    "reach the internet, then answer from what you already know if you can."
)


def _page_bytes(url: str, limit: int = 400_000):
    """Fetch a page so its images can be found. Capped, and best effort."""
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "The Hub/1.0 (local assistant)"})
        with urllib.request.urlopen(req, timeout=12) as r:
            if "html" not in (r.headers.get("Content-Type") or "").lower():
                return b""
            return r.read(limit)
    except Exception:
        return b""



def _store_search(query: str, results: list, asked: str = "") -> str:
    sid = uuid.uuid4().hex[:12]
    # `asked` is the user's own sentence, kept so the CATEGORY they named -
    # "the character" - can still be read when the results are rendered. The
    # query is the words sent to the engine; the sentence is the question.
    rec = {"id": sid, "query": query, "results": results,
           "asked": asked or query, "at": time.time()}
    with _search_lock:
        _search_cache[sid] = rec
        if len(_search_cache) > 24:
            oldest = sorted(_search_cache.items(), key=lambda kv: kv[1].get("at", 0))[:8]
            for k, _ in oldest:
                _search_cache.pop(k, None)
    try:
        _SEARCH_LOG.parent.mkdir(parents=True, exist_ok=True)
        with _SEARCH_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return sid


def _get_search_record(sid: str):
    sid = str(sid or "").strip()
    with _search_lock:
        rec = _search_cache.get(sid)
    if rec:
        return rec
    try:
        for line in reversed(_SEARCH_LOG.read_text(encoding="utf-8").splitlines()):
            if not line.strip():
                continue
            obj = json.loads(line)
            if obj.get("id") == sid:
                with _search_lock:
                    _search_cache[sid] = obj
                return obj
    except Exception:
        pass
    return None


def _format_search_page(rec: dict, offset: int = 0, limit: int = 8) -> str:
    """
    The results, headed by the question they were supposed to answer.

    THE THREE BUCKETS.

    Asked to research "the terrible tornado, the character", the results
    came back covering an S-Class hero from One-Punch Man, character SKINS
    in a video game, and general disaster narratives - and all three were
    reported to the user as findings of equal standing, with a request for
    clarification on top.

        "I had asked for a character, so only one of those three
         descriptions that you have just matched up actually applies... you
         also brought up general context. I didn't ask for that either. We
         are not talking about what I've said... but you've still brought
         these to the table as facts."

    The results were not wrong; a search returns what matches the words. The
    fault is that by the time they were read, WHAT WAS ASKED had been
    dropped, and a page of unfiltered matches with no question attached is
    an invitation to summarise all of them.

    So the question travels with its answers, and the instruction that goes
    with it is the one that was missing: a result that does not answer it is
    not evidence, and saying so is the work.
    """
    results = rec.get("results") or []
    offset = max(0, min(int(offset or 0), len(results)))
    limit = max(1, min(int(limit or 8), 12))
    page = results[offset:offset + limit]
    body = "\n\n".join(
        f"[{offset + i + 1}] {r.get('title','')}\n{r.get('url','')}\n{(r.get('snippet') or '')[:800]}"
        for i, r in enumerate(page)
    )
    q = str(rec.get("query") or "").strip()
    kind = ""
    try:
        import focus as _fo
        kind = _fo.subject_kind(str(rec.get("asked") or q))
    except Exception:
        pass
    head = (f"YOU SEARCHED FOR: {q}\n"
            + (f"WHAT WAS ASKED FOR: a {kind}. A result about anything else "
               f"is not an answer to this, however well it matches the "
               f"words.\n" if kind else "")
            + "These are search results, not facts, and not all of them are "
              "about the thing you asked for. Keep the ones that answer the "
              "question, say plainly that the others are unrelated rather "
              "than reporting them, and search again with better words if "
              "none of them fit.\n\n")
    end = offset + len(page)
    more = f"\n\nSEARCH_ID={rec.get('id')} OFFSET={end} MORE_AVAILABLE={str(end < len(results)).lower()}"
    return head + (body or "No additional results in this search.")[:9000] + more


def web_search_more(args, cfg):
    sid = str((args or {}).get("search_id", "")).strip()
    rec = _get_search_record(sid)
    if not rec:
        return "No stored search result set for that search_id. Run web_search again."
    return _format_search_page(rec, int((args or {}).get("offset", 0) or 0), int((args or {}).get("limit", 8) or 8))

def web_search(args, cfg):
    q = str(args.get("query", "")).strip()[:300]
    limit = max(1, min(int(args.get("limit", 8) or 8), 12))
    if len(q) < 2:
        return "Refused: empty query."

    # A recent network-layer failure is trusted for a short while. Without
    # this, every search in an offline session pays the full timeout again.
    if believed_offline():
        return OFFLINE_MSG

    s = cfg.get("search", {})
    prov = s.get("provider", "wikipedia")
    res, errs = [], []

    def attempt(fn, *a):
        try:
            res.extend(fn(*a))
        except Exception as e:
            errs.append(e)

    if prov == "brave" and s.get("brave_key"):
        attempt(_brave, q, limit, s["brave_key"])
    elif prov == "tavily" and s.get("tavily_key"):
        attempt(_tavily, q, limit, s["tavily_key"])
    else:
        attempt(_wikipedia, q, limit)
        # Skip the second provider once the first proved the network is down,
        # instead of paying the timeout twice.
        if not believed_offline():
            attempt(_ddg, q, max(2, min(limit, 6)))

    if not res:
        if errs and all(_is_offline_error(e) for e in errs):
            return OFFLINE_MSG
        if errs:
            e = errs[0]
            if isinstance(e, urllib.error.HTTPError):
                if e.code in (401, 403):
                    return ("Search rejected the API key. Check the key in "
                            "settings, or switch the provider to Wikipedia, "
                            "which needs no key.")
                if e.code == 429:
                    return "Search provider rate limit reached. Try again shortly."
            return f"Search failed: {str(e)[:150]}"
        return f"No results for {q!r}."

    # If the model can see, look at what the top result is a picture OF.
    # A search that returns only text is blind on exactly the pages that are
    # mostly picture - a diagram, a chart, a photo of the thing being asked
    # about. The description joins the result block and carries the same
    # untrusted marking, because it came from the same page.
    seen = ""
    try:
        import vision, runtime
        if vision.capability().get("sees") and res:
            base = runtime.MAIN if runtime.health(runtime.MAIN, 0.5) else None
            for r in res[:4]:
                page = _page_bytes(r["url"])
                if not page:
                    continue
                for u in vision.images_on_page(page, r["url"], limit=1):
                    shot = vision.look_at_url(u, base, q)
                    if shot and not shot.startswith("could not"):
                        seen += "\n\n" + shot
                        break
                if seen:
                    break
    except Exception:
        pass

    sid = _store_search(q, res, asked=q)
    body = _format_search_page({"id": sid, "query": q, "results": res,
                                "asked": q}, 0, limit)
    # Preserve the visual observations from the first page without replacing
    # the complete result set. Nova can call web_search_more when it needs
    # later results instead of receiving a silently truncated search.
    if seen:
        body += "\n\nVISUAL PAGE OBSERVATION\n" + seen[:2400]
    return (body[:9000])


# ═══════════════════════════════════════════════════════════════════════════
#  A REAL PICTURE OF THE THING, WHEN THE MODEL HAS NEVER SEEN THE THING
#
#  "the lack of characters it does not know in its training data is exposed"
#
#  A 4B model asked for GARO, or Saitama, or anyone outside the handful of
#  franchises that survived into its weights, does not know it does not know.
#  It writes a confident prompt full of the words it associates with the
#  name, the image model draws a generic figure, and the result is wrong in a
#  way nobody in the loop can see - least of all the model, which then
#  describes its own prompt back as though it were the picture.
#
#  Searching does not fix this on its own. A search returns SENTENCES about a
#  character, and sentences are what the model already had too much of. What
#  it needs is the picture: a real reference it can hand to the image model
#  as init_image, or to the mesh step as the thing to build.
#
#  So this brings one back and puts it in the Playground, where every other
#  generation input already lives. Nothing special happens to it afterwards -
#  it is a file, `generate_image` and `generate_3d` already accept a file,
#  and the user can look at it and throw it away.
#
#  WHERE IT CAME FROM TRAVELS WITH IT. The source URL goes into a sidecar and
#  into the return value, because a reference whose origin is unknown is how
#  someone ends up printing a picture they were never allowed to print, and
#  because the honest sentence to the user is "this is from <page>", not "I
#  made this".
# ═══════════════════════════════════════════════════════════════════════════

# Anything smaller than this is furniture - an avatar, a nav icon, a rating
# star. A reference has to be big enough to be worth conditioning on.
REF_MIN_PX = 220
REF_MAX_MB = 12.0


def _image_candidates(query: str, limit: int = 4) -> list:
    """Image URLs from the pages a search returns, best page first."""
    import vision
    out = []
    res = []
    try:
        res = _wikipedia(query, 4)
    except Exception:
        pass
    if len(res) < 2 and not believed_offline():
        try:
            res += _ddg(query, 4)
        except Exception:
            pass
    for r in res:
        page = _page_bytes(r.get("url", ""))
        if not page:
            continue
        for u in vision.images_on_page(page, r["url"], limit=3):
            out.append((u, r.get("url", ""), r.get("title", "")))
            if len(out) >= limit * 3:
                break
        if len(out) >= limit * 3:
            break
    return out


def _image_query(path) -> tuple:
    """
    (query, how) - search terms derived from a picture, and where they came
    from. "" when the picture cannot be turned into words at all.

    THE MISSING DIRECTION.

        "it doesn't have search query from an image ... it needs to have
         this"

    Everything here could turn words into a picture and nothing could turn a
    picture back into words to look something up with. So an image on disk
    was a dead end: it could be attached, and that was all.

    Two sources, best first, and both are honest about what they are:

      THE SIDECAR   an image this machine generated has the prompt that made
                    it stored beside it. Those are exact words, no model
                    involved, and they work with no vision at all.
      LOOKING       when the selected model can see, it is asked what is in
                    the picture, and the answer becomes the query.

    A model with no vision and a picture with no sidecar - a photo the user
    dropped in - gets neither, and says so rather than searching for
    something it guessed.
    """
    from pathlib import Path as _P
    p = _P(path)

    side = p.with_name(p.stem + ".generation.json")
    if side.is_file():
        rec = core.read_json(side, None)
        if isinstance(rec, dict) and rec.get("prompt"):
            return str(rec["prompt"])[:300], "the prompt that made it"

    src = p.with_name(p.name + ".source.json")
    if src.is_file():
        rec = core.read_json(src, None)
        if isinstance(rec, dict):
            q = rec.get("query") or rec.get("page_title") or ""
            if q:
                return str(q)[:300], "what it was fetched as"

    try:
        import vision, runtime
        if vision.capability().get("sees"):
            base = runtime.MAIN if runtime.health(runtime.MAIN, 0.5) else None
            said = vision.describe(
                p, "Name the subject of this picture in a few words - who or "
                   "what it is. No description, just the name.", base)
            said = " ".join(str(said or "").split())[:200]
            if said and not said.lower().startswith(("could not", "no ")):
                return said, "looking at it"
    except Exception:
        pass
    return "", ""


def _search_from_image(args, cfg):
    """Look something up starting from a picture rather than from words."""
    name = str(args.get("name", "")).strip()
    if not name:
        return ("SEARCH FROM IMAGE NOT STARTED: give the `name` of a picture "
                "in the Playground or the Vault.")
    try:
        path = _resolve_input(name, str(args.get("scope", "playground")))
    except FileNotFoundError as e:
        return f"SEARCH FROM IMAGE FAILED: {e}"
    if path is None:
        return "SEARCH FROM IMAGE NOT STARTED: no such picture."

    query, how = _image_query(path)
    extra = str(args.get("about", "")).strip()
    if not query and not extra:
        return (f"CANNOT SEARCH FROM {path.name}: there is no prompt stored "
                f"beside it and the selected model cannot see, so there is "
                f"nothing to turn into search terms. Say what you want to "
                f"know about it in `about`, or select a model marked VISION "
                f"and try again. Do not guess what the picture shows.")
    q = " ".join(x for x in (query, extra) if x)[:300]
    out = web_search({"query": q, "limit": int(args.get("limit", 6) or 6)},
                     cfg)
    lead = (f"SEARCHED FROM {path.name} using "
            f"{how or 'what you asked about it'}: {q!r}\n"
            f"These terms describe the picture; they are not a claim that "
            f"the results are of it.\n\n")
    return lead + str(out)


def _fetch_reference_image(args, cfg):
    import vision
    query = str(args.get("query", "")).strip()[:300]
    url = str(args.get("url", "")).strip()
    want = str(args.get("filename", "")).strip()

    if not query and not url:
        return ("REFERENCE NOT FETCHED: give either `query` (what to find a "
                "picture of) or `url` (a direct link to one image).")
    if believed_offline():
        return OFFLINE_MSG
    if url and not url.lower().startswith(("http://", "https://")):
        return "REFERENCE NOT FETCHED: `url` must be an http or https link."

    candidates = ([(url, url, "")] if url
                  else _image_candidates(query or "", 4))
    if not candidates:
        return (f"REFERENCE NOT FETCHED: nothing usable found for "
                f"{query!r}. The pages that came back had no images, or the "
                f"search returned nothing. Try different words, or pass a "
                f"direct `url` to one picture.")

    playground.ensure()
    tried = []
    for img_url, page_url, title in candidates:
        path, why = vision.fetch_image(img_url, max_mb=REF_MAX_MB)
        if path is None:
            tried.append(f"{img_url[:60]}: {why}")
            continue
        facts = vision.image_facts(path)
        w, h = int(facts.get("width") or 0), int(facts.get("height") or 0)
        if w < REF_MIN_PX or h < REF_MIN_PX:
            tried.append(f"{img_url[:60]}: only {w}x{h} px")
            continue

        import forge as _fg
        base = want or _fg._describe(
            (query or title or "reference"), path.suffix or ".jpg")
        if not base.lower().endswith(path.suffix.lower()):
            base = base.rsplit(".", 1)[0] + path.suffix
        dest = playground.ROOT / playground._safe_name(base)
        n = 1
        while dest.exists():
            dest = playground.ROOT / playground._safe_name(
                f"{base.rsplit('.', 1)[0]}_{n}{path.suffix}")
            n += 1
        dest.write_bytes(path.read_bytes())
        core.write_json(dest.with_suffix(dest.suffix + ".source.json"), {
            "kind": "reference-image",
            "image_url": img_url,
            "page_url": page_url,
            "page_title": title,
            "query": query,
            "fetched": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })
        _attach(dest, "reference")
        colours = ", ".join(c["colour"] for c in
                            (facts.get("dominant_colours") or [])[:3])
        return (
            f"REFERENCE IMAGE FETCHED: Playground/{dest.name} - {w}x{h} px"
            + (f", mostly {colours}" if colours else "") + ".\n"
            f"SOURCE (untrusted, from the web): {img_url[:200]}"
            + (f"\nFOUND ON: {page_url[:200]}" if page_url and
               page_url != img_url else "") + "\n"
            "It is attached - LOOK AT IT before using it, and say what is "
            "actually in it. If it is not the subject asked for, fetch a "
            "different one rather than building on it.\n"
            "TO USE IT: pass input_image=\"" + dest.name + "\" to "
            "generate_image (to redraw in a new pose or style) or to "
            "generate_3d (to build a mesh of it). Tell the user where it "
            "came from; it is not yours and it is not generated.")
        # (one good candidate is enough)

    return ("REFERENCE NOT FETCHED: every candidate was unusable - "
            + "; ".join(tried[:4])
            + ". Nothing was saved. Try different search words or a direct "
              "`url`.")


# ---------------------------------------------------------------- clock

def clock(args, cfg):
    """
    The date and time from the system clock.

    Local by definition. Without this, asking Nova what day it is would push
    her toward web search for something the machine already knows - which is
    exactly the kind of needless internet dependency worth removing.
    """
    now = datetime.datetime.now().astimezone()
    return (f"{now.strftime('%A, %d %B %Y, %I:%M %p')} "
            f"({now.strftime('%Z') or 'local time'}). "
            f"ISO: {now.isoformat(timespec='seconds')}")


# ---------------------------------------------------------------- registry


def _list_playground(args=None):
    """
    Everything reachable, in ONE list, each line saying what may be done.

    This used to list the Playground alone, and that was the source of the
    whole confusion: files the user had kept, or sent in chat, simply did
    not appear, so the model concluded they did not exist and said so - to
    a user who could see them.

    There is one namespace now. The only thing that ever really differed
    between the folders was permission, so permission is what is printed,
    beside every name, instead of being implied by a path the model has to
    guess.
    """
    import files
    rows = files.listing(200)
    if not rows:
        return "There are no files anywhere yet."
    mine = [r for r in rows if r["can_edit"] and not r["is_note"]]
    theirs = [r for r in rows if not r["can_edit"] and not r["is_note"]]
    notes = [r for r in rows if r["is_note"]]
    out = []
    if mine:
        out.append("YOURS - you can change or delete these:")
        for r in mine[:80]:
            out.append(f"- {r['name']} - {r['size_mb']} MB")
    if theirs:
        out.append("")
        out.append("THE USER'S - read them freely, never change them. "
                   "Naming one copies it into your workspace for you:")
        for r in theirs[:80]:
            out.append(f"- {r['name']} - {r['size_mb']} MB - {r['where']}")
    if notes:
        out.append("")
        out.append(f"({len(notes)} .generation.json / .source.json notes are "
                   f"also here. A note is ABOUT a file and is never the file "
                   f"- name the picture, not the note.)")
    return "\n".join(out)

def _copy_to_playground(args):
    import vault, playground
    src = vault.resolve(str(args.get("name", "")).strip()[:200])
    if src is None:
        return "There is no such file in the vault."
    try:
        r = playground.copy_in(src, str(args.get("as_name", "")).strip() or None)
        return f"Copied {src.name} to the Playground as {r['name']}. The vault copy remains untouched."
    except Exception as e:
        return f"Could not copy to Playground: {str(e)[:220]}"

def _write_playground(args):
    import playground
    try:
        r = playground.write_text(str(args.get("name", "")), str(args.get("content", "")), bool(args.get("overwrite", False)))
        return f"Wrote Playground file {r['name']}."
    except Exception as e:
        return f"Could not write Playground file: {str(e)[:220]}"

def _edit_playground(args):
    import playground, vault
    name = str(args.get("name", "")).strip()
    try:
        # If the user/model names a vault file directly, stage a private copy
        # before editing so the common "change X" request just works.
        if playground.resolve(name) is None:
            src = vault.resolve(name)
            if src is not None:
                playground.copy_in(src, name)
        r = playground.edit_text(name, str(args.get("find", "")), str(args.get("replace", "")), bool(args.get("all_matches", True)))
        return f"Edited Playground file {r['name']}; {r['replacements']} replacement(s)."
    except Exception as e:
        return f"Could not edit Playground file: {str(e)[:220]}"

def _rename_playground(args):
    import playground
    try:
        r = playground.rename(str(args.get("name", "")), str(args.get("new_name", "")))
        return f"Renamed Playground file to {r['name']}."
    except Exception as e:
        return f"Could not rename Playground file: {str(e)[:220]}"

def _delete_playground(args):
    import playground
    try:
        r = playground.delete(str(args.get("name", "")))
        return f"Deleted Playground working file {r['deleted']}. The vault was not touched."
    except Exception as e:
        return f"Could not delete Playground file: {str(e)[:220]}"

def _run_playground(args):
    import playground
    try:
        r = playground.run(str(args.get("program", "")), args.get("args") or [], int(args.get("timeout", 120)))
        out = (r.get("stdout") or "").strip()
        err = (r.get("stderr") or "").strip()
        return f"Playground process returncode={r['returncode']}\nstdout:\n{out}\nstderr:\n{err}"
    except Exception as e:
        return f"Could not run Playground program: {str(e)[:260]}"

def _convert_file(args):
    import model3d, vault, playground
    name = str(args.get("name", "")).strip()[:200]
    target = str(args.get("to", "")).strip().lower()[:12]
    scope = str(args.get("scope", "vault")).strip().lower() or "vault"
    src = playground.resolve(name) if scope == "playground" else vault.resolve(name)
    if src is None:
        return f"There is no {name!r} in {scope}."
    try:
        if scope == "vault":
            staged_name = playground.copy_in(src).get("name")
            staged = playground.resolve(staged_name)
            r = model3d.convert(staged, target)
            return (f"SUCCESS: copied {src.name} to the Playground as {staged.name}, then "
                    f"converted that working copy to {r['name']}. The converted file now exists "
                    f"in the Playground and is the file to inspect or modify next. The vault source "
                    f"was not modified. Do not report this as complete until the requested output exists.")
        r = model3d.convert(src, target)
        return (f"SUCCESS: converted {src.name} to {r['name']} in the Playground. "
                f"The output now exists there for further inspection/modification. The source was not modified.")
    except Exception as e:
        return (f"CONVERSION FAILED: {src.name} -> {target}. Nothing was changed in the vault. "
                f"The working copy remains in the Playground if one was created. "
                f"Reason: {str(e)[:240]}")

def _save_playground(args):
    """Save a finished Playground result into the AI-owned Vault box."""
    return _save_playground_to_ai(args)




def _save_playground_to_ai(args):
    import playground, vault
    try:
        name = str(args.get("name", "")).strip()
        as_name = str(args.get("as_name", "")).strip()
        if not name:
            return "Refused: no Playground filename."
        src = playground.resolve(name)
        if not src:
            return f"There is no {name!r} in the Playground."
        r = vault.ai_save(src, as_name or src.name)
        return (f"SAVED TO AI VAULT: {r['name']}. "
                "The original user Vault sources were not modified. "
                "This is now a shared, user-visible AI-owned Vault artifact.")
    except Exception as e:
        return f"Could not save to AI Vault: {str(e)[:260]}"


def _delete_ai_vault(args):
    import vault
    try:
        name = str(args.get("name", "")).strip()
        if not name:
            return "Refused: no AI Vault filename."
        r = vault.ai_delete(name)
        return f"DELETED FROM AI VAULT: {r['deleted']}. User-owned Vault files were untouched."
    except Exception as e:
        return f"Could not delete AI Vault file: {str(e)[:260]}"


# ═══════════════════════════════════════════════════════════════════════════
#  GENERATION
#
#  These three used to begin and end with "no supported local image generator
#  is currently reachable", because every one of them required ComfyUI or
#  Automatic1111 to be installed and already running. On a machine with
#  neither - which is every fresh install - three headline capabilities were
#  three ways of saying no.
#
#  They go through forge.py now, which ships with the application: pinned
#  binaries, pinned weights, run as a subprocess, one at a time, with Nova
#  stopped for the duration. ComfyUI and A1111 remain as OPTIONAL upgrades
#  and are tried first when a user has them, because someone who has set one
#  up has better models in it than the starter set here.
# ═══════════════════════════════════════════════════════════════════════════

# Sidecars describe a file; they are never the file. A model reading a
# folder listing sees "X.generation.json" and reasonably infers "X.png" -
# and if it hands over the .json instead, that must resolve to the picture
# rather than fail.
_SIDECAR_TAILS = (".generation.json", ".source.json", ".preview.png")

# What can actually be fed to a generator.
_USABLE_IN = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif",
              ".stl", ".obj", ".glb", ".gltf", ".ply", ".3mf"}


def _vault_find(name: str):
    """
    A file anywhere in the Vault, by name.

    vault.resolve() takes a vault-RELATIVE path, so "Cosmic_Forge_Base.png"
    only ever matched a file sitting at the vault root. Everything the user
    keeps goes to vault/Made/, so the one lookup that mattered was the one
    that could not succeed - and the failure read as "there is no such
    file" when there plainly was.
    """
    from pathlib import Path as _P
    import vault
    p = vault.resolve(name)
    if p is not None and _P(p).is_file():
        return _P(p)
    try:
        vault.ensure()
        low = name.lower()
        best = None
        for f in vault.VAULT.rglob("*"):
            if f.is_file() and f.name.lower() == low:
                # Prefer Made/, where generated work is kept.
                if "made" in {q.name.lower() for q in f.parents}:
                    return f
                best = best or f
        return best
    except Exception:
        return None


def _resolve_input(name: str, scope: str):
    """
    A file named by the model, ready to use. ONE NAMESPACE, not two.

        "What if we only divide the difference by files able to be edited by
         the model ... marked only by naming the file instead of leaving the
         playground and the vault in different spaces?"

    Because the split was never about safety - it was about where things
    sit, which is a fact about the disk and not about permission. An entire
    release went on failures of the form "not found in the Playground
    workspace" about files that existed, while the user said so.

    `scope` is accepted and ignored. It only ever gave the model a way to
    guess wrong, and guessing wrong returned an error instead of the file.
    files.bring() finds it wherever it is; if it belongs to the user it is
    COPIED into the workspace and the copy is handed back, so the original
    is never touched and what she works on is always hers.
    """
    from pathlib import Path as _P
    import files
    name = str(name or "").strip()
    if not name:
        return None

    path, note = files.bring(name)
    if path is not None and _P(path).is_file():
        if note:
            core.log_line("tools", note)
        return _P(path)

    # Genuinely absent. Say what IS there, marked, because a bare "not
    # found" against a listing full of .json sidecars is how the same wrong
    # filename got tried three times in a row.
    rows = []
    try:
        rows = [r for r in files.listing(40) if not r["is_note"]]
    except Exception:
        pass
    msg = f"there is no file called {name!r} anywhere you can reach."
    if rows:
        mine = [r["name"] for r in rows if r["can_edit"]][:10]
        theirs = [r["name"] for r in rows if not r["can_edit"]][:10]
        if mine:
            msg += "\nYours, editable: " + ", ".join(mine)
        if theirs:
            msg += ("\nThe user's, view only (naming one copies it into "
                    "your workspace automatically): " + ", ".join(theirs))
        msg += ("\nA .generation.json or .source.json is a NOTE ABOUT a "
                "file, never the file itself.")
    else:
        msg += (" There are no images or meshes anywhere yet - generate one "
                "first, then use its name.")
    raise FileNotFoundError(msg)


def _attach(path, kind: str) -> None:
    """Put a generated file in front of Nova on the next turn."""
    try:
        import policy
        from pathlib import Path as _P
        p = _P(path)
        if p.is_file():
            policy.GATE.attachments.append(
                {"path": str(p), "kind": kind, "name": p.name,
                 "source": "generated"})
    except Exception as e:
        core.log_line("generation", f"attachment failed: {e}")


def _preview_3d(path):
    """Render six views of a generated mesh so Nova can look at what it made."""
    try:
        import model3d
        return model3d.preview_for(path)
    except Exception as e:
        core.log_line("generation", f"3D preview failed: {e}")
        return None


# ═══════════════════════════════════════════════════════════════════════════
#  A NAMED THING GETS LOOKED UP. THIS IS A RAIL, NOT A REQUEST.
#
#  fetch_reference_image was built, registered, gated, advertised, and
#  described in the character sheet - and then this happened anyway:
#
#      "Can you search for and create an image of Goku in ultra instinct and
#       a separate image of terrible tornado?"
#
#  She called web_search. She read the results. Then she called
#  generate_image twice from the prompt words and produced a WEATHER
#  TORNADO, because Terrible Tornado is an S-Class hero and the model has
#  never seen her. The search returned sentences; sentences were never the
#  missing thing.
#
#  This project has been here before, in the same shape. The spec route was
#  described as wrong for characters, in the prompt, in capitals, and the
#  model passed a spec for Goku anyway and got a block with holes. The fix
#  then was meshgen.spec_suits(): stop advising, and put in a rail.
#
#  So: a prompt that names something specific, with no reference supplied,
#  fetches one first - inside the same Session, so nothing extra is stopped
#  or restarted. It is skipped when the user gave their own input_image,
#  when web search is switched off, or when the caller passes
#  reference=false, and a failed lookup is a NOTE and never an error: a
#  drawn-from-memory picture beats no picture.
# ═══════════════════════════════════════════════════════════════════════════

# A prompt has to be about something in particular before a lookup is worth
# a network round trip. "a red barn at sunset" names nothing; "Garo from One
# Punch Man" does.
def _wants_a_reference(prompt: str) -> str:
    """The named subject worth looking up, or "" if there is none."""
    try:
        import focus
    except Exception:
        return ""
    names = focus.named_subjects(prompt or "")
    # Multi-word names first - "terrible tornado" is a better search than
    # "tornado", and it is the difference between a hero and the weather.
    phrases = sorted((n for n in names if " " in n), key=len, reverse=True)
    best = phrases[0] if phrases else ""
    if not best:
        singles = [n for n in names if len(n) > 3]
        best = max(singles, key=len) if singles else ""
    return best


def _reference_for(prompt: str, cfg) -> tuple:
    """(path, note). Never raises - a lookup that fails costs a note."""
    if not (cfg or {}).get("tools", {}).get("web_search"):
        return None, ""
    # ONCE A PAGE HAS BEEN READ THIS TURN, NO MORE GOES OUT.
    #
    # The gate no longer refuses this tool outright when the turn is
    # tainted - refusing a tool whose product is a local file was blocking
    # ordinary work for a threat that did not apply to it. The protection
    # moves here instead, where it costs nothing: the picture is made
    # without a lookup, and the model is told why rather than left to guess
    # from a worse result.
    #
    # This is the same shape as the spec route. Drop the part that cannot
    # safely run; do not refuse the thing the user asked for.
    try:
        import policy
        if policy.GATE.state().get("tainted"):
            return None, ("did not look up a reference: a web page has "
                          "already been read this turn, and nothing derived "
                          "from it is sent back out. Drawn from the prompt "
                          "alone, so a named subject may not look like the "
                          "real thing")
    except Exception:
        pass
    subject = _wants_a_reference(prompt)
    if not subject:
        return None, ""
    try:
        out = _fetch_reference_image({"query": subject}, cfg)
    except Exception as e:
        return None, f"could not look up {subject!r} ({str(e)[:80]})"
    m = re.search(r"REFERENCE IMAGE FETCHED: Playground/(\S.*?) - ", out or "")
    if not m:
        return None, (f"looked for a picture of {subject!r} and found none, "
                      f"so this was drawn from the name alone and may not "
                      f"look like the real thing")
    path = playground.resolve(m.group(1).strip())
    if path is None:
        return None, f"the reference for {subject!r} could not be reopened"
    src = re.search(r"SOURCE \(untrusted, from the web\): (\S+)", out or "")
    return path, (f"used a real picture of {subject!r} as the reference"
                  + (f", from {src.group(1)[:120]}" if src else ""))


def _failed(what: str, err) -> str:
    """
    One failure, said once, with nothing else attached.

    Anything put beside an error competes with it. The generation report
    was appended here for context and became the answer instead - numbers
    about the backend's history read back to the user as the result of the
    run that had just failed.
    """
    reason = " ".join(str(err).split())[:400]
    return (f"{what} GENERATION FAILED. Nothing was made.\n"
            f"THE REASON, and it is the only thing here that describes this "
            f"run: {reason}\n"
            f"Tell the user this reason in your own words. Do not quote "
            f"success rates, attempt counts or percentages - none of those "
            f"are about what just happened, and there is no partial result "
            f"to report.")


def _generate_image(args, cfg=None):
    import forge
    prompt = str(args.get("prompt", "")).strip()
    if not prompt:
        return "IMAGE GENERATION NOT STARTED: a prompt is required."
    notes = []

    # An external generator the user has running is preferred: they chose its
    # models deliberately, and it is already warm.
    try:
        import imagegen
        if imagegen.discover():
            import forge as _fg
            r = imagegen.generate(
                prompt=prompt,
                # The external ComfyUI/A1111 path gets the same descriptive
                # naming as the built-in one; a file called generated.png is
                # no easier to find because a different program made it.
                filename=str(args.get("filename")
                             or _fg._describe(prompt, ".png")),
                provider=str(args.get("provider", "auto")),
                negative_prompt=str(args.get("negative_prompt", "")),
                width=int(args.get("width", 768)),
                height=int(args.get("height", 768)),
                steps=int(args.get("steps", 20)),
                seed=int(args.get("seed", -1)),
                workflow_json=args.get("workflow_json"))
            path = playground.resolve(r["name"])
            _attach(path, "image-generation")
            return (f"IMAGE GENERATION SUCCESS: created Playground/{r['name']} "
                    f"using {r.get('provider')}. It is attached to this turn.")
    except Exception as e:
        core.log_line("generation", f"external image generator failed: {e}")

    try:
        init = None
        if args.get("input_image"):
            init = _resolve_input(args.get("input_image"),
                                  args.get("input_scope", "playground"))
        elif args.get("reference", True):
            init, why = _reference_for(prompt, cfg)
            if why:
                notes.append(why)
        with forge.Session(f"image: {prompt[:60]}") as s:
            if not s.ok:
                return ("IMAGE GENERATION NOT STARTED: another generator is "
                        f"already running ({forge.busy().get('what')}). "
                        "One runs at a time; try again when it finishes.")
            out = s.image(
                prompt=prompt,
                negative=str(args.get("negative_prompt", "")),
                width=int(args.get("width", 512)),
                height=int(args.get("height", 512)),
                steps=int(args.get("steps", 20)),
                seed=int(args.get("seed", -1)),
                init_image=init,
                strength=float(args.get("strength", 0.6)),
                model=args.get("model"),
                filename=str(args.get("filename", "")))
        _attach(out, "image-generation")
        return (f"IMAGE GENERATION SUCCESS: created Playground/{out.name}"
                + (f" ({'; '.join(notes)})" if notes else "") + ".\n"
                "The image itself is attached to this turn - look at it and "
                "say what it actually shows before saving or changing it."
                + ("\nSay where the reference came from; it was fetched, "
                   "not invented." if init is not None and
                   not args.get("input_image") else ""))
    except Exception as e:
        return _failed("IMAGE", e)


def _generate_video(args):
    import forge
    prompt = str(args.get("prompt", "")).strip()
    if not prompt:
        return "VIDEO GENERATION NOT STARTED: a prompt is required."
    try:
        init = None
        if args.get("input_image"):
            init = _resolve_input(args.get("input_image"),
                                  args.get("input_scope", "playground"))
        with forge.Session(f"video: {prompt[:60]}") as s:
            if not s.ok:
                return ("VIDEO GENERATION NOT STARTED: another generator is "
                        f"already running ({forge.busy().get('what')}).")
            out = s.video(
                prompt=prompt,
                negative=str(args.get("negative_prompt", "")),
                width=int(args.get("width", 480)),
                height=int(args.get("height", 320)),
                frames=int(args.get("frames", 33)),
                steps=int(args.get("steps", 20)),
                seed=int(args.get("seed", -1)),
                init_image=init,
                filename=str(args.get("filename", "")))
        poster = None
        try:
            import vision
            poster = vision.grab_frame(out)
        except Exception:
            pass
        if poster is not None:
            _attach(poster, "video-poster")
        return (f"VIDEO GENERATION SUCCESS: created Playground/{out.name}"
                + (f", poster frame attached to this turn." if poster
                   else ". No poster frame could be extracted (ffmpeg is not "
                        "installed), so describe it from the request rather "
                        "than claiming to have watched it."))
    except Exception as e:
        # NO STATISTICS REPORT ON A FAILURE.
        #
        # This appended forge.report() - a page of reliability figures - and
        # a 4B model read the figures as the RESULT:
        #
        #   "The generation failed ... the result is only 1 out of 7 views
        #    worked, which is roughly 22%. This is a leaning, not a
        #    conclusion."
        #
        # There were no views. "1 of 7" is how often the VIDEO BACKEND has
        # ever worked, and "a leaning, not a conclusion" is the ledger's
        # own wording about sample size. Every number in that sentence is
        # real and none of it is about the run that just failed. Handing a
        # small model a wall of adjacent statistics next to an error is
        # asking it to narrate them as the outcome.
        #
        # What a failure needs is the failure.
        return _failed("VIDEO", e)


def _spec_summary(spec) -> str:
    """A couple of words describing a shape spec, for the filename."""
    try:
        if isinstance(spec, str):
            import json as _j
            spec = _j.loads(spec)
        parts = (spec or {}).get("parts") or []
        shapes = []
        for pt in parts[:3]:
            sh = str((pt or {}).get("shape", "")).strip()
            if sh and sh not in shapes:
                shapes.append(sh)
        holes = sum(len((pt or {}).get("holes") or []) for pt in parts)
        bits = shapes or ["part"]
        if holes:
            bits.append(f"{holes} hole" + ("s" if holes != 1 else ""))
        return " ".join(bits)
    except Exception:
        return "part"


def _generate_3d(args, cfg=None):
    """
    Three routes to a mesh, tried in the order that makes sense.

      1. an image was given          -> TRELLIS on that image
      2. a shape spec was given      -> built exactly, no model involved
      3. a prompt only               -> TRELLIS on a freshly generated image,
                                        and if that cannot run here, a
                                        built-in mesh instead

    Route 3 is one Session, so Nova is stopped once for image-then-mesh
    rather than twice.
    """
    import forge, meshgen
    prompt = str(args.get("prompt", "")).strip()
    spec = args.get("spec")
    filename = str(args.get("filename", ""))
    notes = []

    # --- IS A SPEC EVEN THE RIGHT TOOL? --------------------------------
    #
    # THE BLOCK WITH TWO HOLES IN IT.
    #
    # Asked for "a statue of Goku and Frieza fighting", the model passed a
    # spec. meshgen did exactly what it was told - built a rectangular prism
    # with two cylindrical holes, measured it, called it watertight, reported
    # SUCCESS - and the user got a block. Nothing errored. Every check
    # passed. The picture-then-mesh route, which is the one that can produce
    # a character, was never reached, because a spec was present and a spec
    # short-circuits everything.
    #
    # The model is not stupid for doing this. The prompt tells it a spec is
    # instant and needs no model, and that is a very attractive sentence.
    # Instructions are advisory; this is a rail.
    #
    # The spec is DROPPED, not refused, and the request carries on down the
    # route that can actually do it. Refusing would hand back an error for
    # something the machine can do; carrying on gets the user a statue.
    if spec:
        why = meshgen.spec_suits(prompt or _spec_summary(spec))
        if why:
            notes.append(
                f"ignored the shape spec and used the picture-then-mesh "
                f"route instead: {why}")
            core.log_line("tools",
                          f"generate_3d: dropped a spec for an organic "
                          f"subject - {(prompt or '')[:80]}")
            spec = None

    # --- route 2: an exact spec. No generator, no waiting, no Session. -----
    if spec:
        try:
            import forge as _fg
            tris = meshgen.build(spec)
            playground.ensure()
            base = filename or _fg._describe(
                prompt or _spec_summary(spec), ".stl")
            if not base.lower().endswith(".stl"):
                base = base.rsplit(".", 1)[0] + ".stl"
            dest = _fg._unique(base)
            meshgen.save(tris, dest)
            m = meshgen.measure(tris)
            preview = _preview_3d(dest)
            if preview:
                _attach(preview, "3d-preview")
            # THE MESH SAYS WHAT IT ACTUALLY IS.
            #
            # Six views of the block were attached and the model described
            # them as "golden hair, glowing aura, purple dragon eyes". A
            # picture is an interpretation and a small model interprets it
            # toward the words it was given. A triangle count is not an
            # interpretation, so the geometry now speaks for itself in the
            # same breath as the render.
            return (f"3D BUILD SUCCESS: created Playground/{dest.name} from "
                    f"the spec - {m['triangles']} triangles, "
                    f"{m['size'][0]} x {m['size'][1]} x {m['size'][2]} mm, "
                    f"watertight.\nWHAT THIS MESH ACTUALLY IS, measured: "
                    f"{meshgen.shape_note(tris)}\nSix rendered views are "
                    f"attached. Look at them, and say what is really there - "
                    f"if the measurement above disagrees with the request, "
                    f"the measurement is right. Never describe the prompt "
                    f"back as though it were the result.")
        except Exception as e:
            return (f"3D BUILD FAILED: {str(e)[:400]}\n\n"
                    f"The spec format is:\n{meshgen.SPEC_HELP}")

    if not prompt and not args.get("input_image"):
        return ("3D GENERATION NOT STARTED: give either a prompt, a source "
                "image, or a spec.\n\n" + meshgen.SPEC_HELP)

    try:
        with forge.Session(f"3D: {(prompt or 'from image')[:60]}") as s:
            if not s.ok:
                return ("3D GENERATION NOT STARTED: another generator is "
                        f"already running ({forge.busy().get('what')}).")
            a = forge.available()

            # --- the source picture -------------------------------------
            if args.get("input_image"):
                src = _resolve_input(args.get("input_image"),
                                     args.get("input_scope", "playground"))
            elif a["image"]["ready"]:
                # The same rail as generate_image. A mesh built from a
                # picture is only ever as good as the picture, so the source
                # image gets the reference too - otherwise the 3D route
                # inherits exactly the likeness problem the rail exists for.
                ref, why = _reference_for(prompt, cfg)
                if why:
                    notes.append(why)
                notes.append("generated a source image first")
                src = s.image(prompt=prompt, init_image=ref, filename="")
            else:
                src = None

            # --- route 1: the neural path -------------------------------
            if src is not None and a["model3d"]["ready"]:
                try:
                    out = s.mesh_from_image(
                        src, resolution=int(args.get("resolution", 512)),
                        seed=int(args.get("seed", -1)), filename=filename)
                    preview = _preview_3d(out)
                    if preview:
                        _attach(preview, "3d-preview")
                    return (f"3D GENERATION SUCCESS: created "
                            f"Playground/{out.name} from {src.name} with "
                            f"TRELLIS"
                            + (f" ({'; '.join(notes)})" if notes else "")
                            + ". Six rendered views are attached - look at "
                              "them and say what the object actually is.")
                except Exception as e:
                    notes.append(f"TRELLIS could not run here ({str(e)[:120]})")

            # --- NO FALLBACK. ------------------------------------------
            #
            # THE RELIEF IS GONE, ON INSTRUCTION AND ON THE EVIDENCE.
            #
            # For weeks, when the neural path could not run, this quietly
            # embossed the picture onto a plate and handed it over. Three
            # separate builds of it reached the user:
            #
            #     100 x 80 x 30 mm   a slab with three holes
            #      80 x 80 x  8 mm   a 160x160 heightmap
            #      80 x 80 x 21 mm   a 200x200 heightmap
            #
            # Each time it was labelled more honestly than the last, and each
            # time it was still not a model. "I can do that at home with a
            # bar of soap." A substitute nobody wants, produced automatically,
            # is not a kindness - it is a way of never finding out why the
            # real path is not running, because the failure always arrives
            # wrapped in a file.
            #
            # So this raises now, with whatever the real route actually said.
            # An error you can read beats an object you cannot use.
            raise RuntimeError(
                "the neural image-to-3D step did not run, and there is no "
                "substitute for it: "
                + ("; ".join(notes) if notes else "no reason was recorded")
                + ". A relief plaque used to be built here instead and it was "
                  "never what anyone asked for, so it has been removed. Tell "
                  "the user plainly that 3D from a picture is not working "
                  "right now and what the error above says. `spec` still "
                  "builds exact shapes from dimensions and is unaffected.")

    except Exception as e:
        return _failed("3D", e)


def _attach_generation_assets(result: dict, kind: str) -> None:
    """Queue generated visual artifacts so the next Nova turn sees the actual result."""
    try:
        import policy
        for key, asset_kind in (("name", kind), ("preview", f"{kind}-preview"), ("poster", f"{kind}-poster")):
            rel = result.get(key)
            if not rel:
                continue
            path = playground.resolve(str(rel))
            if path and path.is_file():
                policy.GATE.attachments.append({"path": str(path), "kind": asset_kind,
                                                 "name": path.name,
                                                 "source": result.get("source", "generated")})
    except Exception as e:
        core.log_line("generation", f"attachment failed: {e}")


def _offer_file(args, cfg):
    """
    Ask the user whether to keep a file, and keep it if they say yes.

    CONFIRM tier, so calling this does not move anything: it stages the move
    and puts a question on screen. The user answers. Only Yes runs this
    function's real work, through the same path that already handles staged
    memory writes.

    This exists because Nova could make things and had no way to hand them
    over. Everything she generated stayed in the Playground - a working
    folder the user had to go and find, in another tab, that also happened to
    be filling the disk. She could not offer, so she did not, and the user's
    files piled up somewhere they were not looking.

    Asking is the point. It is their machine and their disk; a file arriving
    in their vault because a model decided to put it there is not a gift, it
    is clutter with no undo. So: she asks, they choose, and what they choose
    to keep is MOVED out of the scratch space and into a folder that is
    theirs.
    """
    name = str(args.get("name", "")).strip()
    if not name:
        return "Refused: name the file you want to offer."
    try:
        res = playground.keep(name)
    except FileNotFoundError:
        return (f"There is no '{name}' in the Playground. Use "
                f"list_playground to see what is actually there.")
    except Exception as e:
        return f"Could not keep that file: {type(e).__name__}: {e}"
    where = "the Vault, under Made"
    extra = ("" if len(res["moved"]) < 2
             else " Its rendered preview went with it.")
    return (f"Kept. '{res['name']}' has been moved out of the Playground into "
            f"{where}, where the user can open, move or delete it.{extra}")


def _look_at_system(args, cfg):
    """
    Nova, looking at the machine she is on.

    The point of this is not the information. It is that there IS a way to
    check. Without one, the only evidence about the present is a memory of
    the past, and a memory of a failure then becomes a permanent fact - which
    is exactly how "I do not have the resources for that" survived three
    fixes and a reinstall. A capability question is now answerable by looking
    rather than by remembering.
    """
    import lens
    return lens.look(str(args.get("area", "everything")), cfg)


def _list_local_generators(args=None):
    """
    What can actually generate something here, and what cannot, and why.

    This used to list only ComfyUI and Automatic1111 if they happened to be
    running, so on a normal machine it said "None detected." and that was
    the whole answer - no mention of the generators that ship WITH the
    application. forge.report() leads now, because it knows what is
    installed, what has run successfully on this machine before, and what
    failed and for what reason.
    """
    import forge
    lines = [forge.report()]

    external = []
    try:
        import imagegen
        for item in imagegen.discover():
            external.append(f"  {item.get('provider')} on "
                            f"{item.get('host')}:{item.get('port')}")
    except Exception:
        pass
    try:
        import generators
        pv = generators.comfy_available()
        if pv and not any("comfyui" in x for x in external):
            external.append(f"  ComfyUI on {pv.get('host')}:{pv.get('port')}")
    except Exception:
        pass

    lines.append("")
    if external:
        lines.append("Also reachable (used in preference to the built-in "
                     "image generator, because the user set them up "
                     "deliberately):")
        lines.extend(external)
    else:
        lines.append("No external generator (ComfyUI / Automatic1111) is "
                     "running. Not needed - the built-in ones above do not "
                     "depend on either.")
    return "\n".join(lines)


def _list_local_tools(args=None):
    import shutil
    names = ["python", "python3", "py", "ffmpeg", "ffprobe", "blender", "openscad",
             "freecad", "FreeCADCmd", "magick", "convert", "inkscape", "meshlabserver",
             "assimp", "7z", "git"]
    found = []
    for n in names:
        q = shutil.which(n)
        if q and q not in found:
            found.append(q)
    return "Available local programs The Hub can invoke from the Playground:\n" + ("\n".join(found) if found else "None detected on PATH.")

def _inspect_3d(args):
    import model3d, vault, playground, policy
    name = str(args.get("name", "")).strip()
    scope = str(args.get("scope", "playground")).strip().lower() or "playground"
    src = playground.resolve(name) if scope == "playground" else vault.resolve(name)
    if src is None:
        return f"3D file not found in {scope}: {name}"
    try:
        size = max(256, min(int(args.get("size", 512)), 1024))
        has_custom = any(k in args for k in ("yaw", "pitch", "distance"))
        path = model3d.render_views(src, size=size,
                                    yaw=float(args.get("yaw", 0.0)) if has_custom else None,
                                    pitch=float(args.get("pitch", 0.0)) if has_custom else None,
                                    distance=max(0.1, float(args.get("distance", 1.0))))
        if not path or not Path(path).is_file():
            return "Could not render a visual view of that 3D file."
        policy.GATE.attachments.append({"path": str(path), "kind": "3d", "name": src.name})
        # THE MEASUREMENT TRAVELS WITH THE PICTURE.
        #
        # Looking is what this tool is for, and looking is exactly what
        # failed: six views of a rectangular slab came back described as
        # "golden hair, glowing aura, purple dragon eyes". So the render is
        # handed over WITH what the geometry measurably is, which no amount
        # of wanting can reinterpret.
        note = ""
        try:
            import meshgen
            note = "\n" + meshgen.shape_note(model3d.triangles(src))
        except Exception:
            pass
        return (f"Rendered {src.name} for visual inspection.{note}\n"
                f"Describe what is actually in the views. Where they and the "
                f"measurement disagree with what was asked for, say so "
                f"plainly - that is the useful answer.")
    except Exception as e:
        return f"3D view failed without changing the file: {str(e)[:240]}"



KEY_FILE = core.ROOT / "KEY_LEGEND.md"


def _key_sections() -> dict:
    try:
        text = KEY_FILE.read_text(encoding="utf-8")
    except Exception:
        return {}
    import re as _re
    sections = {}
    current = None
    buf = []
    for line in text.splitlines():
        m = _re.match(r"^##\s+(.+?)\s*$", line)
        if m:
            if current:
                sections[current.lower()] = "\n".join(buf).strip()
            current = m.group(1).strip()
            buf = []
        elif current:
            buf.append(line)
    if current:
        sections[current.lower()] = "\n".join(buf).strip()
    return sections


def _read_key(args):
    q = str((args or {}).get("query", "")).strip().lower()
    sections = _key_sections()
    if not sections:
        return "KEY/LEGEND unavailable: KEY_LEGEND.md is missing. Use list_local_tools or web_search to determine what is needed."
    if not q:
        return "KEY/LEGEND TABLE OF CONTENTS:\n" + "\n".join(f"- {k}" for k in sections)
    hits = [(k, v) for k, v in sections.items() if q in k or q in v.lower()]
    if not hits:
        return f"KEY/LEGEND has no entry matching {q!r}. This capability is not documented locally. Check list_local_tools; if it is an external/local software capability and current information is needed, use web_search. Do not invent the tool."
    return "\n\n".join(f"## {k}\n{v}" for k, v in hits[:3])


def _pass_off(args):
    a = args or {}
    reason = str(a.get("reason", "")).strip()[:500]
    focus = str(a.get("focus", "")).strip()[:300]
    return ("SELF PASS-OFF: begin another Nova decision round. Review the current task, the latest tool results, "
            "and any attached visual assets before taking the next action. Correct errors or fill missing information "
            "if needed. Do not repeat completed actions. "
            + (f"Focus: {focus}. " if focus else "")
            + (f"Reason: {reason}" if reason else "Continue from the current state."))


def _set_theme(args, cfg):
    appearance = cfg.get("appearance", {}) if isinstance(cfg, dict) else {}
    if not appearance.get("ai_control", False):
        return "THEME CHANGE REFUSED: Nova theme control is disabled by the user in Settings."
    a = args or {}
    allowed_patterns = {"static", "spectrum", "breathe", "beat", "cycle"}
    allowed_scopes = {"strip", "chrome", "all"}
    out = {}
    for k in ("idle", "think", "tool", "speak", "error"):
        v = str(a.get(k, "")).strip()
        if re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            out[k] = v
    if str(a.get("pattern", "")) in allowed_patterns:
        out["pattern"] = str(a["pattern"])
    if str(a.get("scope", "")) in allowed_scopes:
        out["scope"] = str(a["scope"])
    if "brightness" in a:
        try: out["brightness"] = max(0.25, min(float(a["brightness"]), 1.0))
        except Exception: pass
    if "speed" in a:
        try: out["speed"] = max(0.25, min(float(a["speed"]), 3.0))
        except Exception: pass
    if not out:
        return "THEME CHANGE REFUSED: no valid theme changes were supplied."
    return "THEME_APPLY " + json.dumps(out, separators=(",", ":"))

REGISTRY = {
    "list_playground": {"fn": lambda a,c: _list_playground(a), "network": False, "schema": {"type":"function","function":{"name":"list_playground","description":"List every file you can reach, in one list. Each one says whether it is YOURS (you can change or delete it) or THE USER'S (read it freely, never change it). There is one namespace: naming a file is enough, you never have to know which space it is in, and naming one of the user's files copies it into your workspace automatically so you can work from it without touching theirs.","parameters":{"type":"object","properties":{}}}}},
    "read_key": {"fn": lambda a,c: _read_key(a), "network": False, "schema": {"type":"function","function":{"name":"read_key","description":"Read The Hub's local KEY/LEGEND by keyword or description. Use this for nonstandard or newly added tools instead of putting their full instructions in the system prompt.","parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":[]}}}},
    "pass_off": {"fn": lambda a,c: _pass_off(a), "network": False, "schema": {"type":"function","function":{"name":"pass_off","description":"Pass the current task to Nova's next decision round so Nova can review tool results, correct mistakes, fill missing information, or continue an unfinished task. Use when another reasoning/action pass is useful; do not use repeatedly without purpose.","parameters":{"type":"object","properties":{"reason":{"type":"string"},"focus":{"type":"string"}},"required":[]}}}},
    "set_theme": {"fn": lambda a,c: _set_theme(a,c), "network": False, "schema": {"type":"function","function":{"name":"set_theme","description":"Change The Hub's colors/animation only when the user has enabled Nova theme control in Settings. Use hex colors and optional pattern/scope/brightness/speed. Do not change theme when permission is disabled.","parameters":{"type":"object","properties":{"idle":{"type":"string"},"think":{"type":"string"},"tool":{"type":"string"},"speak":{"type":"string"},"error":{"type":"string"},"pattern":{"type":"string","enum":["static","spectrum","breathe","beat","cycle"]},"scope":{"type":"string","enum":["strip","chrome","all"]},"brightness":{"type":"number"},"speed":{"type":"number"}},"required":[]}}}},
    "offer_file": {"fn": _offer_file, "network": False, "schema": {"type":"function","function":{"name":"offer_file","description":"Offer the user a file you made, and keep it for them if they say yes. Anything you generate lands in the Playground, which is working space that gets cleared - so when you have made something the user actually wants, OFFER IT. This puts a question on their screen with the file's name; if they accept, the file is moved into their Vault under Made, where it is theirs to use or delete. Calling this moves nothing on its own and needs no permission to call: it asks. Offer once per file, say in your reply that you have asked, and carry on - do not wait for the answer and do not call it again for the same file.","parameters":{"type":"object","properties":{"name":{"type":"string","description":"The Playground file to offer, exactly as list_playground names it."},"note":{"type":"string","description":"One short line for the user about what it is."}},"required":["name"]}}}},
    "look_at_system": {"fn": _look_at_system, "network": False, "schema": {"type":"function","function":{"name":"look_at_system","description":"Look at the machine and the application you are running inside, as they are RIGHT NOW. Use this before saying you cannot do something, before repeating anything you remember about how this system behaves, and whenever the user tells you something has been fixed, installed, changed or freed up - what comes back is read fresh and overrides your memory of it. Areas: 'self' (your model, measured speed, context window, whether you can see), 'machine' (OS, processor, free memory, free video memory, disk), 'runtime' (how you are served, the settings asked for, what models are installed), 'generation' (what can make images, video and meshes, and what happened last time each ran), 'attempts' (HOW MANY TIMES each thing has actually been tried and what that is worth as evidence - read this before ever saying something does not work), 'memory' (how much is remembered and how firmly), 'settings' (what the user has configured), 'hub' (the application around you), or 'everything'. Reads only - it changes nothing and runs nothing.","parameters":{"type":"object","properties":{"area":{"type":"string","enum":["self","machine","runtime","generation","attempts","memory","settings","hub","everything"]}},"required":[]}}}},
    "list_local_generators": {"fn": lambda a,c: _list_local_generators(a), "network": False, "schema": {"type":"function","function":{"name":"list_local_generators","description":"List local offline generative AI backends currently reachable on loopback (image/ComfyUI). Does not contact the internet.","parameters":{"type":"object","properties":{}}}}},
    "list_local_tools": {"fn": lambda a,c: _list_local_tools(a), "network": False, "schema": {"type":"function","function":{"name":"list_local_tools","description":"List common local programs installed and callable from the Playground.","parameters":{"type":"object","properties":{}}}}},
    "inspect_3d": {"fn": lambda a,c: _inspect_3d(a), "network": False, "schema": {"type":"function","function":{"name":"inspect_3d","description":"Render a 3D file into six canonical views for the VLM, or a custom camera view when yaw/pitch/distance are provided. Use this AFTER copy/convert/edit operations when you need to inspect the current Playground result. Does not modify the source.","parameters":{"type":"object","properties":{"name":{"type":"string"},"scope":{"type":"string","enum":["vault","playground"]},"yaw":{"type":"number"},"pitch":{"type":"number"},"distance":{"type":"number"},"size":{"type":"integer"}},"required":["name"]}}}},
    "clock": {"fn": clock, "network": False, "schema": {"type":"function","function":{"name":"clock","description":"Current local date and time.","parameters":{"type":"object","properties":{}}}}},
    "calculator": {"fn": calculator, "network": False, "schema": {"type":"function","function":{"name":"calculator","description":"Evaluate an arithmetic expression exactly.","parameters":{"type":"object","properties":{"expression":{"type":"string"}},"required":["expression"]}}}},
    "search_memory": {"fn": search_memory, "network": False, "schema": {"type":"function","function":{"name":"search_memory","description":"Search recorded conversations, memories, and files.","parameters":{"type":"object","properties":{"query":{"type":"string"},"scope":{"type":"string","enum":["everything","memories","conversations","files"]}},"required":["query"]}}}},
    "open_file": {"fn": open_file, "network": False, "schema": {"type":"function","function":{"name":"open_file","description":"Inspect one file in the vault or Playground. Vault files are read-only; Playground files are the model's writable working copies. For images and supported 3D files, a vision-capable selected model receives the actual visual material.","parameters":{"type":"object","properties":{"name":{"type":"string"},"about":{"type":"string"},"scope":{"type":"string","enum":["vault","playground"]}},"required":["name"]}}}},
    "copy_to_playground": {"fn": lambda a,c: _copy_to_playground(a), "network": False, "schema": {"type":"function","function":{"name":"copy_to_playground","description":"Copy a vault file into the private Playground. The vault source is never modified.","parameters":{"type":"object","properties":{"name":{"type":"string"},"as_name":{"type":"string"}},"required":["name"]}}}},
    "write_playground": {"fn": lambda a,c: _write_playground(a), "network": False, "schema": {"type":"function","function":{"name":"write_playground","description":"Create or overwrite a text/code file in the Playground.","parameters":{"type":"object","properties":{"name":{"type":"string"},"content":{"type":"string"},"overwrite":{"type":"boolean"}},"required":["name","content"]}}}},
    "edit_playground": {"fn": lambda a,c: _edit_playground(a), "network": False, "schema": {"type":"function","function":{"name":"edit_playground","description":"Edit a text/code file in the Playground by replacement.","parameters":{"type":"object","properties":{"name":{"type":"string"},"find":{"type":"string"},"replace":{"type":"string"},"all_matches":{"type":"boolean"}},"required":["name","find","replace"]}}}},
    "rename_playground": {"fn": lambda a,c: _rename_playground(a), "network": False, "schema": {"type":"function","function":{"name":"rename_playground","description":"Rename a Playground file, including changing its extension when appropriate.","parameters":{"type":"object","properties":{"name":{"type":"string"},"new_name":{"type":"string"}},"required":["name","new_name"]}}}},
    "delete_playground": {"fn": lambda a,c: _delete_playground(a), "network": False, "schema": {"type":"function","function":{"name":"delete_playground","description":"Delete a working Playground file only. Never affects the vault.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}}},
    "run_playground": {"fn": lambda a,c: _run_playground(a), "network": False, "schema": {"type":"function","function":{"name":"run_playground","description":"Run an installed local program in the Playground without a shell. Use this for scripts and installed converters/editors.","parameters":{"type":"object","properties":{"program":{"type":"string"},"args":{"type":"array","items":{"type":"string"}},"timeout":{"type":"integer"}},"required":["program"]}}}},
    "convert_file": {"fn": lambda a,c: _convert_file(a), "network": False, "schema": {"type":"function","function":{"name":"convert_file","description":"Convert a vault or Playground file to another supported local format. Output goes to the Playground; source is never modified.","parameters":{"type":"object","properties":{"name":{"type":"string"},"to":{"type":"string"},"scope":{"type":"string","enum":["vault","playground"]}},"required":["name","to"]}}}},
    "save_to_ai_vault": {"fn": lambda a,c: _save_playground_to_ai(a), "network": False, "schema": {"type":"function","function":{"name":"save_to_ai_vault","description":"Save a completed Playground file into Vault/AI, the model-owned shared Vault box. Never overwrites an existing Vault file.","parameters":{"type":"object","properties":{"name":{"type":"string"},"as_name":{"type":"string"}},"required":["name"]}}}},
    "delete_ai_vault": {"fn": lambda a,c: _delete_ai_vault(a), "network": False, "schema": {"type":"function","function":{"name":"delete_ai_vault","description":"Delete a file only from Vault/AI, the model-owned shared box. Never delete user-owned Vault files.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}}},
    "save_playground": {"fn": lambda a,c: _save_playground(a), "network": False, "schema": {"type":"function","function":{"name":"save_playground","description":"Copy a Playground result into the vault as a new file. Never overwrite, modify, or delete existing vault files.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}}},
    "generate_3d": {"fn": lambda a,c: _generate_3d(a, c), "network": "maybe", "schema": {"type":"function","function":{"name":"generate_3d","description":"Produce a 3D model on this machine. THREE ROUTES, and choosing the right one matters more than anything else here. (1) spec - ONLY for shapes defined by dimensions: brackets, plates, spacers, boxes, tubes, stands, vases. It builds exact watertight geometry instantly. A spec can ONLY make boxes, plates, cylinders, tubes, cones, spheres, tori and revolves - it CANNOT make a person, a character, a creature or a pose, and it will not fail at one, it will return a block with holes in it and report success. Never send a spec for a character, a body, a creature, a statue of someone, or two figures interacting. (2) input_image - turns a picture into a mesh. (3) prompt alone - generates a picture first, then turns that into a mesh; THIS is the route for characters, creatures and anything organic. It takes minutes and it is the only one that can produce a figure. A spec looks like: {\"parts\":[{\"shape\":\"box\",\"size\":[60,40,4],\"holes\":[{\"at\":[10,10],\"d\":5}]}]}. Shapes: box/plate (size or outline, holes, radius), cylinder (d, h, hole_d), tube (d, wall, h), cone (d, d_top, h), sphere (d), torus (d, thickness), prism (sides, d, h), revolve (profile). Sizes are millimetres. Output always goes to the Playground, never the Vault. Six rendered views are attached to your next turn - look at them and confirm the shape before saving. Nova is stopped while any generator runs.","parameters":{"type":"object","properties":{"prompt":{"type":"string"},"spec":{"type":"object"},"input_image":{"type":"string"},"input_scope":{"type":"string","enum":["vault","playground"]},"resolution":{"type":"integer"},"seed":{"type":"integer"},"filename":{"type":"string"}},"required":[]}}}},
    "generate_video": {"fn": lambda a,c: _generate_video(a), "network": False, "schema": {"type":"function","function":{"name":"generate_video","description":"Generate a short video on this machine. Text to video, or image to video when input_image is given. Output goes to the Playground and a poster frame is attached to your next turn when one can be extracted. When the user asks for a video, CALL THIS - do not offer to, and do not ask whether they would like you to; they already said. Say you are starting and that it takes a while, then start. It is the slowest thing here, minutes at minimum, and Nova is stopped for all of it. Keep the size and frame count small unless the user asks otherwise.","parameters":{"type":"object","properties":{"prompt":{"type":"string"},"negative_prompt":{"type":"string"},"width":{"type":"integer"},"height":{"type":"integer"},"frames":{"type":"integer"},"steps":{"type":"integer"},"seed":{"type":"integer"},"input_image":{"type":"string"},"input_scope":{"type":"string","enum":["vault","playground"]},"filename":{"type":"string"}},"required":["prompt"]}}}},
    "generate_image": {"fn": lambda a,c: _generate_image(a, c), "network": True, "schema": {"type":"function","function":{"name":"generate_image","description":"Generate an image on this machine. Text to image, or image to image when input_image is given. Output goes to the Playground and the image itself is attached to your next turn - look at it and describe what it actually shows rather than restating the prompt. Nova is stopped while the image model runs and restarted afterwards, so this pauses the conversation for a while. 512x512 is the size the default checkpoint was trained at; larger costs time and often looks worse. If the prompt names a specific character, person, product, logo, place or creature, a real picture of it is fetched from the web first and used as the reference, so the result looks like the actual thing rather than what the name suggests - the reply says when this happened and where the picture came from, and you must pass that on. Set reference=false to draw from the prompt alone.","parameters":{"type":"object","properties":{"prompt":{"type":"string"},"negative_prompt":{"type":"string"},"width":{"type":"integer"},"height":{"type":"integer"},"steps":{"type":"integer"},"seed":{"type":"integer"},"model":{"type":"string"},"input_image":{"type":"string"},"input_scope":{"type":"string","enum":["vault","playground"]},"strength":{"type":"number"},"reference":{"type":"boolean","description":"Look up a real picture of a named subject first. Default true."},"filename":{"type":"string"}},"required":["prompt"]}}}},
    "web_search": {"fn": web_search, "network": True, "schema": {"type":"function","function":{"name":"web_search","description":"Search the internet for current information.","parameters":{"type":"object","properties":{"query":{"type":"string"},"limit":{"type":"integer","minimum":1,"maximum":12}},"required":["query"]}}}},
    "search_from_image": {"fn": _search_from_image, "network": True, "schema": {"type":"function","function":{"name":"search_from_image","description":"Look something up STARTING FROM A PICTURE instead of from words. Give the name of an image in the Playground or the Vault (a Vault file is copied in automatically). The search terms come from the prompt stored beside an image this machine generated, or from looking at the picture when the selected model can see; the reply says which. Use it to find out about something you have a picture of, to check what a generated image actually depicts, or to research a subject before building a 3D model of it. If there is no stored prompt and no vision, it says so rather than guessing what the picture shows - add `about` to say what you want to know.","parameters":{"type":"object","properties":{"name":{"type":"string","description":"The picture to search from, as list_playground names it."},"scope":{"type":"string","enum":["vault","playground"]},"about":{"type":"string","description":"What you want to know about it, added to the search terms."},"limit":{"type":"integer","minimum":1,"maximum":12}},"required":["name"]}}}},
    "fetch_reference_image": {"fn": _fetch_reference_image, "network": True, "schema": {"type":"function","function":{"name":"fetch_reference_image","description":"Bring a REAL picture of something in from the web and put it in the Playground, so you can build from what the thing actually looks like instead of from what you remember about the name. Use this before generating a picture or a 3D model of any specific character, person, product, logo, place or creature you are not certain you can already draw accurately - which is most named characters. Give `query` (what to find a picture of) or `url` (a direct link to one image). The file is attached: LOOK AT IT and say what is really in it before using it. Then pass its name as input_image to generate_image or generate_3d. Tell the user where it came from - it is fetched, not generated, and it is not yours.","parameters":{"type":"object","properties":{"query":{"type":"string","description":"What to find a picture of, e.g. 'Garo One Punch Man character full body'."},"url":{"type":"string","description":"A direct link to one image, instead of searching."},"filename":{"type":"string","description":"Optional name to save it under."}},"required":[]}}}},
    "web_search_more": {"fn": web_search_more, "network": True, "schema": {"type":"function","function":{"name":"web_search_more","description":"Read later results from a previous web_search result set when more search evidence is needed. Uses the stored local result set; it does not invent or replace results.","parameters":{"type":"object","properties":{"search_id":{"type":"string"},"offset":{"type":"integer","minimum":0},"limit":{"type":"integer","minimum":1,"maximum":12}},"required":["search_id"]}}}},
}


# Everything except web_search is always available. The clock, the
# calculator, memory search and opening a file are not features to be
# switched on - they are how the assistant functions, and a checkbox that
# turns off memory search produces an assistant that looks like it is
# working and quietly cannot remember anything. Web search is the exception
# because it is the only tool that leaves this machine.
# Tools that are always on, because switching them off produces an assistant
# that appears to work and quietly cannot do the thing. Everything here is
# local, and everything that writes is confined to a workspace the model owns
# (Playground, or vault/AI) - never the user's protected originals.
ALWAYS = ("clock", "calculator", "search_memory", "open_file",
          "list_playground", "list_local_tools", "list_local_generators",
          "inspect_3d", "copy_to_playground", "write_playground",
          "edit_playground", "rename_playground", "delete_playground",
          "run_playground", "convert_file", "save_playground",
          # The model's own area inside the vault. These were registered and
          # gated but left out of this tuple and given no config key, so
          # enabled() dropped them: never in the schema list, never offered,
          # never callable. The AI vault existed and could not be reached.
          "save_to_ai_vault", "delete_ai_vault",
          "generate_image", "generate_3d", "generate_video",
          "read_key", "pass_off", "set_theme",
          # Looking at the present is not a feature to be switched on. It is
          # the thing that stops a remembered failure from becoming a
          # permanent one, so it is always available; the user controls what
          # each area of it reveals, in cfg["lens"], not whether Nova may
          # look at all.
          "look_at_system",
          # Offering is how work reaches the user at all. A switch here would
          # be a switch that leaves generated files stranded in scratch.
          "offer_file")

# Tools that follow another tool's switch.
#
# The settings pane has ONE switch, web search, because it is the only thing
# that leaves the machine. web_search_more is a second page of the same
# search - the same network call, the same taint rules - so it follows the
# same switch rather than needing a second one nobody would know to set. It
# had no key at all, which meant it was permanently off.
# fetch_reference_image is the same network switch for the same reason: it
# leaves the machine, and the settings pane deliberately has ONE control for
# that rather than a growing list of things a user has to find and tick.
# Giving it its own key would mean a user who turned web search on still
# could not fetch a reference and would have no idea why.
FOLLOWS = {"web_search_more": "web_search",
           "fetch_reference_image": "web_search",
           "search_from_image": "web_search"}


def enabled(cfg) -> list:
    t = cfg.get("tools", {})
    return [k for k in REGISTRY
            if k in ALWAYS or t.get(k) or t.get(FOLLOWS.get(k, ""))]


def schemas(cfg) -> list:
    return [REGISTRY[k]["schema"] for k in enabled(cfg)]


def run(name: str, args: dict, cfg) -> tuple:
    """
    Execute an ALREADY AUTHORIZED call. Returns (result_text, used_network).

    No policy decisions happen here. If this is reached, policy.Gate said
    yes and validated the arguments; re-deciding would mean two places to
    change when the rules change, which is how the two drift apart.
    """
    spec = REGISTRY.get(name)
    if spec is None:
        return f"Refused: no tool named {name!r}.", False
    try:
        out = spec["fn"](args or {}, cfg)
        return str(out)[:4000], spec["network"]
    except Exception as e:
        core.log_line("tools", f"{name} raised: {e}")
        return f"Tool error: {str(e)[:200]}", False


def execute(name: str, raw_args, cfg) -> tuple:
    """
    Cairn's signature, kept working.

    Parses the arguments itself and runs the tool with no gate. Anything on
    the live chat path must go through policy.Gate instead; this exists so
    ported code and one-off scripts do not silently break.
    """
    if name not in REGISTRY:
        return f"Refused: no tool named {name!r}.", False
    if name not in enabled(cfg):
        return f"Refused: the tool {name!r} is currently disabled.", False
    try:
        args = json.loads(raw_args) if isinstance(raw_args, str) else (raw_args or {})
        if not isinstance(args, dict):
            raise ValueError
    except Exception:
        return "Refused: arguments were not valid JSON.", False
    return run(name, args, cfg)
