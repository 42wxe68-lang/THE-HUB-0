"""
test_carryover.py - the previous conversations are present, and are used.

WHAT THIS SUITE IS ACTUALLY GUARDING

Two failures, both of which had already happened once.

  1. BUILT AND NOT WIRED IN. growth.py is written, tested, and has never
     been connected to the running tree. A module that assembles a perfect
     block nobody passes to the model is the same thing wearing a different
     name, so the integration tests here call server.build_messages() and
     look for the block in the actual prompt.

  2. A PATH REDIRECTED HALFWAY. test_playground redirected core.DATA and
     not vault.VAULT, and a build shipped with 29 stray scripts; a later
     suite redirected memory.YESOD_DIR and not core.TREE and put a fixture
     leaf into the shipped tree. Everything this suite can write to is
     redirected in one place below, and verify.py snapshots the directories
     around the whole run as the second line of defence.
"""
from __future__ import annotations

import json
import pathlib

import core
import budget
import memory
import carryover
import research


# ------------------------------------------------------------------ fixture

def _redirect(tmp_path):
    """Every path any of this can reach. Returns what to put back."""
    old = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
           core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
           memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
           memory.ACTIVE_STATE)
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"
    core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"
    core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"
    core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    memory.ARCHIVE_DIR = core.SESSIONS / "archive"
    memory.YESOD_DIR = core.TREE / "yesod"
    # build_messages() calls memory.active_move(). ACTIVE_DIR is bound to
    # core.DATA at import, so redirecting core.DATA alone leaves it pointing
    # at the real one and the fixture's turns land in the shipped build -
    # the same half-redirect that put a fixture leaf in data/tree.
    memory.ACTIVE_DIR = core.DATA / "active"
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"
    core.ensure_dirs()
    carryover.forget_cache()
    return old


def _restore(old):
    (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
     core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
     memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
     memory.ACTIVE_STATE) = old
    carryover.forget_cache()


def _session(sid, stamp, rounds, where=None, text="round"):
    msgs = []
    for i in range(rounds):
        msgs.append({"role": "user", "content": f"{sid} {text} {i}"})
        msgs.append({"role": "assistant", "content": f"{sid} answer {i}"})
    d = where or core.SESSIONS
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{sid}.json").write_text(json.dumps(
        {"id": sid, "started": stamp, "updated": stamp, "messages": msgs}),
        encoding="utf-8")


# ------------------------------------------------------------------ shape

def test_rounds_open_at_each_user_message():
    rs = carryover.rounds([
        {"role": "assistant", "content": "hello"},      # leading, kept
        {"role": "user", "content": "one"},
        {"role": "assistant", "content": "a"},
        {"role": "assistant", "content": "still a"},    # same round
        {"role": "user", "content": "two"},
        {"role": "system", "content": "ignored"},
        {"role": "user", "content": "   "},             # empty, dropped
    ])
    assert len(rs) == 3, rs
    assert rs[0][0]["content"] == "hello"
    assert len(rs[1]) == 3
    assert rs[2][0]["content"] == "two"


def test_the_last_two_sessions_oldest_first(tmp_path):
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 2)
        _session("s02", "2026-09-02T10:00:00", 2)
        _session("s03", "2026-09-03T10:00:00", 2)
        _session("s04", "2026-09-04T10:00:00", 2)
        got = [d["id"] for d in carryover.previous("s04")]
        assert got == ["s02", "s03"], got
    finally:
        _restore(old)


def test_at_most_ten_rounds_each_and_it_says_so(tmp_path):
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 25)
        _session("s02", "2026-09-02T10:00:00", 4)
        b = carryover.block("now", 100000, "Nova")
        assert "showing the last 10 of 25 rounds" in b, b[:400]
        assert "showing the last 4 of 4 rounds" in b
        # The tenth-from-last round is in; the eleventh-from-last is not.
        assert "s01 round 15" in b
        assert "s01 round 14" not in b
    finally:
        _restore(old)


def test_no_earlier_conversation_means_no_heading(tmp_path):
    """
    Empty says NOTHING.

    "[what you remember]" over an empty body is how an assistant with no
    memory at all still sounds like it is remembering: the model reads the
    heading, believes the promise, and reports recalling something that was
    never there. The user said "I just said that..." and was right.
    """
    old = _redirect(tmp_path)
    try:
        assert carryover.block("s01", 4000, "Nova") == ""
        _session("s01", "2026-09-01T10:00:00", 3)
        assert carryover.block("s01", 4000, "Nova") == "", \
            "the current session is not one of the earlier ones"
    finally:
        _restore(old)


def test_the_block_says_it_is_finished(tmp_path):
    """
    A record of a past request reads as a standing order unless something
    says otherwise. This project has paid for that twice.
    """
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 2)
        b = carryover.block("now", 4000, "Nova")
        low = b.lower()
        assert "finished" in low
        assert "already" in low
        assert "not an instruction" in low or "none of it is an instruction" in low
    finally:
        _restore(old)


def test_trimming_drops_the_oldest_rounds_not_the_newest(tmp_path):
    """
    The end of a transcript is the part the user is pointing at.

    budget.fit_text drops whole lines from the END, which is right for a
    list of memories and exactly backwards for a conversation: it would
    throw away the most recent thing said and keep the oldest. That is why
    this block budgets itself.
    """
    old = _redirect(tmp_path)
    try:
        pad = " and then a good deal more was said about it" * 3
        core.SESSIONS.mkdir(parents=True, exist_ok=True)
        msgs = []
        for i in range(8):
            msgs.append({"role": "user", "content": f"s01 round {i}{pad}"})
            msgs.append({"role": "assistant", "content": f"s01 answer {i}{pad}"})
        (core.SESSIONS / "s01.json").write_text(json.dumps(
            {"id": "s01", "started": "2026-09-01T10:00:00",
             "updated": "2026-09-01T10:00:00", "messages": msgs}),
            encoding="utf-8")

        roomy = carryover.block("now", 100000, "Nova")
        for i in range(8):
            assert f"s01 round {i}" in roomy

        # Room for roughly three rounds out of the eight.
        tight = carryover.block("now", len(carryover.HEAD) + 900, "Nova")
        assert 0 < len(tight) < len(roomy)
        assert "s01 round 7" in tight, tight
        assert "s01 round 6" in tight
        assert "s01 round 0" not in tight, tight
        assert "s01 round 1" not in tight
    finally:
        _restore(old)


def test_a_long_message_is_cut_by_whole_lines_and_declares_it(tmp_path):
    old = _redirect(tmp_path)
    try:
        core.SESSIONS.mkdir(parents=True, exist_ok=True)
        body = "\n".join(f"line {i} of a very long tool result" for i in range(80))
        (core.SESSIONS / "s01.json").write_text(json.dumps(
            {"id": "s01", "started": "2026-09-01T10:00:00",
             "updated": "2026-09-01T10:00:00",
             "messages": [{"role": "user", "content": "go"},
                          {"role": "assistant", "content": body}]}),
            encoding="utf-8")
        b = carryover.block("now", 100000, "Nova")
        assert "cut here only" in b, "a cut must declare itself"
        assert "data/sessions/s01.json" in b, "and say where the whole thing is"
        assert "line 0 of a very long tool result" in b
        assert b.count("line ") < 80
        # no half-sentence
        for line in b.splitlines():
            assert not line.endswith("of a very"), line
    finally:
        _restore(old)


def test_archived_sessions_are_still_found(tmp_path):
    """A digested session is moved, not deleted. It is still what was said."""
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 3, where=memory.ARCHIVE_DIR)
        _session("s02", "2026-09-02T10:00:00", 3)
        got = [d["id"] for d in carryover.previous("now")]
        assert got == ["s01", "s02"], got
    finally:
        _restore(old)


# ------------------------------------------------------------------ once

def test_prepared_is_stable_while_the_current_session_is_rewritten(tmp_path):
    """
    Assembled once, not per turn - and save_session() rewrites the CURRENT
    session file every single turn, so that file cannot be part of the
    fingerprint or the cache would never hit.

    Byte-identical also matters to llama.cpp: a head that changes every turn
    is a head that is re-evaluated every turn.
    """
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 3)
        first = carryover.prepared("now", 4000, "Nova")
        assert first
        for i in range(3):
            memory.save_session("now", [{"role": "user", "content": f"t{i}"},
                                        {"role": "assistant", "content": "ok"}])
            assert carryover.prepared("now", 4000, "Nova") == first
        # A NEW earlier conversation does change it.
        _session("s02", "2026-09-02T10:00:00", 3)
        assert carryover.prepared("now", 4000, "Nova") != first
    finally:
        _restore(old)


# ------------------------------------------------------------------ inward

def test_the_sentences_that_failed_are_no_longer_sent_to_the_internet():
    """
    Zero's own words, verbatim from the run that prompted this work. Every
    one of them scored on EXPLICIT ("look into", "search") and went to the
    web branch, where web search was off, and Nova was handed an instruction
    to answer from training data and mark it as possibly out of date - about
    the user's own last conversation.
    """
    for said in ("Look into the last prompt in the timeline you see.",
                 "No, look in your memory.",
                 "yes then before that you have a memory to search from.",
                 "Just build a transcript yourself then.",
                 "what did we say about the video",
                 "read your notes from the last session"):
        v = research.preflight(said, {})
        assert not v.required, f"{said!r} was sent outward: {v.reason}"
        assert v.suppressed_by in ("inward", "memory", "personal", "self"), \
            f"{said!r} -> {v.suppressed_by}"


def test_the_outside_world_is_still_checked():
    """The suppressor must not be a lid on the whole preflight."""
    for said in ("who is the current ceo of nvidia",
                 "search for the latest llama.cpp release notes",
                 "what is the price of a Raspberry Pi 5 right now"):
        assert research.preflight(said, {}).required, said


def test_nothing_found_never_becomes_i_have_no_memory(tmp_path):
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 2)
        ev = carryover.evidence_for("something entirely unrelated zzzz",
                                    "now", 2000, "Nova")
        assert "do not answer that you have no memory" in ev.lower(), ev
        # No keyword overlap still hands over the most recent rounds,
        # because "what was the last prompt" carries no keywords and is
        # still a perfectly good question.
        assert "s01 round 1" in ev, ev

        # But with nothing on disk at all it says so, and does not push a
        # model with no material into inventing an exchange.
        for f in core.SESSIONS.glob("*.json"):
            f.unlink()
        none = carryover.evidence_for("anything", "now", 2000, "Nova")
        assert "There are none yet" in none, none
        assert "Do not invent" in none
    finally:
        _restore(old)


def test_a_match_is_handed_over_as_the_words_that_were_said(tmp_path):
    old = _redirect(tmp_path)
    try:
        core.SESSIONS.mkdir(parents=True, exist_ok=True)
        (core.SESSIONS / "s01.json").write_text(json.dumps(
            {"id": "s01", "started": "2026-09-01T10:00:00",
             "updated": "2026-09-01T10:00:00",
             "messages": [
                 {"role": "user", "content": "make a video of a lighthouse"},
                 {"role": "assistant", "content": "the video finished in 43 minutes"},
                 {"role": "user", "content": "now a 3D model of a bracket"},
                 {"role": "assistant", "content": "trellis started"}]}),
            encoding="utf-8")
        ev = carryover.evidence_for("what did we say about the lighthouse video",
                                    "now", 2000, "Nova")
        assert "lighthouse" in ev
        assert "43 minutes" in ev
        assert "record of what was said" in ev
    finally:
        _restore(old)


def test_an_unrelated_question_pulls_nothing(tmp_path):
    """Tacos are not a rock. Overlap, or nothing."""
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 3, text="bracket")
        assert carryover.find("kiln temperature for stoneware", "now") == []
        assert carryover.find("", "now") == []
    finally:
        _restore(old)


# ------------------------------------------------------------------ wired in

def test_it_is_actually_in_the_prompt(tmp_path):
    """
    THE growth.py TEST.

    growth.py is built, tested and not connected to the running tree. A
    block that is assembled perfectly and never handed over is the same
    failure. So this builds a real prompt and looks in it.
    """
    import server
    import runtime
    old = _redirect(tmp_path)
    saved = (runtime.health, runtime.live_ctx, runtime.resolve_max_tokens,
             server.SESSION_ID)
    runtime.health = lambda *a, **k: False
    runtime.live_ctx = lambda cfg: 8192
    runtime.resolve_max_tokens = lambda ctx, sampling: 512
    server.SESSION_ID = "now"
    try:
        _session("s01", "2026-09-01T10:00:00", 3, text="lighthouse")
        msgs, last_user, rep = server.build_messages(
            [{"role": "user", "content": "what did we say last time"}],
            core.load(), "")
        system = msgs[0]["content"]
        assert msgs[0]["role"] == "system", "one system message, and it is first"
        assert sum(1 for m in msgs if m["role"] == "system") == 1
        assert "[earlier conversations" in system, \
            "the earlier conversations never reached the prompt"
        assert "s01 lighthouse 2" in system, "and they reached it with content"
        # The pointer beside the question, where a small model is looking.
        tail = msgs[-1]["content"]
        assert "[where the past is]" in tail, tail[:400]
        assert "last prompt" in tail
        assert rep["headroom"] > 0

        # A TURN THAT NAMES NO TOOL IS NOT TOLD IT IS ASKING FOR ONE.
        #
        # The tool hint used to search six earlier turns and announce the
        # first name it found as what THIS message wants - so a question
        # about the past was handed to a 2B model as an instruction to
        # generate something.
        assert "It is asking for" not in tail, tail[:600]
        assert ("names no tool" in tail
                or "asking for" not in tail), tail[:600]

        # The user's own words are marked as theirs, and are last.
        assert "in the user's own words" in tail
        assert tail.rstrip().endswith("what did we say last time")
        assert tail.index("in the user's own words") > tail.index("[this turn]")
        assert last_user == "what did we say last time"
    finally:
        (runtime.health, runtime.live_ctx, runtime.resolve_max_tokens,
         server.SESSION_ID) = saved
        _restore(old)


def test_the_budget_has_a_line_for_it():
    p = budget.Plan(n_ctx=32768, max_tokens=2048, character_tokens=3000)
    assert p.carryover > 0
    assert "carryover" in p.as_dict()
    total = (p.character + p.frame + p.knowledge + p.recall + p.evidence
             + p.carryover + p.history)
    assert total <= p.workable, (total, p.workable)
    # A tiny window still leaves room for the conversation itself.
    small = budget.Plan(n_ctx=2048, max_tokens=512, character_tokens=900)
    assert small.history > 0 and small.carryover >= 0


def test_the_server_offers_the_running_conversation_back():
    """
    ui.html declares `let history=[]` and rebuilds it empty on every load.
    Without a door back to the server, refreshing the page is amnesia with
    no error and nothing in a log.
    """
    src = pathlib.Path("server.py").read_text(encoding="utf-8")
    assert '"/api/session"' in src
    assert '"/api/session/new"' in src
    ui = pathlib.Path("ui.html").read_text(encoding="utf-8")
    assert "restoreSession" in ui
    assert 'fetch("/api/session")' in ui
    assert 'fetch("/api/session/new"' in ui


def test_ending_a_conversation_does_not_overwrite_it(tmp_path):
    """
    save_session() REPLACES the file for its id. Clearing the screen without
    rotating the id meant the first turn of the next conversation wrote over
    the whole of the last one, and that file was the only copy there was.
    """
    import server
    old = _redirect(tmp_path)
    saved = server.SESSION_ID
    try:
        server.SESSION_ID = "s_live"
        server._history_ref["messages"] = [
            {"role": "user", "content": "the thing we were doing"},
            {"role": "assistant", "content": "here is the thing"}]
        new_id = server.roll_session("test")
        assert new_id != "s_live"
        assert server._history_ref["messages"] == []
        kept = core.read_json(core.SESSIONS / "s_live.json", None)
        assert kept and len(kept["messages"]) == 2, "the transcript was lost"
        # And it is now one of the earlier conversations.
        assert "the thing we were doing" in carryover.block(new_id, 4000, "Nova")
    finally:
        server.SESSION_ID = saved
        server._history_ref["messages"] = []
        _restore(old)


def test_two_rolls_in_one_second_do_not_collide(tmp_path):
    import server
    old = _redirect(tmp_path)
    saved = server.SESSION_ID
    try:
        seen = set()
        for i in range(4):
            server._history_ref["messages"] = [
                {"role": "user", "content": f"conversation {i}"},
                {"role": "assistant", "content": "ok"}]
            seen.add(server.SESSION_ID)
            server.roll_session("test")
        seen.add(server.SESSION_ID)
        assert len(seen) == 5, seen
        files = sorted(f.name for f in core.SESSIONS.glob("*.json"))
        assert len(files) == 4, files
    finally:
        server.SESSION_ID = saved
        server._history_ref["messages"] = []
        _restore(old)


# ------------------------------------------------------------------ no walls

def test_nothing_here_can_run_out_of_time():
    """
    The rule, applied to a file test_nowalls.py does not cover.

    "Nothing may fail for taking time." Reading a transcript off a disk has
    no business having a deadline, and a deadline here would fail exactly
    the way the others did: quietly, and by removing the thing it was meant
    to protect.
    """
    src = pathlib.Path("carryover.py").read_text(encoding="utf-8")
    for banned in ("timeout", "deadline", "time.time()", "signal.alarm",
                   "TimeoutError", "expire"):
        assert banned not in src, f"carryover.py has a {banned}"


# ------------------------------------------------------------ ending one

def test_a_conversation_ends_after_its_rounds(tmp_path):
    """
    A conversation that never ends is one conversation forever: the
    transcript grows until it fills the window and every turn is spent at
    full context. Something has to draw the line.
    """
    import server
    old = _redirect(tmp_path)
    saved = (server.SESSION_ID, core.CONFIG)
    try:
        core.CONFIG = tmp_path / "config.json"
        cfg = core.load()
        cfg.setdefault("chat", {})["rounds_per_conversation"] = 3
        core.save(cfg)
        assert server.rounds_limit(core.load()) == 3

        convo = []
        for i in range(3):
            convo += [{"role": "user", "content": f"ask {i}"},
                      {"role": "assistant", "content": f"answer {i}"}]
        assert server.rounds_in(convo) == 3
        assert server.rounds_in(convo[:4]) == 2
        assert server.rounds_in([]) == 0
        assert server.rounds_in([{"role": "user", "content": "   "}]) == 0

        # 0 means never end one on its own.
        cfg["chat"]["rounds_per_conversation"] = 0
        core.save(cfg)
        assert server.rounds_limit(core.load()) == 0
    finally:
        (server.SESSION_ID, core.CONFIG) = saved
        _restore(old)


def test_ending_on_rounds_marks_nothing(tmp_path):
    """
    THE GREY ZONE. Running out of rounds is not a verdict.

    If an ordinary ending counted as anything, the word would mean nothing:
    almost every conversation ends this way.
    """
    import server
    old = _redirect(tmp_path)
    saved = server.SESSION_ID
    try:
        server.SESSION_ID = "s_rounds"
        server._history_ref["messages"] = [
            {"role": "user", "content": "twenty rounds of ordinary work"},
            {"role": "assistant", "content": "done"}]
        server.roll_session("20 rounds")
        kept = core.read_json(core.SESSIONS / "s_rounds.json", None)
        assert kept["outcome"] == "", kept
        assert "marked_at" not in kept
    finally:
        server.SESSION_ID = saved
        server._history_ref["messages"] = []
        _restore(old)


def test_failure_is_marked_kept_and_readable(tmp_path):
    import server
    old = _redirect(tmp_path)
    saved = server.SESSION_ID
    try:
        server.SESSION_ID = "s_bad"
        server._history_ref["messages"] = [
            {"role": "user", "content": "convert the bracket to obj"},
            {"role": "assistant", "content": "here is a poem about brackets"},
            {"role": "user", "content": "no, convert the FILE"}]
        server.roll_session("the user marked it a failure", "failure")

        kept = core.read_json(core.SESSIONS / "s_bad.json", None)
        assert kept["outcome"] == "failure"
        assert kept["marked_at"]
        assert len(kept["messages"]) == 3, "the transcript is kept, not deleted"

        log = (core.LOGS / "failure.log").read_text(encoding="utf-8")
        assert "s_bad marked a failure" in log
        assert "convert the FILE" in log, "what was being asked when it broke"
    finally:
        server.SESSION_ID = saved
        server._history_ref["messages"] = []
        _restore(old)


def test_a_mark_survives_the_next_turns_save(tmp_path):
    """
    save_session() runs on every turn and must not erase a mark the user
    made. Sticky by default; only an explicit outcome changes it.
    """
    old = _redirect(tmp_path)
    try:
        memory.save_session("s1", [{"role": "user", "content": "a"}],
                            outcome="failure")
        memory.save_session("s1", [{"role": "user", "content": "a"},
                                   {"role": "assistant", "content": "b"}])
        assert core.read_json(core.SESSIONS / "s1.json", {})["outcome"] == "failure"
        memory.save_session("s1", [{"role": "user", "content": "a"}],
                            outcome="")
        assert core.read_json(core.SESSIONS / "s1.json", {})["outcome"] == ""
        # nothing else is a mark
        memory.save_session("s1", [{"role": "user", "content": "a"}],
                            outcome="brilliant")
        assert core.read_json(core.SESSIONS / "s1.json", {})["outcome"] == ""
    finally:
        _restore(old)


def test_the_model_is_told_which_it_was_and_what_unmarked_means(tmp_path):
    old = _redirect(tmp_path)
    try:
        _session("s01", "2026-09-01T10:00:00", 2)
        _session("s02", "2026-09-02T10:00:00", 2)
        p = core.SESSIONS / "s02.json"
        d = core.read_json(p, {})
        d["outcome"] = "failure"
        core.write_json(p, d)
        carryover.forget_cache()

        b = carryover.block("now", 6000, "Nova")
        assert "MARKED A FAILURE by the user" in b, b[:600]
        assert "not marked either way" in b, b[:600]

        # And the grey zone is spelled out, not left to be inferred.
        low = b.lower()
        assert "not approval" in low
        assert "not a fault" in low
        assert "almost every conversation is unmarked" in low
        assert carryover.summary("now")["failures"] == 1
    finally:
        _restore(old)


def test_the_failure_count_is_for_the_user_not_the_prompt(tmp_path):
    """
    A running score is a judgement about her rather than about one piece of
    work, and there is no evidence that telling a 2B model it has failed
    three times lately makes the fourth attempt better. The mark belongs
    beside the conversation it describes.
    """
    old = _redirect(tmp_path)
    try:
        for i in range(3):
            _session(f"s0{i}", f"2026-09-0{i + 1}T10:00:00", 2)
            p = core.SESSIONS / f"s0{i}.json"
            d = core.read_json(p, {})
            d["outcome"] = "failure"
            core.write_json(p, d)
        carryover.forget_cache()
        m = carryover.marks(10)
        assert m["failures"] == 3
        b = carryover.block("now", 6000, "Nova")
        for n in ("3 of", "three", "failures so far", "you have failed"):
            assert n not in b.lower(), n
    finally:
        _restore(old)


def test_the_interface_has_one_button_and_it_is_failure():
    ui = pathlib.Path("ui.html").read_text(encoding="utf-8")
    assert 'id="fail"' in ui
    assert 'id="fresh"' not in ui, "the New conversation button was replaced"
    assert 'outcome:"failure"' in ui.replace(" ", "")
    assert "failArmed" in ui, "one stray click must not mark a good conversation"
    assert 'id="c_rounds_per_conversation"' in ui, "it is set in Settings"
    src = pathlib.Path("server.py").read_text(encoding="utf-8")
    assert "rounds_limit(" in src and "rounds_in(" in src
    assert '"rolled"' in src, "the page has to be told the conversation ended"


if __name__ == "__main__":
    import sys
    import testkit
    sys.exit(testkit.run(dict(globals()), "carryover - the past is present"))
