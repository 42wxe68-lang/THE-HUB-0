"""
hold.py - how firmly a memory is held, and how easily it comes to hand.

WHY THIS FILE EXISTS.

    "how is this supposed to remember things if there is no memory and only
     sessions to go from, it cannot load EVERY session, even the largest AI
     would strain from bearing years of data on it all at once"

That is the whole problem stated in one sentence, and it is the same problem
a brain solves. A person does not hold thirty years of days in mind. They
hold almost none of it, and yet nothing is missing: the right thing arrives
when the situation calls for it, most of it never arrives at all, and what
has not been thought about in a decade can come back in one exposure.

Before this file, a memory here had ONE number - `weight` - and retrieval was
exact word overlap against a growing blocklist. Every leak that got fixed
made the blocklist longer, and the end of that road was measured: with the
fact "Image generation takes about 170 seconds" sitting in the store, asking
"how long does an image take here" returned NOTHING. The store was
write-only. Each fix was right about its leak and wrong about the direction.

═══════════════════════════════════════════════════════════════════════════
 ONE NUMBER CANNOT DESCRIBE A MEMORY
═══════════════════════════════════════════════════════════════════════════

Bjork & Bjork's New Theory of Disuse (1992) separates two quantities that a
single `weight` collapses:

    STORAGE STRENGTH   how deeply embedded it is. Never decreases.
    RETRIEVAL STRENGTH how easily it comes to mind right now. Decays.

The consequences are not decoration:

  * Storage strength never falls, so nothing that mattered is ever truly
    gone - only currently out of reach.
  * Retrieval strength decays more slowly the higher storage strength is,
    so what has been returned to often stays available for longer without
    anything being pinned by hand.
  * A retrieval that was HARD teaches more than one that was easy. Bjork's
    A3: the gain in storage strength is a DECREASING function of current
    retrieval strength. Remembering something nearly lost strengthens it
    enormously; remembering something you just said barely counts.

  * And the property that decides the whole design: with one number you
    cannot represent "I have completely forgotten this and would need one
    reminder to have it back". That is the most characteristic thing about
    human long-term memory, and it is why this file stores two.

The operational form is FSRS's DSR model - stability, retrievability,
difficulty - fitted on some 350 million real reviews, which is a better
empirical base than anything this project could invent. Its constants are
used as published rather than guessed at.

═══════════════════════════════════════════════════════════════════════════
 AND FEELING IS A THIRD QUANTITY, NOT A BIGGER WEIGHT
═══════════════════════════════════════════════════════════════════════════

    "this should save all the memories it can with weights including the
     weight of emotions, loss and regret, as well as the positive side to
     keep things on the right track you will need to keep both"

Both, and separately, because the literature is clear that they come apart.

WHAT IS TRUE AND WELL REPLICATED: emotionally significant events are
retained better, the advantage appears only AFTER about a day (it is a
consolidation effect, not an encoding one), and it tracks AROUSAL - how much
was at stake - more reliably than whether the feeling was good or bad.

WHAT IS ALSO TRUE AND MATTERS MORE: the FEELING fades while the CONTENT
stays, and negative feeling fades faster than positive. This is the Fading
Affect Bias, and it is one of the better-replicated findings in the area
(N=2,163, 12,314 memories: negative affect faded in 30.5% of cases against
10.3% for positive). Talking about a bad experience accelerates the fade of
the feeling while the memory of what happened stays put.

So loss and regret weight a memory UP - through its stability, which is what
keeps it available - and their affective charge decays on its own clock,
faster than the positive, and faster still every time it is recalled.

That is not a softening of what was asked for. It is the difference between
a system that learns from a bad outcome and one that keeps flinching at it.
The literature is blunt about the alternative: affect that does not fade is
the dysphoric profile, and a memory system whose negative weights never
decay has a bug with a clinical name. So `check()` looks for exactly that.

Nothing here is inference about the user. These are properties of a stored
line: how long since it was useful, how often it has come back, how much was
at stake when it was written down.

Sources for every constant are in DECISIONS.md, ADR-109.
"""
from __future__ import annotations

import math

# ── the forgetting curve ──────────────────────────────────────────────────
#
# R(t, S) = (1 + FACTOR * t/S) ^ DECAY
#
# A power law, not an exponential. Wixted's work and every large review
# corpus fit power-law retention better; an exponential drops too fast early
# and too slow late. These are FSRS-4.5/5's published constants, chosen so
# that R = 0.9 exactly when t = S - which is what makes STABILITY readable
# as "days until this is 90% likely to come to mind".
DECAY = -0.5
FACTOR = 0.9 ** (1.0 / DECAY) - 1.0          # = 19/81 ≈ 0.2346

# Stability of something just written down, in days. Deliberately short: a
# thing said once is not knowledge yet, and saying so is the point of the
# whole file.
S_NEW = 1.0

# Nothing is ever pinned by accumulating stability alone; this is a sanity
# ceiling of about 150 years, past which the arithmetic stops meaning much.
S_MAX = 55000.0


def retrievability(stability: float, days: float) -> float:
    """How likely this is to come to mind now. 1.0 = certain, 0.0 = gone."""
    s = max(float(stability or S_NEW), 0.01)
    t = max(float(days or 0.0), 0.0)
    return float((1.0 + FACTOR * t / s) ** DECAY)


def days_until(stability: float, target: float = 0.9) -> float:
    """When this will have decayed to `target` retrievability."""
    s = max(float(stability or S_NEW), 0.01)
    r = min(max(float(target), 0.001), 0.999)
    return float((s / FACTOR) * (r ** (1.0 / DECAY) - 1.0))


# ── strengthening ─────────────────────────────────────────────────────────
#
# The FSRS stability-increase form, with its published weights. The term
# that matters most is (e^(W_R*(1-R)) - 1): the LOWER the retrievability at
# the moment of recall, the larger the gain. That is Bjork's A3 written as
# arithmetic, and it is why a memory that was nearly lost and came back is
# worth more than one that was never at risk.
W_GAIN = 1.54        # overall scale of a successful recall  (FSRS w8)
W_DAMP = 0.1542      # diminishing returns on already-stable items  (w9)
W_HARD = 1.26        # reward for difficulty  (w10)


def strengthen(stability: float, days: float, *,
               difficulty: float = 5.0, arousal: float = 0.0) -> float:
    """
    Stability after this memory was successfully brought back.

    `difficulty` (1..10) is how tangled the memory is - a single fact is
    easy, a whole session is not. `arousal` (0..1) is how much was at stake,
    and it raises stability rather than shouting louder at retrieval time,
    because the emotional advantage in the literature is a consolidation
    effect: it shows up a day later, not at the moment of encoding.
    """
    s = max(float(stability or S_NEW), 0.01)
    r = retrievability(s, days)
    d = min(max(float(difficulty or 5.0), 1.0), 10.0)
    gain = (math.exp(W_GAIN) * (11.0 - d) * (s ** -W_DAMP)
            * (math.exp(W_HARD * (1.0 - r)) - 1.0))
    # Arousal is a modest multiplier on the gain, not a free ride. The
    # measured emotional retention advantage is real and it is not large.
    gain *= 1.0 + 0.6 * min(max(float(arousal or 0.0), 0.0), 1.0)
    return float(min(s * (1.0 + gain), S_MAX))


# A recall that FAILED still teaches something - it says this was harder to
# reach than its stability claimed - so stability is revised down, never to
# zero, and never below where it started.
W_FAIL = 1.9
W_FAIL_D = 0.27
W_FAIL_S = 0.51


def weaken(stability: float, days: float, *, difficulty: float = 5.0) -> float:
    """Stability after this should have come back and did not."""
    s = max(float(stability or S_NEW), 0.01)
    r = retrievability(s, days)
    d = min(max(float(difficulty or 5.0), 1.0), 10.0)
    post = (W_FAIL * (d ** -W_FAIL_D) * ((s + 1.0) ** W_FAIL_S - 1.0)
            * math.exp(0.29 * (1.0 - r)))
    return float(max(min(post, s), S_NEW * 0.5))


# ── feeling ───────────────────────────────────────────────────────────────
#
# Two half-lives, and they are not the same number. The Fading Affect Bias
# is the finding that the sting of a bad memory fades faster than the glow
# of a good one, with the content of both retained. The ratio below is set
# from the replication's fade rates (30.5% of negative memories showed
# fading affect against 10.3% of positive), not from taste.
AFFECT_HALFLIFE_NEG = 45.0     # days for the sting to halve
AFFECT_HALFLIFE_POS = 140.0    # days for the glow to halve

# Every retelling accelerates the fade of the feeling. This is measured, not
# assumed - disclosure at 0, 2 and 3 retellings increases the effect - and
# it is the mechanism by which a memory system stays useful without staying
# wounded.
RECALL_FADE = 0.88             # affect multiplier per recall


def affect_now(affect: float, valence: float, days: float,
               recalls: int = 0) -> float:
    """
    How much feeling is still attached. The CONTENT is not touched by this.

    That separation is the entire point: what happened is kept at full
    strength while how much it stings is allowed to settle. A system that
    decays them together forgets its lessons; one that decays neither keeps
    flinching.
    """
    a = min(max(abs(float(affect or 0.0)), 0.0), 1.0)
    if a <= 0.0:
        return 0.0
    half = (AFFECT_HALFLIFE_NEG if float(valence or 0.0) < 0
            else AFFECT_HALFLIFE_POS)
    a *= 0.5 ** (max(float(days or 0.0), 0.0) / half)
    a *= RECALL_FADE ** max(int(recalls or 0), 0)
    return float(round(a, 4))


def check(traces) -> list:
    """
    Anything wrong with the SHAPE of what is being held.

    The literature names one failure mode explicitly: negative feeling that
    does not fade. Persistent negative affective weighting is the dysphoric
    profile, and in a memory system it is a bug with a known analogue rather
    than an accurate model of anything. So it is looked for, by hand, and
    reported - not silently corrected, because a silent correction of this
    would hide the fault that caused it.
    """
    problems = []
    # Each trace carries the charge it is CURRENTLY stored with, and its
    # age. Those two together say whether the clock has been running: a
    # negative memory from six months ago that still reads at full charge
    # has had its affect written back undecayed somewhere, which is the
    # exact failure being watched for.
    stuck = []
    for t in traces or ():
        if float(t.get("valence", 0) or 0) >= 0:
            continue
        age = float(t.get("age_days", 0) or 0)
        if age < AFFECT_HALFLIFE_NEG:
            continue                      # too soon to say anything
        stored = min(max(abs(float(t.get("affect", 0) or 0)), 0.0), 1.0)
        ought = affect_now(1.0, -1.0, age, t.get("recalls", 0))
        if stored > ought * 2.0 and stored > 0.35:
            stuck.append(t)
    if stuck:
        problems.append(
            f"{len(stuck)} negative memories still carry most of their "
            f"original charge long after it should have settled. The "
            f"content is meant to stay while the feeling fades; charge that "
            f"does not fade means it is being written back undecayed.")
    return problems


# ── what is worth keeping at all ─────────────────────────────────────────
#
# THE OTHER HALF, AND IT IS WHERE THE REAL DAMAGE WAS.
#
# A regex scoring 5 for /(never|must not|do not|don't) \w+/ read
#
#     "why did you copy me, don't do that"
#
# as a BOUNDARY - the same category as "everything must run offline" - and
# filed a moment's irritation as permanent identity, where it was then shown
# at the top of every prompt forever.
#
# Grammar is not salience. What earns a place in a long-lived memory is
# SURPRISE: the degree to which something was not already known. Event
# segmentation theory puts prediction error at the encoding gate for exactly
# this reason - it is what marks the boundary of an event worth storing.
#
# A complaint about the last reply is maximally unsurprising given the last
# reply. "Everything must run offline" is a standing fact about the world.
# The difference is measurable without understanding either sentence.

def surprise(text: str, known) -> float:
    """
    0..1 - how much of this is not already in `known`.

    `known` is any iterable of strings already held. Cheap on purpose: this
    runs on every candidate, and a decision about what to keep must never
    cost more than the thing being kept.
    """
    import re
    words = set(re.findall(r"[a-z0-9][a-z0-9'-]{2,}", (text or "").lower()))
    if not words:
        return 0.0
    seen = set()
    for k in known or ():
        seen |= set(re.findall(r"[a-z0-9][a-z0-9'-]{2,}", str(k).lower()))
    if not seen:
        return 1.0
    return round(len(words - seen) / len(words), 4)


def initial_stability(*, surprise_score: float = 0.5, arousal: float = 0.0,
                      stated: bool = True) -> float:
    """
    How firmly to hold something the first time it is seen.

    Nothing starts strong. A thing said once has been said once, and this
    project has an explicit rule about the difference between one
    observation and knowledge. What raises it is being surprising (it was
    not already known) and being consequential (something was at stake) -
    never the grammatical mood it happened to be phrased in.
    """
    s = S_NEW
    s *= 1.0 + 1.6 * min(max(float(surprise_score), 0.0), 1.0)
    s *= 1.0 + 1.2 * min(max(float(arousal), 0.0), 1.0)
    if not stated:
        s *= 0.55            # inferred, not said. Held, but held loosely.
    return float(round(min(s, S_MAX), 4))
