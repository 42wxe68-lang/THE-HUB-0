"""Local 3D inspection, rendering, and sandbox conversion helpers.

The language model cannot consume an STL/OBJ/STEP file as a visual scene just
because the file exists.  This module gives The Hub a visual representation of
3D geometry and a safe, explicit conversion playground.

The vault is never modified by conversion.  Outputs live under data/playground
until an explicit save copies one result into the vault.
"""
from __future__ import annotations

import json
import math
import os
import re
import shutil
import subprocess
import tempfile
import time
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

import core

SUPPORTED = {".stl", ".obj", ".ply", ".3mf", ".glb", ".gltf", ".step", ".stp"}
MESH_FORMATS = {".stl", ".obj", ".ply", ".3mf", ".glb", ".gltf"}
TEXTISH = {".txt", ".md", ".csv", ".json", ".log", ".py", ".js", ".html", ".css",
           ".yaml", ".yml", ".ini", ".cfg", ".sql", ".sh", ".bat", ".rs", ".go",
           ".c", ".h", ".cpp", ".java", ".ts", ".tsx", ".jsx", ".xml", ".toml"}

PLAYGROUND = core.DATA / "playground"


def ensure_playground() -> Path:
    PLAYGROUND.mkdir(parents=True, exist_ok=True)
    return PLAYGROUND


def _safe_name(name: str) -> str:
    name = Path(str(name).replace("\\", "/")).name
    name = re.sub(r"[^A-Za-z0-9._()\- ]+", "_", name).strip(" .")
    return name or "output"


def _unique(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(2, 10000):
        p = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not p.exists():
            return p
    raise RuntimeError("too many files with that name")


def list_playground() -> list[dict]:
    ensure_playground()
    out = []
    for p in sorted(PLAYGROUND.rglob("*")):
        if p.is_file() and not p.name.startswith("."):
            out.append({"name": str(p.relative_to(PLAYGROUND)).replace("\\", "/"),
                        "size_mb": round(p.stat().st_size / 1048576, 3),
                        "suffix": p.suffix.lower()})
    return out


def resolve_playground(name: str) -> Path | None:
    rel = Path(str(name).replace("\\", "/"))
    if rel.is_absolute() or ".." in rel.parts:
        return None
    p = (PLAYGROUND / rel).resolve()
    try:
        p.relative_to(PLAYGROUND.resolve())
    except ValueError:
        return None
    return p if p.is_file() else None


def _load_trimesh(path: Path):
    try:
        import trimesh
        return trimesh.load(path, force="scene", process=False)
    except Exception:
        return None


def _scene_triangles(scene):
    if scene is None:
        return []
    geoms = getattr(scene, "geometry", None)
    if geoms is None:
        return []
    out = []
    for geom in geoms.values():
        verts = getattr(geom, "vertices", None)
        faces = getattr(geom, "faces", None)
        if verts is None or faces is None:
            continue
        for face in faces:
            try:
                a, b, c = [verts[int(i)] for i in face[:3]]
                out.append((tuple(float(x) for x in a), tuple(float(x) for x in b), tuple(float(x) for x in c)))
            except Exception:
                continue
    return out


def _parse_stl(path: Path):
    data = path.read_bytes()
    tris = []
    if len(data) >= 84 and not (data[:5].lower() == b"solid" and b"facet" in data[:512]):
        n = int.from_bytes(data[80:84], "little")
        for i in range(min(n, 500_000)):
            o = 84 + i * 50 + 12
            if o + 36 > len(data):
                break
            pts = []
            for j in range(3):
                p = o + j * 12
                import struct
                pts.append(struct.unpack("<fff", data[p:p+12]))
            tris.append(tuple(pts))
        return tris
    text = data.decode("latin-1", "replace")
    cur = []
    for line in text.splitlines():
        p = line.strip().split()
        if len(p) == 4 and p[0].lower() == "vertex":
            try:
                cur.append((float(p[1]), float(p[2]), float(p[3])))
            except ValueError:
                pass
        if len(cur) == 3:
            tris.append(tuple(cur)); cur = []
    return tris


def _parse_obj(path: Path):
    verts, faces = [], []
    for line in path.read_text("utf-8", "replace").splitlines():
        if line.startswith("v "):
            p = line.split()
            if len(p) >= 4:
                verts.append((float(p[1]), float(p[2]), float(p[3])))
        elif line.startswith("f "):
            ids = []
            for x in line.split()[1:]:
                try: ids.append(int(x.split("/")[0]))
                except ValueError: pass
            if len(ids) >= 3:
                base = ids[0]
                for i in range(1, len(ids)-1):
                    def vi(n): return verts[n-1 if n > 0 else len(verts)+n]
                    faces.append((vi(base), vi(ids[i]), vi(ids[i+1])))
    return faces


def _parse_ply(path: Path):
    data = path.read_bytes()
    head_end = data.find(b"end_header")
    if head_end < 0:
        return []
    head = data[:head_end+10].decode("ascii", "replace").splitlines()
    nverts = nfaces = 0; fmt = "ascii"
    for line in head:
        if line.startswith("format binary_little_endian"): fmt = "binle"
        elif line.startswith("element vertex "): nverts = int(line.split()[-1])
        elif line.startswith("element face "): nfaces = int(line.split()[-1])
    if fmt != "ascii":
        return []  # trimesh handles binary PLY when available
    # `end_header` is followed by a newline that this slice used to keep, so
    # splitlines() produced a leading "" and every row shifted by one: the
    # vertex list came back one short and the first face index then ran off
    # the end of it. The file parsed as a crash, which surfaced as "partial
    # read: IndexError" on a perfectly valid PLY. Drop blank lines first, and
    # never trust an index into verts.
    rows = [r for r in data[head_end + 10:].decode("utf-8", "replace").splitlines()
            if r.strip()]
    verts = []
    for row in rows[:nverts]:
        parts = row.split()
        if len(parts) >= 3:
            try:
                verts.append(tuple(map(float, parts[:3])))
            except ValueError:
                pass
    out = []
    for row in rows[nverts:nverts + nfaces]:
        parts = row.split()
        if not parts:
            continue
        try:
            k = int(parts[0])
            ids = [int(x) for x in parts[1:1 + k]]
        except ValueError:
            continue
        if len(ids) < 3 or any(i < 0 or i >= len(verts) for i in ids):
            continue
        for i in range(1, len(ids) - 1):
            out.append((verts[ids[0]], verts[ids[i]], verts[ids[i + 1]]))
    return out


def _parse_3mf(path: Path):
    out = []
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith(".model")]
        if not names: return []
        root = ET.fromstring(z.read(names[0]))
    verts = []
    ns = {"m": "http://schemas.microsoft.com/3dmanufacturing/core/2015/02"}
    for v in root.findall(".//m:mesh/m:vertices/m:vertex", ns):
        verts.append((float(v.attrib.get("x", 0)), float(v.attrib.get("y", 0)), float(v.attrib.get("z", 0))))
    for t in root.findall(".//m:mesh/m:triangles/m:triangle", ns):
        ids = [int(t.attrib.get(k, 0)) for k in ("v1", "v2", "v3")]
        if max(ids, default=-1) < len(verts): out.append((verts[ids[0]], verts[ids[1]], verts[ids[2]]))
    return out


def triangles(path: Path):
    path = Path(path)
    scene = _load_trimesh(path) if path.suffix.lower() in MESH_FORMATS else None
    t = _scene_triangles(scene)
    if t: return t
    s = path.suffix.lower()
    if s == ".stl": return _parse_stl(path)
    if s == ".obj": return _parse_obj(path)
    if s == ".ply": return _parse_ply(path)
    if s == ".3mf": return _parse_3mf(path)
    return []


def _project_point(p, yaw, pitch, scale, cx, cy):
    x, y, z = p
    cyaw, syaw = math.cos(yaw), math.sin(yaw)
    x1 = x * cyaw - y * syaw; y1 = x * syaw + y * cyaw
    cp, sp = math.cos(pitch), math.sin(pitch)
    y2 = y1 * cp - z * sp; z2 = y1 * sp + z * cp
    return cx + x1 * scale, cy - z2 * scale, y2


def _png_rgb(width, height, pixels):
    """Encode an RGB pixel matrix as PNG using only the standard library."""
    import struct, zlib, binascii
    raw = b"".join(b"\x00" + bytes(row) for row in pixels)
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", binascii.crc32(tag + data) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" +
            chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _render_one(tris, size, yaw, pitch, distance, center, span):
    width = height = size
    px = [[18, 20, 26] * width for _ in range(height)]
    proj = []
    scale = size * 0.40 / max(span * distance, 1e-6)
    for tri in tris[:80_000]:
        q=[]
        for p in tri:
            pp=(p[0]-center[0],p[1]-center[1],p[2]-center[2])
            q.append(_project_point(pp, math.radians(yaw), math.radians(pitch), scale, size/2, size/2))
        depth=sum(p[2] for p in q)/3
        proj.append((depth,q))
    proj.sort(key=lambda x:x[0], reverse=True)
    for depth,q in proj:
        shade=max(44,min(215,int(135+depth*0.9)))
        poly=[(int(a),int(b)) for a,b,_ in q]
        minx=max(0,min(x for x,_ in poly)); maxx=min(width-1,max(x for x,_ in poly))
        miny=max(0,min(y for _,y in poly)); maxy=min(height-1,max(y for _,y in poly))
        if maxx<minx or maxy<miny: continue
        ax,ay=poly[0]; bx,by=poly[1]; cx,cy=poly[2]
        den=(by-cy)*(ax-cx)+(cx-bx)*(ay-cy)
        if den==0: continue
        for yy in range(miny,maxy+1):
            row=px[yy]
            for xx in range(minx,maxx+1):
                u=((by-cy)*(xx-cx)+(cx-bx)*(yy-cy))/den
                v=((cy-ay)*(xx-cx)+(ax-cx)*(yy-cy))/den
                w=1-u-v
                if u>=0 and v>=0 and w>=0:
                    j=xx*3; row[j:j+3]=[shade,shade,shade]
    return px


def _encode_pixels(px, width, height):
    import struct, zlib, binascii
    raw=b"".join(b"\x00"+bytes(row) for row in px)
    def chunk(tag,data):
        return struct.pack(">I",len(data))+tag+data+struct.pack(">I",binascii.crc32(tag+data)&0xffffffff)
    return (b"\x89PNG\r\n\x1a\n"+
            chunk(b"IHDR",struct.pack(">IIBBBBB",width,height,8,2,0,0,0))+\
            chunk(b"IDAT",zlib.compress(raw,6))+chunk(b"IEND",b""))


def _compose_views(view_pixels, out_path):
    size = len(view_pixels[0])
    if len(view_pixels) == 1:
        blob=_encode_pixels(view_pixels[0], size, size)
        out_path.write_bytes(blob)
        return out_path
    cols, rows = 3, 2
    flat=[]
    for y in range(rows*size):
        row=[]
        for x in range(cols*size):
            idx=(y//size)*cols+(x//size)
            local_y=y%size; local_x=x%size
            src_row = view_pixels[idx][local_y]
            j = local_x * 3
            row.extend(src_row[j:j+3])
        flat.append(row)
    out_path.write_bytes(_encode_pixels(flat, cols*size, rows*size))
    return out_path


def render_views(path: Path, out: Path | None = None, size: int = 512, yaw: float | None = None,
                 pitch: float | None = None, distance: float = 1.0) -> Path | None:
    """Render six canonical views, or one controllable custom view, of a 3D object."""
    path = Path(path)
    tris = triangles(path)
    if not tris:
        return render_external(path, out, size)
    pts = [p for tri in tris[:150_000] for p in tri]
    if not pts: return None
    mins = [min(p[i] for p in pts) for i in range(3)]
    maxs = [max(p[i] for p in pts) for i in range(3)]
    span = max(maxs[i]-mins[i] for i in range(3)) or 1.0
    center = tuple((mins[i]+maxs[i])/2 for i in range(3))
    out_path = Path(out or (core.DATA / "playground" / (path.stem + ".preview.png")))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if yaw is not None or pitch is not None:
        views=[(float(yaw or 0.0), float(pitch or 0.0))]
    else:
        views=[(0,0),(180,0),(90,0),(-90,0),(0,90),(0,-90)]
    pixels=[_render_one(tris,size,y,p,distance,center,span) for y,p in views]
    if len(pixels)==1:
        return _compose_views(pixels, out_path)
    return _compose_views(pixels, out_path)


def render(path: Path, out: Path | None = None, size: int = 512) -> Path | None:
    """Backward-compatible six-view renderer."""
    return render_views(path, out=out, size=size)


def _find_cad() -> str | None:
    for exe in ("FreeCADCmd", "freecadcmd", "FreeCAD"):
        p = shutil.which(exe)
        if p: return p
    # common Windows installations
    for base in (os.environ.get("ProgramFiles", ""), os.environ.get("ProgramFiles(x86)", "")):
        if not base: continue
        root = Path(base)
        for p in root.glob("FreeCAD*/bin/FreeCADCmd.exe"):
            return str(p)
        for p in root.glob("FreeCAD*/bin/FreeCAD.exe"):
            return str(p)
    return None


def render_external(path: Path, out: Path | None, size: int = 640):
    exe = _find_cad()
    if not exe or path.suffix.lower() not in {".step", ".stp"}:
        return None
    # FreeCAD can export a STEP to a mesh which we then render with our rasterizer.
    ensure_playground()
    tmp = PLAYGROUND / ("_preview_" + path.stem + ".stl")
    script = (
        "import FreeCAD as App, Part; "
        f"d=App.newDocument(); Part.insert(r'{str(path)}','*'); "
        f"objs=d.Objects; import Mesh; Mesh.export(objs,r'{str(tmp)}')"
    )
    # NO DEADLINE. A STEP file with a lot of geometry takes FreeCAD as long
    # as it takes, and 120 seconds was a guess about somebody else's machine
    # - the same guess that killed a video 25 minutes from the end and a
    # mesh at flow step 10 of 12. The duration is LOGGED instead, so the
    # next question ("how long does this actually take here") has an answer
    # made of measurements rather than of another guess.
    t0 = time.time()
    core.log_line("forge", f"FreeCAD: meshing {path.name} for a preview")
    try:
        r = subprocess.run([exe, "-c", script], capture_output=True)
        core.log_line("forge",
                      f"FreeCAD: {path.name} took {time.time() - t0:.0f}s, "
                      f"exit {r.returncode}, "
                      f"{'wrote' if tmp.exists() else 'wrote NO'} mesh")
        if tmp.exists(): return render(tmp, out, size)
    except Exception as e:
        core.log_line("forge",
                      f"FreeCAD: {path.name} failed after "
                      f"{time.time() - t0:.0f}s - {type(e).__name__}: {e}")
    return None


def preview_for(path: Path) -> Path | None:
    return render(Path(path))


def _write_obj(tris, dest: Path) -> bool:
    if not tris:
        return False
    verts = []
    faces = []
    for tri in tris:
        idxs = []
        for p in tri:
            verts.append(p)
            idxs.append(len(verts))
        faces.append(tuple(idxs))
    lines = ["# The Hub native mesh export\n"]
    for x, y, z in verts:
        lines.append(f"v {x:.9g} {y:.9g} {z:.9g}\n")
    for a, b, c in faces:
        lines.append(f"f {a} {b} {c}\n")
    dest.write_text("".join(lines), encoding="utf-8")
    return dest.exists()


def _write_ascii_stl(tris, dest: Path, name: str = "The HubMesh") -> bool:
    if not tris:
        return False
    lines = [f"solid {name}\n"]
    for tri in tris:
        lines += ["  facet normal 0 0 0\n", "    outer loop\n"]
        for x, y, z in tri:
            lines.append(f"      vertex {x:.9g} {y:.9g} {z:.9g}\n")
        lines += ["    endloop\n", "  endfacet\n"]
    lines.append(f"endsolid {name}\n")
    dest.write_text("".join(lines), encoding="utf-8")
    return dest.exists()


def _write_ply(tris, dest: Path) -> bool:
    if not tris:
        return False
    verts = [p for tri in tris for p in tri]
    lines = ["ply\n", "format ascii 1.0\n", f"element vertex {len(verts)}\n",
             "property float x\n", "property float y\n", "property float z\n",
             f"element face {len(tris)}\n", "property list uchar int vertex_indices\n", "end_header\n"]
    for p in verts:
        lines.append(f"{p[0]:.9g} {p[1]:.9g} {p[2]:.9g}\n")
    for i in range(0, len(verts), 3):
        lines.append(f"3 {i} {i+1} {i+2}\n")
    dest.write_text("".join(lines), encoding="utf-8")
    return dest.exists()


def _native_mesh_convert(src: Path, dest: Path) -> bool:
    tris = triangles(src)
    ext = dest.suffix.lower()
    if ext == ".obj": return _write_obj(tris, dest)
    if ext == ".stl": return _write_ascii_stl(tris, dest, src.stem)
    if ext == ".ply": return _write_ply(tris, dest)
    return False


def _trimesh_convert(src: Path, dest: Path) -> bool:
    scene = _load_trimesh(src)
    if scene is not None:
        try:
            if hasattr(scene, "export"):
                scene.export(dest, file_type=dest.suffix.lower().lstrip("."))
                if dest.exists():
                    return True
        except Exception:
            pass
    # Common mesh conversions should still work when trimesh is absent or
    # cannot load one particular file. The Hub already has parsers for STL/OBJ/
    # PLY/3MF, so use those before declaring a basic conversion impossible.
    return _native_mesh_convert(src, dest)


def _freecad_convert(src: Path, dest: Path) -> bool:
    exe = _find_cad()
    if not exe: return False
    script_path = PLAYGROUND / ("_convert_" + os.urandom(6).hex() + ".py")
    src_ext = src.suffix.lower()
    target_ext = dest.suffix.lower()
    script = [
        "import FreeCAD as App",
        "import Part, Mesh",
        "doc=App.newDocument('The HubConvert')",
        f"src=r'{str(src)}'",
        f"out=r'{str(dest)}'",
    ]
    if target_ext in {'.step', '.stp'} and src_ext in MESH_FORMATS:
        # A mesh has no native B-rep/NURBS semantics. Make a faceted shell/compound
        # in FreeCAD so conversion is honest: the resulting STEP preserves the
        # visible faceted geometry, not imaginary smooth CAD surfaces.
        script += [
            f"tris={json.dumps(triangles(src))}",
            "faces=[]",
            "for tri in tris:",
            "    try:",
            "        pts=[App.Vector(*p) for p in tri]",
            "        wire=Part.makePolygon(pts+[pts[0]])",
            "        faces.append(Part.Face(wire))",
            "    except Exception: pass",
            "shape=Part.makeCompound(faces)",
            "obj=doc.addObject('PartDesign::Feature','ConvertedMesh')",
            "obj.Shape=shape",
            "doc.recompute()",
            "Part.export([obj],out)",
        ]
    else:
        script += [
            f"Part.insert(src,'*')",
            "objs=list(doc.Objects)",
            "doc.recompute()",
            "ext=out.lower().rsplit('.',1)[-1]",
            "if ext in ('stl','obj','ply','3mf'): Mesh.export(objs,out)",
            "elif ext in ('step','stp'): Part.export(objs,out)",
            "else: raise RuntimeError('unsupported FreeCAD target')",
        ]
    script = "\n".join(script) + "\n"
    script_path.write_text(script, encoding="utf-8")
    # NO DEADLINE, same reason, and the same log line so a slow conversion
    # is a measured fact instead of a mystery followed by a guess.
    t0 = time.time()
    core.log_line("forge", f"FreeCAD: converting to {dest.name}")
    try:
        r = subprocess.run([exe, str(script_path)], capture_output=True)
        core.log_line("forge",
                      f"FreeCAD: {dest.name} took {time.time() - t0:.0f}s, "
                      f"exit {r.returncode}, "
                      f"{'wrote' if dest.exists() else 'wrote NO'} file")
        return r.returncode == 0 and dest.exists()
    finally:
        try: script_path.unlink()
        except Exception: pass


def convert(src: Path, target_ext: str) -> dict:
    """Convert a vault file into the playground; never overwrite vault."""
    src = Path(src); target_ext = target_ext.lower().strip()
    if not target_ext.startswith("."): target_ext = "." + target_ext
    if target_ext not in SUPPORTED and target_ext.lstrip(".") not in {x.lstrip(".") for x in TEXTISH}:
        raise ValueError(f"unsupported target format: {target_ext}")
    ensure_playground()
    dest = _unique(PLAYGROUND / _safe_name(src.stem + target_ext))
    ok = False
    if target_ext in MESH_FORMATS and src.suffix.lower() in MESH_FORMATS:
        ok = _trimesh_convert(src, dest)
        if not ok:
            raise RuntimeError("No local mesh conversion path succeeded for this file")
    elif target_ext in {".step", ".stp"} or src.suffix.lower() in {".step", ".stp"}:
        ok = _freecad_convert(src, dest)
        if not ok:
            raise RuntimeError("STEP conversion needs a local FreeCAD/FreeCADCmd installation")
    elif src.suffix.lower() in TEXTISH and target_ext in TEXTISH:
        dest.write_bytes(src.read_bytes()); ok = True
    if not ok:
        raise RuntimeError(f"no safe local converter for {src.suffix} -> {target_ext}")
    return {"ok": True, "name": str(dest.relative_to(PLAYGROUND)).replace("\\", "/"),
            "path": str(dest), "from": src.name, "to": target_ext}


def save_to_vault(name: str, vault_root: Path) -> dict:
    src = resolve_playground(name)
    if src is None: raise FileNotFoundError(name)
    vault_root = Path(vault_root).resolve(); vault_root.mkdir(parents=True, exist_ok=True)
    dest = _unique(vault_root / _safe_name(src.name))
    shutil.copy2(src, dest)
    return {"ok": True, "name": str(dest.relative_to(vault_root)).replace("\\", "/")}
