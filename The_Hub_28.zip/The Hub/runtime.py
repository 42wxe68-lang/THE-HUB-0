"""
runtime.py - owns every llama-server.exe process The Hub starts.

Two models, deliberately separated:

  MAIN     port 8090   GPU, long-lived    Nova. What the user talks to.
  CURATOR  port 8091   CPU ONLY, ad hoc   The background memory model.
  EARS     port 8092   CPU ONLY           whisper.cpp.

The curator is never given -ngl. It cannot touch VRAM, so it cannot slow
Nova down and cannot contribute to the memory overcommit that froze this
machine during early testing. It spawns, serves one batch, and exits.

This is the only module in The Hub that starts a process. argv is built
here from clamped numeric values; shell=False means there is no shell to
inject into. No string from the model, the network, or the browser ever
reaches the command line.

WHAT CHANGED FROM CAIRN, AND WHY IT MATTERS MORE THAN IT LOOKS
--------------------------------------------------------------
1. THE PORTS ARE HUB'S OWN.
   Cairn holds 8080/8081/8082. Sharing them would mean whichever started
   second silently failed to bind, or worse, talked to the other one's
   model.

2. ORPHANS ARE SWEPT BY PORT, NEVER BY IMAGE NAME.
   Cairn's server.py did `taskkill /F /IM llama-server.exe` on startup. On
   a machine where both applications exist, that is The Hub reaching over
   and killing Cairn's model mid-sentence. Here the sweep finds the PID
   listening on The Hub's own port and kills only that, after checking the
   image name matches. Nothing outside this application is ever touched.

3. A MODEL THAT WILL NOT FIT IS MADE TO FIT, NEVER REFUSED.
   16 GB of RAM and 4 GB of VRAM is a real ceiling, and it is TWO ceilings.
   Loading past either does not produce an error: RAM overcommit makes
   Windows swap, and VRAM overcommit makes the NVIDIA driver page the card
   over PCIe into system memory - silently, since driver 536.40 - which
   pins the GPU at full board power for as long as it lasts. Neither
   raises. Both cost a hard reset on a machine with no battery.

   So plan() budgets both, in the order the machine cares about: the
   WEIGHTS go under the ceiling first, by choosing a real -ngl and sending
   it, and then the WINDOW is fitted inside whatever that left. The model
   the user chose always starts. What changes is how much of it sits on the
   card and how wide its context is - both announced, both overridable.
"""
from __future__ import annotations

import json
import pathlib
import re
import subprocess
import threading
import time
import urllib.error
import urllib.request
import uuid

import core
import events
import gguf

MAIN_PORT = core.MAIN_PORT
CUR_PORT = core.CURATOR_PORT
EAR_PORT = core.EAR_PORT
MAIN = f"http://127.0.0.1:{MAIN_PORT}"

# How long post() will ride out a model reload before giving up. Long enough
# to cover a full load on this hardware; short enough that a genuinely dead
# server is still reported as dead rather than hanging a turn forever.
RELOAD_GRACE = 240.0
CUR = f"http://127.0.0.1:{CUR_PORT}"
EAR = f"http://127.0.0.1:{EAR_PORT}"

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_proc = None
_log = None
_lock = threading.RLock()
_status, _detail, _model = "stopped", "", None
_rt = {}          # the resolved runtime settings of the live model
_corrected = False   # one offload correction per start(); see _correct_offload
_vram = None
_advisory = ""
_stream = None


def _set(status: str, detail: str = "") -> None:
    global _status, _detail
    with _lock:
        _status, _detail = status, detail


def set_advisory(text: str) -> None:
    global _advisory
    with _lock:
        _advisory = text or ""


def state() -> dict:
    with _lock:
        return {
            "status": _status,
            "detail": _detail,
            "model": _model,
            "advisory": _advisory,
            "running": _proc is not None and _proc.poll() is None,
        }


def _clamp(v, lo, hi, dflt):
    try:
        return max(lo, min(hi, int(v)))
    except (TypeError, ValueError):
        return dflt


# ---------------------------------------------------------------- http

def post(base: str, path: str, payload: dict, timeout: int = 900):
    """
    POST to a local model server, waiting out a reload rather than failing it.

    503 from llama-server means "loading", not "broken". It happens whenever
    the model is coming back up - after a model switch, and after a generator
    has borrowed the card. A turn that was in flight at that moment used to
    die with `Error: HTTP Error 503: Service Unavailable` even though nothing
    had actually gone wrong and the model was seconds away from serving.

    forge.Session now waits for the model before handing control back, so
    this should rarely fire. It stays because "the server is still starting"
    is a condition with an obvious correct response - wait for it - and
    turning that into a failed reply is a choice nobody would make
    deliberately.
    """
    req = urllib.request.Request(
        base + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    deadline = time.time() + RELOAD_GRACE
    while True:
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError as e:
            if e.code != 503 or time.time() >= deadline:
                raise
            core.log_line("runtime",
                          "model is still loading (503) - waiting rather "
                          "than failing the turn")
            time.sleep(1.0)
            # A urllib Request cannot be replayed after a failure; rebuild it.
            req = urllib.request.Request(
                base + path,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
        except urllib.error.URLError:
            # Connection refused during the gap between stop and listen.
            if time.time() >= deadline:
                raise
            time.sleep(1.0)
            req = urllib.request.Request(
                base + path,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )


def health(base: str = MAIN, t: float = 1.5) -> bool:
    try:
        with urllib.request.urlopen(base + "/health", timeout=t) as r:
            return json.loads(r.read().decode()).get("status") == "ok"
    except Exception:
        return False


# ---------------------------------------------------------------- argv

def _argv(model_path, port: int, rt: dict, gpu: bool) -> list:
    a = [
        str(core.LLAMA_EXE),
        "-m", str(model_path),
        "--host", "127.0.0.1",
        "--port", str(port),
        # Resolved before launch by start(); by the time argv is built this
        # is a real number, never "auto".
        "-c", str(_clamp(rt.get("n_ctx"), 512, 131072, 8192)),
        "-t", str(_clamp(rt.get("threads"), 1, 32, 6)),
        "--parallel", str(_clamp(rt.get("parallel"), 1, 8, 1)),
        "--jinja",
    ]
    # KV cache type. f16 unless the config says otherwise, and the config
    # says otherwise only when somebody has measured it on this build: if
    # b10456 lacks a CUDA kernel for the quantised type, attention falls
    # back to the CPU with no error and generation halves in speed.
    kv = str(rt.get("kv_type") or "f16").strip().lower()
    if kv in ("q8_0", "q4_0", "q5_0", "f16", "bf16"):
        a += ["--cache-type-k", kv, "--cache-type-v", kv]
    # Vision. A VL model needs its multimodal projector alongside the weights.
    # Both live in llm/models and are validated against the directory scan, so
    # a bad config value cannot point the process at an arbitrary file.
    # SIGHT. Found on disk, not typed into a settings box.
    #
    # Two things were wrong here. It required a filename someone had to know
    # to enter, so the flag was never passed and no projector ever loaded -
    # which is why /props always said no vision and the honest answer to
    # "why doesn't vision work" was an empty text field.
    #
    # And it was gated on `gpu`. Multimodal does not need a GPU;
    # --no-mmproj-offload exists precisely for the case where the card is
    # full. Gated this way, a CPU-only machine could never see at all.
    # The physical batch. This is the peak-power knob: prefill runs one
    # ubatch at a time, so halving it halves the largest single thing the GPU
    # is asked to do and the compute buffer that holds it. It costs some
    # prompt-processing speed and nothing else - no capability, no context, no
    # quality. On a machine drawing from an adapter with no battery behind it,
    # that is a good trade and it is the user's to make in settings.
    ub = _clamp(rt.get("n_ubatch"), 32, 4096, UBATCH_DEFAULT)
    a += ["-ub", str(ub), "-b", str(max(ub, _clamp(rt.get("n_batch"),
                                                   32, 8192, 2048)))]
    # SIGHT belongs to the main model. The curator is CPU-only by
    # construction - it is never given -ngl so it cannot contend for the card
    # - and handing it a projector would have quietly undone that, because
    # llama.cpp offloads a projector to the GPU unless told not to.
    if gpu:
        try:
            import vision
            mp = pathlib.Path(str(model_path))
            # ONE number, worked out by plan() against the same ceiling the
            # model was fitted to - including the first-load safety share, so
            # the projector cannot quietly spend the margin that exists to
            # keep the machine on.
            a += vision.projector_args(
                mp, float(rt.get("_card_free_mb")
                          if rt.get("_card_free_mb") is not None else -1.0))
        except Exception as e:
            core.log_line("runtime", f"projector search failed: {e}")
        ngl = rt.get("n_gpu_layers", "auto")
        # THIS IS THE NUMBER plan() WORKED OUT, AND IT IS SENT.
        #
        # It used to be omitted whenever the setting said "auto", on the
        # belief that llama.cpp would then size the offload to real free VRAM.
        # It does not. In b10456, llama_model::n_gpu_layers() returns
        # `params.n_gpu_layers >= 0 ? params.n_gpu_layers : n_layer_all + 1` -
        # no VRAM is consulted anywhere on that path, so the default and
        # -ngl 99 are the same instruction: put everything on the card.
        #
        # plan() replaces "auto" with an integer whenever it can measure the
        # card. "auto" surviving to here means it could not - no nvidia-smi,
        # or an unreadable header - and in that case omitting the flag is
        # still right, because the honest response to an unmeasured machine is
        # not to start guessing at it.
        if not (isinstance(ngl, str)
                and ngl.strip().lower() in ("auto", "all")):
            a += ["-ngl", str(_clamp(ngl, 0, 999, 99))]
    return a


# ---------------------------------------------------------------- main

_bench = {}


def benchmark() -> dict:
    """
    Measure the model that is actually loaded, on this machine, right now.

    Ordered deliberately: the machine is measured first (available_mb), then
    the model is loaded, then it is benchmarked, and only THEN is headroom
    checked - because how much room is left is a question about a running
    model, not a prediction about a file on disk.

    What comes out is real: tokens per second, the context the server
    actually granted, and how much memory remained once it settled. That last
    number is what decides whether memory work can run at all.
    """
    global _bench
    out = {"when": time.strftime("%F %T")}
    try:
        with urllib.request.urlopen(MAIN + "/props", timeout=8) as r:
            props = json.loads(r.read().decode())
        out["n_ctx"] = (props.get("default_generation_settings") or {}).get(
            "n_ctx") or props.get("n_ctx") or 0
    except Exception:
        out["n_ctx"] = 0

    try:
        t0 = time.time()
        r = post(MAIN, "/v1/chat/completions", {
            "messages": [{"role": "user",
                          "content": "Count from one to twenty in words."}],
            "max_tokens": 64, "temperature": 0.0, "stream": False,
        }, timeout=180)
        d = json.loads(r.read().decode())
        dt = max(0.001, time.time() - t0)
        usage = d.get("usage") or {}
        gen = int(usage.get("completion_tokens") or 0)
        out["gen_tok_s"] = round(gen / dt, 1) if gen else 0.0
        out["first_reply_s"] = round(dt, 2)
    except Exception as e:
        out["error"] = str(e)[:160]

    # Can this model see? Probed, not declared - the same reason the
    # context window is measured rather than trusted. A model without
    # vision handed an image does not error, it invents a description.
    try:
        import vision
        out["vision"] = vision.probe(MAIN, core.under(core.MODELS, _model or ""))
    except Exception as e:
        out["vision"] = {"sees": False, "why": str(e)[:80]}

    # Headroom, measured while the model is up and settled.
    out["free_mb"] = round(available_mb())
    out["vram_free_mb"] = round(vram_free_mb())
    # Memory work reuses this same model, so it needs no weights of its own -
    # only room for one more short request. That is why removing the second
    # model mattered: the old curator needed its own 350 MB and a spare core
    # on a machine that had neither.
    # Whether background memory work is AFFORDABLE on this machine with this
    # model. Measured, not assumed - and it is a question about generation
    # SPEED as much as memory. Organising a day of conversation is several
    # short generations; at 3 tokens a second on a 9B that is minutes of the
    # machine being busy, and on a laptop already near its memory ceiling
    # that is what turns "slow" into "unresponsive".
    #
    # This value used to be computed and then never read.
    tok_s = out.get("gen_tok_s") or 0.0
    room = out["free_mb"] < 0 or out["free_mb"] > 800
    quick = tok_s <= 0 or tok_s >= 6.0
    out["can_consolidate"] = bool(room and quick)
    if not out["can_consolidate"]:
        out["consolidate_why"] = (
            f"background memory work is off: {tok_s:.1f} tok/s and "
            f"{out['free_mb']:.0f} MB free. It would compete with your "
            f"replies. Memory still records everything and search still "
            f"works; only the summarising pass is skipped.")
    _bench = out
    core.log_line("runtime", f"{out['when']} benchmark {out}")
    return out


def bench() -> dict:
    return dict(_bench)


def _warm() -> None:
    """
    The first request after a cold launch pays a one-time CUDA kernel load,
    measured at ~12.5s on a GTX 1650. Spend it here during startup so the
    user never sees it on their first message.
    """
    try:
        post(MAIN, "/v1/chat/completions", {
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 1, "temperature": 0,
        }, timeout=300).read()
    except Exception:
        pass


# THE RAMP.
#
# Bringing a model up used to be four heavy things back to back inside about
# fifteen seconds: the load itself, a warm-up generation, a vision probe, and
# a benchmark. Each one takes the card from idle to full in well under a
# second, and the machine has no battery to flatten what the adapter cannot
# follow. Two of the three recorded resets landed inside that window.
#
# So there is a pause between them. It is not a timeout and nothing fails for
# taking longer - it is the opposite of a timeout. The model is coming up
# either way; this only decides whether it arrives as one continuous demand or
# as four separated ones.
SETTLE_S = 2.5


def _bring_up(deadline: int = 300) -> None:
    t0 = time.time()
    while time.time() - t0 < deadline:
        if _proc is None or _proc.poll() is not None:
            return _set("error", "llama-server exited - see data/logs/llama.log")
        if health():
            break
        time.sleep(0.5)
    else:
        return _set("error", "timed out starting llama-server")

    # llama-server has just printed what it really allocated. Read it while it
    # is the newest thing in the log, and the next load of this model budgets
    # from a measurement instead of an estimate.
    report = {}
    try:
        report = learn_from_log(_model or "", _rt or {})
    except Exception:
        pass
    forget_vram()          # the card is occupied now; the old reading is void

    # THE PLAN, CHECKED AGAINST WHAT THE PROCESS ACTUALLY DID.
    #
    # Everything before this point was arithmetic on a header plus an estimate
    # of the buffers. llama-server has now stated what it really allocated, and
    # it stated it BEFORE the sustained compute that costs the machine. If the
    # budget was wrong, this is the moment it is cheap to say so.
    try:
        if _correct_offload(report):
            return
    except Exception as e:
        core.log_line("runtime", f"refit check failed: {e}")

    time.sleep(SETTLE_S)
    _set("warming", "loading kernels")
    _warm()
    time.sleep(SETTLE_S)
    # The model changed, so anything the old one implied about sight is stale.
    # Vision belongs to this one loaded model; there is no helper model.
    try:
        import vision
        vision.probe(MAIN, core.under(core.MODELS, _model or ""))
    except Exception as e:
        core.log_line("runtime", f"vision probe failed: {e}")
    if state()["status"] != "error":
        time.sleep(SETTLE_S)
        _set("measuring", "benchmarking the loaded model")
        try:
            benchmark()
        except Exception:
            pass
        _set("ready")


def available_mb() -> float:
    """
    Free physical memory in MB, or -1 if it cannot be determined.

    "Available MBytes" is the counter that matters, not
    FreePhysicalMemory: a large mmap'd model floods the standby list, which
    is reclaimable but reads as "used", so the naive counter shows a machine
    with room to spare as having none.
    """
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        st = MS()
        st.dwLength = ctypes.sizeof(MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            return st.ullAvailPhys / 1048576.0
    except Exception:
        pass
    try:
        with open("/proc/meminfo") as f:            # for tests off Windows
            for line in f:
                if line.startswith("MemAvailable:"):
                    return float(line.split()[1]) / 1024.0
    except Exception:
        pass
    return -1.0


VRAM_TTL = 2.0             # seconds a reading stays good for
_vram_at = 0.0


def forget_vram() -> None:
    """
    Drop the cached reading. Called whenever the card's occupancy changes.

    This exists because the old cache was permanent. One nvidia-smi call, made
    before llama-server started, answered every question for the life of the
    process - so plan() believed the card was empty on every reload, after
    every image generation, and after every model switch, for nine days and
    122 benchmarks that all recorded the identical 3938 MB. A number that
    never changes is not a measurement.
    """
    global _vram, _vram_at
    _vram, _vram_at = None, 0.0


def vram_free_mb() -> float:
    """
    Free VRAM in MB, or -1.

    Held for VRAM_TTL seconds, not forever. The reading costs about 200 ms and
    plan() is called seven or eight times inside one binary search, so a
    cache is necessary; what is not necessary is keeping it across the event
    that changes the answer.
    """
    global _vram, _vram_at
    if _vram is not None and (time.time() - _vram_at) < VRAM_TTL:
        return _vram
    _vram_at = time.time()
    _vram = -1.0
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=memory.free",
                            "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=10, shell=False)
        if r.returncode == 0 and r.stdout.strip():
            _vram = float(r.stdout.strip().splitlines()[0].strip())
    except Exception:
        pass
    return _vram


# llama.cpp mmaps the weights. Those pages are file-backed, so under memory
# pressure Windows reclaims them rather than swapping or failing - which is
# exactly why "Available MBytes" is the counter that matters and
# FreePhysicalMemory is not: a large mmap'd model floods the standby list,
# which reads as used and is reclaimable on demand.
#
# So counting the whole file against available RAM is wrong. Measured on the
# target machine: an 11.3 GB model with ~2.3 GB offloaded to a 4 GB card runs
# with 9.3 GB free and settles at ~1.7 GB still available. The naive sum said
# it needed 13.1 GB and would have refused a model that demonstrably works.
MMAP_RESIDENT = 0.55       # fraction of host-side weights held resident
PROCESS_OVERHEAD_MB = 700  # llama-server itself, compute buffers, CUDA context
CTX_FLOOR = 2048           # below this a conversation stops being useful
HEADROOM_MB = 600          # left free so the curator can still spawn


# ═══════════════════════════════════════════════════════════════════════════
# THE SECOND CEILING
# ═══════════════════════════════════════════════════════════════════════════
#
# The docstring at the top of this file has said since Cairn that "16 GB of
# RAM and 4 GB of VRAM is a real ceiling". Only the first half was ever
# checked. plan() worked out `gpu_mb` - how much of the model it expected the
# card to hold - used it as a SUBTRACTION in the host-RAM sum, and then threw
# it away. It never reached the process, and nothing ever asked whether the
# card could hold it.
#
# Meanwhile _argv omitted -ngl on "auto", on the belief that llama.cpp would
# size the offload to free VRAM itself. It does not. In the pinned build,
# b10456:
#
#     uint32_t llama_model::n_gpu_layers() const {
#         return params.n_gpu_layers >= 0 ? params.n_gpu_layers
#                                         : hparams.n_layer_all + 1;
#     }
#
# There is no VRAM query on that path. "auto" is a label on the default, not
# a measurement, and omitting -ngl is identical to -ngl 99: every layer.
#
# That used to fail loudly, which is why plan() could reasonably say "start it
# and let llama.cpp tell you". NVIDIA driver 536.40 ended that. System Memory
# Fallback is on by default, so an over-subscribed card does not raise - the
# driver pages VRAM over PCIe into system RAM and carries on. Nothing errors.
# What happens instead is that the GPU stops idling between tokens and sits at
# full board power servicing page faults, indefinitely, while generation runs
# slower than not using the card at all.
#
# On a laptop with no battery there is nothing to absorb that. The failure is
# not a crash; it is the machine going off, with BugcheckCode 0 - no bugcheck,
# the rail simply went away.
#
# So the card gets a budget, and the budget gets sent. What follows is the
# same two-stage shape plan() already had for RAM, applied where it was
# missing: fit the WEIGHTS under the ceiling first, then fit the WINDOW inside
# what is left. There is still no refusal path.

VRAM_RESERVE_MB = 400      # this card also draws the desktop
CUDA_CONTEXT_MB = 300      # the CUDA runtime's own footprint in the process
COMPUTE_BUFFER_MB = 260    # graph scratch at ubatch 512, until it is measured
UBATCH_DEFAULT = 512       # llama.cpp's own default physical batch
UBATCH_GENTLE = 256        # the low-power setting: half the prefill peak

# THE FIRST LOAD IS THE ONE WITH NOTHING BEHIND IT.
#
# Everything above except VRAM_RESERVE_MB is an estimate, and the first time a
# model is loaded there is no measurement to replace it - the report that
# corrects it does not exist until a load has produced one. Build 27 packed
# the card to within 60 MB of the ceiling on that estimate, and the first load
# took the machine down. The second, budgeted from the measurement the first
# one left behind, was fine and ran an image generation straight afterwards.
#
# The costs are not symmetric. Being cautious costs one slower load. Being
# wrong costs a hard reset. So an UNMEASURED model is offered a fraction of
# the card, and the measurement it produces takes the fraction away.
#
# This is learning from the past without being held back by it: the penalty
# attaches to not knowing, never to having failed. One real measurement and
# it is gone, whatever happened before.
FIRST_LOAD_SHARE = 0.70    # of the usable ceiling, while this model is unmeasured
AFTER_RESET_SHARE = 0.55   # and the machine's last boot followed a power loss


# ---------------------------------------------------------------- measured

# WHAT ACTUALLY HAPPENED LAST TIME BEATS WHAT WE PREDICTED.
#
# The two numbers above are estimates, and this project has a rule about
# estimates: "This should never be timed for 'how long it should take', only
# for how long it has taken in the past." The same applies to memory.
#
# llama-server states its real allocations on stdout, and stdout is already
# teed to data/logs/llama.log. After a load we read what it said and keep it,
# so the next load budgets from measurement instead of a guess - and the
# per-layer cost comes out of the same reading rather than from prorating a
# file size that includes tensors which never leave the CPU.

_BUF = re.compile(r"([A-Za-z0-9_]+)\s+(model|KV|compute|output)\s+buffer size"
                  r"\s*=\s*([0-9.]+)\s*MiB")
_OFFLOADED = re.compile(r"offloaded\s+(\d+)\s*/\s*(\d+)\s+layers")


def _memo_file():
    return core.LOGS / "fit.json"


def memo(model_name: str = None) -> dict:
    """What the last successful load of this model actually cost. {} if none."""
    try:
        with _memo_file().open(encoding="utf-8") as f:
            all_of_it = json.load(f)
        return all_of_it if model_name is None else (all_of_it.get(model_name) or {})
    except Exception:
        return {}


# ------------------------------------------------- what happened last time

# WHEN THE MACHINE GOES OFF, THE APPLICATION IS THE ONLY THING THAT DOES NOT
# FIND OUT.
#
# A hard reset takes the process with it. Nothing is written, no exception is
# raised, and the next launch starts clean and cheerful with no idea that the
# last session ended with the lights going out. The user is left holding the
# only copy of that information, and answering "did it crash?" from memory.
#
# Windows knows. It writes Kernel-Power event 41 on the next boot, and the
# event says which kind of ending it was:
#
#   BugcheckCode 0   no bugcheck. Nothing crashed. The power went away.
#   BugcheckCode !0  a stop error - a real software or driver fault.
#
# That distinction is the whole diagnosis and it costs one command to read.
_POWER = None
_PW_TIME = re.compile(r'SystemTime=[\'"]([^\'"]+)')
_PW_CODE = re.compile(r"BugcheckCode[\'\"]?>?\s*(\d+)")


def last_power_loss(refresh: bool = False) -> dict:
    """
    The most recent unexpected shutdown Windows recorded, or {}.

    {"when": ISO time, "bugcheck": int, "kind": "power"|"stop error"}

    Read once per process: it is a fact about the last boot and cannot change
    while this one is running.
    """
    global _POWER
    if _POWER is not None and not refresh:
        return _POWER
    _POWER = {}
    try:
        r = subprocess.run(
            ["wevtutil", "qe", "System",
             "/q:*[System[(EventID=41)]]", "/c:1", "/rd:true", "/f:xml"],
            capture_output=True, text=True, timeout=20, shell=False)
        xml = (r.stdout or "").strip()
        if r.returncode == 0 and xml:
            when = _PW_TIME.search(xml)
            code = _PW_CODE.search(xml)
            bug = int(code.group(1)) if code else 0
            _POWER = {"when": when.group(1) if when else "",
                      "bugcheck": bug,
                      "kind": "stop error" if bug else "power"}
    except Exception:
        pass
    return _POWER


def overrun_mb(report: dict, planned_against: float = 0.0) -> float:
    """
    How far past the card's usable ceiling this load actually went. 0 if none.

    TWO INDEPENDENT SIGNALS, because one of them can be missing.

      1. The process's own report. Weights, cache and buffers on the card,
         against the ceiling plan() budgeted from. This is exact, and it is
         available before a single token has been generated.

      2. What the card says now. If free VRAM has dropped below the display
         reserve, the desktop is being squeezed whatever any arithmetic
         claims - and a spilled card on Windows does not raise, it just goes
         quiet and draws full power until something gives.

    Either one is enough. The estimate that got us here was allowed to be
    wrong; what is not allowed is carrying on as though it were right.
    """
    worst = 0.0
    total = float((report or {}).get("card_total_mb") or 0.0)
    if total and planned_against > 0:
        worst = max(worst, total - (planned_against - VRAM_RESERVE_MB))
    now = vram_free_mb()
    if now >= 0:
        worst = max(worst, VRAM_RESERVE_MB - now)
    return max(0.0, worst)


def _correct_offload(report: dict) -> bool:
    """
    Lower -ngl and load again, ONCE, before anything heavy runs.

    The window that takes the machine down is not the load - it is the
    sustained compute just after it: the warm-up, the vision probe, the
    benchmark. llama-server states what it allocated *during* the load, so
    there is a gap between finding out the budget was wrong and paying for it.
    This is that gap being used.

    One correction per start(). A budget that can restart itself twice is a
    boot loop, and this project has a rule about becoming the reason something
    stops.
    """
    global _corrected
    if _corrected:
        return False
    over = overrun_mb(report, float((_rt or {}).get("_vram_free_mb") or 0.0))
    if over <= 0:
        return False
    _corrected = True
    core.log_line("runtime",
                  f"the card is {over:.0f} MB over what was budgeted for it - "
                  f"loading again with fewer layers before anything runs")
    events.write("runtime.refit", model=_model, over_mb=round(over, 1),
                 report=report)
    cfg = dict(core.load().get("runtime") or {})
    # The measurement this load produced is already filed, so plan() will use
    # it. Nothing is hand-adjusted here: it is asked again, better informed.
    set_advisory(f"The first load of {_model} put {over:.0f} MB more on the "
                 f"graphics card than was budgeted for it. Loading again with "
                 f"fewer layers, measured this time rather than estimated.")
    threading.Thread(target=lambda: start(_model, cfg), daemon=True).start()
    return True


def fit_state() -> dict:
    """
    What the budget decided for the model that is running, in plain numbers.

    A limiter nobody can see is indistinguishable from one that is not
    working, which is how this one went thirteen releases without anyone
    noticing it never sent its answer anywhere.
    """
    rt = dict(_rt or {})
    ngl = rt.get("n_gpu_layers")
    return {
        "layers_on_card": ngl if isinstance(ngl, int) else None,
        "layers_setting": ngl if isinstance(ngl, str) else None,
        "claimed_mb": rt.get("_card_claimed_mb"),
        "vram_free_mb": rt.get("_vram_free_mb"),
        "n_ctx": rt.get("n_ctx"),
        "n_ubatch": rt.get("n_ubatch", UBATCH_DEFAULT),
        "measured": memo(_model or ""),
        "power": last_power_loss(),
        "power_note": power_note(),
    }


def power_note() -> str:
    """One plain sentence about the last reset, or "" if there was not one."""
    p = last_power_loss()
    if not p:
        return ""
    when = (p.get("when") or "").replace("T", " ")[:19] or "at some point"
    if p["kind"] == "power":
        return (f"The last time this machine stopped, at {when} UTC, it was "
                f"not a crash - Windows recorded no bugcheck, which means the "
                f"power went away rather than something failing. The model now "
                f"loads with a measured share of the card instead of all of "
                f"it, which is the part of that this application controls.")
    return (f"Windows recorded a stop error (bugcheck {p['bugcheck']}) at "
            f"{when} UTC. That is a software or driver fault rather than a "
            f"power loss, and it is worth reading in Event Viewer.")


def _on_gpu(device: str) -> bool:
    """CUDA0 is the card. CUDA_Host is pinned system RAM, which is not."""
    d = device.upper()
    return d.startswith(("CUDA", "ROCM", "HIP", "VULKAN", "SYCL")) \
        and "HOST" not in d


def read_load_report(text: str) -> dict:
    """
    Pull the real allocation out of one llama-server startup log.

    Returns {} when the log does not contain a complete report, which is the
    normal case for a load that failed - and a failed load must not be allowed
    to teach the budget anything.
    """
    on_card = host = overhead = card_total = 0.0
    ngl = total = 0
    seen = False
    for line in text.splitlines():
        m = _OFFLOADED.search(line)
        if m:
            ngl, total = int(m.group(1)), int(m.group(2))
        m = _BUF.search(line)
        if not m:
            continue
        dev, kind, mb = m.group(1), m.group(2), float(m.group(3))
        if _on_gpu(dev):
            card_total += mb
        if kind == "model":
            seen = True
            if _on_gpu(dev):
                on_card += mb
            else:
                host += mb
        elif _on_gpu(dev):
            # KV, compute and output buffers on the card. KV we can compute
            # from the header; compute and output we cannot, so they are the
            # part worth remembering.
            if kind in ("compute", "output"):
                overhead += mb
    if not seen:
        return {}
    return {"on_card_mb": round(on_card, 1), "host_mb": round(host, 1),
            "overhead_mb": round(overhead, 1), "ngl": ngl, "layers": total,
            # Everything the process put on the card: weights, cache and
            # buffers together. This is the number to compare against what
            # plan() thought it was spending, and the only honest way to find
            # out whether the budget was right.
            "card_total_mb": round(card_total, 1)}


def learn_from_log(model_name: str, rt: dict) -> dict:
    """
    Read the last load out of llama.log and remember what it cost.

    Only the tail after the most recent session header is read, so an older
    load of a different model cannot be mistaken for this one.
    """
    try:
        p = core.LOGS / "llama.log"
        if not p.is_file():
            return {}
        raw = p.read_text(encoding="utf-8", errors="replace")
        head = raw.rfind("===== ")
        report = read_load_report(raw[head:] if head >= 0 else raw)
        if not report or not report.get("ngl"):
            return {}
        report["n_ctx"] = int(rt.get("n_ctx") or 0)
        report["kv_type"] = str(rt.get("kv_type") or "f16")
        report["n_ubatch"] = int(rt.get("n_ubatch") or UBATCH_DEFAULT)
        report["when"] = time.strftime("%F %T")
        if report["ngl"]:
            report["mb_per_layer"] = round(report["on_card_mb"] / report["ngl"], 2)
        core.LOGS.mkdir(parents=True, exist_ok=True)
        book = memo()
        book[model_name] = report
        tmp = _memo_file().with_suffix(".tmp")
        tmp.write_text(json.dumps(book, indent=2), encoding="utf-8")
        tmp.replace(_memo_file())
        core.log_line("runtime",
                      f"measured {model_name}: {report['on_card_mb']:.0f} MB of "
                      f"weights on the card over {report['ngl']} layers, "
                      f"{report['overhead_mb']:.0f} MB of buffers")
        return report
    except Exception as e:
        core.log_line("runtime", f"could not read the load report: {e}")
        return {}


def plan(model_name: str, rt: dict) -> tuple:
    """
    Work out how best to run the model the user chose. Returns (rt, advisory).

    THERE IS NO REFUSAL PATH, AND THAT IS DELIBERATE.

    An earlier version of this returned (ok, rt, note) and `start()` bailed
    out when ok was False. That was wrong twice over. It removed a capability
    Cairn had - Cairn loaded whatever you selected - so a model downloaded on
    purpose could become permanently unselectable, and the model dropdown
    became a list of suggestions this file was willing to honour. And the
    numbers doing the blocking were invented: MMAP_RESIDENT and the GPU share
    below are calibrated guesses, and a guess must never outrank a decision.

    llama.cpp is the thing that actually knows whether a model loads. It
    fails with a real error when it cannot. This function's job is to make
    the attempt as likely to succeed as possible and to say plainly what it
    expects - not to stand in front of the door.

    What it will do, governed by runtime.fit_policy:

        "adapt"  (default)  lower n_ctx so the chosen model fits, and say so
        "warn"              change nothing, say what is predicted
        "off"               say nothing

    Lowering the context keeps the model the user picked running, which is
    what they asked for. It is announced every time and it is reversible from
    settings. Nothing else is ever changed on their behalf.
    """
    rt = dict(rt or {})
    policy_mode = str(rt.get("fit_policy") or "adapt").lower()
    if policy_mode == "off":
        return rt, ""

    try:
        path = core.under(core.MODELS, model_name)
        weights_mb = path.stat().st_size / 1048576.0
    except Exception:
        return rt, ""

    want_ctx = _clamp(rt.get("n_ctx"), 512, 131072, 8192)
    kv_type = str(rt.get("kv_type") or "f16").lower()

    meta = gguf.read(path)
    if meta and meta.usable:
        kv_at = lambda c: meta.kv_mb(c, kv_type)
        detail = (f"{meta.layers} layers, {meta.kv_heads} kv heads, "
                  f"{meta.kv_bytes_per_token(kv_type)/1024:.0f} KB per token")
        if meta.train_ctx and want_ctx > meta.train_ctx:
            rt["n_ctx"] = want_ctx = meta.train_ctx
    else:
        per_tok_kb = 0.35 * max(1.0, (weights_mb / 1024.0) ** 0.5)
        kv_at = lambda c: per_tok_kb * c / 1024.0
        detail = "header unreadable, so this is an estimate from file size"

    ub = _clamp(rt.get("n_ubatch"), 32, 4096, UBATCH_DEFAULT)
    book = memo(model_name)
    known = bool(meta and meta.usable)
    # n_layer_all + 1: llama.cpp counts the output layer as offloadable too.
    layers_all = (meta.layers + 1) if known else 0

    # ═══════════════════════════════════════════════════════════════════
    # STAGE ONE - THE CARD. The weights go under the ceiling first.
    # ═══════════════════════════════════════════════════════════════════
    vram = vram_free_mb()
    asked_ngl = rt.get("n_gpu_layers", "auto")
    auto_ngl = isinstance(asked_ngl, str) and asked_ngl.strip().lower() == "auto"
    # COMPUTE WHAT IS COMPUTABLE; MEASURE WHAT IS NOT.
    #
    # The weights are computable: the GGUF's tensor table states where every
    # tensor sits, so what -ngl n puts on the card is exact arithmetic, not a
    # share of the file size. The compute and output buffers are not - they
    # depend on the build, the backend and the batch - so those are read out
    # of the last load's own report and only estimated until there is one.
    per_layer = weights_mb / layers_all if layers_all else 0.0
    measured = float(book.get("overhead_mb") or 0.0)
    if measured:
        # The buffers scale with the physical batch, so a measurement taken at
        # a different one is adjusted rather than discarded. The CUDA context
        # inside it does not scale, which is why only the part above a bare
        # context is moved.
        was_ub = float(book.get("n_ubatch") or UBATCH_DEFAULT) or UBATCH_DEFAULT
        scratch = max(0.0, measured - CUDA_CONTEXT_MB) * (ub / was_ub)
        buffers = CUDA_CONTEXT_MB + scratch
    else:
        buffers = CUDA_CONTEXT_MB + COMPUTE_BUFFER_MB * (ub / float(UBATCH_DEFAULT))

    def on_card(ngl: int) -> float:
        n = max(0, min(ngl, layers_all))
        exact = meta.weights_mb_on_card(n) if known else None
        return per_layer * n if exact is None else exact

    def card_kv(ngl: int, ctx: int) -> float:
        """The part of the cache that follows the offloaded layers."""
        if not known or not ngl:
            return 0.0
        return meta.kv_mb_layers(max(layers_all - ngl, 0), meta.layers,
                                 ctx, kv_type, ub)

    def card_need(ngl: int, ctx: int) -> float:
        if not ngl:
            return 0.0
        return on_card(ngl) + card_kv(ngl, ctx) + buffers

    vram_ceiling = (vram - VRAM_RESERVE_MB) if vram > 0 else 0.0
    # Until this model has produced one real load report, only a share of that
    # ceiling is offered - less again if the machine's last boot followed a
    # power loss. A measurement removes the share entirely; see FIRST_LOAD_SHARE.
    if vram_ceiling > 0 and not measured:
        share = AFTER_RESET_SHARE if (last_power_loss().get("kind") == "power") \
            else FIRST_LOAD_SHARE
        vram_ceiling *= share
    all_ngl = isinstance(asked_ngl, str) and asked_ngl.strip().lower() == "all"
    # No card, a header we could not read, or "all" - which is the one way to
    # ask for llama.cpp's own default back. An unmeasured machine is not one
    # to start guessing on, and a stated preference is not ours to overrule.
    settled = None if (vram <= 0 or not layers_all or all_ngl) else (
        None if auto_ngl else _clamp(asked_ngl, 0, 999, layers_all))

    def best_ngl(ctx: int):
        """
        The most layers this card can hold at this window.

        This is where "the model should always load in with this as the
        primary focus to stay under" is enforced, and it is a function of the
        window rather than a constant, because the cache follows the layers:
        a wider window means fewer layers fit, and moving a layer off the card
        takes its share of the cache with it.
        """
        if settled is not None or not auto_ngl or vram_ceiling <= 0 \
                or not layers_all:
            return settled
        n = 0
        while n < layers_all and card_need(n + 1, ctx) <= vram_ceiling:
            n += 1
        return n

    # ═══════════════════════════════════════════════════════════════════
    # STAGE TWO - THE WINDOW, inside whatever stage one left.
    # ═══════════════════════════════════════════════════════════════════
    avail = available_mb()
    advisory = float(rt.get("ram_budget_mb") or 0)
    # An advisory number written by the installer during one busy moment is
    # not a property of the machine, so what is free NOW wins when both exist.
    ceiling = avail if avail > 0 else advisory
    if ceiling <= 0 and vram_ceiling <= 0:
        return rt, ""

    def host_need(ctx: int, ngl) -> float:
        gpu_mb = on_card(ngl) if ngl else 0.0
        host_weights = max(0.0, weights_mb - gpu_mb) * MMAP_RESIDENT
        if known and ngl:
            # Exact: the cache of the layers that stayed behind. The old 0.45
            # multiplier was a guess standing in for this.
            kv = meta.kv_mb_layers(0, max(layers_all - ngl, 0), ctx, kv_type, ub)
        else:
            kv = kv_at(ctx)
            if gpu_mb > 0:
                kv *= 0.45
        return host_weights + kv + PROCESS_OVERHEAD_MB

    def over_host(ctx: int) -> bool:
        return ceiling > 0 and \
            host_need(ctx, best_ngl(ctx)) + HEADROOM_MB > ceiling

    def over_card(ctx: int) -> bool:
        # Only a stated -ngl can overrun the card; the automatic one is chosen
        # so that it cannot. This is the branch that catches a typed number.
        n = best_ngl(ctx)
        return bool(n) and vram_ceiling > 0 and card_need(n, ctx) > vram_ceiling

    def why(ctx: int) -> str:
        n = best_ngl(ctx)
        if over_card(ctx):
            return (f"about {card_need(n, ctx)/1024:.1f} GB on a card with "
                    f"{vram/1024:.1f} GB free")
        return (f"about {host_need(ctx, n)/1024:.1f} GB against "
                f"{ceiling/1024:.1f} GB of free memory")

    def settle(ctx: int) -> None:
        """Record the offload and the claim that go with the chosen window."""
        n = best_ngl(ctx)
        if n is None and settled is not None:
            n = settled
        if n is None:
            return
        rt["n_gpu_layers"] = n
        claimed = card_need(n, ctx)
        rt["_card_claimed_mb"] = round(claimed, 1)
        rt["_vram_free_mb"] = round(vram, 1)
        # What is left of the card INSIDE the budget - after the reserve and
        # after the first-load share. This is the only figure anything else is
        # allowed to spend from.
        rt["_card_free_mb"] = round(max(0.0, vram_ceiling - claimed), 1)

    if not (over_host(want_ctx) or over_card(want_ctx)):
        settle(want_ctx)
        return rt, ""                      # comfortable, nothing to say

    if policy_mode == "warn":
        settle(want_ctx)
        return rt, (
            f"Heads up: {model_name} at {want_ctx} tokens looks like "
            f"{why(want_ctx)}. Starting anyway because you chose it. If the "
            f"machine slows badly, lower n_ctx in settings. ({detail})")

    # "adapt": find the largest context that fits BOTH ceilings and use that.
    was = why(want_ctx)
    fitted = 0
    lo, hi = CTX_FLOOR, want_ctx
    while lo <= hi:
        mid = ((lo + hi) // 2) // 512 * 512 or 512
        if not (over_host(mid) or over_card(mid)):
            fitted, lo = mid, mid + 512
        else:
            hi = mid - 512

    if fitted >= CTX_FLOOR and fitted < want_ctx:
        rt["n_ctx"] = fitted
        settle(fitted)
        return rt, (
            f"{model_name} at {want_ctx} tokens needs {was}, so it is starting "
            f"with a {fitted}-token context instead. Change n_ctx in settings "
            f"to override, or set runtime.fit_policy to \"warn\" to be told and "
            f"left alone. ({detail})")

    # Even the floor is over budget. It still starts - it is the user's
    # machine and their model, and llama.cpp is what actually knows. What
    # this can do is be honest about what is likely, and be useful about it.
    # Down to the floor, not left at what was asked for. This branch used to
    # recompute the number it already had - min(want_ctx, want_ctx) - so on
    # the one machine where the budget had something urgent to say, "adapt"
    # adapted nothing. The floor is the smallest window that is still a
    # conversation; below it there is no point, and it still starts.
    rt["n_ctx"] = CTX_FLOOR
    settle(rt["n_ctx"])
    alts = _models_that_fit(ceiling, kv_type)
    msg = (f"{model_name} needs {why(CTX_FLOOR)} even at a minimal context. "
           f"Starting it anyway. If Windows begins swapping, the machine will "
           f"slow badly - closing other applications first is worth it.")
    if alts:
        msg += (" Also on disk and comfortable at this moment: "
                + ", ".join(f"{n}" for n, _ in alts[:3]) + ".")
    return rt, msg


def _models_that_fit(ceiling: float, kv_type: str) -> list:
    """
    Which models on disk can actually run right now, and at what context.

    Same two ceilings as plan(): whatever the card will hold goes on the card,
    the rest is charged to RAM, and the window is what is left over on both.
    """
    out = []
    v = vram_free_mb()
    vram_ceiling = (v - VRAM_RESERVE_MB) if v > 0 else 0.0
    for m in gguf.scan(core.MODELS):
        layers_all = (m.layers + 1) if m.usable else 0
        per_layer = (m.size_mb / layers_all) if layers_all else 0.0
        buffers = float(memo(m.path.name).get("overhead_mb") or 0.0) or \
            (CUDA_CONTEXT_MB + COMPUTE_BUFFER_MB)
        gpu_layers = 0
        if vram_ceiling > 0 and layers_all:
            room = vram_ceiling - buffers
            gpu_layers = max(0, min(layers_all, int(room // per_layer)
                                    if per_layer > 0 else 0))
        gpu = per_layer * gpu_layers
        base = max(0.0, m.size_mb - gpu) * MMAP_RESIDENT + PROCESS_OVERHEAD_MB
        spare = ceiling - HEADROOM_MB - base
        if spare <= 0:
            continue
        if m.usable:
            # The cache is split the way the layers are, so the budget for it
            # is host spare plus whatever the card has not already spent.
            card_spare = max(0.0, vram_ceiling - gpu - buffers) if gpu else 0.0
            ctx = m.ctx_for_budget(spare + card_spare, kv_type)
            ctx = min(ctx, m.train_ctx or ctx, CTX_SANE_MAX)
        else:
            ctx = 4096
        if ctx >= CTX_FLOOR:
            out.append((m.path.name, ctx))
    out.sort(key=lambda x: -x[1])
    return out


def fits(model_name: str, rt: dict) -> tuple:
    """
    Kept for callers that asked the old yes/no question. Always says yes.

    The honest answer to "does this fit" is "start it and find out", and the
    only component qualified to say otherwise is llama.cpp. This returns the
    advisory text so a caller can show it, and True so no caller can turn it
    back into a gate.
    """
    _, advisory = plan(model_name, rt)
    return True, advisory


def sweep_ports() -> int:
    """
    Kill anything still listening on THIS application's ports.

    Never by image name. Cairn's llama-server.exe is also called
    llama-server.exe, and a console window closed with the X button leaves
    orphans on both sides; a name-based sweep would take the other
    application down with it.
    """
    killed = 0
    # 8103 included: trellis-server is started for one mesh and stopped in a
    # finally, but a crash or a hard close leaves a 693 MB process holding
    # the card, and the next generation would then fail for a reason that
    # has nothing to do with it.
    for port in (MAIN_PORT, CUR_PORT, EAR_PORT, core.TRELLIS_PORT):
        for pid in _pids_on(port):
            if _image_of(pid) in ("llama-server.exe", "whisper-server.exe",
                                  "trellis-server.exe"):
                try:
                    subprocess.run(["taskkill", "/F", "/PID", str(pid)],
                                   capture_output=True, shell=False, timeout=10)
                    killed += 1
                except Exception:
                    pass
    if killed:
        core.log_line("runtime", f"swept {killed} orphaned process(es) "
                                 f"from The Hub ports")
    return killed


def _pids_on(port: int) -> list:
    out = []
    try:
        r = subprocess.run(["netstat", "-ano", "-p", "TCP"],
                           capture_output=True, text=True, shell=False,
                           timeout=15)
        for line in (r.stdout or "").splitlines():
            parts = line.split()
            if len(parts) >= 5 and parts[3].upper() == "LISTENING" \
                    and parts[1].endswith(f":{port}"):
                try:
                    out.append(int(parts[4]))
                except ValueError:
                    pass
    except Exception:
        pass
    return out


def _image_of(pid: int) -> str:
    try:
        r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH", "/FO", "CSV"],
                           capture_output=True, text=True, shell=False, timeout=10)
        line = (r.stdout or "").strip().splitlines()
        if line:
            return line[0].split(",")[0].strip('"')
    except Exception:
        pass
    return ""


def start(model_name: str, rt: dict) -> dict:
    global _proc, _log, _model, _rt, _corrected

    if not core.LLAMA_EXE.is_file():
        return {"ok": False, "error": f"missing {core.LLAMA_EXE}"}
    # Allowlist, not a path. The UI sends a filename; only one the directory
    # scan actually found is accepted.
    if model_name not in {m["name"] for m in core.models()}:
        return {"ok": False, "error": f"unknown model: {model_name!r}"}
    path = core.under(core.MODELS, model_name)

    # AUTO CONTEXT, resolved before anything else looks at n_ctx.
    #
    # The window is chosen from the model's own header and the memory free
    # right now - at the CEILING, not the floor. A window smaller than
    # necessary is the direct cause of a model that reasons and never
    # answers, which is the failure this removes.
    rt = dict(rt or {})
    # Whatever the card held a moment ago - another model, a generation that
    # just finished - is not what it holds now. Measure it for this load.
    forget_vram()
    ctx, ctx_note = resolve_ctx(model_name, rt)
    rt["n_ctx"] = ctx
    if ctx_note:
        core.log_line("runtime", f"context: {ctx_note}")

    # plan() advises; it cannot veto. The model the user selected is the
    # model that gets loaded, and llama.cpp reports a real failure if it
    # genuinely cannot.
    rt, advisory = plan(model_name, rt)
    if ctx_note and not advisory:
        advisory = ctx_note
    set_advisory(advisory)
    if advisory:
        core.log_line("runtime", f"{time.strftime('%F %T')} {advisory}")

    stop()
    core.LOGS.mkdir(parents=True, exist_ok=True)
    _log = open(core.LOGS / "llama.log", "a", encoding="utf-8", errors="replace")
    _log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {model_name} =====\n")
    _log.flush()

    if _model != model_name:
        _corrected = False          # a different model gets its own one chance
    _model = model_name
    _rt = dict(rt)
    _set("starting", model_name)
    try:
        _proc = subprocess.Popen(
            _argv(path, MAIN_PORT, rt, gpu=True),
            stdout=_log, stderr=subprocess.STDOUT,
            cwd=str(core.RUNTIME), shell=False, creationflags=NO_WINDOW,
        )
    except OSError as e:
        _set("error", str(e))
        return {"ok": False, "error": str(e)}

    threading.Thread(target=_bring_up, daemon=True).start()
    return {"ok": True, "advisory": advisory, "n_ctx": rt.get("n_ctx")}


def stop() -> None:
    global _proc, _log
    p, _proc = _proc, None
    if p is not None and p.poll() is None:
        try:
            p.terminate()
            p.wait(timeout=10)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
    if _log is not None:
        try:
            _log.close()
        except Exception:
            pass
        _log = None
    forget_vram()
    _set("stopped")


# ---------------------------------------------------------------- stream

def set_stream(r) -> None:
    global _stream
    with _lock:
        _stream = r


def cancel_stream() -> bool:
    with _lock:
        r = _stream
    if r is None:
        return False
    try:
        r.close()
    except Exception:
        pass
    return True


# ---------------------------------------------------------------- curator

class Curator:
    """
    CPU-only helper model. Context manager: spawns, serves a batch, exits.

        with Curator("LFM2.5-350M-Q8_0.gguf") as c:
            text = c.ask(system_prompt, user_text)
    """

    def __init__(self, model_name: str, threads: int = 4):
        self.model = model_name
        self.threads = threads
        self.p = None
        self.log = None

    def __enter__(self):
        if self.model not in {m["name"] for m in core.models()}:
            raise RuntimeError(f"curator model not found: {self.model!r}")
        path = core.under(core.MODELS, self.model)
        core.LOGS.mkdir(parents=True, exist_ok=True)
        self.log = open(core.LOGS / "curator.log", "a", encoding="utf-8", errors="replace")
        self.log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {self.model} =====\n")
        self.log.flush()
        self.p = subprocess.Popen(
            _argv(path, CUR_PORT,
                  {"n_ctx": 4096, "threads": self.threads, "parallel": 1},
                  gpu=False),
            stdout=self.log, stderr=subprocess.STDOUT,
            cwd=str(core.RUNTIME), shell=False, creationflags=NO_WINDOW,
        )
        t0 = time.time()
        while time.time() - t0 < 150:
            if self.p.poll() is not None:
                raise RuntimeError("curator exited during startup")
            if health(CUR):
                return self
            time.sleep(0.4)
        raise RuntimeError("curator never became ready")

    def ask(self, system: str, user: str, max_tokens: int = 400) -> str:
        try:
            r = post(CUR, "/v1/chat/completions", {
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "max_tokens": max_tokens,
                "temperature": 0.2,
                "stream": False,
            }, timeout=300)
            d = json.loads(r.read().decode())
            return (d["choices"][0]["message"].get("content") or "").strip()
        except Exception:
            return ""

    def __exit__(self, *exc):
        if self.p is not None and self.p.poll() is None:
            try:
                self.p.terminate()
                self.p.wait(timeout=10)
            except Exception:
                try:
                    self.p.kill()
                except Exception:
                    pass
        if self.log is not None:
            try:
                self.log.close()
            except Exception:
                pass
        return False


# ---------------------------------------------------------------- ears

"""
Hearing. whisper.cpp on port 8082, CPU only.

Deliberately CPU: the GTX 1650 has 4 GB and the language model already holds
about 2 GB of it. Putting the speech model on the GPU too would contend for
VRAM - the exact failure that froze this machine during early testing. On
six threads, base.en transcribes a few seconds of speech in well under a
second, which is all a push-to-talk turn needs.

This replaces the browser's built-in speech recognition, which streams audio
to a vendor server. Hearing is one of Nova's senses; it belongs on the same
side of the line as her thinking.
"""

_ear = None
_ear_log = None
_ear_state = {"status": "off", "detail": "", "model": None}


def ear_state() -> dict:
    with _lock:
        d = dict(_ear_state)
        d["running"] = _ear is not None and _ear.poll() is None
        return d


def whisper_models() -> list:
    """Scan for whisper ggml-*.bin weights. Same drop-in rule as the LLM."""
    if not core.MODELS.is_dir():
        return []
    return [{"name": f.name, "size_mb": round(f.stat().st_size / 1048576, 1)}
            for f in sorted(core.MODELS.glob("ggml-*.bin")) if f.is_file()]


def ear_start(model_name: str, threads: int = 6) -> dict:
    global _ear, _ear_log
    if not core.WHISPER_EXE.is_file():
        return {"ok": False, "error": "whisper-server.exe not installed"}
    if model_name not in {m["name"] for m in whisper_models()}:
        return {"ok": False, "error": f"speech model not found: {model_name!r}"}
    path = core.under(core.MODELS, model_name)

    ear_stop()
    core.LOGS.mkdir(parents=True, exist_ok=True)
    _ear_log = open(core.LOGS / "whisper.log", "a", encoding="utf-8", errors="replace")
    _ear_log.write(f"\n===== {time.strftime('%Y-%m-%d %H:%M:%S')} {model_name} =====\n")
    _ear_log.flush()

    argv = [
        str(core.WHISPER_EXE),
        "-m", str(path),
        "--host", "127.0.0.1",
        "--port", str(EAR_PORT),
        "-t", str(_clamp(threads, 1, 32, 6)),
        "-l", "en",
        "--no-timestamps",
    ]
    with _lock:
        _ear_state.update({"status": "starting", "detail": model_name,
                           "model": model_name})
    try:
        _ear = subprocess.Popen(argv, stdout=_ear_log, stderr=subprocess.STDOUT,
                                cwd=str(core.WHISPER_DIR), shell=False,
                                creationflags=NO_WINDOW)
    except OSError as e:
        with _lock:
            _ear_state.update({"status": "error", "detail": str(e)})
        return {"ok": False, "error": str(e)}

    def wait():
        t0 = time.time()
        while time.time() - t0 < 120:
            if _ear is None or _ear.poll() is not None:
                with _lock:
                    _ear_state.update({"status": "error",
                                       "detail": "whisper exited - see data/logs/whisper.log"})
                return
            try:
                urllib.request.urlopen(EAR + "/", timeout=1).read()
                with _lock:
                    _ear_state.update({"status": "ready", "detail": ""})
                return
            except urllib.error.HTTPError:
                with _lock:
                    _ear_state.update({"status": "ready", "detail": ""})
                return
            except Exception:
                time.sleep(0.4)
        with _lock:
            _ear_state.update({"status": "error", "detail": "timed out"})

    threading.Thread(target=wait, daemon=True).start()
    return {"ok": True}


def ear_stop() -> None:
    global _ear, _ear_log
    p, _ear = _ear, None
    if p is not None and p.poll() is None:
        try:
            p.terminate()
            p.wait(timeout=10)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass
    if _ear_log is not None:
        try:
            _ear_log.close()
        except Exception:
            pass
        _ear_log = None
    with _lock:
        _ear_state.update({"status": "off", "detail": ""})


def transcribe(wav_bytes: bytes) -> str:
    """
    Send a WAV to whisper.cpp and return text. Loopback only.

    The browser sends 16 kHz mono PCM it built itself, so there is no
    ffmpeg dependency and no container format to negotiate.
    """
    if ear_state()["status"] != "ready":
        raise RuntimeError("speech model not ready")
    boundary = "----hub" + uuid.uuid4().hex
    pre = (f"--{boundary}\r\n"
           'Content-Disposition: form-data; name="file"; filename="a.wav"\r\n'
           "Content-Type: audio/wav\r\n\r\n").encode()
    mid = (f"\r\n--{boundary}\r\n"
           'Content-Disposition: form-data; name="response_format"\r\n\r\n'
           "json\r\n"
           f"--{boundary}--\r\n").encode()
    body = pre + wav_bytes + mid
    req = urllib.request.Request(
        EAR + "/inference", data=body, method="POST",
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    with urllib.request.urlopen(req, timeout=120) as r:
        raw = r.read().decode("utf-8", "replace")
    try:
        d = json.loads(raw)
        txt = d.get("text") or d.get("transcription") or ""
    except Exception:
        txt = raw
    return re.sub(r"\s+", " ", re.sub(r"\[[^\]]*\]", " ", txt)).strip()


# ═══════════════════════════════════════════════════════════════════════════
# §  AUTOMATIC CONTEXT
#
# n_ctx used to be a number the user typed. That was wrong twice over:
#
#   * every fact needed to decide it is already measured. gguf.py reads the
#     model's trained context length from its header; plan() already computes
#     the largest window that fits in free memory; benchmark() reads back what
#     llama-server actually granted.
#
#   * the typed number was then silently overruled - clamped down by the
#     header, lowered again by the fitter - and reported back as something
#     else. Being asked for a value that is not the one used is worse than not
#     being asked.
#
# So: AUTO, and auto means the CEILING, not the floor. A window smaller than
# necessary is the direct cause of the failure this exists to remove - the
# model runs out of room and answers nothing. Given a choice, take the room.
#
#     auto  =  min( what the model was trained for,
#                   what fits in memory right now,
#                   CTX_SANE_MAX )
#
# The manual override stays. Fitting is not the only consideration: a large
# window costs prompt-processing time on every single turn, so capping it on
# a slow model is a legitimate choice a measurement cannot make. What changes
# is that the user is no longer REQUIRED to make it.
# ═══════════════════════════════════════════════════════════════════════════

CTX_SANE_MAX = 32768      # beyond this, prompt processing dominates on a laptop
CTX_AUTO_MIN = 4096       # never auto-select less than this; below it the
                          # model cannot hold a conversation and a memory


def model_limits(model_name: str) -> dict:
    """
    What this specific model can do, read from its own header.

    Returns trained context, an exact per-token KV cost, and the ceiling the
    interface should not let the user exceed.
    """
    out = {"train_ctx": 0, "kv_kb_per_token": 0.0, "max": CTX_SANE_MAX,
           "auto_max": CTX_SANE_MAX, "source": "unknown"}
    try:
        path = core.under(core.MODELS, model_name)
        meta = gguf.read(path)
        if meta and meta.usable:
            out["train_ctx"] = int(meta.train_ctx or 0)
            out["kv_kb_per_token"] = round(
                meta.kv_bytes_per_token("f16") / 1024.0, 3)
            out["source"] = "gguf header"
        if out["train_ctx"]:
            # What the model CAN do, and what AUTO should choose, are two
            # different numbers. LFM2.5-2.6B advertises 131072 and the fitter
            # happily found 76288 free - but 76k tokens of prompt on a laptop
            # means prompt processing dominates every single turn, which is
            # the slowness this cap exists to prevent.
            #
            # `max` is the model's real limit and bounds a MANUAL request.
            # `auto_max` is what auto will take by itself.
            out["max"] = out["train_ctx"]
            out["auto_max"] = min(out["train_ctx"], CTX_SANE_MAX)
    except Exception as e:
        out["why"] = str(e)[:80]
    return out


def resolve_ctx(model_name: str, rt: dict) -> tuple:
    """
    (n_ctx, note). Resolves "auto" to the largest sane window that fits.

    A number in config is honoured as a request, still clamped to what the
    model was actually trained for - asking for 32k from an 8k model does not
    give you 32k, it gives you a failed load or silent truncation.
    """
    lim = model_limits(model_name)
    ceiling = lim["max"] or CTX_SANE_MAX
    asked = rt.get("n_ctx")
    auto = isinstance(asked, str) and asked.strip().lower() in ("auto", "")

    if not auto:
        want = _clamp(asked, 512, 131072, 8192)
        if want > ceiling:
            return ceiling, (f"{model_name} was trained for {ceiling} tokens, "
                             f"so {want} is not available. Using {ceiling}.")
        return want, ""

    # AUTO. Start from the sane ceiling - not the model's advertised maximum
    # - and come down only as far as memory requires.
    ceiling = lim.get("auto_max") or ceiling
    fits = _largest_that_fits(model_name, rt, ceiling)
    chosen = max(CTX_AUTO_MIN, min(ceiling, fits))
    if chosen >= ceiling:
        full = lim.get("train_ctx") or ceiling
        if full > ceiling:
            return ceiling, (f"{ceiling} tokens. {model_name} advertises "
                             f"{full}, but a window that large spends most of "
                             f"every turn on prompt processing. Set n_ctx by "
                             f"hand if you want more.")
        return ceiling, (f"{ceiling} tokens - everything {model_name} was "
                         f"trained for")
    return chosen, (f"{chosen} tokens - {model_name} supports {ceiling}, and "
                    f"this is what fits in memory right now")


def _largest_that_fits(model_name: str, rt: dict, ceiling: int) -> int:
    """Binary search the biggest window that fits, using plan()'s own maths."""
    try:
        probe = dict(rt)
        lo, hi, best = CTX_AUTO_MIN, ceiling, 0
        while lo <= hi:
            mid = ((lo + hi) // 2) // 512 * 512 or 512
            probe["n_ctx"] = mid
            _, advisory = plan(model_name, probe)
            # plan() lowers n_ctx when it does not fit and says so; an empty
            # advisory means it was comfortable at that size.
            if not advisory:
                best, lo = mid, mid + 512
            else:
                hi = mid - 512
        return best or CTX_AUTO_MIN
    except Exception:
        return CTX_AUTO_MIN


def live_ctx(cfg: dict) -> int:
    """
    The window in force RIGHT NOW, as one number, never the string "auto".

    Order matters. What llama-server GRANTED is the truth; what config asked
    for is only a request, and with n_ctx on auto it is not even a number.
    Budgeting against a request that was lowered is how a prompt overflows a
    window it was told it had.
    """
    granted = (bench() or {}).get("n_ctx") or 0
    if granted:
        return int(granted)
    asked = (cfg.get("runtime") or {}).get("n_ctx")
    if isinstance(asked, str):
        return CTX_AUTO_MIN if asked.strip().lower() in ("auto", "") \
            else _clamp(asked, 512, 131072, CTX_AUTO_MIN)
    return _clamp(asked, 512, 131072, CTX_AUTO_MIN)


def resolve_max_tokens(n_ctx: int, sampling: dict) -> int:
    """
    How long a reply may be. "auto" scales with the window.

    This was the constant 1024, and it is the direct cause of the reported
    failure: a thinking model spends its whole allowance on reasoning, emits
    no answer, and the interface says "no text came back - try raising
    max_tokens". The user should never have been shown that sentence.

    A third of the window is the same share budget.Plan already reserves, so
    the two can no longer disagree.
    """
    asked = sampling.get("max_tokens")
    if isinstance(asked, str) and asked.strip().lower() in ("auto", ""):
        return max(512, min(8192, int(n_ctx // 3)))
    return _clamp(asked, 64, 32768, max(512, int(n_ctx // 3)))
