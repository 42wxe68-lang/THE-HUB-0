"""
events.py - the append-only history. Nothing here is ever rewritten.

WHY THIS EXISTS
---------------
Cairn's memory was its tree.json. If that file went wrong, the memory was
wrong, and there was nothing underneath it to appeal to. Every structure in
The Hub's data/ directory - the sephirot, the branches, the leaf weights,
the ash - is a DERIVED view. This log is the thing they are derived from.

    events.jsonl      the source of truth. Append only. Never edited.
        |
        +--> data/tree/*.json        the living Tree of Life
        +--> data/ash/ash.jsonl      what faded
        +--> data/knowledge/*.json   what was worked out

Delete every derived file and `python -c "import memory; memory.rebuild()"`
puts the tree back. That is the test of whether this is real, and it is run
by verify.py on every install.

FORMAT
------
One JSON object per line, UTF-8:

    {"t": "2026-08-25T21:14:03+00:00", "k": "leaf.plant", "d": {...}}

  t   ISO-8601 UTC, seconds
  k   kind, dotted. leaf.plant, leaf.ash, leaf.prune, digest.write,
      digest.merge, knowledge.grow, hub.research, hub.gate
  d   payload. Whatever the writer needs; readers must tolerate extra keys.

A line that will not parse is skipped by readers rather than aborting the
read. A corrupt tail - a crash mid-write - costs the last event, not the
history.
"""
from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

import core

LOG = core.EVENTS / "events.jsonl"
_lock = threading.Lock()

# One file, rolled at 8 MB. At roughly 200 bytes an event that is around
# 40,000 events, which is years of ordinary use on one machine.
ROLL_BYTES = 8 * 1024 * 1024


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write(kind: str, **payload) -> None:
    """
    Append one event. Never raises - a memory system that crashes the
    conversation because it could not write its own diary is worse than one
    that misses a line.
    """
    try:
        core.EVENTS.mkdir(parents=True, exist_ok=True)
        line = json.dumps({"t": now(), "k": kind, "d": payload},
                          ensure_ascii=False)
        with _lock:
            if LOG.exists() and LOG.stat().st_size > ROLL_BYTES:
                LOG.replace(core.EVENTS / f"events-{now()[:10]}.jsonl")
            with LOG.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
                # PUT IT ON THE DISK, NOT IN A BUFFER.
                #
                # This is the file the whole memory is rebuilt from when the
                # tree goes wrong - "nothing ever deleted, rebuild() from
                # history". Buffered, its most recent minutes exist only in
                # RAM, and the machine this runs on has been going off
                # without warning: Windows commits the file's new SIZE and
                # loses the bytes, so the log comes back with the right
                # length full of NUL. The user's own events.jsonl is now
                # padded exactly that way.
                #
                # An append-only log that is not durable is a log that
                # discards precisely the events worth having - the ones just
                # before the thing that went wrong.
                f.flush()
                os.fsync(f.fileno())
    except Exception:
        pass


def read(kinds: tuple = (), limit: int = 0) -> list:
    """
    Read the history oldest-first, optionally filtered by kind prefix.

    Rolled files are read before the live one so the order is chronological
    across a roll.
    """
    out = []
    try:
        files = sorted(core.EVENTS.glob("events-*.jsonl")) + [LOG]
    except Exception:
        return out
    for p in files:
        if not p.exists():
            continue
        try:
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    # NUL padding is what a lost write leaves
                    # behind. Strip it rather than counting it
                    # as a torn line.
                    line = line.strip("\x00 \t\r\n")
                    if not line:
                        continue
                    try:
                        e = json.loads(line)
                    except Exception:
                        continue          # a torn line costs one event
                    if kinds and not any(str(e.get("k", "")).startswith(k)
                                         for k in kinds):
                        continue
                    out.append(e)
        except Exception:
            continue
    if limit and len(out) > limit:
        out = out[-limit:]
    return out


def count() -> int:
    n = 0
    try:
        for p in list(core.EVENTS.glob("events-*.jsonl")) + [LOG]:
            if p.exists():
                with p.open("rb") as f:
                    n += sum(1 for _ in f)
    except Exception:
        pass
    return n


def tail(n: int = 20) -> list:
    return read(limit=n)
