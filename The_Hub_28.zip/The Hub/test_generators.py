"""
test_generators.py - the ComfyUI adapter, and the contract the tools keep.

WHAT CHANGED

This file used to import modelgen and videogen and drive them with mocks.
Those two modules were ComfyUI-only adapters: they required a ComfyUI server
to be installed and running, and without one, generate_3d and generate_video
could only say so. forge.py replaced them with generators that ship WITH The
Hub, so nothing imported either module any more and both were deleted.

generators.py stays, because imagegen still uses it to talk to a ComfyUI a
user has set up deliberately - which is preferred over the built-in image
generator when it is there, since somebody who installed ComfyUI has better
models in it than the starter checkpoint here.

So this now tests what still exists: the ComfyUI plumbing, and the promise
that the three generation tools are registered, gated, and argument-checked.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

TMP = Path(tempfile.mkdtemp(prefix="hub-gen-test-"))
import core                                                       # noqa: E402
core.DATA = TMP / "data"
core.TREE = core.DATA / "tree"
core.KNOWLEDGE = core.DATA / "knowledge"
core.ASH = core.DATA / "ash"
core.EVENTS = core.DATA / "events"
core.SESSIONS = core.DATA / "sessions"
core.LOGS = core.DATA / "logs"
core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                 core.EVENTS, core.SESSIONS, core.LOGS)
core.ensure_dirs()

import generators, playground, policy, tools                      # noqa: E402
playground.ROOT = core.DATA / "playground"
playground.ensure()

GEN_TOOLS = ("generate_image", "generate_video", "generate_3d")


def test_the_three_generation_tools_are_fully_wired():
    for name in GEN_TOOLS:
        assert name in tools.REGISTRY, f"{name} is not a registered tool"
        assert name in policy.TIERS, f"{name} has no policy tier"
        assert name in policy.ARGS, f"{name} has no argument schema"
        assert name in tools.enabled({"tools": {}}), \
            f"{name} is never offered to Nova"


def test_the_pixels_are_always_made_on_this_machine():
    """
    THE INVARIANT, RESTATED PRECISELY.

    This used to assert `not network` for all three generators and called it
    "generation is on-device". That conflated two different claims, and only
    one of them was ever the point:

      * nothing is generated on somebody else's computer  - still absolute
      * nothing is ever downloaded                        - no longer true

    generate_image and generate_3d now fetch a REFERENCE PICTURE when the
    prompt names a specific subject, because a model that has never seen
    Terrible Tornado draws a weather system. The prompt is not sent to a
    generation service, no pixels come back from one, and the whole lookup
    is skipped when web search is off. That is `maybe`, and pretending it is
    `False` would be the drift this suite exists to catch.
    """
    for name in GEN_TOOLS:
        assert policy.TIERS[name]["network"] is not True, (
            f"{name} is behind the web-search switch - generation must stay "
            f"available with the network off")
    assert policy.TIERS["generate_video"]["network"] is False, (
        "video has no reference route and should not have grown one")
    src = (core.ROOT / "forge.py").read_text(encoding="utf-8")
    for host in ("api.openai", "replicate.com", "stability.ai",
                 "huggingface.co/api/inference"):
        assert host not in src, f"forge reaches a remote generator: {host}"


def test_a_reference_is_only_fetched_when_web_search_is_on():
    """The one switch must still mean it."""
    import tools as _t
    path, why = _t._reference_for("a picture of Goku in ultra instinct",
                                  {"tools": {"web_search": False}})
    assert path is None and why == "", (
        "a lookup was attempted with web search switched off")


def test_an_unnamed_prompt_is_never_looked_up():
    """"a red barn at sunset" names nothing, and a network round trip for it
    would be cost with no benefit."""
    import tools as _t
    assert _t._wants_a_reference("a red barn at sunset") == ""
    assert _t._wants_a_reference("abstract blue geometric pattern") == ""
    got = _t._wants_a_reference("terrible tornado, the character, full body")
    assert "tornado" in got, got


def test_generate_3d_advertises_the_spec_route():
    desc = tools.REGISTRY["generate_3d"]["schema"]["function"]["description"]
    assert "spec" in desc.lower()
    props = tools.REGISTRY["generate_3d"]["schema"]["function"]["parameters"]["properties"]
    assert "spec" in props and "input_image" in props and "prompt" in props


def test_output_goes_to_the_playground_not_the_vault():
    for name in GEN_TOOLS:
        desc = tools.REGISTRY[name]["schema"]["function"]["description"]
        assert "Playground" in desc, \
            f"{name} does not say where its output goes"


def test_comfy_probe_is_offline_safe():
    """comfy_available() must return None rather than raise when nothing
    is listening. It runs on a machine with no ComfyUI far more often than
    on one with it."""
    assert generators.comfy_available() is None


def test_token_replacement_in_a_workflow():
    wf = {"3": {"inputs": {"text": "{{PROMPT}}", "image": "{{INPUT_IMAGE}}"}}}
    out = generators._replace_tokens(wf, prompt="a lovely cat",
                                     input_image="cat.png")
    assert out["3"]["inputs"]["text"] == "a lovely cat"
    assert out["3"]["inputs"]["image"] == "cat.png"


def test_a_generated_filename_cannot_escape_the_playground():
    for nasty in ("../../etc/passwd", "..\\\\..\\\\windows\\\\system32\\\\x.png",
                  "/absolute/path.png"):
        safe = generators._safe_filename(nasty)
        assert "/" not in safe and "\\\\" not in safe and ".." not in safe, safe


def test_unique_naming_never_overwrites():
    playground.ensure()
    first = generators.save_unique_playground("thing.png", b"one")
    second = generators.save_unique_playground("thing.png", b"two")
    assert first != second
    assert first.read_bytes() == b"one", "the first file was overwritten"


def test_run_exclusive_restores_the_model_even_on_failure():
    import runtime
    calls = {"stop": 0, "start": 0}
    real_state, real_stop, real_start = runtime.state, runtime.stop, runtime.start
    runtime.state = lambda: {"status": "ready", "model": "stub.gguf"}
    runtime.stop = lambda: calls.__setitem__("stop", calls["stop"] + 1)
    runtime.start = lambda m, c: calls.__setitem__("start", calls["start"] + 1)
    try:
        def boom():
            raise RuntimeError("generator exploded")
        try:
            generators.run_exclusive(boom)
        except RuntimeError:
            pass
        assert calls["stop"] == 1 and calls["start"] == 1, \
            f"the model was not restored: {calls}"
    finally:
        runtime.state, runtime.stop, runtime.start = real_state, real_stop, real_start


if __name__ == "__main__":
    import testkit
    sys.exit(testkit.run(dict(globals()),
                         "GENERATORS - ComfyUI adapter and tool contract"))
