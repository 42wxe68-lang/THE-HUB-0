"""
grove.py - the living tree. Leaf, Branch, Limb, ActiveTree.

WHERE THIS CAME FROM
--------------------
This is LuminovaZero's tree_of_life.py, brought across and adapted. The
mechanics are Luminova's and are kept deliberately intact:

  * a Leaf carries weight 0.0-1.0, and that weight is how alive it is
  * time takes weight away              (decay)
  * being thought about gives it back   (reinforce)
  * a pinned leaf never decays
  * relevance is word overlap + tag overlap + weight + recency,
    in Luminova's own proportions: 0.50 / 0.25 / 0.15 / 0.10
  * a Branch is a cluster around a theme; branches bud when nothing
    existing fits, and close when their last leaf goes
  * the Active Tree is the slice held in mind right now, re-woven
    around whatever is being talked about

WHAT CHANGED, AND WHY
---------------------
1. LIMBS ARE NOT FIXED.
   Luminova hard-wired three limbs - knowledge, core, reality - with an
   assert. The Hub's outer topology is the ten sephirot it inherited
   from Cairn, so a limb is created by name. The three-limb model is not
   lost; it is what data/knowledge holds, one layer over.

2. NOTHING IS DELETED. THE ASH IS NEW.
   Luminova's prune() dropped faded leaves on the floor: `self.leaves =
   [l for l in self.leaves if l.is_alive()]` and the memory was gone. The
   The Hub writes every faded leaf to data/ash/ash.jsonl before removing it
   from the living tree. Decay -> ash -> purge. Only the representation
   fades. The raw fact is kept forever, and can be read back.

3. WRITES GO THROUGH core.write_json.
   Luminova used a plain `open(path, "w")`. A crash mid-write left a
   truncated JSON file and the limb failed to load next boot - silently,
   because load() caught the exception and logged it. Atomic temp-and-
   rename makes a torn write impossible.

4. from_dict TOLERATES UNKNOWN KEYS.
   Luminova's `Leaf.from_dict` was `cls(**d)`. Add one field in a later
   version and every leaf saved by the newer build raises TypeError on the
   older one - and the caller swallowed it, so a whole limb would silently
   read as empty. Unknown keys are dropped now.

5. THREAD SAFETY IS REAL.
   RLock rather than Lock, because remember() -> _best_branch_for() ->
   relevance() re-enters. Under Luminova's Lock that path was one nested
   call away from a deadlock.

Nothing here knows what a sephira is. This module is only about how a
memory lives and dies. memory.py decides where memories go.
"""
from __future__ import annotations

import json
import math
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import core
import events

# ---------------------------------------------------------------- tuning
# Luminova's numbers, kept. Overridable per Limb from config so the ten
# sephirot can age at different speeds - Tiferet is meant to be volatile
# and Keter is meant to be permanent, which one global rate cannot express.

DECAY_PER_DAY = 0.02
ASH_BELOW = 0.05
BRANCH_SPLIT_AT = 20
ACTIVE_MAX_LEAVES = 40
RELEVANCE_CUTOFF = 0.10
BUD_THRESHOLD = 0.15      # below this no branch fits, so a new one buds

_WORD = re.compile(r"\b\w{3,}\b")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _age_days(stamp: str) -> float:
    try:
        d = datetime.fromisoformat(stamp)
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - d).total_seconds() / 86400.0)
    except Exception:
        return 30.0


# ---------------------------------------------------------------- leaf

class Leaf:
    """
    One memory. The smallest living unit of the tree.

    weight  0.0-1.0, how alive this is. Decays with time, grows when used.
    pin     True means it never decays. Used for what must not be forgotten.
    truth   what the system currently believes about it. A claim shown to be
            wrong becomes "disproven" and stays; it does not vanish, because
            knowing something was wrong is worth more than never having
            heard it.
    """

    # stability   how firmly held, in days. Never falls on its own.
    # recalled_at when it last actually came back (not merely touched).
    # recalls     how many times it has come back.
    # affect      0..1, how much was at stake when it was written.
    # valence     -1 loss or regret, +1 something that went right, 0 neutral.
    #
    # An old file has none of these and loads fine: from_dict fills them,
    # and a leaf with stability 0 is treated as new rather than as gone.
    # kind    WHERE THIS CAME FROM, chosen from a fixed set at the moment
    #         it is written. See KINDS below - it is the field that keeps
    #         what is real apart from what somebody believes.
    # holder  whose belief it is, when kind is "attributed". Empty otherwise.
    FIELDS = ("leaf_id", "content", "limb", "branch", "tags", "weight", "pin",
              "source", "truth", "created_at", "accessed_at", "access_count",
              "origin", "stability", "recalled_at", "recalls", "affect",
              "valence", "kind", "holder")

    # ── WHAT IS REAL, WHAT THEY THINK, AND WHAT THEY SAY SOMEONE ELSE
    #    THINKS ────────────────────────────────────────────────────────
    #
    #     "observations are things that really exist ... for other peoples
    #      perceptions separately from their own"
    #
    # People are bad at this. The finding is blunt: humans do not store a
    # source tag at all - they reconstruct it at retrieval from how the
    # memory FEELS, and every source error in the literature follows from
    # that missing tag. A machine does not have to inherit the flaw. The
    # tag is bound here, at the moment of writing, from a closed set.
    #
    # It matters more than it sounds. Forcing an explicit source choice
    # rather than a yes/no "do I know this" cuts misattribution from 8.5%
    # to 0.55% - and a provenance flag applied at RETRIEVAL buys nothing at
    # all, while the same flag applied at ingestion reverses the effect.
    # Late is the same as never here.
    #
    # And the one that must never leak: an attributed belief is SEALED.
    # "Zero says his brother thinks the card is fine" is not evidence about
    # the card. Asked what is true, this tree will not walk through a
    # believes-edge to answer - which is exactly the failure that the
    # decoupling mechanism exists to prevent, and the same failure children
    # under four make when a real fact is sitting in front of them.
    KINDS = ("observed",    # measured or seen here. The only kind that is
                            # evidence about the world on its own.
             "stated",      # the user said it. Their perception, and true
                            # of THEM whatever else is the case.
             "attributed",  # the user says someone else holds this. Sealed.
             "inferred",    # worked out rather than witnessed. Held loosely.
             "unknown")

    # SUPERSEDED is not CONTRADICTED.
    #
    # "I use vim" followed six months later by "I use helix now" is one fact
    # with a history, not two facts in conflict. Marking the earlier one
    # disproven says the user was wrong; marking it superseded says time
    # passed. It stays findable as history and stops being reported as
    # current, which is the behaviour a person actually expects.
    TRUTHS = ("confirmed", "probable", "uncertain", "contradicted",
              "superseded", "disproven", "unknown")

    def __init__(self, content: str, limb: str, branch: str,
                 tags: List[str] = None, weight: float = 0.7,
                 pin: bool = False, source: str = "experience",
                 truth: str = "probable", leaf_id: str = None,
                 created_at: str = None, accessed_at: str = None,
                 access_count: int = 0, origin: str = "",
                 stability: float = 0.0, recalled_at: str = "",
                 recalls: int = 0, affect: float = 0.0,
                 valence: float = 0.0, kind: str = "", holder: str = ""):
        self.leaf_id = leaf_id or uuid.uuid4().hex[:12]
        self.content = str(content).strip()[:600]
        self.limb = limb
        self.branch = branch
        self.tags = [str(t).lower()[:24] for t in (tags or [])][:10]
        self.weight = max(0.0, min(1.0, float(weight)))
        self.pin = bool(pin)
        self.source = source
        self.truth = truth if truth in self.TRUTHS else "probable"
        self.created_at = created_at or now()
        self.accessed_at = accessed_at or self.created_at
        self.access_count = int(access_count)
        self.origin = origin      # who planted it: user, curator, tool, seed
        try:
            import hold as _h
            self.stability = float(stability) or _h.S_NEW
        except Exception:
            self.stability = float(stability) or 1.0
        self.recalled_at = recalled_at or self.created_at
        self.recalls = int(recalls or 0)
        self.affect = max(0.0, min(1.0, float(affect or 0.0)))
        self.valence = max(-1.0, min(1.0, float(valence or 0.0)))
        k = str(kind or "").strip().lower()
        self.kind = k if k in self.KINDS else "unknown"
        self.holder = str(holder or "").strip()[:60]
        # An attributed belief with nobody holding it is not attributable
        # to anyone, which makes it indistinguishable from a claim about
        # the world - the exact confusion the field exists to prevent.
        if self.kind == "attributed" and not self.holder:
            self.kind = "stated"

    def is_about_the_world(self) -> bool:
        """
        May this stand as evidence for what is actually the case?

        Only what was witnessed here. Something the user said is true of
        THEM - reliably, and worth a great deal - but it is their account,
        and something they say a third party believes is not even that.
        """
        return self.kind == "observed"

    # ---- how firmly this is held ---------------------------------------

    def retrievability(self) -> float:
        """How likely this is to come to mind right now."""
        import hold
        return hold.retrievability(self.stability,
                                   _age_days(self.recalled_at
                                             or self.created_at))

    def feeling(self) -> float:
        """How much charge is still attached. The content is untouched."""
        import hold
        return hold.affect_now(self.affect, self.valence,
                               _age_days(self.created_at), self.recalls)

    def came_back(self, difficulty: float = 5.0) -> None:
        """
        It was needed and it was there.

        Stability rises by more the harder it was to reach - that is the
        whole of Bjork's desirable difficulty, and it is why this cannot be
        collapsed into "bump the weight". The feeling attached settles a
        little further at the same time, which is the measured direction:
        retelling fades the affect while the content stays.
        """
        import hold
        days = _age_days(self.recalled_at or self.created_at)
        self.stability = hold.strengthen(self.stability, days,
                                         difficulty=difficulty,
                                         arousal=self.affect)
        self.recalls += 1
        self.recalled_at = now()
        self.accessed_at = self.recalled_at
        self.access_count += 1

    # ---- relevance: Luminova's formula, unchanged ----------------------

    def relevance(self, query: str) -> float:
        if not query:
            return self.weight * 0.5
        # STOPWORDS ARE NOT SHARED SUBJECT MATTER.
        #
        # The gate below - "no shared word, no recall" - was reading raw
        # words, so "the" counted. Asked to "recreate the statue of Goku and
        # Freiza fighting", a leaf reading "the bracket needs two 5mm holes"
        # shared exactly one word, "the", cleared the gate on it, and then
        # scored 0.31 on weight and recency: comfortably admitted.
        #
        # That is how unrelated things reached the model - not a broken
        # ranking, a broken ADMISSION test, which is the harder kind to see
        # because everything after it behaves correctly. Tacos are not a
        # rock; "the" is not a subject.
        q = {w for w in _WORD.findall(query.lower()) if w not in STOP}
        if not q:
            return self.weight * 0.5
        c = {w for w in _WORD.findall(self.content.lower()) if w not in STOP}
        t = {x.lower() for x in self.tags} - STOP

        # AND "picture" IS NOT A SUBJECT EITHER.
        #
        # Stripping stopwords was not enough. "A picture of GOD striking an
        # anvil" still recalled "asked for a picture of a goth girl
        # yesterday", because they genuinely share a content word - and that
        # word is the medium, not the topic.
        #
        # Every creative request in this application contains one of these.
        # They are perfect false connectors: common enough to link any two
        # requests, and meaningless as a relation. "I do not want it to
        # randomly reference EVERY text where it creates something."
        #
        # So a match on these alone does not admit a memory. They still
        # count toward the SCORE once something real has matched, because
        # "generate an image of a bracket" and "the bracket image" really are
        # closer than the subject word alone says.
        # STEMMED, so a plural or a tense cannot keep a question apart from
        # the fact that answers it. This admits nothing new on its own -
        # the words still have to be the same word.
        q, c, t = stems(q), stems(c), stems(t)
        strong_q, strong_c, strong_t = q - WEAKS, c - WEAKS, t - WEAKS

        # AND ASSOCIATION, which is the part word overlap can never do.
        # "what card am I on" and "a GTX 1650 with 4 GB of VRAM" share no
        # word in any tense. They are connected because this user said them
        # together, and for no other reason.
        near = neighbours_for(strong_q)
        linked = bool(near & strong_c) or bool(near & strong_t)

        if strong_q and not (strong_q & strong_c) and not (
                strong_q & strong_t) and not linked:
            return 0.0

        # No shared word, no recall. Luminova's formula floors every leaf at
        # weight*0.15 + recency*0.10, which is about 0.25 for anything recent
        # - comfortably above the 0.10 cutoff. The effect was that asking
        # about VRAM returned the three most recent memories regardless of
        # subject, and the ranking looked plausible enough to hide it. The
        # weight and recency terms are for ORDERING things that matched, not
        # for admitting things that did not.
        if not (q & c) and not (q & t) and not linked:
            return 0.0

        content_overlap = len(q & c) / max(len(q), 1)
        tag_overlap = len(q & t) / max(len(q), 1)
        # An association is a real connection and a weaker one than saying
        # the same word. It ranks below a direct hit and above nothing.
        assoc = (len(near & (c | t)) / max(len(q), 1)) if linked else 0.0

        # RECENCY IS NOT THE SAME THING AS BEING WELL HELD.
        #
        # This used to be exp(-age/180) alone: everything faded on one
        # clock regardless of how firmly it was held or how often it had
        # come back. That is the single-number model, and it cannot say
        # "forgotten but one reminder from having it back".
        #
        # Retrievability replaces it. A fact returned to for years stays
        # available; one said once in passing does not; and NEITHER of them
        # is deleted, because stability is kept whatever retrievability
        # does. See hold.py.
        try:
            import hold
            recency = hold.retrievability(self.stability,
                                          _age_days(self.recalled_at
                                                    or self.created_at))
        except Exception:
            recency = math.exp(-_age_days(self.created_at) / 180.0)
        score = (content_overlap * 0.50 + tag_overlap * 0.25
                 + assoc * 0.22 + self.weight * 0.15 + recency * 0.18)
        # A disproven memory still surfaces - you want to remember that you
        # were wrong - but it does not outrank what is true.
        if self.truth == "superseded":
            score *= 0.35         # history, not the current answer
        if self.truth in ("disproven", "contradicted"):
            score *= 0.55
        return round(min(1.0, score), 4)

    # ---- lifecycle -----------------------------------------------------

    def decay(self, days: float = 1.0, rate: float = DECAY_PER_DAY) -> None:
        if not self.pin:
            self.weight = max(0.0, self.weight - rate * days)

    def reinforce(self, amount: float = 0.05) -> None:
        self.weight = min(1.0, self.weight + amount)
        self.accessed_at = now()
        self.access_count += 1

    def is_alive(self, floor: float = ASH_BELOW) -> bool:
        return self.pin or self.weight >= floor

    # ---- serialisation -------------------------------------------------

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.FIELDS}

    @classmethod
    def from_dict(cls, d: dict) -> "Leaf":
        # Unknown keys dropped rather than raising. A file written by a
        # newer build must not make an older one lose the whole limb.
        clean = {k: v for k, v in (d or {}).items() if k in cls.FIELDS}
        clean.setdefault("content", "")
        clean.setdefault("limb", "")
        clean.setdefault("branch", "general")
        return cls(**clean)

    def __repr__(self) -> str:
        return (f"Leaf({self.limb}/{self.branch} w={self.weight:.2f}"
                f"{'*' if self.pin else ''} {self.content[:40]!r})")


# ---------------------------------------------------------------- branch

class Branch:
    """
    A named cluster of leaves around a theme.

    Branches bud when a memory arrives with no good home, and close when
    their last leaf falls - unless they are permanent.
    """

    def __init__(self, name: str, limb: str, permanent: bool = False,
                 theme: str = "", branch_id: str = None,
                 created_at: str = None):
        self.branch_id = branch_id or uuid.uuid4().hex[:8]
        self.name = name
        self.limb = limb
        self.permanent = bool(permanent)
        self.theme = theme or name
        self.created_at = created_at or now()
        self.leaves: List[Leaf] = []

    def add(self, leaf: Leaf) -> None:
        self.leaves.append(leaf)

    def remove(self, leaf_id: str) -> None:
        self.leaves = [l for l in self.leaves if l.leaf_id != leaf_id]

    def fallen(self, floor: float) -> List[Leaf]:
        """The leaves that have faded past the floor. Caller ashes them."""
        return [l for l in self.leaves if not l.is_alive(floor)]

    def keep_only_living(self, floor: float) -> None:
        self.leaves = [l for l in self.leaves if l.is_alive(floor)]

    def is_alive(self) -> bool:
        return self.permanent or bool(self.leaves)

    def relevance(self, query: str) -> float:
        """Average of the top five leaves, plus the theme's own match."""
        theme_hit = 0.0
        if query and self.theme:
            q = set(_WORD.findall(query.lower()))
            t = set(_WORD.findall(self.theme.lower()))
            if q and t:
                theme_hit = len(q & t) / max(len(q), 1)
        if not self.leaves:
            return round(theme_hit * 0.6, 4)
        top = sorted((l.relevance(query) for l in self.leaves), reverse=True)[:5]
        return round(max(sum(top) / len(top), theme_hit * 0.6), 4)

    def total_weight(self) -> float:
        return sum(l.weight for l in self.leaves)

    def to_dict(self) -> dict:
        return {"branch_id": self.branch_id, "name": self.name,
                "limb": self.limb, "permanent": self.permanent,
                "theme": self.theme, "created_at": self.created_at,
                "leaves": [l.to_dict() for l in self.leaves]}

    @classmethod
    def from_dict(cls, d: dict) -> "Branch":
        b = cls(name=d.get("name", "general"), limb=d.get("limb", ""),
                permanent=d.get("permanent", False),
                theme=d.get("theme", ""), branch_id=d.get("branch_id"),
                created_at=d.get("created_at"))
        b.leaves = [Leaf.from_dict(x) for x in (d.get("leaves") or [])]
        return b

    def __repr__(self) -> str:
        return f"Branch({self.limb}/{self.name} n={len(self.leaves)})"


# ---------------------------------------------------------------- limb

class Limb:
    """
    One named region of memory, holding branches, holding leaves.

    In The Hub a Limb is a sephira. It does not know that. It knows how
    to take a memory, find it a branch, and let it age.
    """

    def __init__(self, name: str, seeds: Dict[str, str] = None,
                 decay_rate: float = DECAY_PER_DAY, cap: int = 0,
                 permanent_leaves: bool = False):
        self.name = name
        self.decay_rate = decay_rate
        self.cap = cap                      # 0 = uncapped
        self.permanent_leaves = permanent_leaves
        self.branches: Dict[str, Branch] = {}
        self._lock = threading.RLock()
        for bname, theme in (seeds or {}).items():
            self.branches[bname] = Branch(bname, name, permanent=True,
                                          theme=theme)

    # ---- structure -----------------------------------------------------

    def add_branch(self, name: str, theme: str = "") -> Branch:
        name = re.sub(r"[^a-z0-9_ -]", "", str(name).lower().strip())[:24] or "general"
        with self._lock:
            if name not in self.branches:
                self.branches[name] = Branch(name, self.name, theme=theme or name)
                events.write("branch.bud", limb=self.name, branch=name)
            return self.branches[name]

    def best_branch(self, text: str, tags: List[str] = None) -> Branch:
        """
        Luminova's rule: the best-matching branch wins if it matches at all,
        otherwise a new branch buds, named after the first tag.
        """
        query = text + " " + " ".join(tags or [])
        with self._lock:
            if not self.branches:
                return self.add_branch("general", "anything not yet sorted")
            best = max(self.branches.values(), key=lambda b: b.relevance(query))
            if best.relevance(query) > BUD_THRESHOLD:
                return best
        # The most informative keyword, not the first one. Longest wins:
        # in "the laptop has 16 GB of RAM" that is "laptop", which is a
        # branch worth having, where tags[0] would have given "laptop" only
        # by luck and "has" just as often.
        picks = [t for t in (tags or []) if len(t) >= 4] or list(tags or [])
        name = max(picks, key=len) if picks else "general"
        return self.add_branch(name, theme=text[:80])

    def all_leaves(self) -> List[Leaf]:
        with self._lock:
            return [l for b in self.branches.values() for l in b.leaves]

    def leaf_count(self) -> int:
        with self._lock:
            return sum(len(b.leaves) for b in self.branches.values())

    def find(self, leaf_id: str) -> Optional[Leaf]:
        for l in self.all_leaves():
            if l.leaf_id == leaf_id:
                return l
        return None

    # ---- planting ------------------------------------------------------

    def plant(self, content: str, tags: List[str] = None, branch: str = None,
              weight: float = 0.7, pin: bool = False,
              source: str = "experience", truth: str = "probable",
              origin: str = "", stability: float = 0.0,
              affect: float = 0.0, valence: float = 0.0,
              kind: str = "", holder: str = "") -> Optional[Leaf]:
        content = str(content or "").strip()
        if len(content) < 3:
            return None
        low = content.lower()[:300]
        with self._lock:
            for b in self.branches.values():
                for l in b.leaves:
                    if l.content.lower()[:300] == low:
                        l.reinforce(0.06)      # said again means it matters
                        return None
        # Keywords first, THEN branch selection. Luminova named a budded
        # branch after tags[0], and this called best_branch() before the tags
        # existed - so every new branch was named after the first word of the
        # sentence, and the tree filled up with branches called "the", "a"
        # and "currently".
        tags = list(tags) if tags else _keywords(content)
        tgt = (self.add_branch(branch) if branch
               else self.best_branch(content, tags))
        leaf = Leaf(content=content, limb=self.name, branch=tgt.name,
                    tags=tags, weight=weight,
                    pin=pin or self.permanent_leaves, source=source,
                    truth=truth, origin=origin, stability=stability,
                    affect=affect, valence=valence, kind=kind, holder=holder)
        with self._lock:
            tgt.add(leaf)
            self._enforce_cap()
        events.write("leaf.plant", limb=self.name, branch=tgt.name,
                     leaf_id=leaf.leaf_id, text=leaf.content[:300],
                     tags=leaf.tags, weight=leaf.weight, pin=leaf.pin,
                     source=source, truth=truth, origin=origin)
        return leaf

    def _enforce_cap(self) -> None:
        """
        Cairn capped each sephira by count and dropped the oldest. That is
        kept, but the weakest goes rather than the oldest: an old fact that
        keeps being used outlives a new one nobody ever refers to again.
        Overflow falls to ash, it is not deleted.
        """
        if not self.cap:
            return
        # Pinned leaves do not occupy cap space. Counting them and then
        # refusing to evict them means a sephira with 24 pins and a cap of 24
        # silently stops accepting anything new - the write succeeds, the
        # eviction pass finds nothing evictable, and the newest memory is the
        # one that quietly falls out. Identity and boundaries are pinned, so
        # this was worst exactly where memory matters most.
        mortal = [(l, b) for b in self.branches.values()
                  for l in b.leaves if not l.pin]
        if len(mortal) <= self.cap:
            return
        mortal.sort(key=lambda lb: (lb[0].weight, lb[0].accessed_at))
        for leaf, branch in mortal[:len(mortal) - self.cap]:
            branch.remove(leaf.leaf_id)
            _to_ash(leaf, "overflow")

    # ---- ageing --------------------------------------------------------

    def age(self, days: float, floor: float = ASH_BELOW) -> int:
        """
        Let time pass. Faded leaves fall to ash, then leave the living tree.
        Returns how many fell.
        """
        fell = 0
        with self._lock:
            for b in self.branches.values():
                for l in b.leaves:
                    l.decay(days, self.decay_rate)
                for l in b.fallen(floor):
                    _to_ash(l, "faded")
                    fell += 1
                b.keep_only_living(floor)
            for name in [n for n, b in self.branches.items() if not b.is_alive()]:
                del self.branches[name]
                events.write("branch.close", limb=self.name, branch=name)
        return fell

    # ---- persistence ---------------------------------------------------

    def to_dict(self) -> dict:
        with self._lock:
            return {"name": self.name,
                    "branches": {k: v.to_dict()
                                 for k, v in self.branches.items()}}

    def load_dict(self, d: dict) -> None:
        with self._lock:
            for bname, bdata in (d.get("branches") or {}).items():
                b = Branch.from_dict(bdata)
                if bname in self.branches and self.branches[bname].permanent:
                    b.permanent = True      # a seed branch stays permanent
                self.branches[bname] = b

    def __repr__(self) -> str:
        return f"Limb({self.name} b={len(self.branches)} l={self.leaf_count()})"


# ---------------------------------------------------------------- ash

def _ash_file():
    """
    Resolved at call time, never captured at import.

    ASH_FILE used to be a module constant built from core.ASH when grove was
    first imported. Anything that redirected core.ASH afterwards - a test
    harness, a relocated data directory - left the constant pointing at the
    old path while mkdir created the new one. The write then went somewhere
    nothing reads, and `except Exception: pass` made it silent.

    That is the one failure this system must not have. A leaf leaves the
    living tree on the promise that it is kept, and a silent write failure
    turns fading into deletion.
    """
    core.ASH.mkdir(parents=True, exist_ok=True)
    return core.ASH / "ash.jsonl"


ASH_FILE = core.ASH / "ash.jsonl"          # kept for anything importing it
_ash_lock = threading.Lock()


def _to_ash(leaf: Leaf, reason: str) -> None:
    """
    The Tree of Death.

    A leaf that has faded is written here before it leaves the living tree,
    and this file is never rewritten or trimmed. What was remembered stays
    remembered; only its place in the working mind is given up.
    """
    # The event is written FIRST, so the text is durable before the leaf
    # leaves the living tree. Even if the ash file cannot be written, the
    # memory is recoverable from the log - which is what rebuild() reads.
    events.write("leaf.ash", limb=leaf.limb, branch=leaf.branch,
                 leaf_id=leaf.leaf_id, text=leaf.content[:300], reason=reason)
    try:
        row = leaf.to_dict()
        row["ashed_at"] = now()
        row["reason"] = reason
        with _ash_lock:
            with _ash_file().open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception as e:
        # Loud, not silent. Ash failing means search can no longer reach a
        # memory that the tree has already let go of.
        core.log_line("memory", f"ASH WRITE FAILED for {leaf.leaf_id}: {e} "
                                f"(recoverable from the event log)")


def ash_read(limit: int = 200, query: str = "") -> List[dict]:
    """Read back what faded. Newest first."""
    out = []
    try:
        if not _ash_file().exists():
            return out
        with _ash_file().open("r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    except Exception:
        return out
    if query:
        q = set(_WORD.findall(query.lower()))
        out = [r for r in out
               if q & set(_WORD.findall(str(r.get("content", "")).lower()))]
    return list(reversed(out))[:limit]


def ash_count() -> int:
    try:
        if not _ash_file().exists():
            return 0
        with _ash_file().open("rb") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def rekindle(leaf_id: str) -> Optional[dict]:
    """
    Take something back out of the ash.

    The ash file is append-only, so nothing is removed from it here. The
    caller replants the returned row into the living tree, which is why
    this is possible at all.
    """
    for row in ash_read(limit=100000):
        if row.get("leaf_id") == leaf_id:
            return row
    return None


# ---------------------------------------------------------------- active

class ActiveTree:
    """
    The slice of memory held in mind right now.

    Luminova's Active Tree, kept whole: it re-weaves itself around whatever
    is being talked about, and being woven into it strengthens a leaf a
    little, because being thought about is a form of use.
    """

    def __init__(self, max_leaves: int = ACTIVE_MAX_LEAVES):
        self.leaves: List[Leaf] = []
        self.max_leaves = max_leaves
        self._lock = threading.RLock()

    def weave(self, source: List[Leaf], query: str) -> "ActiveTree":
        scored = [(l.relevance(query), l) for l in source]
        scored = [(s, l) for s, l in scored if s >= RELEVANCE_CUTOFF]
        scored.sort(key=lambda x: -x[0])
        with self._lock:
            self.leaves = [l for _, l in scored[:self.max_leaves]]
            for l in self.leaves:
                l.reinforce(0.02)
        return self

    def by_limb(self) -> Dict[str, List[Leaf]]:
        groups: Dict[str, List[Leaf]] = {}
        with self._lock:
            for l in self.leaves:
                groups.setdefault(l.limb, []).append(l)
        return groups

    def stats(self) -> dict:
        with self._lock:
            n = len(self.leaves)
            return {"leaves": n,
                    "avg_weight": round(sum(l.weight for l in self.leaves)
                                        / max(n, 1), 3),
                    "pinned": sum(1 for l in self.leaves if l.pin)}


# ---------------------------------------------------------------- helpers

STOP = set(
    """the a an and or but if then of to in on at for with is are was were be
    been being it its this that these those i you he she they we my your our
    as by from not no yes do does did have has had will would can could
    should about into over under than them there here what when where which
    who how why also just very much more most some any all""".split())

# WORDS TOO COMMON IN THIS APPLICATION TO MEAN "same subject".
#
# Not stopwords - they carry meaning. But every creative request here
# contains one, so a match on them alone links any two requests and says
# nothing. "A picture of GOD striking an anvil" and "a picture of a goth
# girl" share "picture" and are about nothing in common.
#
# They still count toward the SCORE once a real subject word has matched;
# they just cannot admit a memory on their own.
# ═══════════════════════════════════════════════════════════════════════════
#  A WORD IS NOT A STRING, AND THAT IS WHY THE STORE WENT SILENT
#
#  Measured, with the fact "Image generation takes about 170 seconds at
#  768x768" sitting in the tree:
#
#      "how long does an image take here"   ->   NOTHING RECALLED
#
#  "take" and "takes" are different strings. "image" is on the WEAK list -
#  correctly, it is the medium and not the subject - so it could not admit
#  anything on its own. Between the two, a question and the exact fact that
#  answers it had no admissible word in common, and the store was
#  write-only.
#
#  Every step that got here was a real fix for a real leak: stopwords, then
#  WEAK, then a minimum overlap. Each one subtracted. None added anything
#  back, and the end of that road is a memory that never says anything.
#
#  Two things are added back here, and neither reopens a leak:
#
#    STEMS      takes/taking/taken are one word. This cannot connect two
#               unrelated things - they still have to share the word.
#    NEIGHBOURS words that keep turning up together in this user's own
#               memories are related for this user. "card" reaches "GTX"
#               and "VRAM" because THEY said them together, not because a
#               dictionary said so. It starts empty, and it is the part
#               that grows with use.
# ═══════════════════════════════════════════════════════════════════════════

def stem(w: str) -> str:
    """
    Crude, deliberate, and reversible in the head.

    Not a linguistic stemmer. It exists so that a question and the fact that
    answers it are not kept apart by a plural, and it is short enough that
    anyone can see what it will do to a given word.
    """
    w = (w or "").lower()
    if len(w) <= 3:
        return w
    # -ies -> -y first, so tries and try land together.
    if w.endswith("ies") and len(w) > 4:
        w = w[:-3] + "y"
    elif w.endswith("s") and not w.endswith(("ss", "us", "is")):
        w = w[:-1]
    for suf in ("ing", "ed"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[:-len(suf)]
            # running -> runn -> run
            if len(w) > 2 and w[-1] == w[-2] and w[-1] not in "aeiou":
                w = w[:-1]
            break
    # AND THE TRAILING e, LAST. Without it "take" and "taking" stem to
    # "take" and "tak" and stay strangers, which is the exact pair that
    # made the store silent.
    if len(w) > 3 and w.endswith("e"):
        w = w[:-1]
    return w


def stems(words) -> set:
    return {stem(w) for w in words}


# ── neighbours: association learned from this user's own memories ────────
#
# "what card am I on" against the stored fact "The machine has a GTX 1650
# with 4 GB of VRAM" shares no word at all. Word overlap cannot answer it
# and never will, however the threshold is tuned.
#
# What can answer it is the thing a person actually has: an association
# built out of their own experience. If any memory ever said "card" and
# "GTX" in the same breath, those two are linked FOR THIS USER - and if
# nobody ever did, they are not linked, which is also correct. No
# dictionary, no embedding model, no download. It starts knowing nothing
# and learns from what is stored, which is the point.
#
# Rebuilt from the tree rather than persisted: it is a few thousand short
# lines at most, the build is milliseconds, and a cache that can disagree
# with its source is the shape of bug this project keeps finding.

_NEIGHBOURS: dict = {}
_NEIGHBOUR_SIG = None


def learn_neighbours(texts) -> dict:
    """Words that keep company with each other, from these lines alone."""
    counts: dict = {}
    seen: dict = {}
    for line in texts or ():
        ws = [w for w in stems(
            {x for x in _WORD.findall(str(line).lower()) if x not in STOP})
            if len(w) > 2]
        for w in ws:
            seen[w] = seen.get(w, 0) + 1
        for i, a in enumerate(ws):
            for b in ws[i + 1:]:
                if a == b:
                    continue
                counts.setdefault(a, {})[b] = counts.get(a, {}).get(b, 0) + 1
                counts.setdefault(b, {})[a] = counts.get(b, {}).get(a, 0) + 1
    out = {}
    for w, others in counts.items():
        # Only the company it keeps most often, and only where the pairing
        # happened more than once - one accident is not an association.
        best = sorted(others.items(), key=lambda kv: -kv[1])[:6]
        keep = {o for o, n in best if n >= 2}
        if keep:
            out[w] = keep
    return out


def neighbours_for(words) -> set:
    """Everything associated with these words, one hop out."""
    out = set()
    for w in words or ():
        out |= _NEIGHBOURS.get(w, set())
    return out - set(words or ())


def set_neighbours(mapping: dict, signature=None) -> None:
    global _NEIGHBOURS, _NEIGHBOUR_SIG
    _NEIGHBOURS = mapping or {}
    _NEIGHBOUR_SIG = signature


def neighbour_signature():
    return _NEIGHBOUR_SIG


WEAK = set(
    """picture pictures image images photo photos render rendering video
    model models mesh statue figure file files thing things one two three
    make makes made making create creates created creating generate
    generates generated generating build builds built building want wants
    wanted need needs needed like please try tries tried again new old good
    bad better best real realistic detailed quality""".split())

# The same list, stemmed once, because relevance() compares stems.
WEAKS = {stem(w) for w in WEAK}



def _keywords(text: str, n: int = 8) -> List[str]:
    seen = []
    for w in _WORD.findall((text or "").lower()):
        if w not in STOP and w not in seen:
            seen.append(w)
        if len(seen) >= n:
            break
    return seen


def save_limb(limb: Limb, path: Path) -> None:
    core.write_json(path, limb.to_dict())


def load_limb(limb: Limb, path: Path) -> bool:
    d = core.read_json(path, None)
    if not isinstance(d, dict):
        return False
    limb.load_dict(d)
    return True
