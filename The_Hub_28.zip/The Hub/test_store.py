"""
test_store.py - the memory has as much room as the machine has, and no less.

THE RULE THIS IS ABOUT

    "the files stored should also be able to store lots as well, these
     should not be limited by anything other than an automatically
     understood 'computers limit.' ... this way we can scale when we
     install on a new device"

Every other limit in this application that was written down instead of
measured turned out to be a property of one laptop on one afternoon. The fit
limiter is the long version (ADR-142); this is the same question one layer
out, and it gets the same answer: measure it, every time, and never write it
into config.

Three numbers, one choice:

    USED       measured by walking data/
    CHOSEN     the user's ceiling. 0 means "the machine's", and is default
    CEILING    what this disk can actually give, measured, never stored

And one promise that outranks all of them: NOTHING HERE DELETES ANYTHING. A
storage ceiling that trimmed to stay under itself would do it silently, to
the oldest material, which is the least replaceable. What a full store does
is say so, and decline to START something large. purge.py stays the only
thing that removes anything, and it asks first.
"""
from __future__ import annotations

import pathlib
import sys

import core
import store


def _redirect(tmp_path):
    old = (core.ROOT, core.DATA)
    core.ROOT = pathlib.Path(tmp_path)
    core.DATA = core.ROOT / "data"
    core.DATA.mkdir(parents=True, exist_ok=True)
    store.forget()
    return old


def _restore(old):
    core.ROOT, core.DATA = old
    store.forget()


def _fill(path: pathlib.Path, mb: float):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        if mb > 0:
            f.seek(int(mb * 1048576) - 1)
            f.write(b"\0")


# ------------------------------------------------------------- it measures

def test_the_ceiling_comes_from_the_disk_and_is_never_written_down():
    """
    Move the folder to a bigger drive and the bar gets longer by itself. That
    is the whole requirement, and it only works if nothing is remembered.
    """
    src = pathlib.Path("store.py").read_text(encoding="utf-8")
    body = src[src.index("def ceiling_gb"):src.index("# ------", src.index("def ceiling_gb"))]
    assert "disk_usage" in body, "the ceiling is not measured from the disk"
    assert "core.save" not in src and "write_json" not in src, \
        "store.py writes something down - a stored measurement is a laptop"
    assert store.ceiling_gb() >= 0


def test_the_machine_is_described_without_being_remembered():
    m = store.machine()
    for k in ("disk_total_gb", "disk_free_gb", "where"):
        assert k in m
    assert m["disk_total_gb"] >= m["disk_free_gb"] >= 0


def test_what_is_used_is_actually_walked(tmp_path):
    old = _redirect(tmp_path)
    try:
        assert store.used_gb(force=True) == 0.0
        _fill(core.DATA / "playground" / "big.png", 64)
        _fill(core.DATA / "sessions" / "a.json", 8)
        got = store.measure(force=True)
        assert abs(got["bytes"] / store.GB - 72 / 1024.0) < 0.01, got["bytes"]
        assert abs(got["parts"]["made"] / store.GB - 64 / 1024.0) < 0.01
        assert abs(got["parts"]["conversations"] / store.GB - 8 / 1024.0) < 0.01
    finally:
        _restore(old)


def test_a_folder_nobody_named_still_counts(tmp_path):
    """
    A budget that only measures the folders it knows about is wrong on the
    first day somebody adds one, and wrong in the direction that matters.
    """
    old = _redirect(tmp_path)
    try:
        _fill(core.DATA / "something_new" / "x.bin", 32)
        got = store.measure(force=True)
        assert got["parts"].get("other", 0) > 0, got["parts"]
        assert abs(got["bytes"] / 1048576.0 - 32) < 0.5
    finally:
        _restore(old)


def test_the_measurement_can_be_dropped(tmp_path):
    old = _redirect(tmp_path)
    try:
        store.measure(force=True)
        _fill(core.DATA / "ash" / "a.json", 16)
        assert store.measure()["bytes"] == 0, "the cache should still be held"
        store.forget()
        assert store.measure()["bytes"] > 0, "forget() did not drop it"
    finally:
        _restore(old)


# --------------------------------------------------------------- it chooses

def test_zero_means_the_machines_own_limit(tmp_path):
    old = _redirect(tmp_path)
    try:
        assert store.chosen_gb({"storage": {"limit_gb": 0}}) == store.ceiling_gb()
        assert store.chosen_gb({}) == store.ceiling_gb()
        assert store.state({"storage": {"limit_gb": 0}})["following_machine"]
    finally:
        _restore(old)


def test_a_number_above_what_the_disk_allows_is_clamped_and_said_so(tmp_path):
    old = _redirect(tmp_path)
    try:
        cfg = {"storage": {"limit_gb": 9_000_000}}
        assert store.chosen_gb(cfg) == store.ceiling_gb()
        st = store.state(cfg)
        assert st["clamped"] is True and st["asked_gb"] == 9_000_000
    finally:
        _restore(old)


def test_a_number_below_it_is_honoured(tmp_path):
    old = _redirect(tmp_path)
    try:
        cfg = {"storage": {"limit_gb": 1}}
        assert store.chosen_gb(cfg) == 1
        assert store.state(cfg)["following_machine"] is False
    finally:
        _restore(old)


def test_the_operating_system_gets_its_share_first():
    """
    "What the computer can give" is not "every free byte". A disk taken to
    zero does not report an error - it stops Windows paging and updating and
    fails by corrupting.
    """
    assert store.os_reserve_gb() >= store.OS_RESERVE_GB
    assert store.state()["os_reserve_gb"] == store.os_reserve_gb()


def test_the_default_in_config_follows_the_machine():
    assert core.DEFAULTS["storage"]["limit_gb"] == 0


# -------------------------------------------------------- it never deletes

def test_nothing_here_removes_anything():
    """
    The single most destructive thing this application could do, and it would
    do it silently, at 3am, to the oldest and least replaceable material.
    """
    src = pathlib.Path("store.py").read_text(encoding="utf-8")
    for banned in ("unlink", "rmtree", "remove(", "rmdir", "shutil.move"):
        assert banned not in src, f"store.py can delete: {banned}"


def test_a_full_store_declines_to_start_rather_than_making_room(tmp_path):
    old = _redirect(tmp_path)
    try:
        cfg = {"storage": {"limit_gb": 1}}
        _fill(core.DATA / "playground" / "huge.bin", 1100)
        store.forget()
        ok, why = store.has_room_for(500, cfg)
        assert ok is False
        assert "deleted" in why and "raise the ceiling" in why, why
        assert (core.DATA / "playground" / "huge.bin").exists(), \
            "asking the question removed something"
    finally:
        _restore(old)


def test_room_is_never_negative(tmp_path):
    old = _redirect(tmp_path)
    try:
        _fill(core.DATA / "ash" / "a.bin", 200)
        store.forget()
        assert store.room_gb({"storage": {"limit_gb": 0.05}}) == 0.0
    finally:
        _restore(old)


def test_an_unmeasurable_need_never_blocks(tmp_path):
    old = _redirect(tmp_path)
    try:
        assert store.has_room_for(0)[0] is True
        assert store.has_room_for(-5)[0] is True
    finally:
        _restore(old)


def test_the_generation_start_check_asks_the_store_too():
    """
    The same shape as the RAM check beside it: asked ONCE, before Popen,
    never of something already running. "A generation may fail because it
    never started, or because it ran and errored. Never because a number ran
    out."
    """
    src = pathlib.Path("forge.py").read_text(encoding="utf-8")
    fn = src[src.index("def enough_room_to_start"):src.index("def _run(")]
    assert "store.room_gb()" in fn
    assert "Nothing has been deleted" in fn


# ----------------------------------------------------------- it is visible

def test_the_three_numbers_reach_the_interface():
    src = pathlib.Path("server.py").read_text(encoding="utf-8")
    assert '"storage": store.state(cfg)' in src
    ui = pathlib.Path("ui.html").read_text(encoding="utf-8")
    assert 'id="storefill"' in ui and 'id="st_limit_gb"' in ui
    for token in ("used_gb", "chosen_gb", "ceiling_gb", "following_machine",
                  "os_reserve_gb"):
        assert token in ui, f"the bar never shows {token}"
    assert "d.storage=" in ui, "the ceiling is never saved"


def test_the_model_can_be_asked_how_much_room_is_left():
    src = pathlib.Path("lens.py").read_text(encoding="utf-8")
    assert "store.state()" in src
    assert "Nothing is ever deleted" in src


def test_setup_measures_the_device_instead_of_freezing_a_number():
    """
    write_config used to freeze n_ctx at 4096 or 8192 from a VRAM reading
    taken during setup - and OVERWROTE a number the user had chosen, on every
    re-install, because the small-card branch assigned instead of defaulting.
    """
    src = pathlib.Path("install.py").read_text(encoding="utf-8")
    fn = src[src.index("def write_config"):]
    assert 'rt["n_ctx"] = 4096' not in fn, "setup freezes the window again"
    assert 'rt.setdefault("n_ctx", "auto")' in fn
    assert 'cfg.setdefault("storage", {}).setdefault("limit_gb", 0)' in fn
    assert "def report_limits" in src, "setup never says what it found"


if __name__ == "__main__":
    import testkit
    sys.exit(testkit.run(dict(globals()),
                         "store - as much room as the machine has"))
