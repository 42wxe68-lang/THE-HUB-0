"""
persona.py - the part of the system prompt that belongs to the user.

THE PROBLEM
-----------
The character sheet was one 13,000-character file and Settings showed the
whole of it in a text box. Two things were wrong with that, and they pull in
opposite directions.

For the USER: almost none of it is theirs. "SAYING IS NOT DOING", "WHAT THE
PAST IS FOR", "TOOLS", "FILES AND SIGHT" - that is the application explaining
itself to the model it runs. It is not a personality, it is wiring, and
putting it in an editable box invites somebody to delete the paragraph that
stops Nova announcing actions she never takes. What they actually wanted to
change is three things: her name, who she is, and what she is like.

For the BUILD: the sheet is shipped, so an update replaces it - and replacing
it threw away whatever the user had written into it. Zero's standing rule is
the opposite: "the app must hold files across changes and updates, that is
the whole point."

THE SPLIT
---------
The shipped sheet keeps the wiring and marks out where the user's own words
go, with the ### blocks Zero asked for:

    ### YOURS: NAME ###
    Nova
    ### END ###

Anything between those markers in character.md is a DEFAULT. The user's own
text lives in data/persona.json, which is never shipped and never replaced,
so an update rewrites the wiring and leaves the person alone.

    LOCKED, and not shown in Settings at all
        how to use the app, the tools, the rules about doing rather than
        announcing, the application's own name, and its creator

    THEIRS, and the only thing Settings shows
        NAME             what she is called
        CHARACTER        who she is
        CHARACTERISTICS  what she is like

WHY THE NAME IS A BLOCK AND NOT A FIND-AND-REPLACE
--------------------------------------------------
The obvious implementation is to write the sheet with "Nova" in it and swap
the string. That breaks the moment a user calls their assistant "Hub", or
"It", or any word the wiring also uses for something else - and it breaks
silently, in the middle of an instruction, in a way nobody would think to
look for. The name is a block with a stated meaning, and the wiring refers to
"you" throughout, which needs no substitution at all.

NOTHING HERE VALIDATES WHAT THE USER WRITES
-------------------------------------------
It is their assistant on their machine. What is guaranteed is that their text
lands where it is meant to land and the wiring around it survives - not that
what they wrote is a good idea.
"""
from __future__ import annotations

import re
import threading

import core

# The blocks the user owns, in the order they appear in Settings. The help
# text is what the interface shows; there is no separate copy of it in
# ui.html, because two copies of one sentence become two different sentences.
FIELDS = (
    ("name", "Name",
     "What she is called. Used in the interface and in her own voice.",
     "line"),
    ("character", "Character",
     "Who she is. This goes into the head of every prompt, so a few plain "
     "sentences carry further than a list of adjectives.",
     "text"),
    ("characteristics", "Characteristics",
     "What she is like. One per line - the model reads these as traits to "
     "hold, not instructions to follow.",
     "lines"),
)
KEYS = tuple(k for k, _l, _h, _kind in FIELDS)

STORE = "persona.json"
MAX_CHARS = 4000          # per field; the whole sheet has a token budget

# ### YOURS: NAME ###  ...  ### END ###
_BLOCK = re.compile(
    r"^###[ \t]*YOURS:[ \t]*([A-Za-z_]+)[ \t]*#*[ \t]*$(.*?)^###[ \t]*END[ \t]*#*[ \t]*$",
    re.MULTILINE | re.DOTALL)

_lock = threading.Lock()


def path():
    return core.DATA / STORE


# ------------------------------------------------------------------ shipped

def defaults() -> dict:
    """What the shipped sheet says, before the user has said anything."""
    out = {k: "" for k in KEYS}
    try:
        raw = core.CHARACTER.read_text(encoding="utf-8")
    except Exception:
        return out
    for m in _BLOCK.finditer(raw):
        key = m.group(1).strip().lower()
        if key in out:
            out[key] = m.group(2).strip()
    return out


def marked() -> bool:
    """Does the shipped sheet actually carry the blocks? Guarded by a test."""
    try:
        raw = core.CHARACTER.read_text(encoding="utf-8")
    except Exception:
        return False
    return {m.group(1).strip().lower() for m in _BLOCK.finditer(raw)} >= set(KEYS)


# -------------------------------------------------------------------- theirs

def stored() -> dict:
    """The user's own text. {} until they have written some."""
    d = core.read_json(path(), {})
    if not isinstance(d, dict):
        return {}
    return {k: str(d.get(k) or "").strip() for k in KEYS if str(d.get(k) or "").strip()}


def current() -> dict:
    """What is in force: the user's text where they gave any, the sheet's else."""
    out = defaults()
    out.update(stored())
    return out


def save(values: dict) -> dict:
    """
    Write the user's text. Only the three keys; everything else is ignored.

    An EMPTY field is not a value - it means "go back to what the sheet
    says". Storing "" would leave the prompt with a hole where her name
    should be, and the model would fill it with something.
    """
    keep = {}
    for k in KEYS:
        if k not in values:
            continue
        v = str(values.get(k) or "").strip()[:MAX_CHARS]
        if v:
            keep[k] = v
    with _lock:
        core.write_json(path(), keep)
    return current()


def reset(key: str = "") -> dict:
    """Drop one field, or all of them, back to the shipped default."""
    with _lock:
        held = stored()
        if key:
            held.pop(key, None)
        else:
            held = {}
        core.write_json(path(), held)
    return current()


# --------------------------------------------------------------------- sheet

def _rendered(key: str, value: str) -> str:
    # The block holds exactly what the user typed - their name, not a
    # sentence about it - and the wiring supplies the sentence. That way a
    # name is a name in Settings, and it cannot be typed into a shape the
    # sheet did not expect.
    if key == "name":
        return f"You are {str(value).strip().splitlines()[0][:60]}."
    if key == "characteristics":
        lines = [ln.strip(" \t-*") for ln in str(value).splitlines()]
        lines = [ln for ln in lines if ln]
        return "\n".join("- " + ln for ln in lines)
    return str(value).strip()


def sheet() -> str:
    """
    The whole system prompt, wiring and person together.

    core.character() calls this, so every consumer - the prompt builder, the
    token budget, the tests - sees one merged text and none of them has to
    know the split exists.
    """
    try:
        raw = core.CHARACTER.read_text(encoding="utf-8")
    except Exception:
        return ""
    now = current()

    def swap(m):
        key = m.group(1).strip().lower()
        if key not in now:
            return m.group(0)
        # The markers do not survive into the prompt. They are for whoever
        # reads the file, not for the model, and a 2B model given a line of
        # hashes in its own instructions will eventually write one back.
        return _rendered(key, now[key])

    return _BLOCK.sub(swap, raw).strip()


def fields() -> list:
    """What Settings should draw, and nothing else."""
    now, base = current(), defaults()
    mine = stored()
    return [{"key": k, "label": label, "help": help_, "kind": kind,
             "value": now.get(k, ""), "default": base.get(k, ""),
             "changed": k in mine}
            for k, label, help_, kind in FIELDS]


def name() -> str:
    """Her name, for anything that needs it outside the prompt."""
    return (current().get("name") or core.ASSISTANT).strip().splitlines()[0][:60]
