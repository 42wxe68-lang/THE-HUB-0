"""
test_ui.py - the interface is code, so it gets tested like code.

WHY THIS EXISTS
---------------
Three regressions shipped in a row, all in ui.html, all invisible to a test
suite that only ever exercised Python:

  1. the system prompt pane was orphaned - the tab button was deleted, the
     pane stayed, and its loader ran on a condition that could never fire
  2. `$("savehth").onclick = ...` was left behind after its panel was
     removed. That is TOP-LEVEL code. `null.onclick` throws, and every line
     after it - the model list, the status poller, the send button - never
     ran. The page loaded and sat there dead.
  3. lockParams() lost its only caller when that same panel went, so the
     runtime fields silently stopped locking during a load

None of these are subtle. All three are "you referred to something that is
not there", and a machine can check that in a second.

Cairn already knew. Its refresh() carries the comment: "Every section is
wrapped separately: one failing block can never blank the others. That bug
cost us the model list once already." It cost the model list a second time
because that lesson lived in a comment instead of a test.

WHAT IS CHECKED
---------------
STATIC   every $("id") resolves, or is guarded; the script parses; every
         fetch("/api/...") has a route in server.py; every tab button has
         a pane and vice versa
EXECUTED the script is actually run against a minimal DOM with a stubbed
         fetch returning a real /api/state payload, and the model dropdown
         is checked for options. That is the failure the user reported, so
         that is the thing asserted.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

PASS, FAIL = [], []


def check(label: str, ok: bool, detail: str = "") -> bool:
    (PASS if ok else FAIL).append(label)
    print(f"  {'ok  ' if ok else 'FAIL'}  {label}")
    if detail and (not ok or len(detail) < 90):
        print(f"        {detail[:200]}")
    return ok


def section(n, title):
    print(f"\n{n}. {title}")


HTML = (HERE / "ui.html").read_text(encoding="utf-8")
JS = re.search(r"<script[^>]*>(.*?)</script>", HTML, re.S).group(1)
MARKUP = HTML[:HTML.index("<script")] + HTML[HTML.index("</script>"):]
IDS = set(re.findall(r'id="([A-Za-z0-9_]+)"', MARKUP))


# ---------------------------------------------------------------- 1

section(1, "EVERY ELEMENT THE SCRIPT REACHES FOR EXISTS")

refs = set(re.findall(r'\$\("([A-Za-z0-9_]+)"\)', JS))
missing = sorted(refs - IDS)

# A reference is safe if the result is checked before use. Anything else is
# a TypeError waiting for the panel to be removed.
unguarded = []
for mid in missing:
    for line in JS.splitlines():
        if f'$("{mid}")' not in line:
            continue
        guarded = ("if(" in line and mid in line) or "?." in line \
            or re.search(r'const \w+\s*=\s*\$\("%s"\)' % mid, line) \
            or "wire(" in line
        if not guarded:
            unguarded.append((mid, line.strip()[:80]))
        break

check("no unguarded reference to a missing element",
      not unguarded,
      "; ".join(f"#{m} -> {l}" for m, l in unguarded) or "")
if missing:
    print(f"        (absent but safely guarded: {', '.join(missing)})")


# ---------------------------------------------------------------- 2

section(2, "THE SCRIPT PARSES AND RUNS TO THE END")

tmp = Path(tempfile.mkdtemp())
(tmp / "ui.js").write_text(JS, encoding="utf-8")

node = shutil.which("node")
if not node:
    check("node is available to execute the interface", False,
          "install Node.js to run the executed half of this suite")
else:
    r = subprocess.run([node, "--check", str(tmp / "ui.js")],
                       capture_output=True, text=True)
    check("the interface JavaScript parses", r.returncode == 0,
          (r.stderr or "").strip()[:200])

    # A real /api/state payload, shaped exactly like the server's.
    STATE = {
        "status": "ready", "detail": "", "locked": False, "model": None,
        "models": [{"name": "LFM2.5-2.6B-Q4_K_M.gguf", "size_mb": 1596.9},
                   {"name": "GPT-OSS-20B-HauhauCS-Balanced-MXFP4.gguf",
                    "size_mb": 11550.2}],
        "config": {"assistant_name": "Nova", "model": "",
                   "tools": {"web_search": False},
                   "runtime": {"n_ctx": 8192, "threads": 4, "kv_type": "f16",
                               "n_gpu_layers": "auto", "fit_policy": "adapt",
                               "mmproj": "", "parallel": 1},
                   "sampling": {"temperature": 0.7, "top_p": 0.9, "top_k": 40,
                                "min_p": 0.05, "repeat_penalty": 1.1,
                                "max_tokens": 1024, "seed": -1},
                   "voice": {"enabled": False, "name": "", "rate": 1,
                             "pitch": 1, "barge_in": False, "listen": False,
                             "auto_send": False, "barge_threshold": 0.02,
                             "barge_ms": 250},
                   "hearing": {"enabled": False, "model": "", "threads": 2,
                               "silence_ms": 900, "min_speech_ms": 300,
                               "auto_send": True},
                   "search": {"provider": "duckduckgo", "brave_key": "",
                              "tavily_key": ""},
                   "memory": {"expire_days": 3, "recall_count": 4,
                              "max_digests_per_session": 10, "autosave_min": 5,
                              "decay_per_day": 0.01, "ash_below": 0.12,
                              "prune_interval_h": 6}},
        "memory": {"leaves": 12, "branches": 3, "ash": 1, "events": 40,
                   "sephirot": {}},
        "net": {"online": True}, "speech_models": [], "vault": {"count": 0},
        "sight": {"sees": False, "why": "not checked"},
        "consolidate": {"busy": False}, "index": {"docs": 0},
        "bench": {}, "hub": {},
    }

    # A DOM small enough to read, real enough that a missing element behaves
    # the way a browser makes it behave: null, and an exception on use.
    shim = """
const __state = %s;
const __created = [];
function El(id){
  this.id=id; this.options=[]; this.children=[];
  /* A classList that REMEMBERS. The page signals a captured frame by adding
     "on" to the eye button, and a no-op stub made that unobservable - so the
     test had to reach for `pendingImg`, which is a `let` and therefore not on
     globalThis, and always read as false. Assert on what the user can see. */
  this._cls = new Set();
  this.classList={ add:(c)=>this._cls.add(c), remove:(c)=>this._cls.delete(c),
    toggle:(c,f)=>{ (f===undefined ? (this._cls.has(c)?this._cls.delete(c)
      :this._cls.add(c)) : (f?this._cls.add(c):this._cls.delete(c))); },
    contains:(c)=>this._cls.has(c) };
  this.style={}; this.dataset={}; this.value=""; this.textContent="";
  this.innerHTML=""; this.checked=false; this.disabled=false;
  this.add=(o)=>{this.options.push(o);};
  this.append=()=>{}; this.appendChild=()=>{}; this.remove=()=>{};
  this.focus=()=>{}; this.scrollTo=()=>{}; this.addEventListener=()=>{};
  this.removeEventListener=()=>{}; this.querySelectorAll=()=>[];
  this.querySelector=()=>null;
  this.getContext=()=>({drawImage(){},fillRect(){},clearRect(){},
    getImageData:()=>({data:new Uint8ClampedArray(4)})});
  /* Counting encodes is how the suite knows a frame was actually captured.
     It does not depend on which element instance holds a CSS class, and it
     cannot be fooled by a variable that is lexically scoped. */
  this.toDataURL=()=>{ __cam.frames++; return "data:image/jpeg;base64,TEST"; };
  this.videoWidth=1280; this.videoHeight=720;
  this.play=()=>Promise.resolve();
  this.setAttribute=()=>{}; this.getAttribute=()=>null;
  this.closest=()=>null; this.insertAdjacentHTML=()=>{};
}
const __ids = new Set(%s);
const __els = {};
global.document = {
  getElementById:(id)=> __ids.has(id) ? (__els[id] ||= new El(id)) : null,
  createElement:(t)=>{const e=new El("<"+t+">"); __created.push(e); return e;},
  querySelectorAll:()=>[], querySelector:()=>null,
  addEventListener:()=>{}, body:new El("body"), head:new El("head"),
  hidden:false, visibilityState:"visible",
};
global.window = global;
global.addEventListener = ()=>{};
global.removeEventListener = ()=>{};
global.dispatchEvent = ()=>true;
global.matchMedia = ()=>({matches:false, addEventListener(){}, addListener(){}});
global.alert = ()=>{}; global.confirm = ()=>true; global.prompt = ()=>null;
global.navigator = {onLine:true, userAgent:"test",
  clipboard:{writeText:()=>Promise.resolve()}};

/* A camera stack that behaves the way a real browser does.

   Before permission, enumerateDevices() lists the cameras but every deviceId
   is an EMPTY STRING - the W3C rule is "no deviceIDs are ever seen by a page
   without user permission". That is exactly what produced the reported
   OverconstrainedError, so the stub reproduces it rather than approximating
   it: {exact:""} matches nothing and throws, the same as Chrome. */
const __cam = {granted:false, calls:[], denyBusy:false, present:true, frames:0};
const __track = (label) => ({label, kind:"video", stop(){}});
global.navigator.mediaDevices = {
  enumerateDevices: async () => __cam.present ? [
    {kind:"videoinput", deviceId: __cam.granted ? "cam-integrated" : "",
     label: __cam.granted ? "Integrated Webcam" : ""},
    {kind:"videoinput", deviceId: __cam.granted ? "cam-usb" : "",
     label: __cam.granted ? "USB Camera" : ""},
  ] : [],
  getUserMedia: async (c) => {
    __cam.calls.push(JSON.stringify(c));
    const v = c && c.video;
    if (!__cam.present) { const e=new Error("no device");
      e.name="NotFoundError"; throw e; }
    if (__cam.denyBusy) { const e=new Error("in use");
      e.name="NotReadableError"; throw e; }
    let want = null;
    if (v && v.deviceId)
      want = v.deviceId.exact !== undefined ? v.deviceId.exact : v.deviceId.ideal;
    if (v && v.deviceId && v.deviceId.exact !== undefined) {
      if (!(__cam.granted && ["cam-integrated","cam-usb"].includes(want))) {
        const e = new Error("");
        e.name = "OverconstrainedError"; e.constraint = "deviceId"; throw e;
      }
    }
    __cam.granted = true;
    const lbl = want === "cam-usb" ? "USB Camera" : "Integrated Webcam";
    return {getVideoTracks:()=>[__track(lbl)], getTracks:()=>[__track(lbl)]};
  },
};
global.URL = { createObjectURL:()=>"blob:x", revokeObjectURL:()=>{} };
global.Blob = function(){}; global.FileReader = function(){
  this.readAsArrayBuffer=()=>{}; this.readAsDataURL=()=>{}; };
global.location = {href:"http://127.0.0.1:8430/", origin:"http://127.0.0.1:8430"};
global.Option = function(label,value){ this.label=label; this.text=label;
  this.value=value; };
global.speechSynthesis = {getVoices:()=>[], speak(){}, cancel(){},
  addEventListener(){}, onvoiceschanged:null};
global.SpeechSynthesisUtterance = function(){};
global.AudioContext = function(){ return {
  createMediaStreamSource:()=>({connect(){},disconnect(){}}),
  createScriptProcessor:()=>({connect(){},disconnect(){}}),
  createAnalyser:()=>({connect(){},disconnect(){},fftSize:2048,
    frequencyBinCount:1024, getByteTimeDomainData(){}, getByteFrequencyData(){},
    getFloatTimeDomainData(){}}),
  createGain:()=>({connect(){},disconnect(){},gain:{value:1}}),
  audioWorklet:{addModule:()=>Promise.resolve()},
  destination:{}, close(){return Promise.resolve();}, resume(){return Promise.resolve();},
  state:"running", sampleRate:48000}; };
global.webkitAudioContext = global.AudioContext;
global.MediaRecorder = function(){ this.start=()=>{}; this.stop=()=>{};
  this.addEventListener=()=>{}; this.state="inactive"; };
global.MediaRecorder.isTypeSupported = () => true;
global.setImmediate = global.setImmediate || ((f)=>Promise.resolve().then(f));
const __posted = [];
global.fetch = (url,opts)=>{
  if (opts && String(opts.method||"").toUpperCase() === "POST")
    __posted.push(String(url));
  return __fetch(url,opts);
};
const __fetch = (url,opts)=>Promise.resolve({
  ok:true, status:200,
  json:()=>Promise.resolve(
    String(url).includes("/api/state") ? __state :
    String(url).includes("/api/tree")  ? {tree:{},meta:{},shape:{},yesod:[],sessions:[]} :
    String(url).includes("/api/character") ? {text:"You are Nova."} :
    String(url).includes("/api/vault")  ? {items:[],stats:{count:0,mb:0,kinds:{}}} :
    {ok:true}),
  text:()=>Promise.resolve(""), body:null,
});
global.setInterval = ()=>0;
/* setTimeout must actually RUN the callback. Stubbing it to a no-op meant
   grabFrame's "let the exposure settle" await never resolved, so the camera
   path could not be tested at all. Zero delay, but it fires. */
global.setTimeout = (f, _ms)=>{ if(typeof f==="function") setImmediate(f); return 0; };
global.clearTimeout = ()=>{}; global.clearInterval = ()=>{};
global.requestAnimationFrame = ()=>0;
global.EventSource = function(){ this.close=()=>{}; };
// runInThisContext, NOT require(). A module has its own scope, so
// `function refresh(){}` would not become global and the check below would
// report a top-level throw that never happened. This runs the script the
// way a <script> tag does.
const __vm = require("vm"), __fs = require("fs");
let __err = null;
try { __vm.runInThisContext(__fs.readFileSync(__dirname + "/ui.js", "utf8")); }
catch(e){ __err = e; }

(async ()=>{
  if (__err) { console.log(JSON.stringify({fatal:String(__err)})); return; }
  try { if (typeof refresh === "function") await refresh(); } catch(e){}
  // CLICK THE BUTTONS. A handler only throws when it runs, so loading the
  // script proves nothing about them - which is exactly how a Save settings
  // button that died on `d.tools[k]=` shipped twice.
  const clicked = {};
  for (const id of ["savecfg", "savechar", "halt", "ear", "eye"]) {
    const el = __els[id];
    if (!el || typeof el.onclick !== "function") { clicked[id] = "no handler"; continue; }
    /* Race every handler against a timeout. A handler whose promise never
       settles - the mic loop does exactly that - would otherwise leave the
       event loop empty, node would exit with no output at all, and the whole
       suite would report nothing rather than a failure. */
    try {
      const r = el.onclick({preventDefault(){}, stopPropagation(){}});
      await Promise.race([Promise.resolve(r),
        new Promise(res => setImmediate(() => res("pending")))]);
      clicked[id] = "ok";
    } catch (e) { clicked[id] = String((e && e.name) || e); }
  }
  // ── the camera, from a cold start, exactly as reported ──────────────
  //
  // Asserting on __cam.frames - the number of times a canvas was actually
  // encoded - rather than on a CSS class or on `pendingImg`. pendingImg is
  // declared with `let`, which under runInThisContext is lexical and never
  // lands on globalThis, so reading it always gave false and the test
  // reported a failure the page did not have.
  const cam = {};
  try {
    __cam.granted = false; __cam.calls.length = 0; __cam.frames = 0;
    document.getElementById("camsel").value = "";
    await globalThis.grabFrame();
    cam.cold = {ok: __cam.frames > 0, calls: __cam.calls.slice(),
                granted: __cam.granted};

    // a specific camera, now that permission exists and ids are real
    __cam.frames = 0; __cam.calls.length = 0;
    document.getElementById("camsel").value = "cam-usb";
    await globalThis.grabFrame();
    cam.picked = {ok: __cam.frames > 0, calls: __cam.calls.slice()};

    // a camera held by another application
    __cam.frames = 0; __cam.calls.length = 0; __cam.denyBusy = true;
    await globalThis.grabFrame();
    cam.busy = {ok: __cam.frames > 0, tries: __cam.calls.length};
    __cam.denyBusy = false;

    // no camera at all
    __cam.frames = 0; __cam.calls.length = 0; __cam.present = false;
    await globalThis.grabFrame();
    cam.none = {ok: __cam.frames > 0, tries: __cam.calls.length};
    __cam.present = true;
  } catch (e) { cam.fatal = String((e && e.stack) || e).slice(0, 300); }

  const sel = __els["model"];
  console.log(JSON.stringify({
    fatal: null,
    model_options: sel ? sel.options.map(o=>o.value) : null,
    reached_end: typeof globalThis.refresh === "function",
    has_send: typeof globalThis.send !== "undefined",
    clicked: clicked,
    posted: __posted,
    cam: cam,
  }));
})();
""" % (json.dumps(STATE), json.dumps(sorted(IDS)))

    (tmp / "run.js").write_text(shim, encoding="utf-8")
    r = subprocess.run([node, str(tmp / "run.js")], capture_output=True,
                       text=True, timeout=60, cwd=tmp)
    out = {}
    for line in (r.stdout or "").splitlines():
        try:
            out = json.loads(line)
        except Exception:
            pass

    check("the script runs top to bottom without throwing",
          out.get("fatal") is None,
          str(out.get("fatal") or "")[:200] or (r.stderr or "")[:200])
    check("execution reaches the end, so refresh() is defined",
          bool(out.get("reached_end")),
          "a top-level throw stops every later line, including the poller")

    # ---------------------------------------------------------------- 3
    section(3, "THE MODEL BAR IS POPULATED  (the reported failure)")
    opts = out.get("model_options")
    # ---------------------------------------------------------------- 3b
    bad = {k: v for k, v in (out.get("clicked") or {}).items()
           if v not in ("ok", "no handler")}
    check("every button handler runs without throwing", not bad,
          "; ".join(f"{k}: {v[:70]}" for k, v in bad.items()))
    posted = out.get("posted") or []
    check("Save settings actually POSTs the config",
          any("/api/config" in u for u in posted),
          f"POSTed: {posted}")

    # ---------------------------------------------------------------- 3c
    cam = out.get("cam") or {}
    cold = cam.get("cold") or {}
    check("a camera works on the FIRST try, before any permission exists",
          cold.get("ok"),
          f"calls: {cold.get('calls')}")
    check("and it never asks for a device id it cannot have yet",
          not any('"exact":""' in c.replace(" ", "")
                  for c in (cold.get("calls") or [])),
          "deviceId {exact:''} is the OverconstrainedError")
    picked = cam.get("picked") or {}
    check("a chosen camera is still honoured once ids are real",
          picked.get("ok") and any("cam-usb" in c
                                   for c in (picked.get("calls") or [])),
          str(picked.get("calls"))[:110])
    none = cam.get("none") or {}
    check("no camera at all fails cleanly instead of looping the ladder",
          none.get("ok") is False and none.get("tries", 9) <= 4,
          f"{none.get('tries')} attempt(s)")
    busy = cam.get("busy") or {}
    check("a camera held by another app fails once, not four times",
          busy.get("ok") is False and busy.get("tries") == 1,
          f"{busy.get('tries')} attempt(s) - retrying a busy device only "
          f"re-prompts")

    check("the model dropdown receives the models from /api/state",
          bool(opts), f"got {opts}")
    check("both models on disk are listed",
          opts is not None and len(opts) == 2, str(opts))
    check("and they are listed by filename, which is what /api/model wants",
          bool(opts) and opts[0].endswith(".gguf"), str((opts or [])[:1]))

shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------- 4

section(4, "TABS AND PANES AGREE")

tabs = set(re.findall(r'id="tab_([a-z]+)"', MARKUP))
# Derive panes from what tab() actually switches, not from every id that
# happens to begin with v_ - v_rate and v_pitch are slider readouts.
panes = set(re.findall(r'\["tab_([a-z]+)","v_[a-z]+"\]', JS))
panes |= set(re.findall(r'id="v_([a-z]+)" class="hide"', MARKUP))
panes |= {"mem"}
check("every tab button has a pane", not (tabs - panes),
      f"buttons with no pane: {sorted(tabs - panes)}")
check("every pane has a tab button", not (panes - tabs),
      f"panes with no button: {sorted(panes - tabs)}")
check("the surface is small enough to take in at a glance",
      len(tabs) <= 3, f"{len(tabs)} tabs: {sorted(tabs)}")

switched = sorted(re.findall(r'id="t_([a-z_]+)"', MARKUP))
check("web search is the only tool switch", switched == ["web_search"],
      str(switched))

# THE WHOLE SHEET IS NO LONGER REACHABLE, ON PURPOSE.
#
# It used to be one 13,000-character textarea. Almost none of it was the
# user's - it is the application explaining itself to the model - and an
# editable box containing that wiring is an invitation to delete the
# paragraph that stops her announcing actions she never takes. Settings now
# shows the three blocks character.md marks as theirs, and nothing else.
check("the part of the prompt that is the user's is reachable",
      "personafields" in MARKUP and 'which==="set"' in JS,
      "it must live in a pane a button can actually open")
check("the wiring is not offered as an editable box",
      "charbox" not in MARKUP and "/api/character" not in JS,
      "the whole system prompt is editable again")


# ---------------------------------------------------------------- 5

section(5, "EVERY CALL THE PAGE MAKES HAS A ROUTE BEHIND IT")

# The character class has to include "/" on BOTH sides of this comparison.
# Without it a nested route like /api/purge/stage was invisible to the left
# side and truncated to "/api/purge" on the right, so the first nested
# endpoint added to the application reported itself as dead - a false alarm
# about the one thing this check exists to catch honestly.
server_src = (HERE / "server.py").read_text(encoding="utf-8")
routes = set(re.findall(r'p == "(/api/[A-Za-z0-9_/-]+)"', server_src))
routes |= set(re.findall(r'p\.startswith\("(/api/[A-Za-z0-9_/-]+/)"\)', server_src))
called = set(re.findall(r'fetch\("(/api/[A-Za-z0-9_/-]+)', JS))

dead = sorted(c for c in called
              if c not in routes and not any(c.startswith(r) for r in routes))
check("no call goes to an endpoint that was removed", not dead, str(dead))


print("\n" + "=" * 62)
print(f"  {len(PASS)} passed, {len(FAIL)} failed")
for f in FAIL:
    print(f"    FAILED: {f}")
print("=" * 62)
raise SystemExit(1 if FAIL else 0)
