"""
test_purge.py - erasing memory really erases, and cannot happen by accident.

TWO CLAIMS, AND BOTH HAVE TO HOLD

A purge that does not fully erase is worse than no purge at all: the user
believes something is gone and it is still on disk, or still in the running
process's cache waiting to be written back. So half of this checks that the
data is genuinely destroyed - files, and the in-memory tree that would
otherwise re-save itself on the next write.

The other half checks the opposite: that it takes two deliberate steps. The
whole point of the second screen is that a single mis-click cannot reach the
destructive call. That is only true if the server refuses a commit that has
no valid token - so every way of arriving at commit() without having meant to
is tested here as a refusal, not a deletion.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

C = {"g": "\033[92m", "r": "\033[91m", "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0}


def check(label, cond, detail=""):
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


TMP = Path(tempfile.mkdtemp(prefix="hub-purge-"))
import core                                                       # noqa: E402
core.DATA = TMP / "data"
core.TREE = core.DATA / "tree"
core.KNOWLEDGE = core.DATA / "knowledge"
core.ASH = core.DATA / "ash"
core.EVENTS = core.DATA / "events"
core.SESSIONS = core.DATA / "sessions"
core.LOGS = core.DATA / "logs"
core.CONFIG = TMP / "config.json"
core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                 core.EVENTS, core.SESSIONS, core.LOGS)
core.ensure_dirs()

import events, grove, memory, purge                               # noqa: E402
events.LOG = core.EVENTS / "events.jsonl"
grove.ASH_FILE = core.ASH / "ash.jsonl"
memory.YESOD_DIR = core.TREE / "yesod"
memory.ARCHIVE_DIR = core.SESSIONS / "archive"
memory.UNSORTED = core.TREE / "unsorted.jsonl"
memory.ACTIVE_DIR = core.DATA / "active"
memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"


def fill():
    """Put real things into memory so there is something to lose."""
    memory._limbs = {}
    memory._loaded = False
    memory.graft("keter", "Goes by Zero and builds local AI systems",
                 origin="user", truth="confirmed")
    memory.graft("gevurah", "Everything must run offline", origin="user")
    memory.graft("hod", "Coconuts are tropical fruits", origin="user")
    memory.save_session("test-session", [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hello back"}])
    memory.active_move("a bracket, 60mm, two holes", kind="user_turn")
    return memory.status()


def main() -> int:
    print("\n1. IT COUNTS WHAT IS THERE BEFORE IT OFFERS TO DELETE IT")
    st = fill()
    check("memory was filled for the test", st["leaves"] >= 3,
          f"{st['leaves']} leaves, {st['events']} events, "
          f"{st['sessions']} session(s)")

    pv = purge.preview("everything")
    named = {i["name"]: i["count"] for i in pv["items"]}
    check("the preview counts real memories", named.get("memories", 0) >= 3,
          str(named))
    check("and real conversations",
          named.get("saved conversations", 0) >= 1)
    check("and real events", named.get("recorded events", 0) >= 3)
    check("it says plainly that everything cannot be undone",
          pv["reversible"] is False and "cannot" in pv["keeps"])
    check("while clearing memories alone CAN be undone",
          purge.preview("memories")["reversible"] is True,
          "the event log survives that one, so rebuild works")

    print("\n2. NOTHING IS DELETED WITHOUT A CONFIRMATION")
    before = memory.status()["leaves"]
    for token, label in (("", "an empty token"),
                         ("made-up-token", "a token nobody issued"),
                         ("x" * 24, "a plausible-looking invented token")):
        try:
            purge.commit(token, "everything")
            check(f"{label} is refused", False, "IT DELETED")
        except PermissionError as e:
            check(f"{label} is refused", True, str(e)[:80])
    check("and nothing was lost while trying",
          memory.status()["leaves"] == before, f"{before} leaves still there")

    print("\n3. A CONFIRMATION IS SINGLE USE, SCOPED, AND EXPIRES")
    staged = purge.stage("ash")
    check("staging returns a token and a description",
          bool(staged.get("token")) and staged["scope"] == "ash")
    check("staging on its own deletes nothing",
          memory.status()["leaves"] == before)
    try:
        purge.commit(staged["token"], "everything")
        check("a token staged for one scope cannot erase another", False,
              "IT DELETED - this is the dangerous one")
    except PermissionError as e:
        check("a token staged for one scope cannot erase another", True,
              str(e)[:90])

    purge.commit(staged["token"], "ash")
    try:
        purge.commit(staged["token"], "ash")
        check("a token cannot be used twice", False, "IT DELETED AGAIN")
    except PermissionError as e:
        check("a token cannot be used twice", True, str(e)[:80])

    old = purge.stage("ash")
    purge._STAGED[old["token"]]["at"] -= (purge.TOKEN_TTL + 5)
    try:
        purge.commit(old["token"], "ash")
        check("an expired token is refused", False, "IT DELETED")
    except PermissionError as e:
        check("an expired token is refused", True, str(e)[:80])
    check("the window is short enough to matter", purge.TOKEN_TTL <= 300,
          f"{purge.TOKEN_TTL:.0f}s")

    print("\n4. A NARROW SCOPE TAKES ONLY WHAT IT SAID IT WOULD")
    st = fill()
    leaves_before = st["leaves"]
    events_before = st["events"]
    s = purge.stage("conversations")
    r = purge.commit(s["token"], "conversations")
    check("conversations are gone", memory.status()["sessions"] == 0,
          r["message"][:100])
    check("but the memories are not", memory.status()["leaves"] == leaves_before,
          f"{memory.status()['leaves']} leaves kept")
    check("and neither is the event log",
          memory.status()["events"] >= events_before)
    check("the Vault and Playground were never in scope",
          all(n not in r["removed"] for n in ("vault", "playground")),
          f"removed: {r['removed']}")

    print("\n5. CLEARING MEMORIES KEEPS THE LOG, SO IT CAN BE REBUILT")
    st = fill()
    s = purge.stage("memories")
    purge.commit(s["token"], "memories")
    check("memory is empty afterwards", memory.status()["leaves"] == 0,
          f"{memory.status()['leaves']} leaves")
    check("the event log survived", memory.status()["events"] > 0,
          f"{memory.status()['events']} events")
    rebuilt = memory.rebuild()
    check("and rebuilding brings the memories back",
          rebuilt.get("leaves", 0) > 0,
          f"{rebuilt.get('leaves')} leaves restored from the log alone")

    print("\n6. ERASING EVERYTHING LEAVES NOTHING, INCLUDING IN MEMORY")
    st = fill()
    check("filled again", st["leaves"] >= 3, f"{st['leaves']} leaves")
    s = purge.stage("everything")
    r = purge.commit(s["token"], "everything")
    check("the call reports success", r["ok"], r["message"][:110])

    now = memory.status()
    check("no memories remain", now["leaves"] == 0, f"{now['leaves']}")
    check("no conversations remain", now["sessions"] == 0)
    check("the event log itself is gone", now["events"] <= 1,
          f"{now['events']} - the only line allowed is the purge receipt")

    leaked = [q.name for q in (core.TREE.rglob("*") if core.TREE.is_dir() else [])
              if q.is_file()]
    check("nothing is left in the tree folder", not leaked, str(leaked[:5]))

    # THE CACHE IS THE TRAP, and it is not enough to check a flag right after
    # the delete - status() reloads lazily and would set it again. What
    # matters is whether the process can WRITE THE OLD TREE BACK OUT. So:
    # force a save, then read the disk fresh, and see if anything returned.
    try:
        memory.save()
    except Exception:
        pass
    memory._limbs = {}
    memory._loaded = False
    revived = memory.status()["leaves"]
    check("saving after a purge does not write the old memories back",
          revived == 0,
          f"{revived} leaf/leaves came back from the in-process cache")

    print("\n7. THERE IS A RECEIPT, AND IT SAYS WHAT WENT")
    receipt = [e for e in events.read() if e.get("k") == "memory.purged"]
    check("a purge is recorded", bool(receipt))
    if receipt:
        d = receipt[-1].get("d") or {}
        check("the receipt names the scope", d.get("scope") == "everything",
              str(d.get("scope")))
        check("and how much went, without keeping the content",
              d.get("memories", 0) > 0 and "text" not in d,
              f"{d.get('memories')} item(s), {d.get('megabytes')} MB")

    print("\n8. IT KEEPS WORKING AFTERWARDS")
    ok = memory.graft("keter", "Something new, after the purge",
                      origin="user", truth="confirmed")
    check("a new memory can be stored right away", ok)
    check("and it is the only one there", memory.status()["leaves"] == 1,
          f"{memory.status()['leaves']} leaf")
    check("no confirmations are left staged", purge.pending() == 0)

    shutil.rmtree(TMP, ignore_errors=True)
    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
