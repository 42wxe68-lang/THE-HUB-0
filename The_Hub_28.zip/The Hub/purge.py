"""
purge.py - erase memory, on purpose, with a receipt.

WHY THIS IS ITS OWN MODULE AND NOT THREE LINES IN A HANDLER

Everything else in this application is built so that nothing is ever really
lost. A faded leaf falls to ash and is kept forever. A disproven claim keeps
its evidence and changes its truth state. A session is archived, not deleted.
The event log is append-only, and the whole tree can be rebuilt from it -
that is the property that makes the system repairable.

A purge is the one operation that breaks all of that deliberately. It is the
user saying: not archived, not decayed, not superseded - gone. Something that
destructive deserves to be one place, written out plainly, rather than a
shutil.rmtree buried in a route handler.

THREE THINGS MAKE IT SAFE

1. IT IS TWO STEPS, NEVER ONE. `stage()` returns a token and a description of
   exactly what would go. `commit(token)` is the only thing that deletes, and
   it will not accept a token it did not issue, a token for a different scope,
   a token already used, or a token more than two minutes old. A single
   mis-click cannot reach the second step, because the second step does not
   exist until the first one has been taken.

2. IT SAYS WHAT IT WILL DO BEFORE IT DOES IT. `preview()` counts the real
   leaves, branches, ash, events, sessions and files on disk. The dialog shows
   those numbers. "Delete everything?" is not a question anybody can answer
   responsibly; "delete 412 memories, 38 conversations and 1,204 events?" is.

3. IT KEEPS A RECEIPT. Every purge writes one final line to a fresh event log
   saying what was destroyed and when. Not the content - that is the point -
   but the shape of it. A memory that goes silent with no record of why is
   indistinguishable from a memory that broke.

SCOPES

    conversations   sessions and their archive. Memory keeps everything it
                    learned; only the transcripts go.
    ash             what already faded. Frees space, loses nothing live.
    active          the moving frontier - recent working context only.
    memories        the trees: leaves, branches, knowledge, ash, frontier.
                    The event log SURVIVES, so this is reversible with
                    Rebuild from events.
    everything      the trees AND the event log AND the transcripts. Nothing
                    survives and nothing can be rebuilt. This is the one that
                    needs the second click.

Config, models, the Vault and the Playground are never touched by any scope.
Those are the user's files and their machine, not the assistant's memory.
"""
from __future__ import annotations

import os
import secrets
import shutil
import sys
import threading
import time
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import core

# A staged purge is valid for two minutes. Long enough to read the dialog and
# think about it; short enough that a token left open in a forgotten tab
# cannot be clicked into effect an hour later.
TOKEN_TTL = 120.0

_LOCK = threading.RLock()
_STAGED: dict[str, dict] = {}


SCOPES = {
    "conversations": {
        "label": "conversations",
        "what": "every saved conversation and its archive",
        "keeps": "everything Nova learned from them stays in memory",
    },
    "ash": {
        "label": "ash",
        "what": "everything that has already faded out of memory",
        "keeps": "nothing live is affected",
    },
    "active": {
        "label": "recent working memory",
        "what": "the moving frontier of what was recently active",
        "keeps": "the trees and the event log are untouched",
    },
    "memories": {
        "label": "memories",
        "what": "the Tree of Life, the Knowledge Tree, ash and the frontier",
        "keeps": "the event log survives, so Rebuild from events restores it",
    },
    # THE PLAYGROUND FILLS UP, AND NOTHING EVER EMPTIED IT.
    #
    # Every generated image, video and mesh lands there and stays. After a
    # few sessions that is gigabytes on the user's disk, which is what the
    # "memory constraint issue with the file buildup in the playground" was.
    #
    # It is safe to clear because it is scratch, and because there is now
    # somewhere else to put the things worth keeping: Nova offers a file,
    # the user says yes, and it MOVES into vault/Made. Anything still in the
    # Playground is either working state or something nobody chose. This
    # scope never touches the Vault, so nothing kept can be lost by it.
    "playground": {
        "label": "the Playground",
        "what": "every working file Nova has generated but nobody kept",
        "keeps": "your Vault is untouched, including everything under Made",
    },
    "everything": {
        "label": "everything",
        "what": "all memory, all conversations, and the event log itself",
        "keeps": "nothing - this cannot be undone or rebuilt",
    },
}


# ---------------------------------------------------------------- what is there

def _count_files(folder: Path, pattern: str = "*") -> int:
    try:
        return sum(1 for q in folder.glob(pattern) if q.is_file())
    except OSError:
        return 0


def _dir_bytes(folder: Path) -> int:
    total = 0
    try:
        for q in folder.rglob("*"):
            if q.is_file():
                try:
                    total += q.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return total


def preview(scope: str = "everything") -> dict:
    """
    Exactly what this scope would destroy, counted from disk right now.

    Counted, not estimated. A confirmation dialog that says "are you sure?"
    is asking the user to authorise something neither of you has looked at.
    """
    scope = (scope or "everything").strip().lower()
    if scope not in SCOPES:
        raise ValueError(f"unknown purge scope {scope!r}. "
                         f"Known: {', '.join(sorted(SCOPES))}")

    import memory
    import events as _events

    try:
        st = memory.status()
    except Exception:
        st = {}

    items = []
    targets = _targets(scope)

    if scope in ("memories", "everything"):
        items.append(("memories", int(st.get("leaves", 0) or 0)))
        items.append(("branches", int(st.get("branches", 0) or 0)))
        items.append(("things in ash", int(st.get("ash", 0) or 0)))
    if scope == "ash":
        items.append(("things in ash", int(st.get("ash", 0) or 0)))
    if scope in ("conversations", "everything"):
        items.append(("saved conversations", int(st.get("sessions", 0) or 0)))
        items.append(("archived conversations", int(st.get("archived", 0) or 0)))
    if scope in ("active", "memories", "everything"):
        act = st.get("active") or {}
        n = act.get("entries") if isinstance(act, dict) else 0
        items.append(("recent working entries", int(n or 0)))
    if scope == "everything":
        try:
            items.append(("recorded events", int(_events.count())))
        except Exception:
            pass
    if scope == "playground":
        try:
            import playground as _pg
            items.append(("working files", len(_pg.list_files())))
        except Exception:
            pass

    size = sum(_dir_bytes(t) for t in targets if t.is_dir())
    spec = SCOPES[scope]
    return {
        "scope": scope,
        "label": spec["label"],
        "what": spec["what"],
        "keeps": spec["keeps"],
        "reversible": scope != "everything",
        "items": [{"name": n, "count": c} for n, c in items if c or True],
        "total": sum(c for _, c in items),
        "mb": round(size / 1048576.0, 1),
        "paths": [t.name for t in targets],
    }


def _targets(scope: str) -> list:
    """The directories a scope removes. Never config, models, Vault or
    Playground - those are the user's, not the assistant's."""
    d = core.DATA
    if scope == "conversations":
        return [core.SESSIONS]
    if scope == "ash":
        return [core.ASH]
    if scope == "active":
        return [d / "active"]
    if scope == "playground":
        import playground as _pg
        return [_pg.ROOT]
    if scope == "memories":
        return [core.TREE, core.KNOWLEDGE, core.ASH, d / "active"]
    # everything
    return [core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS, core.SESSIONS,
            d / "active", d / "chat_attachments"]


# ---------------------------------------------------------------- two steps

def stage(scope: str = "everything") -> dict:
    """
    Step one. Describes the damage and issues a single-use token.

    Deletes nothing. This exists so that the destructive call needs something
    the caller can only have got by asking first - which is what makes one
    stray click harmless.
    """
    detail = preview(scope)
    token = secrets.token_urlsafe(18)
    with _LOCK:
        now = time.time()
        for k, v in list(_STAGED.items()):
            if now - v["at"] > TOKEN_TTL:
                _STAGED.pop(k, None)
        _STAGED[token] = {"scope": detail["scope"], "at": now, "used": False}
    detail["token"] = token
    detail["expires_in"] = int(TOKEN_TTL)
    return detail


def _check(token: str, scope: str) -> str:
    """Why this token is not usable, or "" if it is."""
    with _LOCK:
        rec = _STAGED.get(token or "")
        if rec is None:
            return ("that confirmation is not one this session issued - "
                    "start again")
        if rec["used"]:
            return "that confirmation has already been used"
        if time.time() - rec["at"] > TOKEN_TTL:
            _STAGED.pop(token, None)
            return ("that confirmation expired - it is only valid for "
                    f"{int(TOKEN_TTL)} seconds")
        if rec["scope"] != scope:
            return (f"that confirmation was for {rec['scope']!r}, not "
                    f"{scope!r}")
    return ""


def commit(token: str, scope: str = "everything") -> dict:
    """
    Step two. The only function here that deletes anything.

    Refuses a token it did not issue, one already used, one that has expired,
    and one staged for a different scope. Each of those is a different way of
    arriving here without having meant to.
    """
    scope = (scope or "everything").strip().lower()
    if scope not in SCOPES:
        raise ValueError(f"unknown purge scope {scope!r}")
    why = _check(token, scope)
    if why:
        raise PermissionError(why)

    before = preview(scope)

    with _LOCK:
        _STAGED[token]["used"] = True

    removed, failed = [], []
    for target in _targets(scope):
        if not target.exists():
            continue
        try:
            shutil.rmtree(target)
            removed.append(target.name)
        except Exception as e:
            failed.append(f"{target.name}: {type(e).__name__}")

    # Put the empty rooms back, so nothing has to check whether a directory
    # exists before writing to it for the rest of the session.
    for target in _targets(scope):
        try:
            target.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
    try:
        core.ensure_dirs()
    except Exception:
        pass

    _reload_memory()

    # THE RECEIPT. Written after the delete, into whatever event log now
    # exists - which for scope "everything" is a brand new empty one. It is
    # the first line of the new history, and it says what the old one was.
    try:
        import events
        events.write("memory.purged", scope=scope,
                     removed=", ".join(removed) or "nothing",
                     memories=before.get("total", 0),
                     megabytes=before.get("mb", 0.0))
    except Exception:
        pass
    try:
        core.log_line("memory",
                      f"PURGE {scope}: removed {', '.join(removed) or 'nothing'}"
                      + (f" (failed: {'; '.join(failed)})" if failed else ""))
    except Exception:
        pass

    after = {}
    try:
        import memory
        after = memory.status()
    except Exception:
        pass

    return {
        "ok": not failed,
        "scope": scope,
        "removed": removed,
        "failed": failed,
        "before": before,
        "leaves": int(after.get("leaves", 0) or 0),
        "events": int(after.get("events", 0) or 0),
        "sessions": int(after.get("sessions", 0) or 0),
        "message": _summary(scope, before, failed),
    }


def _summary(scope: str, before: dict, failed: list) -> str:
    n = before.get("total", 0)
    mb = before.get("mb", 0.0)
    if failed:
        return (f"Purged what it could of {before.get('label', scope)}, but "
                f"some of it could not be removed: {'; '.join(failed)}. "
                f"Something else on this machine may have those files open.")
    if scope == "everything":
        return (f"Everything is gone - {n} item(s), {mb} MB. There is no "
                f"event log to rebuild from. Nova starts from nothing.")
    if scope == "memories":
        return (f"Memory cleared - {n} item(s), {mb} MB. The event log "
                f"survived, so Rebuild from events will bring it back.")
    return (f"Cleared {before.get('label', scope)} - {n} item(s), {mb} MB. "
            f"{before.get('keeps', '')}")


def _reload_memory() -> None:
    """
    Make the running process forget too.

    Deleting the files is not enough on its own: the tree is held in memory
    and would carry on answering from a cache of things that no longer exist,
    then write that cache back to disk on the next save and undo the purge.
    """
    try:
        import memory
        with memory._lock:
            memory._limbs = {}
            memory._loaded = False
    except Exception:
        pass
    try:
        import index
        if hasattr(index, "invalidate"):
            index.invalidate()
    except Exception:
        pass
    try:
        import knowledge
        if hasattr(knowledge, "reload"):
            knowledge.reload()
    except Exception:
        pass


def pending() -> int:
    """How many staged purges are still live. For tests and diagnostics."""
    with _LOCK:
        now = time.time()
        return sum(1 for v in _STAGED.values()
                   if not v["used"] and now - v["at"] <= TOKEN_TTL)
