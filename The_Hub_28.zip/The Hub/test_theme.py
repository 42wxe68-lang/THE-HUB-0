from pathlib import Path
import re

html=Path(__file__).with_name("ui.html").read_text(encoding="utf-8")
assert 'id="c_idle"' in html and 'id="c_think"' in html and 'id="c_tool"' in html
assert 'id="c_pattern"' in html and 'value="spectrum"' in html and 'value="cycle"' in html
assert 'id="statusbar"' in html and 'id="resetcolors"' in html
js=re.search(r"<script[^>]*>([\s\S]*)</script>",html,re.S).group(1)
for needle in ["function applyTheme", "function setMode", "body.rgb-cycle", "speechBusy", "localStorage.setItem(\"hub-theme\"", "setMode(\"speak\")"]:
    assert needle in (html if needle.startswith("body.") else js), needle
print("theme checks passed")
