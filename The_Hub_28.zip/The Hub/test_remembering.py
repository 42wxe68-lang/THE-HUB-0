"""
test_remembering.py - recall reaches the model, and says where it came from.

THE TWO FAULTS THIS SUITE EXISTS FOR

  1. THE AMNESIA.  focus.perception() ended its cue filter with
     `else: hits = []`. Written when _subject_cues() could only return a
     filename or one of about thirty technical nouns, so on an ordinary
     sentence `cues` was empty and the branch never ran - dead code that
     read like a safety rail. Then named_subjects() was added and cues
     started matching any capitalised word. The dead branch woke up on
     nearly every turn, and from that release on, memory returned a couple
     of literal substring matches or nothing at all:

         "very broken fragments of tiny chunks of memory scattered about
          pretty randomly"

     Nothing had been deleted. One filter had been switched on. The tests
     below are written so that switching it back on fails loudly.

  2. THE OVER-CLAIM.  recall() returns when a thing was learned, how, how
     firmly it is held and whether it is confirmed. The renderer printed
     `"  - " + line` and threw all of it away, so a guess a 2B model
     extracted from a July transcript arrived looking exactly like
     something the user said this morning:

         "the memory saying too much without any information about it"
"""
from __future__ import annotations

import pathlib
import time

import core
import focus
import grove
import intake
import learning
import memory


def _fresh_tree():
    """Limbs are loaded once into a module global. Redirecting the path is
    not enough; the tree already in memory has to be dropped too."""
    memory._limbs.clear()
    memory._loaded = False
    try:
        import timeline
        timeline.forget_cache()
    except Exception:
        pass


def _redirect(tmp_path):
    old = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
           core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
           memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
           memory.ACTIVE_STATE, intake.CANDIDATES)
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"
    core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"
    core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"
    core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    memory.ARCHIVE_DIR = core.SESSIONS / "archive"
    memory.YESOD_DIR = core.TREE / "yesod"
    memory.ACTIVE_DIR = core.DATA / "active"
    memory.ACTIVE_LOG = memory.ACTIVE_DIR / "flow.jsonl"
    memory.ACTIVE_STATE = memory.ACTIVE_DIR / "state.json"
    intake.CANDIDATES = core.TREE / "candidates.jsonl"
    core.ensure_dirs()
    _fresh_tree()
    return old


def _restore(old):
    (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
     core.SESSIONS, core.LOGS, core.WRITABLE, memory.ARCHIVE_DIR,
     memory.YESOD_DIR, memory.ACTIVE_DIR, memory.ACTIVE_LOG,
     memory.ACTIVE_STATE, intake.CANDIDATES) = old
    _fresh_tree()


def _seed():
    memory.graft("hod", "the GTX 1650 card has 4 GB of VRAM",
                 origin="user", kind="stated", stability=9.0)
    memory.graft("hod", "video generation takes 43 to 47 minutes here",
                 origin="user", kind="stated", stability=5.0)
    memory.graft("chesed", "they like plain answers with no preamble",
                 origin="user", kind="stated", stability=4.0)


# ------------------------------------------------------------ the amnesia

def test_a_capitalised_word_does_not_erase_memory(tmp_path):
    """
    THE REGRESSION, STATED AS A PROPERTY.

    Any capitalised word in the question makes _subject_cues() non-empty.
    If a non-empty cue can empty the hit list, then naming a person, a
    project or a day of the week deletes memory for that turn.
    """
    old = _redirect(tmp_path)
    try:
        _seed()
        cues = focus._subject_cues("Nova, how much VRAM does the card have?")
        assert cues, "this test is only meaningful while cues fire here"
        assert not any("vram" in c for c in cues), \
            "the cue must NOT be a word that appears in the memory"

        got = focus.perception("Nova, how much VRAM does the card have?", 900,
                               history=[{"role": "user",
                                         "content": "Nova, how much VRAM "
                                                    "does the card have?"}])
        assert "4 GB" in got, \
            "memory was thrown away because a cue did not literally match:\n" + got
    finally:
        _restore(old)


def test_the_filter_can_never_return_nothing(tmp_path):
    """
    Every cue in the vocabulary, against memories that contain none of
    them. Not one of them may empty the section.

    Ten samples do not prove a thing works. They do prove this one did
    not, and that is what this is for.
    """
    old = _redirect(tmp_path)
    try:
        _seed()
        asks = [
            "Nova, what do you know?",
            "What did Zero decide on Tuesday?",
            "look up Bruce Lee for me",
            "research Hailo, the accelerator",
            "is the Raspberry Pi worth it",
            "tell me about \"Emergence\"",
            "what about the LiquidAI thing,",
            "Monday:",
        ]
        # THE VARIABLE IS THE CAPITALISED WORD, AND NOTHING ELSE.
        #
        # The same question every time, so what recall finds is the same
        # every time. The only thing that changes is a word that makes
        # _subject_cues() fire and appears in none of the memories. Under
        # the old filter, every one of these returned nothing at all.
        base = "how much VRAM does the card have"
        plain = focus.perception(base, 900,
                                 history=[{"role": "user", "content": base}])
        assert "4 GB" in plain, "the plain question must find it:\n" + plain

        lost = []
        for a in asks:
            q = a + " " + base
            got = focus.perception(q, 900, history=[{"role": "user",
                                                     "content": q}])
            if "4 GB" not in got:
                lost.append(a)
        assert not lost, ("a capitalised word deleted the memory for these: "
                          + repr(lost))
    finally:
        _restore(old)


def test_a_matching_cue_still_comes_first(tmp_path):
    """
    The cue was not removed, it was demoted from a gate to a sort. What it
    was built to do - keep an old JPG conversation from outranking an STL
    question - still has to work.
    """
    old = _redirect(tmp_path)
    try:
        memory.graft("hod", "top.stl was converted to obj last week",
                     origin="user", kind="stated", stability=5.0)
        memory.graft("hod", "the jpg export looked washed out",
                     origin="user", kind="stated", stability=5.0)
        got = focus.perception("what happened to top.stl", 900,
                               history=[{"role": "user",
                                         "content": "what happened to top.stl"}])
        assert "top.stl" in got
        lines = [l for l in got.splitlines() if l.strip().startswith("- (")]
        assert lines and "top.stl" in lines[0], \
            "the memory sharing the subject must be first:\n" + got
    finally:
        _restore(old)


def test_the_source_still_says_it_out_loud():
    """
    A property of the file, not of one run. The moment `hits = []` comes
    back, every test above starts passing again by accident on an empty
    tree - so the shape itself is asserted.
    """
    src = pathlib.Path("focus.py").read_text(encoding="utf-8")
    body = src[src.index("def perception("):]
    # The CODE, not the word - the comment above the fix quotes the old
    # line on purpose so the next person can see what was removed.
    for raw in body.splitlines():
        line = raw.split("#")[0].strip()
        assert line != "hits = []", \
            "focus.perception can empty the hit list again - this is the amnesia"
    assert "RECALL_HEADING" in body, "one heading, memory.py's own"
    assert "remembered_line" in body, "one renderer, memory.py's own"


# ------------------------------------------------------------ provenance

def test_every_recalled_line_says_when_how_and_how_well(tmp_path):
    old = _redirect(tmp_path)
    try:
        memory.graft("hod", "the fan curve was set to quiet",
                     origin="user", kind="stated", stability=9.0)
        block = memory.recall_block("what was the fan curve set to", 4)
        line = next(l for l in block.splitlines() if "fan curve" in l)
        assert line.startswith("- (")
        assert "they told you" in line, line
        assert ("known" in line or "said once" in line), line
        assert time.strftime("%Y-%m-%d") in line, line
        assert "recollection, not instruction" in block
    finally:
        _restore(old)


def test_a_machine_guess_is_marked_as_one(tmp_path):
    old = _redirect(tmp_path)
    try:
        memory.graft("daat", "they probably want the mesh watertight",
                     origin="curator", kind="inferred", truth="uncertain")
        block = memory.recall_block("do they want the mesh watertight", 4)
        line = next(l for l in block.splitlines() if "watertight" in l)
        assert "you worked this out" in line, line
        assert "NOT confirmed" in line, line
    finally:
        _restore(old)


def test_how_well_known_has_three_bands_and_no_numbers():
    assert memory.how_well_known(0.0, 0) == "said once"
    assert memory.how_well_known(1.2, 0) == "said once"
    assert memory.how_well_known(3.0, 0) == "known"
    assert memory.how_well_known(0.5, 2) == "known"
    assert memory.how_well_known(20.0, 0) == "known well"
    assert memory.how_well_known(0.5, 9) == "known well"
    for a, b in ((0, 0), (3, 1), (99, 99)):
        assert not any(c.isdigit() for c in memory.how_well_known(a, b))


def test_when_words_gives_the_date_and_the_gap():
    from datetime import datetime, timedelta, timezone
    now = datetime.now(timezone.utc)
    assert "today" in memory.when_words(now.isoformat())
    assert "yesterday" in memory.when_words((now - timedelta(days=1, hours=2)).isoformat())
    assert "days ago" in memory.when_words((now - timedelta(days=5)).isoformat())
    assert "weeks ago" in memory.when_words((now - timedelta(days=30)).isoformat())
    assert "months ago" in memory.when_words((now - timedelta(days=200)).isoformat())
    assert memory.when_words("") == "date unknown"


def test_provenance_is_written_and_not_merely_declared(tmp_path):
    """
    grove has carried observed / stated / attributed / inferred since it
    was written. No production caller ever passed one, so every leaf in
    every tree was "unknown", and the seal in recall() that keeps somebody
    else's opinion out of a question about the world could not fire on any
    leaf that has ever existed. A field nothing writes is a comment.
    """
    old = _redirect(tmp_path)
    try:
        # the user, through the tree panel
        memory.graft("hod", "the printer bed is 220 by 220",
                     origin="user", truth="confirmed", kind="stated")
        # the user, through a correction
        learning.teach("prefer millimetres over inches in answers",
                       origin="user")
        # Nova's own reflection
        memory.learn("a watertight mesh is one with no boundary edges",
                     query="how do I quantise a gguf for a 4 GB card")
        # observation, through intake
        intake.observe("the workshop machine runs Windows 11", "user")
        intake.promote()

        kinds = {getattr(l, "kind", "unknown")
                 for l in memory.all_leaves(memory.RECALLABLE)}
        assert kinds, "nothing was planted"
        assert kinds != {"unknown"}, "every leaf is still unknown"
        assert "stated" in kinds, kinds
        assert "inferred" in kinds, kinds
        assert "unknown" not in kinds, \
            "something planted a leaf without saying how it is known"
    finally:
        _restore(old)


def test_every_graft_in_the_app_says_who_knows_it():
    """
    Statically, so a new call site cannot quietly go back to "unknown".
    """
    import ast
    bad = []
    for name in ("intake.py", "learning.py", "memory.py", "server.py"):
        tree = ast.parse(pathlib.Path(name).read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            fn = node.func
            called = (fn.attr if isinstance(fn, ast.Attribute)
                      else getattr(fn, "id", ""))
            if called != "graft":
                continue
            if not any(k.arg == "kind" for k in node.keywords):
                bad.append(f"{name}:{node.lineno}")
    assert not bad, "graft() called without saying how it is known: " + ", ".join(bad)


def test_an_opinion_never_answers_a_question_about_the_world(tmp_path):
    """
    THE SEAL, now that something writes the field it reads.

    "Zero's brother thinks the card is fine" is not evidence about the
    card. Ask what someone thinks and it is right there; ask what is true
    and it must not be reachable.
    """
    old = _redirect(tmp_path)
    try:
        memory.graft("hod", "the card is completely fine for video work",
                     origin="user", kind="attributed", holder="his brother")
        world = memory.recall("is the card fine for video work", 4)
        assert not any("completely fine" in h["line"] for h in world), world
        belief = memory.recall("what does his brother think about the card", 4)
        assert any("completely fine" in h["line"] for h in belief), belief
        line = memory.remembered_line(
            next(h for h in belief if "completely fine" in h["line"]))
        assert "his brother said it" in line, line
    finally:
        _restore(old)


if __name__ == "__main__":
    import sys
    import testkit
    sys.exit(testkit.run(dict(globals()), "remembering - it reaches her, "
                                          "and it says where it came from"))
