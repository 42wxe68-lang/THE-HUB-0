"""
test_logging.py - every log line carries the time it was written.

WHY THIS FILE EXISTS

Zero sent five logs so a repair could be checked against evidence. Four of
them settled their questions immediately. The fifth, tools.log, could not:

    promised an action without calling a tool (generate_video); pushed back once
    promised an action without calling a tool (generate_image); pushed back once
    ... thirty lines, not one of them stamped ...

The fix for the perseveration bug shipped somewhere in the middle of that
run. Which lines came before it and which came after is unrecoverable, so
the log could neither confirm the repair nor refute it. That is a worse
failure than a bug: a bug you can find, but an unordered log is a witness
who cannot say when.

Two rules locked here:
  1. core.log_line stamps every line it writes.
  2. It does not stamp twice - policy.py, memory.py and research.py already
     format their own, in two different shapes.

And one more, from the same lesson: the promise line records what was ASKED
next to what was PROMISED. Thirty identical "(generate_video)" entries look
the same whether the tool was right or wrong; with the ask beside it, a
wrong one is visible at a glance.
"""
from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

import core
import testkit

STAMP = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}")


def _logged(name: str, *lines: str) -> list[str]:
    """Write lines through core.log_line into a throwaway logs dir."""
    with tempfile.TemporaryDirectory() as d:
        old = core.LOGS
        core.LOGS = Path(d) / "logs"
        try:
            for line in lines:
                core.log_line(name, line)
            return (core.LOGS / f"{name}.log").read_text(
                encoding="utf-8").splitlines()
        finally:
            core.LOGS = old


def test_an_unstamped_line_gets_a_time():
    out = _logged("tools",
                  "promised an action without calling a tool (generate_3d)")
    assert len(out) == 1
    assert STAMP.match(out[0]), f"no time on the line: {out[0]!r}"
    assert "generate_3d" in out[0]


def test_every_line_gets_one_not_just_the_first():
    out = _logged("tools", "first", "second", "third")
    assert len(out) == 3
    for line in out:
        assert STAMP.match(line), f"unstamped: {line!r}"


def test_a_line_that_stamps_itself_is_not_stamped_twice():
    # policy.py's shape, and the shape runtime.py uses. Both must survive.
    for own in ("2026-09-05T15:08:25 REFUSE  generate_3d  tier=auto bad-args",
                "2026-09-01 07:17:26 tool phase failed: timed out"):
        out = _logged("policy", own)
        assert out[0] == own, f"double-stamped: {out[0]!r}"


def test_log_line_still_never_raises():
    # The contract that made it useful in the first place.
    old = core.LOGS
    core.LOGS = Path("/nonexistent-root-that-cannot-be-made/logs")
    try:
        core.log_line("tools", "this must not blow up")
    finally:
        core.LOGS = old


def test_the_promise_line_records_what_was_asked():
    src = Path("server.py").read_text(encoding="utf-8")
    i = src.index("promised an action without calling a ")
    window = src[i - 700:i + 400]
    assert "asked:" in window, (
        "the promise line names the tool but not the request - which is "
        "exactly what made thirty log lines unreadable")
    assert "recent_asks" in window, (
        "the ask must come from what the USER said, never from Nova's reply")


# --------------------------------------------------------------------------
#  THE WHOLE STORY SURVIVES, NOT A SUMMARY OF IT
#
#      "the model should see most of the information so it knows what went
#       wrong but we should know what went wrong even if it cannot"
#
#  Two audiences, two needs. The model has a small context and needs one
#  sentence it can pass on. We have a text editor and need everything.
#  Before this, both got a summary - and on four real failures the summary
#  was a picture of a loading bar.
# --------------------------------------------------------------------------

def _fail_log(output, **kw):
    import core, forge
    with tempfile.TemporaryDirectory() as d:
        old = core.LOGS
        core.LOGS = Path(d) / "logs"
        try:
            path = forge.keep_the_whole_log("video", output, **kw)
            return Path(path).read_text(encoding="utf-8") if path else ""
        finally:
            core.LOGS = old


def test_a_failed_run_keeps_every_line_it_printed():
    body = "\n".join(f"line {i}" for i in range(1, 3001))
    kept = _fail_log(body, seconds=2598.3, code=1,
                     argv=["sd-cli", "-M", "vid_gen"])
    for probe in ("line 1", "line 1500", "line 3000"):
        assert probe in kept, f"{probe!r} was dropped from the failure log"


def test_the_failure_log_says_what_ran_and_for_how_long():
    kept = _fail_log("boom", seconds=2598.3, code=1,
                     argv=["sd-cli", "-M", "vid_gen", "--steps", "12"])
    assert "43 min" in kept, "the duration is missing"
    assert "2598.1" in kept or "2598.3" in kept, "the raw seconds are missing"
    assert "vid_gen" in kept, "the command that failed is missing"
    assert "exit    : 1" in kept, "the exit code is missing"


def test_the_model_gets_one_sentence_and_we_get_the_file():
    """The two audiences, checked against each other in one test."""
    import forge
    whole = ("\n".join(f"[flow] [####....] {i}/12 {i * 1020.0}s"
                       for i in range(1, 11))
             + "\nerror: failed to allocate 4096 MB")
    for_the_model = forge._explain(whole)
    assert for_the_model == "error: failed to allocate 4096 MB", for_the_model
    assert len(for_the_model) < 240, "too long to sit in a small context"
    for_us = _fail_log(whole, seconds=10802.9, code="raised")
    assert "1/12" in for_us and "10/12" in for_us, (
        "the progress history is exactly what says where it died")


def test_run_writes_a_failure_log_and_names_it_in_the_line():
    src = Path("forge.py").read_text(encoding="utf-8")
    run = src[src.index("    def _run(self"):src.index("    def cancel(self")]
    assert run.count("keep_the_whole_log(") == 2, (
        "one of the two failure paths in _run does not keep its output")
    assert "full output:" in run, (
        "forge.log does not say where the whole thing was kept")
    mesh = src[src.index("    def mesh_from_image"):]
    assert "keep_the_whole_log(" in mesh, (
        "a failed 3D run still keeps only a 600-character excerpt")


if __name__ == "__main__":
    sys.exit(testkit.run(dict(globals()), "A LOG YOU CAN PUT IN ORDER"))
