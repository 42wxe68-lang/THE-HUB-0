"""The Hub Playground: model-owned working files.

Rules:
- Vault files are read-only to the model.
- Playground files may be created, copied, edited, renamed, deleted, converted,
  and executed by the model.
- Saving to the vault creates a new copy and never overwrites/deletes anything.
- All paths are confined to the Playground for writes/execution.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import core

ROOT = core.DATA / "playground"


def ensure() -> Path:
    ROOT.mkdir(parents=True, exist_ok=True)
    return ROOT


def _safe_rel(name: str) -> Path:
    rel = Path(str(name).replace("\\", "/"))
    if not name or rel.is_absolute() or ".." in rel.parts:
        raise ValueError("path must stay inside the Playground")
    return rel


def resolve(name: str, must_exist: bool = True) -> Path | None:
    try:
        rel = _safe_rel(name)
    except ValueError:
        return None
    p = (ROOT / rel).resolve()
    try:
        p.relative_to(ROOT.resolve())
    except ValueError:
        return None
    if must_exist and not p.is_file():
        return None
    return p


def _safe_name(name: str) -> str:
    p = _safe_rel(name)
    if len(p.parts) != 1:
        raise ValueError("output filename must be a single Playground filename")
    return p.name


def list_files() -> list[dict]:
    ensure()
    out = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and not p.name.startswith("."):
            out.append({"name": str(p.relative_to(ROOT)).replace("\\", "/"),
                        "size_mb": round(p.stat().st_size / 1048576, 3),
                        "suffix": p.suffix.lower()})
    return out


def copy_in(src: Path, dest_name: str | None = None) -> dict:
    ensure()
    src = Path(src).resolve()
    if not src.is_file():
        raise FileNotFoundError(src)
    name = dest_name or src.name
    rel = _safe_rel(name)
    dest = (ROOT / rel).resolve()
    try:
        dest.relative_to(ROOT.resolve())
    except ValueError:
        raise ValueError("destination escapes Playground")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        raise FileExistsError(dest.name)
    shutil.copy2(src, dest)
    return {"ok": True, "name": str(dest.relative_to(ROOT)).replace("\\", "/"),
            "path": str(dest)}


def write_text(name: str, text: str, overwrite: bool = False) -> dict:
    ensure()
    rel = _safe_rel(name)
    dest = (ROOT / rel).resolve()
    dest.relative_to(ROOT.resolve())
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and not overwrite:
        raise FileExistsError(dest.name)
    dest.write_text(str(text), encoding="utf-8")
    return {"ok": True, "name": str(dest.relative_to(ROOT)).replace("\\", "/")}


def edit_text(name: str, find: str, replace: str, all_matches: bool = True) -> dict:
    p = resolve(name)
    if not p:
        raise FileNotFoundError(name)
    data = p.read_text(encoding="utf-8")
    if not find:
        raise ValueError("find text cannot be empty")
    count = data.count(find)
    if count == 0:
        raise ValueError("text to replace was not found")
    if all_matches:
        new = data.replace(find, replace)
        changed = count
    else:
        new = data.replace(find, replace, 1)
        changed = 1
    p.write_text(new, encoding="utf-8")
    return {"ok": True, "name": str(p.relative_to(ROOT)).replace("\\", "/"),
            "replacements": changed}


def rename(old: str, new: str) -> dict:
    src = resolve(old)
    if not src:
        raise FileNotFoundError(old)
    rel = _safe_rel(new)
    dst = (ROOT / rel).resolve()
    dst.relative_to(ROOT.resolve())
    if dst.exists():
        raise FileExistsError(dst.name)
    dst.parent.mkdir(parents=True, exist_ok=True)
    src.rename(dst)
    return {"ok": True, "name": str(dst.relative_to(ROOT)).replace("\\", "/")}


def delete(name: str) -> dict:
    p = resolve(name)
    if not p:
        raise FileNotFoundError(name)
    p.unlink()
    return {"ok": True, "deleted": name}


def save_to_vault(name: str, vault_root: Path) -> dict:
    """Copy one Playground file to Vault; never overwrite an existing vault file."""
    src = resolve(name)
    if not src:
        raise FileNotFoundError(name)
    root = Path(vault_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    dest = root / src.name
    if dest.exists():
        for i in range(2, 10000):
            candidate = root / f"{src.stem} ({i}){src.suffix}"
            if not candidate.exists():
                dest = candidate
                break
        else:
            raise RuntimeError("too many vault files with that name")
    shutil.copy2(src, dest)
    return {"ok": True, "name": str(dest.relative_to(root)).replace("\\", "/")}


def keep(name: str) -> dict:
    """
    MOVE a Playground file into the Vault, because the user said to keep it.

    Moved, not copied, and that is the whole design. The Playground is
    working space; everything generated lands there and, until now, nothing
    ever left. After a few sessions of image and mesh generation it was
    gigabytes of files nobody had chosen to keep, which is what "there is a
    memory constraint issue with the file buildup in the playground" was.

    Copying would have doubled it. Moving means a kept file is out of the
    scratch space and in the user's hands, and the scratch space can then be
    cleared without losing anything anybody wanted.

    A 3D model's rendered preview travels with it - the preview is how the
    mesh is looked at, so leaving it behind would keep the file and lose the
    only way to see it.
    """
    import vault
    src = resolve(name)
    if not src:
        raise FileNotFoundError(name)
    vault.ensure()
    root = vault.MADE_VAULT
    root.mkdir(parents=True, exist_ok=True)

    def _free_name(stem: str, suffix: str) -> Path:
        dest = root / (stem + suffix)
        if not dest.exists():
            return dest
        for i in range(2, 10000):
            c = root / f"{stem} ({i}){suffix}"
            if not c.exists():
                return c
        raise RuntimeError("too many files with that name")

    dest = _free_name(src.stem, src.suffix)
    shutil.move(str(src), str(dest))
    moved = [dest.name]

    # EVERYTHING THAT BELONGS TO IT TRAVELS WITH IT.
    #
    # This moved the file and its 3D preview and left the rest behind, and
    # the leftovers were not harmless - they were A LIE ABOUT WHAT IS THERE.
    # Every kept image left its .generation.json in the Playground, so
    # listing the folder showed
    #
    #     Cosmic_Forge_Base.generation.json
    #     Goku_Ultra_Instinct.generation.json
    #     terrible_tornado.generation.json
    #
    # with no images beside them. Nova read that list, correctly inferred
    # "Cosmic_Forge_Base.png", passed it to generate_video, and the run died
    # with "not found in the Playground workspace" - three times, while the
    # user watched and told her the file was there. It was. In the Vault,
    # because they had kept it.
    #
    # A sidecar without its subject is worse than no sidecar: it is a
    # filename that reads as a promise.
    companions = [
        (src.with_name(src.stem + ".preview.png"),
         dest.stem + ".preview.png"),
        (src.with_name(src.stem + ".generation.json"),
         dest.stem + ".generation.json"),
        (src.with_name(src.name + ".source.json"),
         dest.name + ".source.json"),
    ]
    for extra, newname in companions:
        if not extra.is_file():
            continue
        pdest = root / newname
        if pdest.exists():
            continue
        try:
            shutil.move(str(extra), str(pdest))
            moved.append(pdest.name)
        except Exception:
            pass
    return {"ok": True, "name": dest.name, "moved": moved,
            "where": "vault/Made"}


# HOUSEKEEPING.
#
# Generous on purpose. This is a working folder on someone's own machine, not
# a shared disk, and the cost of trimming too eagerly is losing something
# that was about to be kept. Nothing is ever removed while it is the newest
# thing there, and anything the user kept is already out of this folder.
CAP_MB = 2048
CAP_FILES = 300
KEEP_RECENT = 20


def size_mb() -> float:
    ensure()
    total = 0
    for p in ROOT.rglob("*"):
        if p.is_file():
            try:
                total += p.stat().st_size
            except OSError:
                pass
    return round(total / 1048576.0, 1)


def tidy(dry_run: bool = False) -> dict:
    """
    Trim the oldest scratch files once the Playground passes its cap.

    Returns what it did (or would do) rather than doing it quietly. A folder
    that empties itself with no account of what went is indistinguishable
    from a folder that lost your work.
    """
    ensure()
    files = [p for p in ROOT.rglob("*") if p.is_file()]
    files.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    total = sum(p.stat().st_size for p in files) / 1048576.0

    if total <= CAP_MB and len(files) <= CAP_FILES:
        return {"trimmed": [], "mb_before": round(total, 1),
                "mb_after": round(total, 1), "over": False}

    removed, kept_mb = [], 0.0
    for i, p in enumerate(files):
        mb = p.stat().st_size / 1048576.0
        if i < KEEP_RECENT or (kept_mb + mb <= CAP_MB and i < CAP_FILES):
            kept_mb += mb
            continue
        removed.append(str(p.relative_to(ROOT)).replace("\\", "/"))
        if not dry_run:
            try:
                p.unlink()
            except OSError:
                removed.pop()
    return {"trimmed": removed, "mb_before": round(total, 1),
            "mb_after": round(kept_mb, 1), "over": True}


def save_to_ai_vault(name: str, vault_root: Path) -> dict:
    """Copy Playground result into a model-owned Vault subfolder."""
    src = resolve(name)
    if not src:
        raise FileNotFoundError(name)
    import vault
    return vault.ai_save(src, src.name)


def _run_arg_ok(value: str) -> bool:
    s = str(value)
    low = s.lower()
    if ".." in Path(s.replace("\\", "/")).parts:
        return False
    if Path(s).is_absolute() or low.startswith(("http://", "https://", "ftp://", "\\\\")):
        return False
    if "vault" in low and ("/" in low or "\\" in low):
        return False
    return True


def run(program: str, args: list[str] | None = None, timeout: int = 120) -> dict:
    """Run a local installed program with cwd=Playground, no shell, and confined path-like args."""
    ensure()
    program = str(program).strip()
    if not program:
        raise ValueError("program is required")
    if len(program) > 260 or any(x in program for x in ("|", ">", "<", "&", ";")):
        raise ValueError("program must be one executable, not a shell command")
    args = [str(x) for x in (args or [])][:80]
    if any(len(x) > 1000 or not _run_arg_ok(x) for x in args):
        raise ValueError("an execution argument points outside the Playground or requests a network URL")
    timeout = max(1, min(int(timeout), 300))
    env = os.environ.copy()
    env.update({"HUB_PLAYGROUND": str(ROOT), "NO_PROXY": "*", "no_proxy": "*"})
    try:
        cp = subprocess.run([program, *args], cwd=str(ROOT), capture_output=True,
                            text=True, encoding="utf-8", errors="replace",
                            timeout=timeout, env=env, shell=False)
    except FileNotFoundError:
        raise RuntimeError(f"program not found on this computer: {program}")
    return {"ok": cp.returncode == 0, "returncode": cp.returncode,
            "stdout": cp.stdout[-6000:], "stderr": cp.stderr[-4000:]}
