"""
test_meshgen.py - the built-in 3D generator produces solids, not surfaces.

WHY THE BAR IS "WATERTIGHT" AND NOT "LOOKS RIGHT"

A mesh with open edges renders perfectly in every viewer and is rejected, or
silently mis-filled, by every slicer. It is the exact failure this generator
kept producing while it looked finished: a plate with four bolt holes came
back with 80 open edges and a picture that was indistinguishable from the
correct one.

So every shape here is checked by counting edge use. In a closed solid each
edge belongs to exactly two triangles. Anything else is a failure, however
good the render looks.
"""
from __future__ import annotations

import math
import os
import sys
import tempfile
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import meshgen
import model3d

C = {"g": "\033[92m", "r": "\033[91m", "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0}


def check(label, cond, detail=""):
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


S, CO = math.sin, math.cos

SHAPES = {
    "plate with 2 bolt holes": {"parts": [{"shape": "box", "size": [60, 40, 4],
        "holes": [{"at": [10, 10], "d": 5}, {"at": [50, 30], "d": 5}]}]},
    "rounded plate, 4 holes": {"parts": [{"shape": "box", "size": [80, 50, 3],
        "radius": 5, "holes": [{"at": [8, 8], "d": 4}, {"at": [72, 8], "d": 4},
                               {"at": [8, 42], "d": 4}, {"at": [72, 42], "d": 4}]}]},
    "16 holes in a grid": {"parts": [{"shape": "box", "size": [120, 120, 3],
        "holes": [{"at": [x, y], "d": 5} for x in (15, 45, 75, 105)
                  for y in (15, 45, 75, 105)]}]},
    "C-channel, 6 holes": {"parts": [{"shape": "plate",
        "outline": [[0, 0], [100, 0], [100, 40], [80, 40], [80, 15],
                    [20, 15], [20, 40], [0, 40]], "thickness": 5,
        "holes": [{"at": [10, 7], "d": 4}, {"at": [50, 7], "d": 4},
                  {"at": [90, 7], "d": 4}, {"at": [10, 25], "d": 4},
                  {"at": [90, 25], "d": 4}, {"at": [10, 35], "d": 3}]}]},
    "L-bracket, 3 holes": {"parts": [{"shape": "plate",
        "outline": [[0, 0], [80, 0], [80, 20], [20, 20], [20, 60], [0, 60]],
        "thickness": 4, "holes": [{"at": [10, 10], "d": 5},
                                  {"at": [70, 10], "d": 5},
                                  {"at": [10, 50], "d": 5}]}]},
    "star outline with a hole": {"parts": [{"shape": "plate",
        "outline": [[50 + 30 * CO(i * math.pi / 5),
                     50 + (30 if i % 2 == 0 else 14) * S(i * math.pi / 5)]
                    for i in range(10)],
        "thickness": 3, "holes": [{"at": [50, 40], "d": 6}]}]},
    "cylinder": {"parts": [{"shape": "cylinder", "d": 20, "h": 30}]},
    "bored cylinder": {"parts": [{"shape": "cylinder", "d": 20, "h": 30,
                                  "hole_d": 8}]},
    "washer": {"parts": [{"shape": "cylinder", "d": 30, "h": 2,
                          "hole_d": 16}]},
    "tube": {"parts": [{"shape": "tube", "d": 20, "wall": 2, "h": 40}]},
    "cone": {"parts": [{"shape": "cone", "d": 30, "d_top": 0, "h": 40}]},
    "sphere": {"parts": [{"shape": "sphere", "d": 25}]},
    "torus": {"parts": [{"shape": "torus", "d": 40, "thickness": 8}]},
    "hex prism with a bore": {"parts": [{"shape": "prism", "sides": 6,
        "d": 24, "h": 10, "holes": [{"at": [0, 0], "d": 8}]}]},
    "revolved vase": {"parts": [{"shape": "revolve",
        "profile": [[0, 0], [22, 0], [18, 30], [9, 55], [13, 68], [11, 72],
                    [0, 72]]}]},
    "assembly: plate and posts": {"parts": [
        {"shape": "box", "size": [60, 60, 4], "holes": [{"at": [30, 30], "d": 10}]},
        {"shape": "cylinder", "d": 8, "h": 30, "at": [10, 10, 4]},
        {"shape": "cylinder", "d": 8, "h": 30, "at": [50, 50, 4]}]},
}

EXPECTED_SIZE = {
    "plate with 2 bolt holes": [60.0, 40.0, 4.0],
    "rounded plate, 4 holes": [80.0, 50.0, 3.0],
    "16 holes in a grid": [120.0, 120.0, 3.0],
    "cylinder": [20.0, 20.0, 30.0],
    "washer": [30.0, 30.0, 2.0],
    "sphere": [25.0, 25.0, 25.0],
    "cone": [30.0, 30.0, 40.0],
}


def main() -> int:
    print("\n1. EVERY SHAPE IS A CLOSED SOLID")
    for label, spec in SHAPES.items():
        try:
            tris = meshgen.build(spec)
        except Exception as e:
            check(label, False, f"{type(e).__name__}: {e}")
            continue
        open_edges = meshgen.is_closed(tris)
        check(f"{label}", open_edges == 0,
              f"{len(tris)} triangles, {open_edges} open edge(s)"
              if open_edges else f"{len(tris)} triangles")

    print("\n2. THE DIMENSIONS ARE THE ONES THAT WERE ASKED FOR")
    for label, want in EXPECTED_SIZE.items():
        got = meshgen.measure(meshgen.build(SHAPES[label]))["size"]
        check(f"{label} measures {want}", got == want, f"got {got}")

    print("\n3. AN IMAGE BECOMES A CLOSED RELIEF")
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        src = root / "grad.png"
        px = []
        for y in range(48):
            for x in range(48):
                v = int(255 * (x / 47.0) * (1 - abs(y - 24) / 24.0))
                px.append((v, v, v))
        src.write_bytes(model3d._png_rgb(48, 48, px))
        check("the PNG reader works with no image library",
              meshgen.read_png(src) is not None
              and meshgen.read_png(src)[1] == 48)

        try:
            tris = meshgen.relief(src, width=60, depth=3, base=1.5,
                                  resolution=48)
            check("a relief is generated", len(tris) > 100, f"{len(tris)} triangles")
            check("the relief is a closed solid",
                  meshgen.is_closed(tris) == 0,
                  f"{meshgen.is_closed(tris)} open edge(s)")
            m = meshgen.measure(tris)
            check("it is the width that was asked for",
                  abs(m["size"][0] - 60.0) < 0.1, str(m["size"]))
            check("it has a base under it, so it is printable",
                  m["min"][2] == 0.0 and m["max"][2] >= 1.5, str(m["size"]))
        except Exception as e:
            check("relief generation", False, f"{type(e).__name__}: {e}")

    print("\n4. WHAT IT WRITES, model3d READS BACK")
    with tempfile.TemporaryDirectory() as td:
        tris = meshgen.build(SHAPES["plate with 2 bolt holes"])
        for ext in (".stl", ".obj", ".ply"):
            dest = meshgen.save(tris, Path(td) / ("part" + ext))
            back = model3d.triangles(dest)
            check(f"{ext} round-trips", len(back) == len(tris),
                  f"wrote {len(tris)}, read {len(back)}")

    print("\n5. AN IMPOSSIBLE PART IS REFUSED, NOT SHIPPED BROKEN")
    bad = {"parts": [{"shape": "box", "size": [20, 20, 3],
                      "holes": [{"at": [10, 10], "d": 19.5}]}]}
    try:
        tris = meshgen.build(bad)
        check("a hole wider than its material is refused or still closed",
              meshgen.is_closed(tris) == 0,
              f"{meshgen.is_closed(tris)} open edge(s) - it was shipped broken")
    except Exception as e:
        check("a hole wider than its material is refused with a reason",
              "hole" in str(e).lower() or "outline" in str(e).lower(),
              str(e)[:100])

    try:
        meshgen.build({"parts": [{"shape": "banana"}]})
        check("an unknown shape is refused", False, "it was accepted")
    except ValueError as e:
        check("an unknown shape is refused and lists what is known",
              "banana" in str(e) and "cylinder" in str(e))

    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
