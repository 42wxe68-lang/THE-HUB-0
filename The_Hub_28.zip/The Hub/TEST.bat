@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title The Hub - verification
set "PY=%~dp0.runtime\python\python.exe"
if not exist "%PY%" set "PY=python"
echo.
echo   Checking every subsystem. Nothing is skipped silently.
echo.
"%PY%" test_ui.py
"%PY%" test_playground.py
"%PY%" verify.py
echo.
pause
