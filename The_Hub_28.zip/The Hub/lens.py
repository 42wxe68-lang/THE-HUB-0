"""
lens.py - how Nova sees the system she is running inside.

WHY THIS EXISTS
---------------
Nova was refusing to attempt things she was fully capable of. Told "try
again, I fixed it", she would decline and cite a failure from weeks earlier.
Three separate causes fed that, and two of them were ordinary bugs - a
missing import, a gate that refused arguments the model had been told to
send. The third was not a bug at all. It was an absence.

She had no way to look.

Everything she knew about the machine she runs on arrived second-hand: an
error string from a past run, a sentence in her prompt, a memory of a
conversation. She could not check whether the model had changed, whether the
weights had finished downloading, how much memory was free, or what the
system was even configured to do. With no way to look, the only evidence
available was the past - so the past decided everything.

This is the other half of the fix. A record of a failure stops being a
verdict the moment there is a way to check the present. So there is one:

    look_at_system("machine")     what she is running on
    look_at_system("self")        what she is - model, speed, senses, window
    look_at_system("runtime")     how she is being served, and with what
    look_at_system("generation")  what can make images, video, meshes
    look_at_system("settings")    what the user has configured
    look_at_system("hub")         the application around her
    look_at_system("everything")  all of the above

WHAT IT DELIBERATELY DOES NOT DO
--------------------------------
It reads. It never writes, never changes a setting, and never runs anything.
Seeing how the machine is configured is not the same as being able to
reconfigure it, and conflating the two would trade a real improvement for a
real hazard.

It also never returns a secret. API keys are reported as present or absent
and never as their value, because a key printed into the model's context is
a key that can be repeated into a reply, a saved memory, or a file.

THE USER DECIDES WHAT IS VISIBLE
--------------------------------
Every area has a switch under cfg["lens"], and the user owns all of them.
This was the explicit condition on building it: Nova gets to see "given the
user allows those certain things to be unveiled".

The defaults are open for everything in the list above, because all of it
describes the machine and none of it describes the user - and an assistant
who cannot find out what she is running on is the problem this was written
to solve. Closing one turns that area off; the closed area still ANSWERS,
saying plainly that it is switched off and where the switch is, so Nova can
tell the user how to open it rather than mistaking a closed door for a wall.
That distinction is the entire point of this module.
"""
from __future__ import annotations

import json
import os
import platform
import shutil
import sys
import time
from pathlib import Path

import core

AREAS = ("self", "machine", "runtime", "generation", "attempts", "memory",
         "settings", "hub")

# Open by default. Every one of these is a fact about the machine, not about
# the person using it.
DEFAULT_LENS = {a: True for a in AREAS}


def allowed(cfg: dict) -> dict:
    lens = dict(DEFAULT_LENS)
    for k, v in (cfg.get("lens") or {}).items():
        if k in lens:
            lens[k] = bool(v)
    return lens


def _closed(area: str) -> str:
    return (f"{area}: switched off. The user has this area of the lens "
            f"closed in Settings, so it is not being shown to you right now. "
            f"It is not missing and it is not broken - if you need it, say "
            f"so and ask them to turn it on.")


# ---------------------------------------------------------------- areas

def _fmt_mb(mb) -> str:
    try:
        mb = float(mb)
    except Exception:
        return "unknown"
    if mb < 0:
        return "unknown"
    return f"{mb/1024:.1f} GB" if mb >= 1024 else f"{mb:.0f} MB"


def _self(cfg: dict) -> list:
    import runtime
    st = runtime.state()
    b = runtime.bench()
    name = st.get("model") or cfg.get("model") or "(none loaded)"
    out = [f"You are being served from {name}."]

    n_ctx = b.get("n_ctx") or 0
    if n_ctx:
        out.append(f"Context window granted by the server: {n_ctx} tokens. "
                   f"That is the real number, measured at load - not what the "
                   f"config asked for.")
    tok = b.get("gen_tok_s")
    if tok:
        out.append(f"Generation speed measured on this machine: {tok} tokens "
                   f"a second, first reply in {b.get('first_reply_s','?')}s.")
    v = b.get("vision") or {}
    if v.get("sees"):
        out.append("You can see. Images put in front of you are really "
                   "looked at, not guessed from filenames.")
    elif v:
        # Split out on purpose: a nested quote inside an f-string needs
        # Python 3.12+, and this ships against a floor that predates it.
        why = v.get("why") or "no vision projector is paired with it"
        out.append(f"You cannot see with this model: {why}.")
    samp = cfg.get("sampling") or {}
    out.append(f"Sampling: temperature {samp.get('temperature')}, top_p "
               f"{samp.get('top_p')}, top_k {samp.get('top_k')}, repeat "
               f"penalty {samp.get('repeat_penalty')}, thinking "
               f"{'on' if samp.get('thinking') else 'off'}.")
    out.append(f"Status right now: {st.get('status')}"
               + (f" - {st['detail']}" if st.get("detail") else ""))
    return out


def _machine(cfg: dict) -> list:
    import runtime
    out = []
    out.append(f"Operating system: {platform.system()} "
               f"{platform.release()} ({platform.machine()}).")
    cpus = os.cpu_count() or 0
    out.append(f"Processor: {platform.processor() or 'unknown'}, "
               f"{cpus} logical cores.")
    free = runtime.available_mb()
    out.append(f"System memory free right now: {_fmt_mb(free)}.")
    vram = runtime.vram_free_mb()
    if vram and vram > 0:
        out.append(f"Video memory free right now: {_fmt_mb(vram)}. This is "
                   f"the number that decides what can be generated and at "
                   f"what size, and it changes minute to minute.")
    else:
        out.append("Video memory could not be measured - either there is no "
                   "discrete GPU or nvidia-smi is not on the path.")
    try:
        du = shutil.disk_usage(str(core.ROOT))
        out.append(f"Disk where The Hub lives: {_fmt_mb(du.free/1048576)} "
                   f"free of {_fmt_mb(du.total/1048576)}.")
    except Exception:
        pass
    try:
        import store
        st = store.state()
        out.append(
            f"Memory store: {st['used_gb']:.2f} GB used of a "
            f"{st['chosen_gb']:.0f} GB ceiling"
            + (" - this computer's own limit" if st["following_machine"]
               else f", which the user set (this machine allows up to "
                    f"{st['ceiling_gb']:.0f} GB)")
            + f". {st['room_gb']:.1f} GB left. Nothing is ever deleted to stay "
              f"under it: at the ceiling a large generation will not start, "
              f"and that is all that happens.")
    except Exception:
        pass
    out.append(f"Python: {sys.version.split()[0]}, private to this "
               f"application.")
    return out


def _runtime(cfg: dict) -> list:
    import runtime
    out = []
    out.append(f"You are served by llama.cpp on {runtime.MAIN}. The interface "
               f"the user sees talks to a separate local server on port "
               f"{core.UI_PORT}. Nothing here leaves this machine.")
    rt = cfg.get("runtime") or {}
    out.append(f"Requested settings: n_ctx {rt.get('n_ctx')}, GPU layers "
               f"{rt.get('n_gpu_layers')}, threads {rt.get('threads')}, KV "
               f"cache {rt.get('kv_type')}, fit policy {rt.get('fit_policy')}.")
    try:
        ms = core.models()
        out.append(f"Models installed here: {len(ms)}.")
        for m in ms[:12]:
            mark = " <- loaded" if m["name"] == (cfg.get("model") or "") else ""
            out.append(f"    {m['name']}  {_fmt_mb(m.get('mb', 0))}{mark}")
        if len(ms) > 12:
            out.append(f"    ...and {len(ms)-12} more")
        pj = core.projectors()
        if pj:
            out.append(f"Vision projectors present: "
                       f"{', '.join(p['name'] for p in pj[:6])}. A projector "
                       f"is what lets a model see; it is paired with a model, "
                       f"not loaded on its own.")
    except Exception as e:
        out.append(f"(could not list models: {e})")
    return out


def _generation(cfg: dict) -> list:
    """
    What can be made here, what it is installed as, and how often it has run.

    The same forge.inventory() the launch banner renders. One source: the
    screen the user reads and the description Nova reads cannot drift into
    disagreeing, which is precisely how a 3D generator stayed broken in plain
    sight for weeks.
    """
    out = []
    try:
        import forge
        for e in forge.inventory():
            state = "ready" if e["ready"] else "NOT installed"
            tried = forge.tried_note(e.get("attempts") or {})
            out.append(f"{e['label']}: {state}"
                       + (f" - {tried}" if tried else ""))
            if not e["ready"]:
                if e.get("why"):
                    out.append(f"    {e['why']}")
                continue
            for d in [e.get("what")] + list(e.get("extra") or []) + [e.get("how")]:
                if d:
                    out.append(f"    {d}")
            # HOW LONG IT REALLY TAKES, from runs that happened rather than
            # from a number somebody picked. There is no time limit on any
            # of this any more; the honest thing to say about duration is
            # what the log has actually seen.
            if e.get("took"):
                out.append(f"    time: {e['took']}. There is no time limit "
                           f"- it runs until it is done.")
        out.append("")
        out.append(forge.report())
    except Exception as e:
        out.append(f"(the generation report could not be read: {e})")
    return out


def _attempts(cfg: dict) -> list:
    """
    How many times each thing has actually been tried, and what that is worth.

    The whole point of showing a COUNT rather than a verdict: a capability
    with one failure behind it and a capability with twenty look identical
    as booleans and are nothing alike as evidence.
    """
    try:
        import ledger, forge
        out = [ledger.breakdown(forge._fingerprint())]
    except Exception as e:
        return [f"(the attempt record could not be read: {e})"]
    out += _last_run()
    return out


def _last_run() -> list:
    """
    WHAT ACTUALLY HAPPENED LAST TIME, in order, from the logs that already
    exist.

        "which log would tell us if the system was or was not working and if
         the limit of 20 turns or the video generation not doing anything is
         the actual problem"

    All of it was already being written down and no two parts of it were in
    the same file. A refusal by the gate lands in policy.log and never
    reaches forge at all; a generator that started and died lands in
    forge.log; how long it ran is a number in attempts.jsonl. Three files,
    three formats, and a question that needs all three to answer.

    THE DECIDING NUMBER IS THE DURATION. A run that never started reads as
    a second or two. A run that started and failed at the end reads as
    minutes or hours. Those are different faults with the same sentence -
    "the generation failed" - printed over both.
    """
    out = []
    try:
        import ledger, core
        rows = [r for r in ledger._read() if r.get("what") in
                ("image", "video", "model3d", "mesh")]
        if not rows:
            return ["No generation has been attempted on this build yet."]
        last = rows[-1]
        secs = float(last.get("seconds") or 0)
        when = time.strftime("%H:%M:%S",
                             time.localtime(float(last.get("at") or 0)))
        verdict = "worked" if last.get("ok") else "did not work"
        out.append("")
        out.append(f"THE LAST GENERATION: {last.get('what')} at {when}, "
                   f"{verdict}, and it ran for {ledger._span(secs)}.")
        if not last.get("ok"):
            out.append(f"    it said: {last.get('note') or '(nothing)'}")
            # The duration is what separates the three things that produce
            # the same sentence on screen.
            if secs < 5:
                out.append("    IT NEVER REALLY RAN. Under five seconds "
                           "means it failed before the model was loaded - a "
                           "missing file, missing weights, or a refusal. "
                           "This is not a slow machine and not a time "
                           "limit; there are no time limits.")
            else:
                out.append("    IT RAN AND THEN FAILED. That is a real "
                           "attempt with a real error at the end of it - "
                           "read the error, not the duration.")
        out.append("    logs: data/logs/forge.log has what the generator "
                   "itself printed; data/logs/policy.log has every tool "
                   "call the gate allowed or refused; data/attempts.jsonl "
                   "has one line per attempt with its duration. Every line "
                   "in all three is stamped with the time it was written.")
        # AND POINT AT THE WHOLE THING, BY NAME.
        #
        # The note above is one sentence because that is all a small model
        # can carry. The complete output of the run that produced it is on
        # disk, and the only reason nobody read it before is that nothing
        # ever said where it was.
        try:
            kept = sorted((core.LOGS / "failures").glob("* *.log"))
            if kept:
                out.append(f"    the FULL output of the last {len(kept)} "
                           f"failed run(s) is kept, one file each, in "
                           f"data/logs/failures - most recent: "
                           f"{kept[-1].name}")
        except Exception:
            pass
    except Exception as e:
        out.append(f"(the last run could not be read: {e})")
    return out


def _backlog(memory) -> list:
    """
    Transcripts that have not been distilled yet, and whether that is normal.

    WHY THIS NUMBER IS ON THE SCREEN.

    For as long as the consolidation body sat unreachable, NOTHING wrote a
    digest and nothing grafted a fact from a conversation - both writers
    lived inside that dead block. The tree only ever received what intake
    promoted, and remembered conversations were never written at all.

    They were not deleted. Nothing here deletes: a leaf that fades goes to
    ash and stays searchable, and a transcript is archived only AFTER it has
    been digested - which is why none of them ever moved. The raw material
    is all still on disk.

    So this line exists to make that visible rather than reassuring. A large
    backlog after a long silence is expected and will clear on its own; a
    backlog that never shrinks means consolidation is not running again, and
    that is the thing to look at.
    """
    try:
        import core
        from datetime import datetime, timezone, timedelta
        cfg = core.load()
        days = int((cfg.get("memory") or {}).get("expire_days", 10))
        waiting = ripe = 0
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        for f in core.SESSIONS.glob("*.json"):
            d = core.read_json(f, None)
            if not isinstance(d, dict) or not d.get("messages"):
                continue
            waiting += 1
            try:
                stamp = datetime.fromisoformat(
                    d.get("updated") or d.get("started"))
                if stamp.tzinfo is None:
                    stamp = stamp.replace(tzinfo=timezone.utc)
                if stamp < cutoff:
                    ripe += 1
            except Exception:
                pass
        if not waiting:
            return []
        out = [f"Not distilled yet: {waiting} transcripts on disk, {ripe} of "
               f"them old enough to be worth distilling ({days}+ days). "
               f"A transcript is archived only after it has been digested, "
               f"so anything still sitting here has never been through it."]
        if ripe > 20:
            out.append(
                "That is a backlog. It clears on its own when the machine is "
                "idle, a few at a time - it is not lost, and it is not "
                "something to do by hand.")
        return out
    except Exception:
        return []


def _holding(memory) -> list:
    """
    HOW FIRMLY, not just how many.

    A leaf count says nothing about whether anything is actually being kept.
    Two numbers say it: how much of the tree would come to mind right now,
    and how durable it has become. They move in opposite directions on
    purpose - a memory can be almost unreachable and still be one reminder
    from being permanent, and that combination is the whole reason there
    are two of them.
    """
    import hold
    from grove import _age_days
    rows = [r for rs in memory.tree().values() for r in rs]
    if not rows:
        return []
    live, durable, feeling = [], [], []
    for r in rows:
        st = float(r.get("stability") or hold.S_NEW)
        durable.append(st)
        live.append(hold.retrievability(
            st, _age_days(r.get("recalled") or r.get("created") or "")))
        f = float(r.get("feeling") or 0.0)
        if f > 0.05:
            feeling.append((f, float(r.get("valence") or 0.0)))
    reachable = sum(1 for x in live if x >= 0.5)
    med = sorted(durable)[len(durable) // 2]
    strong = sum(1 for d in durable if d >= 90)
    out = [
        f"Held: {reachable} of {len(rows)} would come to mind right now; "
        f"the rest have faded but are NOT gone - stability is kept whatever "
        f"reachability does, so a faded memory needs one reminder, not "
        f"relearning.",
        f"Durability: median {med:.0f} days, {strong} memories now hold for "
        f"three months or more. Bringing something back raises this, and by "
        f"more the harder it was to reach.",
    ]
    if feeling:
        bad = sum(1 for _, v in feeling if v < 0)
        good = sum(1 for _, v in feeling if v > 0)
        out.append(
            f"Still carries feeling: {len(feeling)} memories ({bad} from "
            f"things that went wrong, {good} from things that went right). "
            f"The charge fades while the content stays, and it fades faster "
            f"on the bad ones - that is the design, not neglect.")
    for p in hold.check([
            {"valence": r.get("valence", 0), "affect": r.get("feeling", 0),
             "age_days": _age_days(r.get("created") or ""),
             "recalls": r.get("recalls", 0)} for r in rows]):
        out.append("PROBLEM: " + p)
    return out


def _memory(cfg: dict) -> list:
    """
    What is remembered, broken down - and how firmly each part is held.

    Asked for directly: "a breakdown of the memories might help for the
    model to use better data". Counts, not contents; the contents arrive
    through recall and search_memory, which is where relevance is decided.
    """
    out = []
    try:
        import memory
        st = memory.status()
        out.append(f"Living tree: {st.get('leaves', 0)} leaves across "
                   f"{st.get('branches', 0)} branches.")
        out.append(f"Ash: {st.get('ash', 0)} faded memories. Faded is not "
                   f"deleted - ash is on disk and searchable, and a fact "
                   f"that fell out of the living tree can still be found.")
        out.append(f"Conversations: {st.get('sessions', 0)} saved, "
                   f"{st.get('archived', 0)} archived.")
        out += _backlog(memory)
        act = st.get("active") or {}
        if isinstance(act, dict):
            out.append(f"Recent working frontier: {act.get('entries', 0)} "
                       f"entries. This decays on purpose.")
        by_limb = st.get("by_limb") or st.get("limbs")
        if isinstance(by_limb, dict) and by_limb:
            parts = ", ".join(f"{k} {v}" for k, v in sorted(by_limb.items()))
            out.append(f"By kind: {parts}.")
        out += _holding(memory)
    except Exception as e:
        out.append(f"(the tree could not be read: {e})")
    try:
        import knowledge
        k = knowledge.status()
        out.append(f"Worked-out understanding: {k.get('entries', 0)} entries.")
    except Exception:
        pass
    out.append("A memory marked [contradicted] or [disproven] was believed "
               "and turned out not to hold. It is kept on purpose. Do not "
               "repeat it as fact and do not pretend it was never said.")
    return out


def _settings(cfg: dict) -> list:
    """
    What the user has chosen. Keys are reported as present, never as values.
    """
    out = []
    t = cfg.get("tools") or {}
    out.append(f"Web search: {'on' if t.get('web_search') else 'off'} - it is "
               f"the only thing here that reaches the internet.")
    s = cfg.get("search") or {}
    keys = [n.replace("_key", "") for n in ("brave_key", "tavily_key")
            if (s.get(n) or "").strip()]
    out.append(f"Search provider: {s.get('provider')}"
               + (f", with a key set for: {', '.join(keys)}" if keys else
                  ", no third-party key set")
               + ". Key values are never shown to you.")
    h = cfg.get("hearing") or {}
    v = cfg.get("voice") or {}
    out.append(f"Hearing: {'on' if h.get('enabled') else 'off'}"
               f" ({h.get('model')}). Voice: "
               f"{'on' if v.get('enabled') else 'off'}.")
    m = cfg.get("memory") or {}
    out.append(f"Memory: leaves decay {m.get('decay_per_day')} a day, fall to "
               f"ash below {m.get('ash_below')}, {m.get('recall_count')} "
               f"recalled per turn, unsorted expires after "
               f"{m.get('expire_days')} days.")
    hub = cfg.get("hub") or {}
    out.append(f"Capability gate: "
               f"{'on' if hub.get('capability_gate', True) else 'OFF'}. "
               f"Confirm-before-writing memories: "
               f"{'on' if hub.get('confirm_writes', True) else 'off'}.")
    a = cfg.get("appearance") or {}
    out.append(f"You are allowed to change the theme: "
               f"{'yes' if a.get('ai_control') else 'no'}.")
    lens = allowed(cfg)
    shut = [k for k, v_ in lens.items() if not v_]
    if shut:
        out.append(f"Parts of this lens the user has closed: "
                   f"{', '.join(shut)}.")
    return out


def _hub(cfg: dict) -> list:
    out = ["The Hub is the application around you: the interface, the memory, "
           "the senses and the runtime that loads you. It is not you."]
    try:
        import memory
        st = memory.status()
        out.append(f"Memory holds {st.get('leaves', 0)} leaves across the "
                   f"tree, {st.get('sessions', 0)} saved conversations, "
                   f"{st.get('ash', 0)} in ash.")
    except Exception:
        pass
    try:
        import knowledge
        k = knowledge.status()
        out.append(f"Worked-out understanding: {k.get('entries', 0)} entries.")
    except Exception:
        pass
    try:
        import vault, playground
        vn = len(vault.listing()) if hasattr(vault, "listing") else 0
        pn = len(playground.listing()) if hasattr(playground, "listing") else 0
        out.append(f"The Vault holds {vn} of the user's files and is "
                   f"read-only to you. The Playground holds {pn} and is "
                   f"yours to write in.")
    except Exception:
        pass
    try:
        import tools
        out.append(f"Tools you can call: {len(tools.enabled(cfg))} of "
                   f"{len(tools.REGISTRY)} registered.")
    except Exception:
        pass
    out.append(f"The application is {len(list(core.ROOT.glob('*.py')))} Python "
               f"modules in one folder, with no framework and no service "
               f"behind it.")
    return out


_LOOKERS = {"self": _self, "machine": _machine, "runtime": _runtime,
            "generation": _generation, "attempts": _attempts,
            "memory": _memory, "settings": _settings, "hub": _hub}


# ---------------------------------------------------------------- entry

def look(area: str, cfg: dict) -> str:
    area = (area or "everything").strip().lower()
    lens = allowed(cfg)
    wanted = list(AREAS) if area in ("", "everything", "all") else [area]

    bad = [a for a in wanted if a not in _LOOKERS]
    if bad:
        return (f"There is no '{bad[0]}' to look at. What you can look at: "
                + ", ".join(AREAS) + ", or everything.")

    blocks = []
    for a in wanted:
        if not lens.get(a, True):
            blocks.append(_closed(a))
            continue
        try:
            lines = _LOOKERS[a](cfg)
        except Exception as e:
            lines = [f"(this could not be read just now: {type(e).__name__}: "
                     f"{str(e)[:140]})"]
        blocks.append(a.upper() + "\n" + "\n".join("  " + ln for ln in lines))

    stamp = time.strftime("%A %d %B %Y, %H:%M")
    return ("THIS IS THE SYSTEM AS IT IS AT " + stamp + ".\n"
            "Everything below was read just now. It describes the present, "
            "and it replaces anything you remember about how this machine "
            "used to be.\n\n"
            + "\n\n".join(blocks))
