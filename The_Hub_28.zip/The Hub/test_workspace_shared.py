from pathlib import Path
import tempfile
import core, vault, playground, tools, policy

def test_ai_vault_is_inside_vault_and_separate_from_user_area(tmp_path):
    old_v, old_a, old_c = vault.VAULT, vault.AI_VAULT, vault.CHAT_VAULT
    try:
        vault.VAULT = tmp_path / 'vault'; vault.AI_VAULT = vault.VAULT / 'AI'; vault.CHAT_VAULT = vault.VAULT / 'Chat'
        vault.ensure()
        assert vault.AI_VAULT.parent == vault.VAULT
        assert vault.ai_path('x.txt') == vault.AI_VAULT / 'x.txt'
        assert vault.ai_path('../escape') is None
    finally:
        vault.VAULT, vault.AI_VAULT, vault.CHAT_VAULT = old_v, old_a, old_c

def test_ai_save_and_delete_only_own_area(tmp_path):
    old_v, old_a = vault.VAULT, vault.AI_VAULT
    try:
        vault.VAULT = tmp_path / 'vault'; vault.AI_VAULT = vault.VAULT / 'AI'; vault.CHAT_VAULT = vault.VAULT / 'Chat'; vault.ensure()
        src = tmp_path / 'work.txt'; src.write_text('new')
        out = vault.ai_save(src, 'result.txt'); assert out['owner'] == 'ai'
        assert (vault.AI_VAULT/'result.txt').read_text() == 'new'
        vault.ai_delete('result.txt')
        assert not (vault.AI_VAULT/'result.txt').exists()
    finally:
        vault.VAULT, vault.AI_VAULT = old_v, old_a

def test_policy_contains_shared_ai_vault_tools():
    assert 'save_to_ai_vault' in policy.TIERS
    assert 'delete_ai_vault' in policy.TIERS
    assert 'save_to_ai_vault' in tools.REGISTRY
    assert 'delete_ai_vault' in tools.REGISTRY
    assert 'save_to_ai_vault' not in [x for x in ('delete_vault','overwrite_vault') if x]

def test_chat_upload_is_protected_user_attachment():
    assert 'save_chat_upload' in Path('vault.py').read_text(encoding='utf-8')
    text=Path('server.py').read_text(encoding='utf-8')
    assert '/api/chat/upload' in text
    assert 'attachments' in text

def test_the_same_file_uploaded_twice_is_not_stored_twice(tmp_path):
    """
    The user's vault held script.py through script (6).py - the same two
    files over and over. save_upload never overwrote, which is right, but it
    also never asked whether the "new" file was the SAME file, so every
    re-drop or retried upload made another copy nobody could tell apart.
    """
    old_v, old_a, old_c = vault.VAULT, vault.AI_VAULT, vault.CHAT_VAULT
    try:
        vault.VAULT = tmp_path / 'vault'
        vault.AI_VAULT = vault.VAULT / 'AI'
        vault.CHAT_VAULT = vault.VAULT / 'Chat'
        vault.ensure()
        body = b"print('hello world')\n"
        first = vault.save_upload('script.py', body)
        assert first['duplicate'] is False
        for _ in range(5):
            again = vault.save_upload('script.py', body)
            assert again['duplicate'] is True
            assert again['name'] == first['name']
        other = vault.save_upload('script.py', b'# something else\n')
        assert other['duplicate'] is False and other['name'] != first['name']
        alias = vault.save_upload('copy_of_script.py', body)
        assert alias['duplicate'] is True and alias['name'] == first['name']
        on_disk = sorted(q.name for q in vault.VAULT.glob('*.py'))
        assert len(on_disk) == 2, f'expected 2 files, got {on_disk}'
    finally:
        vault.VAULT, vault.AI_VAULT, vault.CHAT_VAULT = old_v, old_a, old_c


if __name__ == "__main__":
    import sys, testkit
    sys.exit(testkit.run(dict(globals()), "SHARED WORKSPACE - vault, AI vault and playground boundaries"))
