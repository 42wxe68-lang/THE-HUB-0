"""
test_fit.py - the model is made to fit the machine, and the plan is sent.

WHAT THIS FILE IS ABOUT

The machine-fit limiter has existed since The Hearth and has been byte-for-
byte identical in every Hub build from v2 to v24. It was never removed. It
was never CONNECTED.

`plan()` worked out `gpu_mb` - how much of the model it expected the card to
hold - used it as a subtraction inside the host-RAM sum, and then dropped it.
Meanwhile `_argv` omitted `-ngl` whenever the setting said "auto", on the
strength of this comment:

    # "auto" omits -ngl entirely so llama.cpp fits the offload to real
    # free VRAM.

That is not what llama.cpp does. In the pinned build, b10456:

    uint32_t llama_model::n_gpu_layers() const {
        return params.n_gpu_layers >= 0 ? params.n_gpu_layers
                                        : hparams.n_layer_all + 1;
    }

No VRAM is consulted on that path. "auto" is the name of the default, not a
measurement, and omitting the flag is the same instruction as `-ngl 99`: put
every layer on the card. So a 3.6 GB model went onto a 3.9 GB card together
with its cache, its buffers and - because the projector was offered `gpu_mb`
rather than the truth - its vision projector as well.

That used to fail loudly, which is why plan() could reasonably say "start it
and let llama.cpp decide". NVIDIA driver 536.40 ended that: System Memory
Fallback is on by default, so an over-subscribed card does not raise. The
driver pages it over PCIe into system RAM and the GPU sits at full board
power for as long as the model runs. On a laptop with no battery there is
nothing to absorb that, and the machine goes off with BugcheckCode 0 - no
bugcheck, the rail simply went away.

So these tests hold four promises:

  THE PLAN IS SENT.        A budget nobody enforces is a comment. If plan()
                           decides 27 layers, argv says -ngl 27.

  BOTH CEILINGS ARE REAL.  RAM and VRAM. The weights go under the ceiling
                           first; the window is fitted inside what is left.

  NOTHING IS REFUSED.      Unchanged, and load-bearing. The model the user
                           chose always starts. What adapts is how much of it
                           sits on the card and how wide its context is.

  THE ARITHMETIC IS READ,  Per-layer weight sizes come out of the GGUF tensor
  NOT INVENTED.            table. The cache is sized the way llama.cpp sizes
                           it, sliding window and all. The one figure that
                           cannot be computed - the compute buffers - is read
                           back out of llama-server's own load report.
"""
from __future__ import annotations

import io
import pathlib
import struct
import sys

import core
import gguf
import runtime
import vision


# ═══════════════════════════════════════════════════════════════════════════
#  A REAL GGUF, BUILT HERE
# ═══════════════════════════════════════════════════════════════════════════
#
# Sparse files with a "GGUF" magic and nothing behind it were enough for the
# tests that came before, because nothing read past the magic. Every claim in
# this file is about arithmetic done on a header, so the header has to be
# real: metadata, a tensor table with genuine offsets, and a body of the
# stated size.

S, U32, U64 = gguf.STR, gguf.U32, gguf.U64


def _kv(out, key, vtype, value):
    b = key.encode()
    out.write(struct.pack("<Q", len(b)) + b)
    out.write(struct.pack("<I", vtype))
    if vtype == S:
        vb = value.encode()
        out.write(struct.pack("<Q", len(vb)) + vb)
    elif vtype == gguf.ARR:
        et, items = value
        out.write(struct.pack("<I", et) + struct.pack("<Q", len(items)))
        out.write(struct.pack("<" + gguf._FIXED[et][0][1] * len(items), *items))
    else:
        out.write(struct.pack(gguf._FIXED[vtype][0], value))


def write_gguf(path, meta: dict, blocks: int = 0, block_mb: float = 0.0,
               outside_mb: float = 0.0):
    """
    Write a GGUF whose tensor table describes `blocks` layers of `block_mb`
    each, plus one token-embedding tensor of `outside_mb`.

    The embedding is written FIRST, as real converters do, which is exactly
    the case that breaks "size divided by layers": it is not a layer, and for
    a large-vocabulary model it is the biggest single tensor in the file.
    """
    names = [("token_embd.weight", outside_mb)]
    for i in range(blocks):
        names.append((f"blk.{i}.attn_q.weight", block_mb))
    body, offset, infos = 0, 0, []
    for name, mb in names:
        infos.append((name, offset, int(mb * 1048576)))
        offset += int(mb * 1048576)
    body = offset

    out = io.BytesIO()
    out.write(b"GGUF" + struct.pack("<I", 3))
    out.write(struct.pack("<Q", len(infos)))
    out.write(struct.pack("<Q", len(meta)))
    for k, (t, v) in meta.items():
        _kv(out, k, t, v)
    for name, off, _size in infos:
        b = name.encode()
        out.write(struct.pack("<Q", len(b)) + b)
        out.write(struct.pack("<I", 1))         # one dimension
        out.write(struct.pack("<Q", 1))         # its length; never read
        out.write(struct.pack("<I", 0))         # ggml type; never read
        out.write(struct.pack("<Q", off))
    head = out.getvalue()
    pad = (-len(head)) % 32
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        f.write(head + b"\0" * pad)
        if body:
            f.seek(len(head) + pad + body - 1)
            f.write(b"\0")
    return path


# 35 blocks, 15 of them sharing another layer's cache, a 1024-token window on
# five layers in six: the shape of the Gemma 4 E2B that is actually installed.
GEMMA = {
    "general.architecture": (S, "gemma4"),
    "gemma4.block_count": (U32, 35),
    "gemma4.context_length": (U32, 32768),
    "gemma4.attention.head_count": (U32, 8),
    "gemma4.attention.head_count_kv": (U32, 2),
    "gemma4.attention.key_length": (U32, 256),
    "gemma4.attention.key_length_swa": (U32, 256),
    "gemma4.attention.sliding_window": (U32, 1024),
    "gemma4.attention.sliding_window_pattern": (U32, 6),
    "gemma4.attention.shared_kv_layers": (U32, 15),
}

# The same size and layer count with no window at all: a plain full-attention
# model, here to prove the new arithmetic did not quietly change ITS budget.
DENSE = {
    "general.architecture": (S, "qwen3"),
    "qwen3.block_count": (U32, 35),
    "qwen3.context_length": (U32, 32768),
    "qwen3.attention.head_count": (U32, 8),
    "qwen3.attention.head_count_kv": (U32, 2),
    "qwen3.attention.key_length": (U32, 256),
}

MODEL = "Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf"
BASE_RT = {"n_ctx": 32768, "n_gpu_layers": "auto", "threads": 6,
           "parallel": 1, "kv_type": "f16", "fit_policy": "adapt",
           "ram_budget_mb": 0, "n_ubatch": 512}


class Machine:
    """
    A machine with a stated amount of free RAM and VRAM.

    Every number plan() reads about hardware comes through two functions.
    Replacing them is the whole of the fixture; nothing else is stubbed, so
    what is under test is the real arithmetic on a real header.
    """

    def __init__(self, tmp_path, vram=3938.0, ram=9000.0, meta=None,
                 blocks=35, block_mb=100.0, outside_mb=100.0, memo=None):
        self.dir = pathlib.Path(tmp_path) / "models"
        self.logs = pathlib.Path(tmp_path) / "logs"
        self.logs.mkdir(parents=True, exist_ok=True)
        self.path = write_gguf(self.dir / MODEL, meta or GEMMA,
                               blocks, block_mb, outside_mb)
        self.vram, self.ram, self.memo = vram, ram, memo or {}
        self._saved = None

    def __enter__(self):
        self._saved = (core.MODELS, core.LOGS, runtime.vram_free_mb,
                       runtime.available_mb, runtime.memo)
        core.MODELS, core.LOGS = self.dir, self.logs
        runtime.vram_free_mb = lambda: self.vram
        runtime.available_mb = lambda: self.ram
        runtime.memo = lambda n=None: dict(self.memo)
        return self

    def __exit__(self, *_):
        (core.MODELS, core.LOGS, runtime.vram_free_mb,
         runtime.available_mb, runtime.memo) = self._saved

    def plan(self, **over):
        rt = dict(BASE_RT)
        rt.update(over)
        return runtime.plan(MODEL, rt)

    def argv(self, gpu=True, **over):
        rt, _ = self.plan(**over)
        return runtime._argv(self.path, 8090, rt, gpu=gpu)

    @property
    def ceiling(self):
        return self.vram - runtime.VRAM_RESERVE_MB


def _flag(argv, name):
    """The value after `name` in an argv list, or None if it is not there."""
    return argv[argv.index(name) + 1] if name in argv else None


# ═══════════════════════════════════════════════════════════════════════════
#  THE PLAN IS SENT
# ═══════════════════════════════════════════════════════════════════════════

def test_the_offload_the_plan_chose_reaches_the_command_line(tmp_path):
    """
    The regression this whole file exists for.

    plan() has always worked out how much of the model belongs on the card.
    Until now it kept the answer to itself and llama-server was left to its
    own default, which is every layer.
    """
    with Machine(tmp_path) as m:
        rt, _ = m.plan()
        ngl = rt.get("n_gpu_layers")
        assert isinstance(ngl, int), f"plan() still says {ngl!r}, not a number"
        argv = runtime._argv(m.path, 8090, rt, gpu=True)
        assert _flag(argv, "-ngl") == str(ngl), \
            f"plan said {ngl} layers and argv says {_flag(argv, '-ngl')}"


def test_the_offload_is_left_alone_when_the_card_cannot_be_measured(tmp_path):
    """
    No nvidia-smi means no NVIDIA card, or no way to ask about one. The honest
    response to an unmeasured machine is not to start guessing at it, so the
    flag is omitted exactly as before and llama.cpp keeps its own default.
    """
    with Machine(tmp_path, vram=-1.0) as m:
        rt, _ = m.plan()
        assert rt.get("n_gpu_layers") == "auto"
        assert "-ngl" not in runtime._argv(m.path, 8090, rt, gpu=True)


def test_a_number_the_user_typed_is_never_overruled(tmp_path):
    """
    "A guess must never outrank a decision" is written into plan()'s own
    docstring. MMAP_RESIDENT, the buffer estimate and the reserve are all
    calibrated guesses; a number in settings is not.
    """
    with Machine(tmp_path) as m:
        rt, adv = m.plan(n_gpu_layers=36)
        assert _flag(runtime._argv(m.path, 8090, rt, gpu=True), "-ngl") == "36"
        assert adv, "a decision that overshoots the card should still be told"


# ═══════════════════════════════════════════════════════════════════════════
#  BOTH CEILINGS ARE REAL
# ═══════════════════════════════════════════════════════════════════════════

def test_the_whole_model_is_not_put_on_a_card_that_cannot_hold_it(tmp_path):
    """3.6 GB of weights, a 3.9 GB card. Something has to stay on the CPU."""
    with Machine(tmp_path) as m:
        rt, _ = m.plan()
        assert 0 < rt["n_gpu_layers"] < 36, \
            f"offloaded {rt['n_gpu_layers']} of 36 onto a 4 GB card"
        assert rt["_card_claimed_mb"] <= m.ceiling, \
            f"{rt['_card_claimed_mb']} MB claimed, {m.ceiling} MB usable"


def test_a_card_with_room_takes_the_whole_model(tmp_path):
    """
    The limiter must not become a tax. On hardware that fits the model, every
    layer goes on, exactly as it would have before.
    """
    with Machine(tmp_path, vram=12000.0) as m:
        rt, adv = m.plan()
        assert rt["n_gpu_layers"] == 36, rt["n_gpu_layers"]
        assert rt["n_ctx"] == 32768 and not adv


def test_a_smaller_card_gives_up_layers_rather_than_context(tmp_path):
    """
    Order matters, and the user named it: the model loads "with this as the
    primary focus to stay under, then that of its memory use (context window)
    within that". Layers move to the CPU first; the window is only narrowed
    when moving layers is not enough.
    """
    with Machine(tmp_path, vram=2048.0) as m:
        rt, _ = m.plan()
        assert rt["n_gpu_layers"] < 12
        assert rt["n_ctx"] == 32768, "the window paid for the card's shortfall"


def test_the_display_keeps_its_reserve(tmp_path):
    """This GPU also draws the desktop. It is not all ours to spend."""
    with Machine(tmp_path) as m:
        rt, _ = m.plan()
        left = m.vram - rt["_card_claimed_mb"]
        assert left >= runtime.VRAM_RESERVE_MB - 1, f"only {left:.0f} MB left"


def test_the_host_still_has_a_ceiling_of_its_own(tmp_path):
    """
    The RAM half of the budget is the half that always worked. Adding the card
    must not have cost it: with the card able to take everything and the host
    nearly full, the window still comes down.
    """
    with Machine(tmp_path, vram=2000.0, ram=1500.0) as m:
        rt, adv = m.plan()
        assert 0 < rt["n_gpu_layers"] < 36, "this case needs a split model"
        assert rt["n_ctx"] < 32768 or adv, "host pressure went unnoticed"


# ═══════════════════════════════════════════════════════════════════════════
#  THE WINDOW SITS INSIDE WHAT IS LEFT
# ═══════════════════════════════════════════════════════════════════════════

def test_the_window_narrows_only_when_layers_cannot_save_it(tmp_path):
    """
    The order, and it matters more than it looks.

    A layer moved off the card takes its share of the cache with it, so the
    card almost never has to be answered with a smaller window - it can be
    answered with fewer layers. Layers cost tokens per second; the window is
    the memory this whole application is about. So layers go first.

    The window only gives when the HOST cannot hold what came off the card.
    Here the card is small and the RAM is nearly full, so there is nowhere
    left to put anything and the context is what has to yield.
    """
    with Machine(tmp_path, vram=2000.0, ram=1500.0) as m:
        rt, adv = m.plan()
        assert 0 < rt["n_gpu_layers"] < 36, "the model should have split"
        assert rt["n_ctx"] < 32768, "nothing gave, on a machine with no room"
        assert rt["n_ctx"] >= runtime.CTX_FLOOR
        assert adv and str(rt["n_ctx"]) in adv or "minimal context" in adv


def test_a_tight_card_is_answered_with_layers_not_context(tmp_path):
    """
    The same pressure, with RAM to spare. Nothing should be taken from the
    user's context: the card sheds layers until it fits and the window stays
    exactly where it was.
    """
    with Machine(tmp_path, vram=1400.0, ram=64000.0) as m:
        rt, adv = m.plan()
        assert rt["n_ctx"] == 32768, f"context was spent on the card: {adv}"
        assert rt["n_gpu_layers"] < 36
        assert rt["_card_claimed_mb"] <= m.ceiling


def test_the_window_is_not_narrowed_for_a_ceiling_that_does_not_bind(tmp_path):
    """
    The machine this was written for keeps its whole 32k window. Shrinking a
    context that fits is the same class of mistake as overrunning one that
    does not - it is just the one nobody notices.
    """
    with Machine(tmp_path) as m:
        rt, adv = m.plan()
        assert rt["n_ctx"] == 32768, f"lost context for no reason: {adv}"


def test_the_window_never_falls_below_the_floor(tmp_path):
    with Machine(tmp_path, vram=700.0, ram=900.0) as m:
        rt, _ = m.plan()
        assert rt["n_ctx"] >= runtime.CTX_FLOOR


# ═══════════════════════════════════════════════════════════════════════════
#  NOTHING IS REFUSED
# ═══════════════════════════════════════════════════════════════════════════

def test_a_model_far_too_large_still_starts_and_says_so(tmp_path):
    """
    "It is the user's machine and their model." A budget that can say no is a
    model dropdown that is really a list of suggestions.
    """
    with Machine(tmp_path, vram=512.0, ram=800.0,
                 blocks=35, block_mb=900.0, outside_mb=900.0) as m:
        rt, adv = m.plan()
        assert adv, "silently starting something that will not fit"
        assert rt["n_ctx"] >= runtime.CTX_FLOOR
        ok, _ = runtime.fits(MODEL, dict(BASE_RT))
        assert ok is True, "fits() has been turned back into a gate"


def test_fit_policy_off_says_nothing_and_changes_nothing(tmp_path):
    with Machine(tmp_path, vram=512.0, ram=800.0) as m:
        rt, adv = m.plan(fit_policy="off")
        assert adv == "" and rt["n_ctx"] == 32768
        assert rt.get("n_gpu_layers") == "auto", "off still touched the card"


def test_fit_policy_warn_speaks_and_changes_nothing(tmp_path):
    with Machine(tmp_path, vram=2000.0, ram=1500.0) as m:
        rt, adv = m.plan(fit_policy="warn")
        assert adv and rt["n_ctx"] == 32768, "warn narrowed the window"
        # The offload is still worked out, because "auto" is a request for the
        # application to decide, not a setting warn is protecting. A user who
        # wants llama.cpp's own default says so - n_gpu_layers: "all".
        assert isinstance(rt["n_gpu_layers"], int)


def test_all_asks_for_llama_cpps_own_default_back(tmp_path):
    """
    One explicit way out. Before this repair there was no way IN - "auto"
    silently meant "every layer" - and an escape hatch that cannot be named
    is not one.
    """
    with Machine(tmp_path) as m:
        rt, _ = m.plan(n_gpu_layers="all")
        assert rt["n_gpu_layers"] == "all"
        assert "-ngl" not in runtime._argv(m.path, 8090, rt, gpu=True)


def test_the_start_path_has_no_way_to_bail_out(tmp_path):
    """
    Guarded structurally, not by behaviour: a future edit that reintroduces a
    refusal inside start() would pass every test above.
    """
    src = pathlib.Path("runtime.py").read_text(encoding="utf-8")
    body = src[src.index("def start(model_name"):src.index("def stop()")]
    assert "return {\"ok\": False, \"error\": f\"unknown model" in body
    for banned in ("too large", "will not fit", "refus"):
        assert banned not in body.lower(), f"start() can now refuse: {banned}"


# ═══════════════════════════════════════════════════════════════════════════
#  THE CACHE IS SIZED THE WAY LLAMA.CPP SIZES IT
# ═══════════════════════════════════════════════════════════════════════════

def test_a_windowed_layer_is_not_charged_a_full_length_cache(tmp_path):
    """
    llama_kv_cache_iswa builds two caches:

        size_base = n_ctx
        size_swa  = PAD(min(n_ctx, n_swa + n_ubatch), 256)

    Five layers in six are windowed on a Gemma, so charging all of them the
    full length overstates the cache several times over - and an overstated
    cache is a context window taken away from the user for nothing.
    """
    m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "g.gguf", GEMMA, 35, 1, 1))
    real = m.kv_mb(32768)
    naive = m.kv_bytes_per_token("f16") * 32768 / 1048576.0
    assert real < naive / 4, f"{real:.0f} MB vs a full-length {naive:.0f} MB"
    # And it stops growing: past the window, only the six full layers do.
    assert m.kv_mb(32768) < m.kv_mb(8192) * 3


def test_a_full_attention_model_is_still_charged_a_full_cache(tmp_path):
    """No window in the header means no discount. Qwen must not get one."""
    m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "d.gguf", DENSE, 35, 1, 1))
    naive = m.kv_bytes_per_token("f16") * 32768 / 1048576.0
    assert abs(m.kv_mb(32768) - naive) < naive * 0.02, \
        f"{m.kv_mb(32768):.0f} MB where full attention costs {naive:.0f} MB"


def test_layers_that_share_a_cache_are_not_charged_for_one(tmp_path):
    """
    Gemma 3n and Gemma 4 let later layers reuse an earlier layer's cache:
    `n_layer_kv_from_start = n_layer_all - shared_kv_layers`. Twenty of the
    thirty-five allocate; fifteen do not.
    """
    m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "g.gguf", GEMMA, 35, 1, 1))
    assert m.kv_layers == 20, m.kv_layers
    assert m.kv_mb_layers(0, 20, 8192) == m.kv_mb(8192)
    assert m.kv_mb_layers(20, 35, 8192) == 0.0


def test_the_cache_is_split_the_way_the_layers_are(tmp_path):
    """
    A layer's cache lives where the layer lives, and llama.cpp offloads from
    the END. So which half of the cache lands on the card is a question about
    a slice of the layers - and with a sliding window the slice is not a
    fraction of the whole.
    """
    m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "g.gguf", GEMMA, 35, 1, 1))
    whole = m.kv_mb(16384)
    halves = m.kv_mb_layers(0, 18, 16384) + m.kv_mb_layers(18, 35, 16384)
    assert abs(whole - halves) < 0.01


def test_a_budget_and_the_window_it_buys_agree(tmp_path):
    for meta in (GEMMA, DENSE):
        m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "x.gguf", meta, 35, 1, 1))
        for budget in (40.0, 120.0, 400.0):
            ctx = m.ctx_for_budget(budget)
            assert m.kv_mb(ctx) <= budget + 0.01, (meta["general.architecture"],
                                                   budget, ctx, m.kv_mb(ctx))
            if ctx < (m.train_ctx or 32768):
                assert m.kv_mb(ctx + 512) > budget, "left room on the table"


def test_an_unreadable_header_falls_back_instead_of_raising(tmp_path):
    p = pathlib.Path(tmp_path) / "junk.gguf"
    p.write_bytes(b"NOTGGUF" + b"\0" * 4096)
    assert gguf.read(p) is None
    with Machine(tmp_path) as m:
        m.path.write_bytes(b"NOTGGUF" + b"\0" * 4096)
        rt, _ = m.plan()          # must not raise
        assert "n_ctx" in rt


# ═══════════════════════════════════════════════════════════════════════════
#  THE PER-LAYER COST IS READ, NOT PRORATED
# ═══════════════════════════════════════════════════════════════════════════

def test_the_per_layer_cost_comes_from_the_tensor_table(tmp_path):
    """
    "The file divided by the layer count" is wrong in the direction that
    matters. A GGUF also holds the token embedding - for a 262,144-token
    vocabulary, the largest tensor in the file - which is not a layer.
    Prorating spreads it over all of them, undercounts each, and offers the
    card more layers than it can hold.
    """
    p = write_gguf(pathlib.Path(tmp_path) / "g.gguf", GEMMA,
                   blocks=35, block_mb=50.0, outside_mb=700.0)
    m = gguf.read(p)
    assert len(m.blocks) == 35 and abs(m.outside_mb - 700) < 1
    prorated = m.size_mb / 36 * 36
    assert abs(m.weights_mb_on_card(36) - prorated) < 5     # all of it, agreed
    # …but a single layer is 50 MB, not the 68 MB proration claims.
    assert abs(m.weights_mb_on_card(2) - m.weights_mb_on_card(1) - 50) < 1
    assert m.weights_mb_on_card(1) > 600, "the output head went uncounted"


def test_the_output_head_is_the_first_thing_offloaded(tmp_path):
    """
    `i_gpu_start = n_layer_all + 1 - n_gpu_layers`, so the extra slot beyond
    the blocks - the output head - is the last index and therefore the first
    thing to move. On a large-vocabulary model it is also the biggest, which
    is why the first offloaded "layer" costs far more than the second.
    """
    m = gguf.read(write_gguf(pathlib.Path(tmp_path) / "g.gguf", GEMMA,
                             blocks=35, block_mb=50.0, outside_mb=700.0))
    first = m.weights_mb_on_card(1)
    second = m.weights_mb_on_card(2) - first
    assert first > second * 10, f"{first:.0f} MB then {second:.0f} MB"
    assert m.weights_mb_on_card(0) == 0.0


def test_a_file_with_no_tensor_table_still_gets_a_number(tmp_path):
    with Machine(tmp_path, blocks=0, block_mb=0, outside_mb=0) as m:
        rt, _ = m.plan()
        assert isinstance(rt.get("n_gpu_layers"), int)


# ═══════════════════════════════════════════════════════════════════════════
#  MEASUREMENT BEATS ESTIMATE
# ═══════════════════════════════════════════════════════════════════════════

REPORT = """
load_tensors: offloading 27 repeating layers to GPU
load_tensors: offloaded 27/36 layers to GPU
load_tensors:        CUDA0 model buffer size =  2600.00 MiB
load_tensors:   CPU_Mapped model buffer size =  1086.00 MiB
llama_kv_cache:      CUDA0 KV buffer size =   180.00 MiB
llama_kv_cache:        CPU KV buffer size =    63.00 MiB
llama_context:       CUDA0 compute buffer size =   312.50 MiB
llama_context:   CUDA_Host compute buffer size =    72.00 MiB
llama_context:       CUDA0  output buffer size =     2.00 MiB
"""


def test_the_load_report_is_read_out_of_the_log():
    got = runtime.read_load_report(REPORT)
    assert got["ngl"] == 27 and got["layers"] == 36
    assert got["on_card_mb"] == 2600.0, got
    assert got["host_mb"] == 1086.0, "CPU_Mapped was counted as VRAM"
    # Compute and output on the card only. The KV we can already compute, and
    # CUDA_Host is pinned system memory, not the card.
    assert got["overhead_mb"] == 314.5, got


def test_a_load_that_never_reported_teaches_nothing():
    """
    A failed load must not be allowed to teach the budget anything, or one
    crash becomes a permanently wrong estimate.
    """
    assert runtime.read_load_report("ggml_backend_cuda: out of memory") == {}
    assert runtime.read_load_report("") == {}


def test_what_was_measured_is_used_next_time(tmp_path):
    """
    The buffers are the one figure that cannot be computed from a header - it
    depends on the build, the backend and the batch. So it is read back out of
    llama-server's own report, and a machine that has run this model once
    stops guessing at it.

    Both sides here are MEASURED, so the first-load share is out of the way
    and what is left is only the effect of the number itself.
    """
    with Machine(tmp_path, memo={"overhead_mb": 400.0,
                                 "n_ubatch": 512}) as light:
        roomy = light.plan()[0]["n_gpu_layers"]
    with Machine(tmp_path, memo={"overhead_mb": 1400.0,
                                 "n_ubatch": 512}) as heavy:
        assert heavy.plan()[0]["n_gpu_layers"] < roomy, \
            "a measured gigabyte of buffers changed nothing"


def test_an_unmeasured_model_is_offered_less_of_the_card(tmp_path):
    """
    THE CRASH THAT SURVIVED BUILD 27.

    Everything the card budget uses except the reserve is an estimate, and on
    the first load of a model there is no measurement to replace it - the
    report that corrects it does not exist until a load has produced one.
    Build 27 packed the card to within 60 MB of the ceiling on that estimate
    and the first load took the machine down; the second, budgeted from the
    measurement the first one left behind, was fine.

    The costs are not symmetric. Cautious costs one slower load. Wrong costs a
    hard reset.
    """
    with Machine(tmp_path) as first:
        blind = first.plan()[0]
    with Machine(tmp_path, memo={"overhead_mb": 560.0, "n_ubatch": 512}) as then:
        known = then.plan()[0]
    assert blind["n_gpu_layers"] < known["n_gpu_layers"], \
        "the first load is as bold as one that has been measured"
    assert blind["_card_claimed_mb"] <= first.ceiling * runtime.FIRST_LOAD_SHARE + 1


def test_the_penalty_is_for_not_knowing_not_for_having_failed(tmp_path):
    """
    "Learn from the past without being held back by it."

    A recorded power loss makes an UNMEASURED load more careful still. It must
    not make a measured one careful at all, or one bad night becomes a
    permanent tax on a machine that has since been proved fine.
    """
    saved = runtime._POWER
    try:
        runtime._POWER = {"when": "2026-09-10T04:55:02Z", "bugcheck": 0,
                          "kind": "power"}
        with Machine(tmp_path) as after_reset:
            scared = after_reset.plan()[0]["n_gpu_layers"]
        with Machine(tmp_path, memo={"overhead_mb": 560.0,
                                     "n_ubatch": 512}) as known:
            measured_after_reset = known.plan()[0]["n_gpu_layers"]
        runtime._POWER = {}
        with Machine(tmp_path) as clean:
            calm = clean.plan()[0]["n_gpu_layers"]
        assert scared < calm, "a reset last boot changed nothing"
        with Machine(tmp_path, memo={"overhead_mb": 560.0,
                                     "n_ubatch": 512}) as known2:
            assert known2.plan()[0]["n_gpu_layers"] == measured_after_reset, \
                "a measurement is being discounted because of an old reset"
    finally:
        runtime._POWER = saved


def test_a_measurement_at_a_different_batch_is_adjusted_not_discarded(tmp_path):
    """
    The buffers scale with the physical batch; the CUDA context inside them
    does not. A measurement taken at 512 still says something useful at 256.
    """
    memo = {"overhead_mb": 1000.0, "n_ubatch": 512}
    with Machine(tmp_path, memo=memo) as m:
        big = m.plan(n_ubatch=512)[0]["n_gpu_layers"]
        small = m.plan(n_ubatch=256)[0]["n_gpu_layers"]
    assert small >= big, "halving the batch did not give any of the card back"


def test_the_report_survives_a_round_trip_through_disk(tmp_path):
    with Machine(tmp_path) as m:
        runtime.memo = m._saved[4]              # the real one, not the stub
        (m.logs / "llama.log").write_text(
            "===== 2026-09-10 04:39:17 " + MODEL + " =====\n" + REPORT,
            encoding="utf-8")
        got = runtime.learn_from_log(MODEL, {"n_ctx": 32768})
        assert got.get("overhead_mb") == 314.5
        assert runtime.memo(MODEL)["ngl"] == 27
        assert runtime.memo("something-else.gguf") == {}


# ═══════════════════════════════════════════════════════════════════════════
#  THE VRAM READING IS NOT ETERNAL
# ═══════════════════════════════════════════════════════════════════════════

def test_the_card_is_read_again_after_it_has_been_occupied():
    """
    The reading used to be cached for the life of the process. One nvidia-smi
    call, made before llama-server started, answered every question after it -
    so plan() believed the card was empty on every reload, after every image
    generation, and after every model switch. The user's own runtime.log has
    the identical 3938 MB in 122 of 122 benchmarks across nine days. A number
    that never changes is not a measurement.
    """
    src = pathlib.Path("runtime.py").read_text(encoding="utf-8")
    fn = src[src.index("def vram_free_mb"):src.index("# llama.cpp mmaps")]
    assert "_vram_at" in fn, "the reading is cached with no way to expire"
    assert "if _vram is not None:\n        return _vram" not in fn, \
        "the permanent cache is back"
    for site in ("def stop()", "def start(model_name"):
        body = src[src.index(site):src.index(site) + 2200]
        assert "forget_vram()" in body, f"{site} does not re-read the card"


def test_one_planning_pass_does_not_pay_for_eight_readings(tmp_path):
    """
    The reading costs about 200 ms and resolve_ctx calls plan() eight times
    inside one binary search. Expiring the cache must not turn a startup into
    two seconds of nvidia-smi.
    """
    calls = []
    with Machine(tmp_path) as m:
        real = runtime.vram_free_mb
        runtime._vram = None
        runtime._vram_at = 0.0

        def counted():
            calls.append(1)
            runtime._vram, runtime._vram_at = m.vram, __import__("time").time()
            return m.vram
        runtime.vram_free_mb = lambda: (
            runtime._vram if runtime._vram is not None
            and (__import__("time").time() - runtime._vram_at)
            < runtime.VRAM_TTL else counted())
        try:
            runtime.resolve_ctx(MODEL, dict(BASE_RT, n_ctx="auto"))
        finally:
            runtime.vram_free_mb = real
            runtime._vram = None
    assert len(calls) <= 2, f"asked the card {len(calls)} times for one plan"


# ═══════════════════════════════════════════════════════════════════════════
#  THE PROJECTOR TAKES WHAT IS LEFT, AND NEVER MORE
# ═══════════════════════════════════════════════════════════════════════════

def test_the_projector_does_not_push_the_model_off_the_card(tmp_path):
    """
    projector_args was being handed `min(weights, vram * 0.66)` - the figure
    plan() invented and never sent - while the process was loading every
    layer. On a 4 GB card holding a 3.6 GB model that arithmetic reported
    about a gigabyte spare, so the projector was offloaded on top of a card
    that was already full.
    """
    with Machine(tmp_path) as m:
        write_gguf(m.dir / "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf",
                   {"general.architecture": (S, "clip")}, 1, 600.0, 0.0)
        argv = m.argv(gpu=True)
        assert "--mmproj" in argv, "sight was dropped instead of relocated"
        assert "--no-mmproj-offload" in argv, \
            "a 600 MB projector went onto a card with nothing left"


def test_the_projector_cannot_spend_the_first_load_margin(tmp_path):
    """
    The share held back on an unmeasured load is not spare room. A projector
    sized against raw free VRAM would have eaten exactly the margin that
    exists to keep the machine on - the same fault as before, one file over.

    So plan() hands out ONE number: what is left of the card inside the
    budget. Nothing downstream does its own subtraction.
    """
    with Machine(tmp_path) as m:
        write_gguf(m.dir / "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf",
                   {"general.architecture": (S, "clip")}, 1, 600.0, 0.0)
        rt, _ = m.plan()
        assert rt["_card_claimed_mb"] + rt["_card_free_mb"] \
            <= m.ceiling * runtime.FIRST_LOAD_SHARE + 1, \
            "the budget is handing out room it held back on purpose"
        argv = runtime._argv(m.path, 8090, rt, gpu=True)
        assert "--no-mmproj-offload" in argv


def test_the_projector_is_offloaded_when_there_is_genuinely_room(tmp_path):
    with Machine(tmp_path, vram=12000.0) as m:
        write_gguf(m.dir / "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf",
                   {"general.architecture": (S, "clip")}, 1, 600.0, 0.0)
        argv = m.argv(gpu=True)
        assert "--mmproj" in argv and "--no-mmproj-offload" not in argv


def test_the_curator_is_never_handed_a_projector(tmp_path):
    """
    The module docstring's promise: "The curator is never given -ngl. It
    cannot touch VRAM." A projector would have broken that quietly, because
    llama.cpp offloads a projector to the GPU unless told not to - so the
    CPU-only helper could have taken a share of the card the main model had
    already been budgeted.
    """
    with Machine(tmp_path) as m:
        write_gguf(m.dir / "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf",
                   {"general.architecture": (S, "clip")}, 1, 600.0, 0.0)
        argv = m.argv(gpu=False)
        assert "--mmproj" not in argv and "-ngl" not in argv


# ═══════════════════════════════════════════════════════════════════════════
#  THE POWER LEVER
# ═══════════════════════════════════════════════════════════════════════════

def test_the_batch_reaches_the_command_line(tmp_path):
    """
    Prefill runs one physical batch at a time, so this is the largest single
    thing the GPU is ever asked to do. Halving it halves that peak, and the
    peak is what an adapter with no battery behind it has to follow.
    """
    with Machine(tmp_path) as m:
        argv = m.argv(n_ubatch=256)
        assert _flag(argv, "-ub") == "256"
        assert int(_flag(argv, "-b")) >= 256, "-b must not be below -ub"


def test_a_gentler_batch_costs_context_or_layers_nothing(tmp_path):
    """
    The trade is prompt-processing speed and nothing else. It buys back a
    little of the card, because the compute buffer is smaller.
    """
    with Machine(tmp_path) as m:
        loud = m.plan(n_ubatch=512)[0]
        gentle = m.plan(n_ubatch=256)[0]
        assert gentle["n_ctx"] >= loud["n_ctx"]
        assert gentle["n_gpu_layers"] >= loud["n_gpu_layers"]


def test_the_batch_is_a_setting_the_user_owns():
    rt = core.DEFAULTS["runtime"]
    assert rt["n_ubatch"] == runtime.UBATCH_DEFAULT
    assert rt["n_batch"] >= rt["n_ubatch"]


# ═══════════════════════════════════════════════════════════════════════════
#  NO WALLS
# ═══════════════════════════════════════════════════════════════════════════

def test_nothing_in_the_budget_can_run_out_of_time():
    """
    "Don't become the reason it stops, let go and see if it runs." The ramp
    between load, warm-up, probe and benchmark is a sleep, which is the
    opposite of a deadline: nothing fails for taking longer.
    """
    src = pathlib.Path("runtime.py").read_text(encoding="utf-8")
    plan_src = src[src.index("def plan(model_name"):src.index("def _models_that_fit")]
    for banned in ("signal.alarm", "TimeoutError", "deadline"):
        assert banned not in plan_src, f"plan() has a {banned}"
    ramp = src[src.index("def _bring_up"):src.index("def available_mb")]
    assert "SETTLE_S" in ramp, "the bring-up ramp is gone"


def test_the_docstring_no_longer_promises_a_refusal():
    """
    It said "A MODEL THAT WILL NOT FIT IS REFUSED, NOT ATTEMPTED" while plan()
    said "THERE IS NO REFUSAL PATH, AND THAT IS DELIBERATE", in the same file,
    for thirteen releases. A file that contradicts itself teaches whoever
    reads it next the wrong thing.
    """
    src = pathlib.Path("runtime.py").read_text(encoding="utf-8")
    head = src[:src.index('"""', 3)]
    assert "REFUSED, NOT ATTEMPTED" not in head
    assert "TWO ceilings" in head


# ═══════════════════════════════════════════════════════════════════════════
#  THE USER CAN SEE IT, AND CHANGE IT
# ═══════════════════════════════════════════════════════════════════════════

def test_the_interface_offers_the_batch_and_keeps_it():
    ui = pathlib.Path("ui.html").read_text(encoding="utf-8")
    assert 'id="r_n_ubatch"' in ui, "the peak-power setting has no control"
    assert '"n_gpu_layers","n_ubatch"' in ui, "it is never filled in"
    assert 'd.runtime.n_ubatch=' in ui, "it is never saved"


def test_the_interface_shows_what_the_budget_decided():
    """
    A limiter nobody can see is indistinguishable from one that is not
    working, which is exactly how this one spent thirteen releases computing
    an answer and sending it nowhere.
    """
    ui = pathlib.Path("ui.html").read_text(encoding="utf-8")
    assert 'id="fitnote"' in ui
    assert "s.fit" in ui and "layers_on_card" in ui
    assert "power_note" in ui, "a reset the machine had is still invisible"
    srv = pathlib.Path("server.py").read_text(encoding="utf-8")
    assert '"fit": runtime.fit_state()' in srv


def test_the_state_endpoint_does_not_build_the_same_thing_twice():
    """
    /api/state is polled every two seconds for as long as the application is
    open. Six keys were duplicated in it - sight, focus, intake and ctx were
    each built, discarded, and built again - which is free to write and paid
    for thirty times a minute forever.
    """
    src = pathlib.Path("server.py").read_text(encoding="utf-8")
    body = src[src.index('if p == "/api/state"'):src.index('if p == "/api/session"')]
    for key in ('"sight"', '"focus"', '"intake"', '"ctx"', '"bench"'):
        assert body.count(key + ":") == 1, f"{key} is built twice per poll"
    assert body.count("runtime.bench()") == 1, "bench() is read three times"


def test_a_poll_does_not_reread_every_conversation(tmp_path):
    """
    carryover.marks() used to parse every session file on every poll. At a
    thousand conversations that is a thousand JSON files thirty times a
    minute, to produce twenty rows that had not changed - an idle CPU floor
    that grew with the length of the user's history.
    """
    import carryover
    saved = (core.SESSIONS, carryover._marks_memo.copy())
    core.SESSIONS = pathlib.Path(tmp_path) / "sessions"
    core.SESSIONS.mkdir(parents=True, exist_ok=True)
    try:
        import json as _json
        for i in range(5):
            (core.SESSIONS / f"s{i}.json").write_text(_json.dumps(
                {"id": f"s{i}", "updated": f"2026-09-0{i+1}T10:00:00",
                 "messages": [{"role": "user", "content": "hi"}]}),
                encoding="utf-8")
        carryover._marks_memo.clear()
        reads = []
        real = carryover.load
        carryover.load = lambda f: (reads.append(f.name), real(f))[1]
        try:
            carryover.marks(20)
            first = len(reads)
            carryover.marks(20)
            carryover.marks(20)
            assert first == 5, first
            assert len(reads) == 5, f"re-read {len(reads) - first} unchanged files"
        finally:
            carryover.load = real
    finally:
        core.SESSIONS = saved[0]
        carryover._marks_memo.clear()
        carryover._marks_memo.update(saved[1])


def test_the_event_log_is_actually_written_to_the_disk():
    """
    The log the whole memory can be rebuilt from. Buffered, its most recent
    minutes exist only in RAM - and this machine has been going off without
    warning, which is why the user's own events.jsonl now ends in NUL
    padding: Windows committed the new size and lost the bytes.
    """
    src = pathlib.Path("events.py").read_text(encoding="utf-8")
    w = src[src.index("def write(kind"):src.index("def read(")]
    assert "os.fsync" in w and "f.flush()" in w, \
        "the event log is buffered again"


if __name__ == "__main__":
    import testkit
    sys.exit(testkit.run(dict(globals()),
                         "fit - the model is made to fit, and the plan is sent"))
