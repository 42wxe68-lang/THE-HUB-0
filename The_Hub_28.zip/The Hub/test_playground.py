"""Playground boundary and file-workflow tests."""
from __future__ import annotations

import pathlib
import tempfile
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
TMP = pathlib.Path(tempfile.mkdtemp(prefix="hub-playground-test-"))
import core
core.DATA = TMP / "data"
core.TREE = core.DATA / "tree"
core.KNOWLEDGE = core.DATA / "knowledge"
core.ASH = core.DATA / "ash"
core.EVENTS = core.DATA / "events"
core.SESSIONS = core.DATA / "sessions"
core.LOGS = core.DATA / "logs"
core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS, core.SESSIONS, core.LOGS)
core.ensure_dirs()

import playground
import vault

# THIS SUITE USED TO WRITE INTO THE SHIPPING VAULT.
#
# core.DATA was redirected above, but vault.VAULT is core.ROOT / "vault" and
# was not - so every run of this file created note.txt, script.py and another
# numbered copy in the release tree. A build was packaged with twenty-nine of
# them. It is also, on a real install, this suite writing into the USER'S
# vault: the one directory the whole application is built never to touch.
#
# Playground is derived from core.DATA and follows it. The vault roots have
# to be moved by hand, all four of them.
vault.VAULT = TMP / "vault"
vault.AI_VAULT = vault.VAULT / "AI"
vault.CHAT_VAULT = vault.VAULT / "Chat"
vault.MADE_VAULT = vault.VAULT / "Made"
playground.ROOT = core.DATA / "playground"
vault.ensure(); playground.ensure()

PASS = 0
FAIL = 0

def check(name, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"ok   {name}")
    else:
        FAIL += 1
        print(f"FAIL {name}")

# Vault source is not modified by Playground operations.
source = vault.VAULT / "note.txt"
source.write_text("alpha\nbeta\n", encoding="utf-8")
copy = playground.copy_in(source)
pg = playground.resolve(copy["name"])
check("copy vault -> playground", pg and pg.read_text() == source.read_text())
pg.write_text("changed", encoding="utf-8")
check("vault remains unchanged", source.read_text() == "alpha\nbeta\n")

# Text edit and extension change.
playground.write_text("script.txt", "print('hello')\n")
edit = playground.edit_text("script.txt", "hello", "world")
check("edit playground text", edit["replacements"] == 1 and playground.resolve("script.txt").read_text() == "print('world')\n")
playground.rename("script.txt", "script.py")
check("rename changes extension", playground.resolve("script.py") is not None and playground.resolve("script.txt") is None)

# Saving is additive and never overwrites the existing vault copy.
res1 = playground.save_to_vault("script.py", vault.VAULT)
source2 = vault.VAULT / res1["name"]
source2.write_text("vault version", encoding="utf-8")
playground.write_text("script.py", "playground version", overwrite=True)
res2 = playground.save_to_vault("script.py", vault.VAULT)
check("save creates non-destructive second vault copy", res2["name"] != res1["name"] and source2.read_text() == "vault version")

# Path traversal rejected / confined.
check("playground traversal blocked", playground.resolve("../outside.txt") is None)
try:
    playground.write_text("../outside.txt", "bad")
    ok = False
except Exception:
    ok = True
check("write traversal blocked", ok)

playground.delete("script.py")
check("delete only removes playground copy", playground.resolve("script.py") is None and source2.exists())


# Tool gate accepts Playground operations and has no vault-write/delete operation.
import tools, policy
CFG = {"tools": {"web_search": False}}
policy.GATE.begin_turn("pg-gate")
for tool_name in ("list_playground", "copy_to_playground", "write_playground", "edit_playground",
                  "rename_playground", "delete_playground", "run_playground",
                  "convert_file", "save_playground"):
    # Only validate the tool's existence in the gate; required arguments are
    # tested by the real validators where appropriate.
    check(f"gate knows {tool_name}", policy.TIERS.get(tool_name, {}).get("tier") == policy.AUTO)
check("gate has no vault delete tool", "delete_vault" not in policy.TIERS)
check("gate has no vault overwrite tool", "write_vault" not in policy.TIERS)

# 3D visual path: a model-owned STL produces a preview that is attachable to a VLM turn.
import vision
tri = playground.ROOT / "visual_test.stl"
tri.write_bytes(b"solid t\nfacet normal 0 0 1\n outer loop\n vertex 0 0 0\n vertex 20 0 0\n vertex 0 20 10\n endloop\nendfacet\nendsolid t\n")
vision._cap.update({"checked": True, "sees": True, "via": "native"})
policy.GATE.begin_turn("pg-3d")
out = tools.run("open_file", {"name": "visual_test.stl", "scope": "playground", "about": "What is the shape?"}, CFG)[0]
shots = policy.GATE.attachments
check("playground 3D opens through the same file tool", "visual_test.stl" in out)
check("3D VLM gets an actual rendered preview", len(shots) == 1 and str(shots[0]["path"]).endswith(".preview.png"))

print(f"{PASS} passed, {FAIL} failed")
raise SystemExit(1 if FAIL else 0)
