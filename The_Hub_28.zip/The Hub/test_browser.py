"""
test_browser.py - the real page, in a real browser, against the real server.

    python test_browser.py

WHAT THIS ADDS OVER THE OTHER SUITES

test_ui.py reads ui.html as text: every element the script reaches for
exists, every fetch has a route behind it. test_live.py drives the server
over HTTP with no browser at all. Between them sits the class of fault that
neither can see - the page parses, the routes exist, and the thing is still
broken on screen.

Both of those were live in HUB-ZERO at once:

  * the composer was wrapped in a plain <div>, so the textarea stopped being
    a flex item and collapsed to its default `cols` width - a 205px stub
    beside a wide empty gap. Valid HTML, valid CSS, every test green.

  * `font:15px/1.55 inherit` is not valid shorthand, so the declaration was
    dropped entirely and the box silently rendered at the browser's 13.3px
    monospace default.

Neither is visible to a text-level check. Both are obvious the moment
something measures the rendered box. So this suite loads the page in
Chromium, measures what the user actually gets, types into it, sends, and
reads the reply out of the DOM.

Requires Playwright and Chromium. Where they are absent this reports
OPTIONAL and exits 0 - it is a developer check, not an install requirement.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

C = {"g": "\033[92m", "r": "\033[91m", "y": "\033[93m",
     "d": "\033[90m", "x": "\033[0m"}
_n = {"ok": 0, "fail": 0}


def check(label, cond, detail=""):
    if cond:
        _n["ok"] += 1
        print(f"  {C['g']}ok{C['x']}    {label}")
    else:
        _n["fail"] += 1
        print(f"  {C['r']}FAIL{C['x']}  {label}")
    if detail:
        print(f"        {C['d']}{detail}{C['x']}")


try:
    from playwright.sync_api import sync_playwright
except Exception:
    print(f"\n  {C['y']}OPTIONAL{C['x']}  Playwright is not installed - "
          f"the rendered-page checks were not run.")
    print(f"        {C['d']}pip install playwright && playwright install chromium"
          f"{C['x']}")
    sys.exit(0)

# ---------------------------------------------------------------- scratch

_TMP = Path(tempfile.mkdtemp(prefix="hub-browser-"))
import core                                                      # noqa: E402
core.DATA = _TMP / "data"
core.TREE = core.DATA / "tree"
core.KNOWLEDGE = core.DATA / "knowledge"
core.ASH = core.DATA / "ash"
core.EVENTS = core.DATA / "events"
core.SESSIONS = core.DATA / "sessions"
core.LOGS = core.DATA / "logs"
core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                 core.EVENTS, core.SESSIONS, core.LOGS)
core.CONFIG = _TMP / "config.json"
core.ensure_dirs()

import events, grove, memory, index, policy, vault, playground   # noqa: E402
import runtime, server                                           # noqa: E402

events.LOG = core.EVENTS / "events.jsonl"
grove.ASH_FILE = core.ASH / "ash.jsonl"
memory.YESOD_DIR = core.TREE / "yesod"
memory.ARCHIVE_DIR = core.SESSIONS / "archive"
memory.UNSORTED = core.TREE / "unsorted.jsonl"
vault.VAULT = _TMP / "vault"
vault.AI_VAULT = vault.VAULT / "AI"
vault.CHAT_VAULT = vault.VAULT / "Chat"
playground.ROOT = core.DATA / "playground"

ANSWER = "The composer is wide enough to write in now."

# A real spec-built mesh: pure Python, no model, no download, finishes in
# under a second. It exists so the browser can watch a genuinely generated
# file arrive in the middle of a turn.
SPEC = json.dumps({"units": "mm", "parts": [
    {"shape": "box", "size": [60, 40, 4], "radius": 3,
     "holes": [{"at": [10, 10], "d": 5}, {"at": [50, 30], "d": 5}]}]})
WANT_TOOL = {"on": False}          # flipped on for the generated-file turn


class StubModel(BaseHTTPRequestHandler):
    """Just enough of the chat-completions API to be a model."""

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json"):
        raw = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path.startswith("/health"):
            return self._send(200, '{"status":"ok"}')
        if self.path.startswith("/props"):
            return self._send(200, json.dumps(
                {"default_generation_settings": {"n_ctx": 8192},
                 "model_path": "stub.gguf"}))
        self._send(404, "{}")

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        body = json.loads(self.rfile.read(n) or b"{}")
        if not body.get("stream"):
            # The tool phase. Ask for the mesh once, then stop asking - a
            # stub that requested it every round would loop for six rounds.
            already = any(m.get("role") == "tool"
                          for m in body.get("messages") or [])
            if WANT_TOOL["on"] and not already:
                return self._send(200, json.dumps({"choices": [
                    {"message": {"role": "assistant", "content": "",
                                 "tool_calls": [
                                     {"id": "c1", "type": "function",
                                      "function": {"name": "generate_3d",
                                                   "arguments": json.dumps(
                                                       {"spec": SPEC})}}]},
                     "finish_reason": "tool_calls"}]}))
            return self._send(200, json.dumps({"choices": [
                {"message": {"role": "assistant", "content": ""},
                 "finish_reason": "stop"}]}))
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        for word in ANSWER.split(" "):
            chunk = {"choices": [{"delta": {"content": word + " "}}]}
            self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
            self.wfile.flush()
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


def main() -> int:
    cfg = core.load()
    cfg["model"] = "stub.gguf"
    cfg["tools"] = {"clock": True, "calculator": True, "remember": True,
                    "web_search": False, "generate_3d": True}
    # High enough that the turn below does not trip it; the round limit is
    # exercised on purpose further down with its own value.
    cfg.setdefault("chat", {})["rounds_per_conversation"] = 50
    core.save(cfg)

    stub = ThreadingHTTPServer(("127.0.0.1", core.MAIN_PORT), StubModel)
    stub.daemon_threads = True
    threading.Thread(target=stub.serve_forever, daemon=True).start()
    runtime._set("ready")
    if not runtime.health(runtime.MAIN, 3):
        print("ERROR: stub model did not come up")
        return 2

    # Something real to erase, so the confirmation screen shows counted
    # totals rather than a row of zeroes.
    memory.graft("keter", "Goes by Zero and builds local AI systems",
                 origin="user", truth="confirmed")
    memory.graft("gevurah", "Everything must run offline", origin="user")
    memory.save_session("browser-test", [{"role": "user", "content": "hi"},
                                         {"role": "assistant", "content": "hello"}])

    hub = ThreadingHTTPServer(("127.0.0.1", core.UI_PORT), server.H)
    hub.daemon_threads = True
    threading.Thread(target=hub.serve_forever, daemon=True).start()
    time.sleep(0.4)
    base = f"http://127.0.0.1:{core.UI_PORT}/"
    print(f"\n  The Hub on {base}   stub model on {runtime.MAIN}")

    errors = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        try:
            for width, height, label in ((1280, 860, "desktop"),
                                         (900, 700, "small window")):
                page = browser.new_page(viewport={"width": width,
                                                  "height": height})
                page.on("pageerror", lambda e: errors.append(f"{label}: {e}"))
                page.on("console", lambda m: errors.append(
                    f"{label}: console.error {m.text}")
                    if m.type == "error" else None)
                page.goto(base, wait_until="networkidle")
                page.wait_for_timeout(700)

                print(f"\n{label.upper()}  ({width}x{height})")

                box = page.evaluate("""() => {
                    const i = document.getElementById('in');
                    if (!i) return null;
                    const r = i.getBoundingClientRect();
                    const cs = getComputedStyle(i);
                    const f = document.querySelector('footer').getBoundingClientRect();
                    return {h: Math.round(r.height), w: Math.round(r.width),
                            left: Math.round(r.left), right: Math.round(r.right),
                            font: parseFloat(cs.fontSize),
                            family: cs.fontFamily,
                            footerW: Math.round(f.width)};
                }""")
                check("the composer exists and is measurable", box is not None)
                if not box:
                    continue

                # THE HUB-ZERO BUG: 205px of a 1280px window.
                share = box["w"] / box["footerW"]
                check("it fills the width it is given, not a default cols box",
                      share > 0.75,
                      f"{box['w']}px of {box['footerW']}px  ({share:.0%})")

                # Tall enough to look like somewhere you write a paragraph.
                check("it is at least three lines tall to begin with",
                      box["h"] >= 80, f"{box['h']}px")

                # THE INVALID-SHORTHAND BUG: silently 13.3px monospace.
                check("the font survived the stylesheet",
                      box["font"] >= 14.5,
                      f"{box['font']}px  {box['family'].split(',')[0]}")
                check("it inherits the interface font, not a monospace default",
                      "mono" not in box["family"].lower(),
                      box["family"].split(",")[0])

                # It must not push the send controls off screen or overlap.
                geo = page.evaluate("""() => {
                    const i = document.getElementById('in').getBoundingClientRect();
                    const s = document.getElementById('send').getBoundingClientRect();
                    return {gap: Math.round(s.left - i.right),
                            sendVisible: s.right <= window.innerWidth + 1 && s.width > 0,
                            bottom: Math.round(window.innerHeight - s.bottom)};
                }""")
                check("Send sits beside the composer, fully on screen",
                      geo["sendVisible"] and geo["gap"] >= 0,
                      f"gap {geo['gap']}px, {geo['bottom']}px from the bottom")

                # ---- it grows, and it stops growing ----------------------
                page.fill("#in", "\n".join(f"line {i}" for i in range(40)))
                page.dispatch_event("#in", "input")
                page.wait_for_timeout(250)
                grown = page.evaluate(
                    "() => Math.round(document.getElementById('in')"
                    ".getBoundingClientRect().height)")
                check("it grows as the message gets longer",
                      grown > box["h"], f"{box['h']}px -> {grown}px")
                check("it stops before it eats the conversation",
                      grown <= height * 0.45,
                      f"{grown}px in a {height}px window")

                page.close()

            # ---- a generated file appears IN the conversation ----------
            print("\nWHAT NOVA MAKES IS SHOWN IN THE CHAT, NOT FILED AWAY")
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.on("pageerror", lambda e: errors.append(f"made: {e}"))
            page.goto(base, wait_until="networkidle")
            page.wait_for_timeout(700)

            shown = page.evaluate("""() => {
                const ui = bubble("assistant");
                renderMade(ui, [
                  {name: "2026-09-01 1432 girl on a swing.png", kind: "image",
                   url: "/api/playground/file/x.png", mb: 0.9},
                  {name: "2026-09-01 1447 bracket 2 holes.stl", kind: "model3d",
                   url: "/api/playground/file/b.stl",
                   preview: "/api/playground/file/b.png", mb: 0.1},
                  {name: "2026-09-01 1502 waves.mp4", kind: "video",
                   url: "/api/playground/file/v.mp4", mb: 3.4}]);
                const box = ui.b.querySelector(".made");
                return {
                  cards: box ? box.querySelectorAll(".madeitem").length : 0,
                  imgs: box ? box.querySelectorAll("img").length : 0,
                  videos: box ? box.querySelectorAll("video").length : 0,
                  links: box ? [...box.querySelectorAll(".madecap a")]
                                 .map(a => a.textContent) : [],
                  inMessage: !!(box && box.closest(".bub"))
                };
            }""")
            check("a card is rendered for each generated file",
                  shown["cards"] == 3, str(shown["cards"]))
            check("an image renders as a picture, not a filename",
                  shown["imgs"] >= 1, f"{shown['imgs']} img element(s)")
            check("a 3D model shows its rendered views",
                  shown["imgs"] >= 2, "a .glb cannot be displayed; the "
                                      "six-view render can")
            check("a video gets a player", shown["videos"] == 1)
            check("each one keeps a link with its real name",
                  len(shown["links"]) == 3
                  and "girl on a swing" in shown["links"][0],
                  str(shown["links"][:1]))
            check("and it sits inside the message, not in another pane",
                  shown["inMessage"] is True)
            page.close()

            # ---- AND IT IS STILL THERE WHEN SHE STARTS TALKING ---------
            #
            # THE VANISHING PICTURE.
            #
            # The user watched an image finish generating, appear in the
            # chat, and then disappear the instant Nova began her answer.
            # The file was fine - still sitting in the Playground. What went
            # was the DOM node: the stream handler wrote the answer with
            #
            #     ui.b.textContent = ans
            #
            # and textContent replaces every child a node has. The card had
            # been appended to that same node a moment earlier, so the first
            # token of the reply deleted it. So did the confirm box.
            #
            # This drives a real turn that really builds a mesh, then checks
            # the card is still in the message after the answer has finished
            # streaming. Under the old code it is gone.
            print("\nA GENERATED FILE SURVIVES THE ANSWER THAT FOLLOWS IT")
            WANT_TOOL["on"] = True
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.on("pageerror", lambda e: errors.append(f"survive: {e}"))
            page.goto(base, wait_until="networkidle")
            page.wait_for_timeout(700)

            page.click("#in")
            page.type("#in", "make me a bracket")
            page.click("#send")

            # It must be on screen BEFORE the words are, or this proves nothing.
            page.wait_for_selector(".msg.assistant .made .madeitem",
                                   timeout=60000)
            # The structural guarantee, not a timing one: the card is a
            # sibling of the text node, never a child of it, so no write to
            # the text can reach it however the turn is paced.
            shape = page.evaluate("""() => {
                const b = [...document.querySelectorAll('.msg.assistant .bub')].pop();
                const made = b && b.querySelector('.made');
                const say = b && b.querySelector('.say');
                return {ok: !!(made && say) && made.parentNode === b
                             && !say.contains(made),
                        said: say ? say.textContent.length : -1};
            }""")
            check("the card hangs off the bubble, not off the answer text",
                  shape["ok"] is True,
                  f"{shape['said']} characters of answer written so far")

            page.wait_for_function(
                "() => document.body.innerText.includes('composer is wide enough')",
                timeout=60000)
            page.wait_for_timeout(600)

            after = page.evaluate("""() => {
                const b = [...document.querySelectorAll('.msg.assistant .bub')].pop();
                const made = b ? b.querySelector('.made') : null;
                return {cards: made ? made.querySelectorAll('.madeitem').length : 0,
                        answer: b ? (b.querySelector('.say')||{}).textContent || '' : '',
                        name: made ? (made.querySelector('.madecap a')||{}).textContent || '' : ''};
            }""")
            check("the answer streamed into the same message",
                  "composer is wide enough" in after["answer"],
                  after["answer"][:60])
            check("AND THE FILE IS STILL THERE",
                  after["cards"] >= 1,
                  f"{after['cards']} card(s) surviving; {after['name']}")
            check("it kept its date-stamped name",
                  after["name"].endswith(".stl") and after["name"][:4].isdigit(),
                  after["name"])
            WANT_TOOL["on"] = False
            page.close()

            # ---- the erase-memory confirmation, on screen ---------------
            print("\nERASING MEMORY NEEDS TWO DELIBERATE PRESSES")
            page = browser.new_page(viewport={"width": 1280, "height": 900})
            page.on("pageerror", lambda e: errors.append(f"purge: {e}"))
            page.goto(base, wait_until="networkidle")
            page.wait_for_timeout(700)

            page.click("#gear")
            page.wait_for_timeout(250)
            page.click("#tab_set")
            page.wait_for_timeout(250)

            veil = page.locator("#purgeveil")
            check("the confirmation screen starts hidden",
                  veil.is_hidden())

            page.locator('[data-purge="everything"]').scroll_into_view_if_needed()
            page.locator('[data-purge="everything"]').click()
            page.wait_for_timeout(600)
            check("clicking the red button opens it", veil.is_visible())

            title = page.inner_text("#purgetitle")
            tally = page.inner_text("#purgetally")
            verdict = page.inner_text("#purgeverdict")
            check("it names what is about to happen",
                  "erase everything" in title.lower(), title)
            check("it shows counted totals rather than asking blind",
                  "on disk" in tally.lower(), tally.replace("\n", " | ")[:90])
            check("and warns that this one cannot be undone",
                  "cannot be undone" in verdict.lower(), verdict[:80])

            check("Yes becomes usable only once the totals have arrived",
                  page.locator("#purgeyes").is_enabled())

            # Every route out that is NOT Yes must leave memory alone.
            page.click("#purgeno")
            page.wait_for_timeout(250)
            check("No closes it", veil.is_hidden())

            page.locator('[data-purge="everything"]').click()
            page.wait_for_timeout(500)
            page.keyboard.press("Escape")
            page.wait_for_timeout(250)
            check("Esc closes it", veil.is_hidden())

            page.locator('[data-purge="everything"]').click()
            page.wait_for_timeout(500)
            page.mouse.click(20, 20)
            page.wait_for_timeout(250)
            check("clicking outside closes it", veil.is_hidden())

            leaves_before = json.loads(
                page.evaluate("async () => JSON.stringify("
                              "await (await fetch('/api/state')).json())")
            ).get("memory", {}).get("leaves", 0)
            check("and after all three, nothing has been erased",
                  leaves_before == memory.status()["leaves"],
                  f"{memory.status()['leaves']} leaves still stored")

            # Now actually do it.
            page.locator('[data-purge="conversations"]').click()
            page.wait_for_timeout(600)
            check("a narrower scope says it keeps the memories",
                  "stays in memory" in page.inner_text("#purgeverdict").lower(),
                  page.inner_text("#purgeverdict")[:80])
            page.click("#purgeyes")
            page.wait_for_timeout(900)
            check("pressing Yes closes the screen", veil.is_hidden())
            check("and the conversations are gone",
                  memory.status()["sessions"] == 0,
                  f"{memory.status()['sessions']} session(s)")
            check("while the memories are not",
                  memory.status()["leaves"] > 0,
                  f"{memory.status()['leaves']} leaves kept")
            page.close()

            # ---- a real turn, typed and sent, read back from the DOM -----
            print("\nA REAL TURN, THROUGH THE PAGE")
            page = browser.new_page(viewport={"width": 1280, "height": 860})
            page.on("pageerror", lambda e: errors.append(f"turn: {e}"))
            page.goto(base, wait_until="networkidle")
            page.wait_for_timeout(700)

            page.click("#in")
            page.type("#in", "hello from the browser test")
            typed = page.input_value("#in")
            check("typing reaches the composer", typed.endswith("test"), typed)

            page.click("#send")
            page.wait_for_function(
                "() => document.body.innerText.includes('composer is wide enough')",
                timeout=20000)
            body = page.inner_text("body")
            check("the message the user typed is shown in the log",
                  "hello from the browser test" in body)
            check("the model's reply streams into the page",
                  ANSWER.split(".")[0] in body)
            check("the composer is cleared after sending",
                  page.input_value("#in") == "")

            # ---- A REFRESH MUST NOT LOSE THE CONVERSATION (ADR-126) -----
            #
            # `let history=[]` at the top of ui.html was the whole of the
            # browser's memory, rebuilt empty on every load, while the
            # server still held every turn. There was no error and nothing
            # in a log: the machine simply forgot, silently, on F5.
            page.reload(wait_until="networkidle")
            page.wait_for_timeout(1500)
            body = page.inner_text("body")
            check("a refresh does not lose the conversation",
                  "hello from the browser test" in body, body[:200])
            check("and the page says where it came back from",
                  "restored from this machine" in body)

            # ---- FAILURE TAKES TWO PRESSES ------------------------------
            #
            # The button sits between the eye and the settings gear. A
            # stray click would mark a conversation that was going fine as
            # a failure, which does not merely lose it - it teaches her the
            # wrong thing about what going wrong looks like.
            before = sorted(f.name for f in core.SESSIONS.glob("*.json"))
            page.click("#fail")
            page.wait_for_timeout(500)
            body = page.inner_text("body")
            check("one press only arms it",
                  "hello from the browser test" in body
                  and "Marked a failure" not in body, body[:200])

            page.click("#fail")
            page.wait_for_function(
                "() => document.body.innerText.includes('Marked a failure')",
                timeout=15000)
            body = page.inner_text("body")
            check("the second press ends the conversation",
                  "hello from the browser test" not in body, body[:200])
            after = sorted(f.name for f in core.SESSIONS.glob("*.json"))
            check("and the transcript it ended was kept, not deleted",
                  bool(before) and set(before) <= set(after),
                  f"{before} -> {after}")

            marked = [core.read_json(f, {}) for f in core.SESSIONS.glob("*.json")]
            check("and it is marked a failure on disk",
                  any(d.get("outcome") == "failure" for d in marked),
                  str([d.get("outcome") for d in marked]))
            check("and the mark is written where it can be read back",
                  (core.LOGS / "failure.log").is_file()
                  and "marked a failure" in
                  (core.LOGS / "failure.log").read_text(encoding="utf-8"))
            page.close()

            # ---- AND ONE ENDS ITSELF AFTER ITS ROUNDS -------------------
            #
            # A conversation that never ends is one conversation forever:
            # the transcript grows until it fills the window and every turn
            # is spent at full context.
            print("\nA CONVERSATION THAT ENDS ITSELF")
            _c = core.load()
            _c.setdefault("chat", {})["rounds_per_conversation"] = 1
            core.save(_c)
            page = browser.new_page(viewport={"width": 1280, "height": 860})
            page.on("pageerror", lambda e: errors.append(f"rounds: {e}"))
            page.goto(base, wait_until="networkidle")
            page.wait_for_timeout(700)
            page.click("#in")
            page.type("#in", "one round and then it should end")
            page.click("#send")
            page.wait_for_function(
                "() => document.body.innerText.includes('this conversation is finished')",
                timeout=30000)
            check("it says the conversation is finished and kept",
                  "finished and kept" in page.inner_text("body"))
            page.wait_for_function(
                "() => document.body.innerText.includes('New conversation after')",
                timeout=15000)
            body = page.inner_text("body")
            check("and it starts a new one",
                  "one round and then it should end" not in body, body[:200])
            check("and the reply was delivered before the line was drawn",
                  "New conversation after 1 rounds" in body, body[:200])
            unmarked = [core.read_json(f, {}) for f in core.SESSIONS.glob("*.json")]
            check("a conversation that ends on rounds is NOT marked bad",
                  any(d.get("outcome") == "" and
                      any("one round and then" in str(m.get("content", ""))
                          for m in d.get("messages", []))
                      for d in unmarked),
                  str([(d.get("id"), d.get("outcome")) for d in unmarked]))
            page.close()
        finally:
            browser.close()

    real = [e for e in errors if "api/state" not in e and "Failed to load" not in e]
    check("the page raised no script errors", not real,
          "; ".join(real[:3]) if real else "")

    print("\n" + "=" * 62)
    print(f"  {_n['ok']} passed, {_n['fail']} failed")
    print("=" * 62)
    return 1 if _n["fail"] else 0


if __name__ == "__main__":
    sys.exit(main())
