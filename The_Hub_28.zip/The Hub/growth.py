"""
growth.py - how the tree changes SHAPE. Branches widen into limbs, thin ones
merge back, and nothing has to be told when.

    "it should branch from the limbs and be allowed limbs as needed or to
     drop a limb when makes sense, branches become limbs if wide enough with
     information flows, remember these are the pathways and they are not the
     information stored at the leaves"

Pathways, not contents. Everything in this file decides where a memory HANGS
and never what it says. A leaf is not touched by any of it.

═══════════════════════════════════════════════════════════════════════════
 WHAT DECIDES, AND WHY IT IS NOT A THRESHOLD
═══════════════════════════════════════════════════════════════════════════

The obvious version of "a branch becomes a limb when it is wide enough" is a
number - promote at 20 leaves, say - and it is wrong in a way that shows up
immediately. Twenty near-identical notes about one bracket are not a limb;
they are one subject with a lot said about it. Six notes covering six
genuinely different things might be. SIZE IS NOT STRUCTURE, and a count
cannot tell them apart.

CATEGORY UTILITY can, and it has no free parameters at all (Fisher 1987,
after Gluck & Corter):

    CU = (1/K) · Σ_k P(C_k) [ Σ_i Σ_j P(A_i=v_ij | C_k)²
                              − Σ_i Σ_j P(A_i=v_ij)²    ]

Read it as: how much better you can guess a memory's features once you know
which branch it is on, than you could from the tree as a whole - divided by
how many branches that costs.

That divisor is the whole thing. Without it, every memory becomes its own
branch, because a partition into singletons predicts perfectly. With it, a
split has to EARN the extra branch by explaining something. So:

    a big uniform branch          does not promote - its children add no
                                  predictive power to justify the extra K
    a big and varied branch       promotes - the children really are
                                  different things
    a distinction that stops
    mattering                     MERGES BACK, automatically, when the
                                  features that separated it stop predicting

Category death falls out of the same arithmetic instead of needing a rule of
its own, and nothing is lost when it happens: the leaves land in the merged
parent.

WHEN TO LOOK is a separate question, and re-scoring the whole tree on a timer
would be both expensive and wrong. SUSTAIN (Love, Medin & Gureckis 2004)
answers it with a surprise gate: look only when something arrived that did
not fit anything already there - max activation below tau, tau = 0.5, fixed
and not fitted. Ordinary writes are ordinary and cost nothing.

Sources and parameters are recorded in DECISIONS.md, ADR-119.
"""
from __future__ import annotations

import math
import re

import core
import events

# ── the surprise gate ────────────────────────────────────────────────────
#
# SUSTAIN's recruitment threshold. The one number in this file, and it is
# the one the authors fixed rather than fitted.
TAU = 0.5

# A branch cannot be considered for promotion until it could plausibly hold
# more than one thing. From the Chinese Restaurant Process: the expected
# number of clusters in n items is alpha * ln(1 + n/alpha), so this is the n
# at which that reaches 2. A cheap filter before spending the real test.
ALPHA = 1.0
MIN_TO_CONSIDER = 7

# Merging is the more dangerous direction - it removes a distinction that
# might come back - so it needs a clear win rather than a tie.
MERGE_MARGIN = 1.02


def _features(text: str, tags=None) -> set:
    """
    What a memory is 'made of', for the purpose of deciding where it hangs.

    Deliberately shallow. This is not understanding the sentence; it is
    having enough of a fingerprint to tell whether two memories belong
    together, and a longer analysis here would be a slower way to get the
    same partition.
    """
    import grove
    words = {w for w in re.findall(r"[a-z0-9][a-z0-9'-]{2,}",
                                   (text or "").lower())
             if w not in grove.STOP}
    return grove.stems(words) | {str(t).lower() for t in (tags or [])}


def _profile(items) -> tuple:
    """(counts per feature, n) for a group of (text, tags) pairs."""
    counts, n = {}, 0
    for text, tags in items:
        n += 1
        for f in _features(text, tags):
            counts[f] = counts.get(f, 0) + 1
    return counts, n


def _predictability(counts: dict, n: int) -> float:
    """
    Sum of P(feature)^2 - the chance of guessing a feature right twice over.

    This is the inner sum of category utility. High means the members of
    this group look alike; low means they are a jumble.
    """
    if n <= 0:
        return 0.0
    return sum((c / n) ** 2 for c in counts.values())


def category_utility(groups) -> float:
    """
    How much the partition helps, per branch it costs.

    `groups` is a list of lists of (text, tags). An empty or single-group
    partition explains nothing, by definition.
    """
    groups = [g for g in groups if g]
    if len(groups) < 2:
        return 0.0
    everything = [x for g in groups for x in g]
    all_counts, total = _profile(everything)
    base = _predictability(all_counts, total)
    gain = 0.0
    for g in groups:
        counts, n = _profile(g)
        gain += (n / total) * (_predictability(counts, n) - base)
    return gain / len(groups)


def surprised(existing, text: str, tags=None) -> bool:
    """
    Did this arrive without a home?

    SUSTAIN's rule: the best match among what already exists is below tau.
    Nothing is restructured on a schedule - this is what says look now.
    """
    f = _features(text, tags)
    if not f:
        return False
    best = 0.0
    for group in existing:
        counts, n = _profile(group)
        if n <= 0:
            continue
        # Overlap with the group's typical member, which is what SUSTAIN's
        # activation measures with a receptive field.
        shared = sum(min(counts.get(x, 0) / n, 1.0) for x in f)
        best = max(best, shared / max(len(f), 1))
    return best < TAU


def should_promote(children, siblings) -> tuple:
    """
    (yes, why) - should this branch's children become branches themselves?

    Promotion is not about size. A big uniform branch stays one branch; a
    big VARIED branch splits, because only then do the children explain
    something the parent could not.
    """
    kids = [c for c in children if c]
    if len(kids) < 2:
        return False, "it has nothing to split into"
    n = sum(len(c) for c in kids)
    if n < MIN_TO_CONSIDER:
        return False, (f"only {n} memories - too few for the split to mean "
                       f"anything yet")
    together = [x for c in kids for x in c]
    now = category_utility([together] + [s for s in siblings if s])
    after = category_utility(list(kids) + [s for s in siblings if s])
    if after > now:
        return True, (f"splitting it explains more than keeping it whole "
                      f"({after:.3f} against {now:.3f})")
    return False, (f"its parts are not different enough to be worth separate "
                   f"branches ({after:.3f} against {now:.3f})")


def should_merge(a, b, others) -> tuple:
    """
    (yes, why) - have these two stopped being different things?

    The distinction dies when the features that made it stop predicting
    anything. Nothing is lost: the leaves land together.
    """
    if not a or not b:
        return False, "one of them is empty"
    apart = category_utility([a, b] + [o for o in others if o])
    joined = category_utility([a + b] + [o for o in others if o])
    if joined > apart * MERGE_MARGIN:
        return True, (f"the difference between them no longer predicts "
                      f"anything ({joined:.3f} against {apart:.3f})")
    return False, "they are still telling different things apart"


# ── the limbs that are always there ──────────────────────────────────────
#
#     "it should have enough permanent branches to keep going and never
#      stop such as observations, people known (this would include AI and
#      any other it can talk to), and other things related to its
#      environment, studies"
#
# A person does not derive "there are other people" from experience; they
# start with somewhere to put people. These are the places that exist before
# anything has been learned, so that the first thing learned has somewhere
# to go. They can grow branches and they can never be merged away.
PERMANENT = {
    "observations": "things that were actually seen or measured here",
    "people": "everyone known, including other machines and models",
    "environment": "this computer, its parts, and what is on it",
    "studies": "what is being learned and worked on",
    "doing": "what has been tried, how it went, what it cost",
}


def is_permanent(name: str) -> bool:
    return str(name or "").strip().lower() in PERMANENT


def plan(limb) -> list:
    """
    What this limb's shape should become. Reads only; changes nothing.

    Returned as a list of intentions so a caller can log them, show them, or
    apply them - and so that a restructuring is never a silent side effect
    of writing a memory down.
    """
    out = []
    branches = [b for b in limb.branches.values()]
    groups = {b.name: [(l.content, l.tags) for l in b.leaves]
              for b in branches}
    names = list(groups)

    for name in names:
        if is_permanent(name):
            continue
        kids = _split_by_feature(groups[name])
        others = [groups[o] for o in names if o != name]
        yes, why = should_promote(kids, others)
        if yes:
            out.append({"do": "promote", "branch": name,
                        "into": len(kids), "why": why})

    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if is_permanent(a) or is_permanent(b):
                continue
            others = [groups[o] for o in names if o not in (a, b)]
            yes, why = should_merge(groups[a], groups[b], others)
            if yes:
                out.append({"do": "merge", "branch": a, "with": b,
                            "why": why})
                break
    return out


def _split_by_feature(items) -> list:
    """
    The most telling division of a group, by its single most divisive
    feature. Crude on purpose: this exists to ASK whether a split is worth
    making, and the real division is done by the branch matcher afterwards.
    """
    counts, n = _profile(items)
    if n < 2:
        return [items]
    # A feature that half of them share divides the group best; one that all
    # or none share divides nothing.
    best, score = None, 0.0
    for f, c in counts.items():
        share = c / n
        near = 1.0 - abs(share - 0.5) * 2.0
        if near > score:
            best, score = f, near
    if best is None or score <= 0.0:
        return [items]
    left = [x for x in items if best in _features(x[0], x[1])]
    right = [x for x in items if best not in _features(x[0], x[1])]
    return [g for g in (left, right) if g] or [items]


# ══════════════════════════════════════════════════════════════════════
# §  APPLYING IT
#
# This file was written, tested, and imported by nothing but its own test
# for three releases. A tree whose shape can never change is a tree with
# opinions about growth and no growth, and `plan()` returning intentions
# nobody reads is the most expensive kind of dead code: it looks finished.
#
# So it runs now, from the idle memory loop, once per limb. What it does
# with what it finds is deliberately two settings, not one:
#
#   REPORT (always)   every intention is written to the event log and to
#                     data/logs/memory.log, and surfaces in /api/state.
#                     This is free, reversible, and it is EVIDENCE.
#
#   RESHAPE (off)     merges are actually applied. Off by default because
#                     these thresholds - TAU 0.5, MIN_TO_CONSIDER 7,
#                     MERGE_MARGIN 1.02 - have never been run against a
#                     real tree, and this project has a rule about that:
#
#                       "When you train 10,000 times you know. When you
#                        saw 10 - 5 times, you don't know."
#
#                     Turn it on in config once the log shows it is
#                     proposing sensible things. The switch is
#                     memory.reshape.
#
# Only MERGE is applied. A merge relabels leaves that were already
# together in one limb, and the leaves themselves are untouched. A
# promotion has to invent names for the parts it splits into, and a wrong
# name is invisible forever - nobody looks in the crown for a detail about
# a graphics card.
# ══════════════════════════════════════════════════════════════════════


def apply_merges(limb, intentions: list) -> list:
    """
    Carry out the merges in `intentions`. Returns what was actually done.

    Nothing is deleted: every leaf moves, keeping its id, content, weight,
    stability, provenance and history. The branch it came from closes only
    because it is empty afterwards, which is what branches do.
    """
    done = []
    for step in intentions or []:
        if step.get("do") != "merge":
            continue
        a, b = step.get("branch"), step.get("with")
        src = limb.branches.get(b)
        dst = limb.branches.get(a)
        if src is None or dst is None or src is dst:
            continue
        if is_permanent(b) or getattr(src, "permanent", False):
            continue
        moved = 0
        with getattr(limb, "_lock", _NOLOCK):
            for leaf in list(src.leaves):
                leaf.branch = dst.name
                dst.add(leaf)
                moved += 1
            src.leaves = []
            limb.branches.pop(b, None)
        if moved:
            events.write("branch.merge", limb=limb.name, into=a, was=b,
                         leaves=moved, why=step.get("why", ""))
            done.append({"into": a, "was": b, "leaves": moved,
                         "why": step.get("why", "")})
    return done


class _NoLock:
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


_NOLOCK = _NoLock()


def tend(limbs: dict, reshape: bool = False) -> dict:
    """
    Look at every limb's shape, write down what should change, and - only
    when asked - change it.

    Called from the memory loop, in an idle gap, under the same lock as
    the rest of consolidation.
    """
    proposed, applied = [], []
    for name, limb in (limbs or {}).items():
        try:
            steps = plan(limb)
        except Exception as e:
            core.log_line("memory", f"growth could not read {name}: {e}")
            continue
        for s in steps:
            s = dict(s, limb=name)
            proposed.append(s)
            core.log_line("memory",
                          f"growth would {s['do']} {name}/{s.get('branch')}"
                          + (f" with {s['with']}" if s.get("with") else "")
                          + (f" into {s['into']}" if s.get("into") else "")
                          + f" - {s.get('why', '')}")
        if reshape:
            for d in apply_merges(limb, steps):
                applied.append(dict(d, limb=name))
    if proposed:
        events.write("growth.plan", proposed=len(proposed),
                     applied=len(applied), reshape=bool(reshape))
    return {"proposed": proposed, "applied": applied,
            "reshape": bool(reshape)}
