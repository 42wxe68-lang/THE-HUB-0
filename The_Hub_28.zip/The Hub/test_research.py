"""
test_research.py - the preflight against a corpus, not against intuition.

The number that matters is FALSE POSITIVES: a preflight that fires on "what
did I tell you about my daughter" sends a private sentence to a search
engine, which is a worse failure than missing a search. So the pass bar is
zero false positives, and false negatives are counted and reported rather
than tolerated silently.

    python test_research.py
"""
from __future__ import annotations

import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import research

CFG = {"hub": {"preflight": True}}
CORPUS = pathlib.Path(__file__).resolve().parent / "tests" / "research.jsonl"


def main() -> int:
    if not CORPUS.exists():
        print(f"ERROR: corpus missing at {CORPUS}")
        return 2

    fp = fn = total = 0
    for line in CORPUS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        case = json.loads(line)
        total += 1
        v = research.preflight(case["text"], CFG)
        want = bool(case["required"])
        if v.required and not want:
            fp += 1
            print(f"  FALSE POSITIVE  score={v.score:.1f} [{v.reason}]\n"
                  f"                  {case['text']!r}\n"
                  f"                  would have searched: {v.query!r}")
        elif want and not v.required:
            fn += 1
            print(f"  false negative  score={v.score:.1f} [{v.reason}]\n"
                  f"                  {case['text']!r}  ({case['why']})")

    print(f"\n  {total} cases   false positives: {fp}   false negatives: {fn}")
    if fp:
        print("  FAIL - a false positive sends a private sentence to a "
              "search engine.")
    elif fn:
        print("  PASS with misses - no privacy failure, but "
              f"{fn} question(s) will be answered from stale knowledge.")
    else:
        print("  PASS - clean.")
    return 1 if fp else 0


if __name__ == "__main__":
    raise SystemExit(main())
