"""
vault.py - a place to put things. Files, pictures, video, models, notes.

WHAT IT IS
----------
A folder, `vault/`, sitting beside the application. Drop anything in it -
through the interface or through Explorer, both work, because it is just a
folder - and it becomes something Nova can find and something the interface
can show.

    vault/
      wiring-diagram.png
      the-spec.pdf
      walkthrough.mp4
      bracket.stl
      notes.md

WHAT IT IS NOT
--------------
It is not memory, and nothing here is ever fed to the model wholesale.
Nova gets the CATALOGUE - names, kinds, sizes, dates, and for text files a
short readable head - and can search it through the same engine that
searches everything else. If she needs the contents of one, she asks for
that one.

The distinction matters. Twelve PDFs in a context window is not knowledge,
it is a denial of service against your own model.

WHY IT IS OUTSIDE data/
-----------------------
`data/` is derived and repairable: delete it and the event log rebuilds it.
The vault is the opposite - it is yours, it is the only copy, and nothing in
this application will ever delete or rewrite it. It is read-only to The
The Hub except through explicit user action.

DISPLAY
-------
Images, video and 3D models are served to the browser by path so the
interface can show them inline. Nothing is uploaded anywhere; the browser
fetches them from 127.0.0.1 like any other local file.
"""
from __future__ import annotations

import mimetypes
import glob
import re
from datetime import datetime, timezone
from pathlib import Path

import core

VAULT = core.ROOT / "vault"
AI_VAULT = VAULT / "AI"
CHAT_VAULT = VAULT / "Chat"
# WHERE GENERATED WORK GOES WHEN THE USER SAYS KEEP IT.
#
# The Playground is scratch. Everything Nova generates lands there, nothing
# ever left, and after a few sessions of image and mesh generation it was
# gigabytes of files nobody had chosen - which is a memory problem before it
# is a tidiness one.
#
# A file only reaches this folder because the user was asked and said yes. It
# is theirs from that moment: to use, to move, to delete. Nothing in the
# application ever removes anything from here.
MADE_VAULT = VAULT / "Made"

IMAGE = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".svg", ".avif"}
VIDEO = {".mp4", ".webm", ".mov", ".mkv", ".m4v"}
AUDIO = {".mp3", ".wav", ".ogg", ".flac", ".m4a"}
MODEL3D = {".stl", ".obj", ".glb", ".gltf", ".3mf", ".ply", ".step", ".stp"}
TEXT = {".txt", ".md", ".csv", ".json", ".log", ".py", ".js", ".html", ".css",
        ".yaml", ".yml", ".ini", ".cfg", ".sql", ".sh", ".bat", ".rs", ".go",
        ".c", ".h", ".cpp", ".java", ".ts", ".tsx", ".jsx", ".xml", ".toml"}
DOC = {".pdf", ".docx", ".xlsx", ".pptx", ".odt", ".epub", ".rtf"}

HEAD_CHARS = 1200          # how much of a text file is read for the catalogue
MAX_LIST = 500


def ensure() -> None:
    VAULT.mkdir(parents=True, exist_ok=True)
    AI_VAULT.mkdir(parents=True, exist_ok=True)
    CHAT_VAULT.mkdir(parents=True, exist_ok=True)
    MADE_VAULT.mkdir(parents=True, exist_ok=True)
    made_readme = MADE_VAULT / "READ ME.txt"
    if not made_readme.exists():
        try:
            made_readme.write_text(
                "Things Nova made, that you said to keep.\r\n\r\n"
                "Generated pictures, videos and 3D models start out in the\r\n"
                "Playground, which is working space - it gets cleared. When\r\n"
                "Nova asks whether to keep something and you say yes, the\r\n"
                "file is MOVED here, out of the Playground.\r\n\r\n"
                "It is yours now. Use it, move it, rename it, delete it. The\r\n"
                "application never removes anything from this folder.\r\n",
                encoding="utf-8")
        except Exception:
            pass
    readme = VAULT / "READ ME.txt"
    if not readme.exists():
        try:
            readme.write_text(
                "This folder is yours.\r\n\r\n"
                "Put anything here - pictures, PDFs, video, 3D models, notes,\r\n"
                "spreadsheets, code. The Hub will list it, search it, and\r\n"
                "show it in the interface, and Nova can refer to it.\r\n\r\n"
                "Nothing here is ever sent anywhere. Nothing here is ever\r\n"
                "deleted or rewritten by the application. Text files are read\r\n"
                "so they can be searched; everything else is catalogued by name\r\n"
                "and shown on request.\r\n\r\n"
                "You can drop files in through the interface or straight into\r\n"
                "this folder in Explorer. Both work.\r\n",
                encoding="utf-8")
        except Exception:
            pass


def media_kind(suffix: str) -> str:
    s = suffix.lower()
    if s in IMAGE:
        return "image"
    if s in VIDEO:
        return "video"
    if s in AUDIO:
        return "audio"
    if s in MODEL3D:
        return "model3d"
    if s in TEXT:
        return "text"
    if s in DOC:
        return "document"
    return "file"


def _rel(p: Path) -> str:
    return str(p.relative_to(VAULT)).replace("\\", "/")


def listing(refresh_text: bool = True) -> list:
    """
    The catalogue. Names, kinds, sizes, dates, and a readable head for text.

    Walks subfolders, because people organise things into subfolders and a
    catalogue that ignores them is a catalogue of the wrong folder.
    """
    ensure()
    out = []
    try:
        for p in sorted(VAULT.rglob("*")):
            if not p.is_file() or p.name.startswith("."):
                continue
            if len(out) >= MAX_LIST:
                break
            st = p.stat()
            kind = media_kind(p.suffix)
            head = ""
            if refresh_text and kind == "text" and st.st_size < 2_000_000:
                try:
                    head = p.read_text(encoding="utf-8", errors="replace")[:HEAD_CHARS]
                except Exception:
                    head = ""
            rel = _rel(p)
            rp = Path(p).resolve()
            if rp.is_relative_to(AI_VAULT.resolve()):
                owner = "ai"
            elif rp.is_relative_to(MADE_VAULT.resolve()):
                owner = "made"
            else:
                owner = "user"
            out.append({
                "name": rel,
                "media": kind,
                "owner": owner,
                "size_mb": round(st.st_size / 1048576.0, 3),
                "added": datetime.fromtimestamp(st.st_mtime, timezone.utc)
                          .isoformat(timespec="seconds"),
                "head": head,
                # What the search engine indexes: the filename split into
                # words, plus the head of a text file. A file called
                # "hailo-10h-driver-notes.md" should be findable by "driver".
                "searchtext": (re.sub(r"[_\-/\.]", " ", _rel(p)) + " "
                               + head)[:2000],
            })
    except Exception as e:
        core.log_line("vault", f"listing failed: {e}")
    return out


def catalogue_block(max_items: int = 24) -> str:
    """
    What Nova is told the vault contains. Names and kinds, never contents.

    Deliberately terse: this sits in every prompt, so it has to be worth its
    tokens. If she needs a file she asks for it by name.
    """
    items = listing(refresh_text=False)
    if not items:
        return ""
    by_kind = {}
    for i in items:
        by_kind.setdefault(i["media"], []).append(i["name"])
    ai_count = sum(1 for i in items if i.get("owner") == "ai")
    lines = [f"Vault inventory ({len(items)} files). User originals are protected; "
             f"AI workspace saves live under vault/AI ({ai_count} files). "
             "Chat attachments live under vault/Chat and are user-owned."]
    for kind in ("text", "document", "image", "video", "audio", "model3d", "file"):
        names = by_kind.get(kind) or []
        if not names:
            continue
        shown = ", ".join(names[:max_items // 2])
        more = f" (+{len(names) - max_items // 2} more)" if len(names) > max_items // 2 else ""
        lines.append(f"  {kind}: {shown}{more}")
    return "\n".join(lines)


def resolve(name: str) -> Path | None:
    """
    A vault-relative name to a real path, or None.

    Rejects traversal the same way core.under does, one segment at a time,
    because the vault is the one place the model is invited to name files and
    that makes it the one place a crafted name is worth trying.
    """
    ensure()
    name = (name or "").strip().replace("\\", "/")
    if not name or name.startswith("/") or ".." in name.split("/"):
        return None
    p = VAULT
    for part in name.split("/"):
        if not part or part in (".", "..") or any(c in part for c in ':*?"<>|'):
            return None
        p = p / part
    try:
        p = p.resolve()
        if not p.is_relative_to(VAULT.resolve()) or not p.is_file():
            return None
    except Exception:
        return None
    return p


def read_text(name: str, limit: int = 6000) -> str:
    """The contents of one text file, on request. Never automatic."""
    p = resolve(name)
    if p is None:
        return f"No file called {name!r} in the vault."
    kind = media_kind(p.suffix)
    if kind not in ("text",):
        return (f"{name} is a {kind} file ({round(p.stat().st_size/1048576,2)} MB). "
                f"It can be shown in the interface but not read as text here.")
    try:
        txt = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"Could not read {name}: {e}"
    if len(txt) > limit:
        return (txt[:limit] + f"\n\n[{name}: showing the first {limit} of "
                f"{len(txt)} characters]")
    return txt


def _same_bytes(path: Path, data: bytes) -> bool:
    """Is this exact content already at this path? Size first, then hash."""
    try:
        if path.stat().st_size != len(data):
            return False
        import hashlib
        return (hashlib.sha256(path.read_bytes()).digest()
                == hashlib.sha256(data).digest())
    except OSError:
        return False


def find_duplicate(data: bytes, stem: str = "", suffix: str = ""):
    """
    An existing vault file with exactly these bytes, or None.

    Checks same-stem candidates first - script.py, script (2).py and so on -
    because that is where a re-upload of the same file lands, and it means
    the common case does not read the whole vault.
    """
    ensure()
    import hashlib
    want = hashlib.sha256(data).digest()
    size = len(data)

    def _match(q: Path) -> bool:
        try:
            return (q.is_file() and q.stat().st_size == size
                    and hashlib.sha256(q.read_bytes()).digest() == want)
        except OSError:
            return False

    if stem:
        for q in sorted(VAULT.glob(f"{glob.escape(stem)}*{suffix}")):
            if _match(q):
                return q
    for q in sorted(VAULT.rglob("*")):
        if _match(q):
            return q
    return None


def save_upload(filename: str, data: bytes) -> dict:
    """
    Write a file the user dropped on the interface.

    THE SAME FILE, SEVEN TIMES.

    This never overwrote, which is right - dropping a second photo called
    image.png must not lose the first. But it also never checked whether the
    "second" file was the SAME file, so re-dropping something, or an
    interface that retried an upload, produced script.py, script (2).py,
    script (3).py ... up to script (6).py, all byte-identical. The user's
    vault listing was mostly copies of two files, and neither they nor Nova
    could tell which was which.

    Different name, same bytes: keep the one already there and say so. Same
    name, different bytes: suffix it, exactly as before. The distinction is
    the content, which is the only thing that can actually answer the
    question.
    """
    ensure()
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", (filename or "file").strip())[:120]
    if not safe or safe in (".", ".."):
        safe = "file"

    twin = find_duplicate(data, Path(safe).stem, Path(safe).suffix)
    if twin is not None:
        return {"ok": True, "name": _rel(twin),
                "media": media_kind(twin.suffix),
                "size_mb": round(len(data) / 1048576.0, 3),
                "duplicate": True,
                "note": f"identical to {_rel(twin)}, which is already in the "
                        f"vault - nothing was added"}

    dest = VAULT / safe
    if dest.exists():
        stem, suf = dest.stem, dest.suffix
        n = 2
        while (VAULT / f"{stem} ({n}){suf}").exists():
            n += 1
        dest = VAULT / f"{stem} ({n}){suf}"
    dest.write_bytes(data)
    return {"ok": True, "name": _rel(dest), "media": media_kind(dest.suffix),
            "size_mb": round(len(data) / 1048576.0, 3), "duplicate": False}


def mime(name: str) -> str:
    p = resolve(name)
    if p is None:
        return "application/octet-stream"
    guess, _ = mimetypes.guess_type(p.name)
    if guess:
        return guess
    return {"model3d": "model/stl", "text": "text/plain; charset=utf-8"}.get(
        media_kind(p.suffix), "application/octet-stream")



def ai_path(name: str, must_exist: bool = False) -> Path | None:
    """Resolve a model-owned Vault path strictly inside vault/AI."""
    ensure()
    name = (name or "").strip().replace("\\", "/")
    if not name or name.startswith("/") or ".." in name.split("/"):
        return None
    parts = [p for p in name.split("/") if p]
    if any(p in (".", "..") or any(c in p for c in ':*?"<>|') for p in parts):
        return None
    p = (AI_VAULT.joinpath(*parts)).resolve()
    try:
        if not p.is_relative_to(AI_VAULT.resolve()):
            return None
        if must_exist and not p.is_file():
            return None
    except Exception:
        return None
    return p


def ai_save(source: Path, name: str = "") -> dict:
    """Save a Playground result into the model-owned Vault area."""
    ensure()
    source = Path(source).resolve()
    if not source.is_file():
        raise FileNotFoundError(source)
    raw = (name or source.name).strip().replace("\\", "/")
    if raw.startswith("/") or ".." in raw.split("/"):
        raise ValueError("invalid AI Vault name")
    rel = Path(raw)
    if len(rel.parts) > 4 or any(part in (".", "..") for part in rel.parts):
        raise ValueError("invalid AI Vault path")
    dest = (AI_VAULT / rel).resolve()
    if not dest.is_relative_to(AI_VAULT.resolve()):
        raise ValueError("destination escapes AI Vault")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        stem, suf = dest.stem, dest.suffix
        i = 2
        while True:
            candidate = dest.with_name(f"{stem} ({i}){suf}")
            if not candidate.exists():
                dest = candidate
                break
            i += 1
    dest.write_bytes(source.read_bytes())
    return {"ok": True, "name": _rel(dest), "owner": "ai"}


def ai_delete(name: str) -> dict:
    """Delete only model-owned files under vault/AI."""
    p = ai_path(name, must_exist=True)
    if p is None:
        raise FileNotFoundError(name)
    p.unlink()
    return {"ok": True, "deleted": _rel(p), "owner": "ai"}


def save_chat_upload(filename: str, data: bytes, session: str) -> dict:
    """User-owned attachment stored under Vault/Chat/<session>."""
    ensure()
    safe_session = re.sub(r"[^A-Za-z0-9_-]", "_", session or "session")[:80] or "session"
    folder = CHAT_VAULT / safe_session
    folder.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", (filename or "file").strip())[:160] or "file"
    dest = folder / safe
    if dest.exists():
        stem, suf = dest.stem, dest.suffix
        n = 2
        while (folder / f"{stem} ({n}){suf}").exists():
            n += 1
        dest = folder / f"{stem} ({n}){suf}"
    dest.write_bytes(data)
    return {"ok": True, "name": _rel(dest), "media": media_kind(dest.suffix),
            "size_mb": round(len(data)/1048576.0, 3), "owner": "user",
            "chat_session": safe_session}


def stats() -> dict:
    items = listing(refresh_text=False)
    return {"count": len(items),
            "mb": round(sum(i["size_mb"] for i in items), 2),
            "kinds": {k: sum(1 for i in items if i["media"] == k)
                      for k in {i["media"] for i in items}}}
