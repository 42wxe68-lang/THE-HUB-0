"""
test_growth.py - the tree's shape is tended, and nothing is lost tending it.

growth.py was written, tested and imported by nothing but its own test for
three releases. `plan()` returned intentions and no code anywhere read
them, so the tree's shape could never change, in any version. That is the
most expensive kind of dead code: it looks finished.

These tests are about the two halves of connecting it.

  IT RUNS.        memory's idle loop calls it, every pass, and writes down
                  what it would do whether or not it is allowed to do it.
                  A recommendation nobody records is a recommendation
                  nobody can check.

  NOTHING IS LOST. A merge relabels leaves that were already together in
                  one limb. Every leaf keeps its id, its content, its
                  weight, its stability and its provenance, and the count
                  before equals the count after. Restructuring memory is
                  the one operation where "roughly right" is indistinguish-
                  able from data loss.

And it is OFF by default, because these thresholds have never been run
against a real tree and this project has a rule about that.
"""
from __future__ import annotations

import pathlib

import core
import events
import growth
import intake
import memory


def _redirect(tmp_path):
    old = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
           core.SESSIONS, core.LOGS, core.WRITABLE, memory.YESOD_DIR,
           memory.ACTIVE_DIR, intake.CANDIDATES, events.LOG)
    core.DATA = tmp_path / "data"
    core.TREE = core.DATA / "tree"
    core.KNOWLEDGE = core.DATA / "knowledge"
    core.ASH = core.DATA / "ash"
    core.EVENTS = core.DATA / "events"
    core.SESSIONS = core.DATA / "sessions"
    core.LOGS = core.DATA / "logs"
    core.WRITABLE = (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH,
                     core.EVENTS, core.SESSIONS, core.LOGS)
    memory.YESOD_DIR = core.TREE / "yesod"
    memory.ACTIVE_DIR = core.DATA / "active"
    intake.CANDIDATES = core.TREE / "candidates.jsonl"
    events.LOG = core.EVENTS / "events.jsonl"
    core.ensure_dirs()
    memory._limbs.clear()
    memory._loaded = False
    return old


def _restore(old):
    (core.DATA, core.TREE, core.KNOWLEDGE, core.ASH, core.EVENTS,
     core.SESSIONS, core.LOGS, core.WRITABLE, memory.YESOD_DIR,
     memory.ACTIVE_DIR, intake.CANDIDATES, events.LOG) = old
    memory._limbs.clear()
    memory._loaded = False


def _two_branches(limb, a="kiln", b="firing", n=6):
    for i in range(n):
        limb.plant(f"the {a} reaches cone {i} in about nine hours",
                   branch=a, tags=[a, "firing"])
        limb.plant(f"the {b} takes nine hours to reach cone {i}",
                   branch=b, tags=[a, "firing"])


# --------------------------------------------------------------- it runs

def test_the_memory_loop_actually_calls_it():
    """
    The whole point. `plan()` returning intentions nobody reads is a tree
    with opinions about growth and no growth.
    """
    src = pathlib.Path("memory.py").read_text(encoding="utf-8")
    loop = src[src.index("def loop(stop_evt"):src.index("# What the last growth pass")]
    assert "growth.tend(" in loop, \
        "the memory loop no longer tends the tree - growth.py is dead again"
    assert "import growth" in loop
    assert "reshape" in loop, "the loop must pass the switch, not assume it"


def test_it_reports_even_when_it_may_not_reshape(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        _two_branches(limb)
        before = {b: len(limb.branches[b].leaves) for b in limb.branches}
        got = growth.tend({"hod": limb}, reshape=False)
        assert got["reshape"] is False
        assert got["applied"] == []
        after = {b: len(limb.branches[b].leaves) for b in limb.branches}
        assert before == after, "reporting changed the tree"
    finally:
        _restore(old)


def test_what_it_would_do_reaches_the_log_and_the_state(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        _two_branches(limb)
        plan = [{"do": "merge", "branch": "kiln", "with": "firing",
                 "why": "a test said so"}]
        # tend() logs whatever plan() returns; drive it directly so the
        # test does not depend on a threshold it is not about.
        saved = growth.plan
        growth.plan = lambda lb: plan
        try:
            got = growth.tend({"hod": limb}, reshape=False)
        finally:
            growth.plan = saved
        assert len(got["proposed"]) == 1
        assert got["proposed"][0]["limb"] == "hod"
        log = (core.LOGS / "memory.log").read_text(encoding="utf-8")
        assert "growth would merge hod/kiln with firing" in log, log[-400:]
        memory._GROWTH.update({"at": "now", **got})
        state = memory.growth_state()
        assert state["proposed"] == 1 and state["applied"] == 0
        assert state["reshape"] is False
        assert state["next"] and state["next"][0]["do"] == "merge"
    finally:
        _restore(old)


def test_reshape_is_off_until_it_has_been_watched():
    cfg = core.load()
    assert cfg["memory"].get("reshape") is False, \
        "the tree must not restructure itself on thresholds nobody has measured"


# --------------------------------------------------------- nothing is lost

def test_a_merge_moves_every_leaf_and_loses_none(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        _two_branches(limb)
        before_ids = {l.leaf_id for b in limb.branches.values() for l in b.leaves}
        before_text = {l.content for b in limb.branches.values() for l in b.leaves}
        kiln = len(limb.branches["kiln"].leaves)
        firing = len(limb.branches["firing"].leaves)

        done = growth.apply_merges(limb, [{"do": "merge", "branch": "kiln",
                                           "with": "firing", "why": "test"}])
        assert done and done[0]["leaves"] == firing

        after_ids = {l.leaf_id for b in limb.branches.values() for l in b.leaves}
        after_text = {l.content for b in limb.branches.values() for l in b.leaves}
        assert after_ids == before_ids, "leaf ids changed or leaves vanished"
        assert after_text == before_text, "content changed"
        assert "firing" not in limb.branches, "the empty branch should close"
        assert len(limb.branches["kiln"].leaves) == kiln + firing
        assert all(l.branch == "kiln" for l in limb.branches["kiln"].leaves), \
            "a leaf still claims a branch that no longer exists"
    finally:
        _restore(old)


def test_a_merge_keeps_weight_stability_and_provenance(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        limb.plant("the kiln element was replaced in August", branch="kiln",
                   weight=0.83, stability=7.5, kind="stated")
        limb.plant("the firing schedule is on the wall", branch="firing",
                   weight=0.61, stability=3.25, kind="observed")
        growth.apply_merges(limb, [{"do": "merge", "branch": "kiln",
                                    "with": "firing", "why": "test"}])
        got = {l.content: l for l in limb.branches["kiln"].leaves}
        moved = got["the firing schedule is on the wall"]
        assert round(moved.weight, 2) == 0.61
        assert round(moved.stability, 2) == 3.25
        assert moved.kind == "observed"
    finally:
        _restore(old)


def test_a_permanent_branch_is_never_merged_away(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        limb.plant("Ada is learning piano", branch="people")
        limb.plant("the kiln is in the garage", branch="kiln")
        for step in ({"do": "merge", "branch": "kiln", "with": "people",
                      "why": "test"},
                     {"do": "merge", "branch": "people", "with": "kiln",
                      "why": "test"}):
            growth.apply_merges(limb, [step])
            assert "people" in limb.branches, \
                "a permanent branch was merged away: " + repr(step)
    finally:
        _restore(old)


def test_the_permanent_branches_exist_before_anything_is_learned(tmp_path):
    """
    growth.PERMANENT has named observations / people / environment /
    studies / doing as unmergeable since it was written, and nothing ever
    created them - so its one protection protected nothing, and there was
    nowhere for the first observation to go.
    """
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        for name in ("observations", "people", "environment", "studies"):
            assert name in limb.branches, \
                f"{name} has nowhere to go: {sorted(limb.branches)}"
            assert growth.is_permanent(name)
            assert limb.branches[name].permanent
    finally:
        _restore(old)


def test_a_promotion_is_never_applied(tmp_path):
    """
    Only merges are carried out. A promotion has to invent names for the
    parts it splits into, and a wrong name is invisible forever - nobody
    looks in the crown for a detail about a graphics card.
    """
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        _two_branches(limb)
        before = {b: len(limb.branches[b].leaves) for b in limb.branches}
        done = growth.apply_merges(limb, [{"do": "promote", "branch": "kiln",
                                           "into": 3, "why": "test"}])
        assert done == []
        assert {b: len(limb.branches[b].leaves) for b in limb.branches} == before
    finally:
        _restore(old)


def test_a_nonsense_intention_changes_nothing(tmp_path):
    old = _redirect(tmp_path)
    try:
        limb = memory.limbs()["hod"]
        _two_branches(limb)
        before = {b: len(limb.branches[b].leaves) for b in limb.branches}
        growth.apply_merges(limb, [
            {"do": "merge", "branch": "kiln", "with": "no_such_branch"},
            {"do": "merge", "branch": "no_such_branch", "with": "kiln"},
            {"do": "merge", "branch": "kiln", "with": "kiln"},
            {},
        ])
        assert {b: len(limb.branches[b].leaves) for b in limb.branches} == before
    finally:
        _restore(old)


def test_nothing_here_can_run_out_of_time():
    src = pathlib.Path("growth.py").read_text(encoding="utf-8")
    for banned in ("timeout", "deadline", "signal.alarm", "TimeoutError"):
        assert banned not in src, f"growth.py has a {banned}"


if __name__ == "__main__":
    import sys
    import testkit
    sys.exit(testkit.run(dict(globals()), "growth - the tree's shape, tended"))
