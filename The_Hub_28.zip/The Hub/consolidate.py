"""
consolidate.py - Nova organises her own memory, and cannot talk while she does.

THE CURATOR IS GONE
-------------------
Cairn ran a second model - a 350M on the CPU - to summarise conversations
and pull facts out of them. That solved a real problem badly:

  * it is a second process, a second model file, a second port, a second
    thing to install and go wrong
  * 350M parameters is not enough to read a conversation reliably, which is
    why it needed a rigid JSON schema, which is why it put everything in the
    first field, which is why placement had to be taken away from it
  * on a machine where the main model fills memory, the curator cannot spawn
    at all - measured: free RAM bottomed at 0.1 GB with the 20B loaded

The model already loaded is better at this than any small model, and it is
already there. So it does the job.

WHY GENERATION IS LOCKED
------------------------
One llama-server, one KV cache, one set of weights. Sending a consolidation
prompt while a reply is streaming would interleave two conversations in the
same context and corrupt both. So consolidation takes the model, and while
it holds it, the chat endpoint says so plainly:

    "Nova is organising her memory - about ten seconds."

That is not a limitation to apologise for. It is a machine with one mind
doing one thing at a time, and saying which.

WHEN IT RUNS
------------
Never mid-conversation. The scheduler waits for an idle gap - no request for
`IDLE_BEFORE` seconds - and takes only as long as `MAX_SECONDS`. If the user
starts typing, the current step finishes and the rest waits for the next gap.
Memory work must never be the reason a reply is slow.
"""
from __future__ import annotations

import json
import threading
import time

import core
import events
import runtime

# One lock for the model. Everything that generates takes it.
_MODEL = threading.RLock()
_state = {"busy": False, "what": "", "since": 0.0, "last": 0.0, "runs": 0}
_last_request = time.time()

IDLE_BEFORE = 25.0        # seconds of quiet before memory work may start
MAX_SECONDS = 90.0        # a single pass never runs longer than this


def touch() -> None:
    """Called on every user request. Consolidation waits for quiet."""
    global _last_request
    _last_request = time.time()


def idle_for() -> float:
    return time.time() - _last_request


def busy() -> bool:
    return bool(_state["busy"])


def state() -> dict:
    d = dict(_state)
    d["idle_for"] = round(idle_for(), 1)
    if d["busy"]:
        d["elapsed"] = round(time.time() - d["since"], 1)
    return d


class Session:
    """
    Hold the model for memory work.

    Used as a context manager. Acquiring it blocks chat; releasing it frees
    the model immediately. If the lock cannot be taken quickly, the pass is
    skipped rather than queued - there will be another gap.
    """

    def __init__(self, what: str = "organising memory", wait: float = 2.0):
        self.what = what
        self.wait = wait
        self.ok = False
        self.t0 = 0.0

    def __enter__(self):
        self.ok = _MODEL.acquire(timeout=self.wait)
        if self.ok:
            self.t0 = time.time()
            _state.update({"busy": True, "what": self.what, "since": self.t0})
            events.write("consolidate.start", what=self.what)
        return self

    def expired(self) -> bool:
        return (time.time() - self.t0) > MAX_SECONDS

    def interrupted(self) -> bool:
        """True once the user is active again. Stop at the next clean point."""
        return idle_for() < 1.5

    def ask(self, system: str, user: str, max_tokens: int = 320) -> str:
        """
        One question to the model that is already loaded.

        Low temperature and a hard token cap: this is extraction, not
        conversation, and a consolidation pass that writes an essay is a
        consolidation pass that costs the user their next reply.
        """
        if not self.ok:
            return ""
        try:
            r = runtime.post(runtime.MAIN, "/v1/chat/completions", {
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": user}],
                "max_tokens": max_tokens, "temperature": 0.2,
                "stream": False,
            }, timeout=180)
            d = json.loads(r.read().decode())
            return (d["choices"][0]["message"].get("content") or "").strip()
        except Exception as e:
            core.log_line("memory", f"consolidation ask failed: {e}")
            return ""

    def __exit__(self, *exc):
        if self.ok:
            _state.update({"busy": False, "what": "",
                           "last": time.time(),
                           "runs": _state["runs"] + 1})
            events.write("consolidate.end",
                         seconds=round(time.time() - self.t0, 1))
            _MODEL.release()
        return False


class Generating:
    """
    Taken by the chat path for the duration of a reply.

    Same lock, other direction: while the user is being answered, memory work
    cannot start. Non-blocking by design - if consolidation holds the model,
    the caller is told to wait rather than being queued behind it.
    """

    def __init__(self):
        self.ok = False

    def __enter__(self):
        touch()
        self.ok = _MODEL.acquire(blocking=False)
        return self

    def __exit__(self, *exc):
        if self.ok:
            _MODEL.release()
        return False


def why_busy() -> str:
    s = state()
    return (f"Nova is {s['what']} - about "
            f"{max(1, int(MAX_SECONDS - s.get('elapsed', 0)))}s left. "
            f"She will be back in a moment.")
