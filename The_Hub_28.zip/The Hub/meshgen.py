"""
meshgen.py - real geometry from a description or an image. No model, no download.

WHY THIS EXISTS ALONGSIDE THE NEURAL PATH

trellis.cpp turns a picture into a textured mesh and is the better answer when
it runs. It is a 4B model. On the 4 GB card this application targets it may not
run at all, and "3D generation is unavailable" is not an acceptable answer for
a headline capability.

So this is the floor: pure Python, no binary, no weights, no third-party
package, and it cannot fail for want of VRAM. What it produces is not
imagined - it is constructed - which for a large share of what people actually
want a 3D file FOR (a bracket, a spacer, a plate with holes, a stand, a relief
of a picture) is the better answer anyway, because the result is exact,
watertight and dimensioned rather than approximately shaped.

TWO WAYS IN

  build(spec)          a shape description -> exact solid geometry
  relief(image, ...)   an image -> a displaced surface, printable

Nova reaches the first by writing a small JSON spec. That is deliberate: a
language model is good at turning "a 60mm L-bracket, 4mm thick, two 5mm holes
in each leg" into numbers, and bad at emitting a valid mesh triangle by
triangle. The numbers are then built by code that cannot produce a broken
solid.

EVERYTHING IS TRIANGLES

Output is the same (v0,v1,v2) triangle list model3d.py already reads, renders
and writes, so a generated mesh is inspected, converted and saved by exactly
the same code as a mesh the user supplied.
"""
from __future__ import annotations

import json
import math
import os
import re
import sys
from pathlib import Path

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import model3d

Tri = tuple


# ═══════════════════════════════════════════════════════════════════════════
# §1  A POLYGON WITH HOLES, EXTRUDED
#
# The workhorse. A plate with bolt holes, an L-bracket, a washer, a spacer,
# a face plate - all of them are a 2D outline, some round or rectangular
# holes in it, and a thickness. Done exactly, this covers most of what a
# person actually wants to print.
# ═══════════════════════════════════════════════════════════════════════════

def _area(poly) -> float:
    a = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        a += x1 * y2 - x2 * y1
    return a / 2.0


def _ccw(poly):
    return list(poly) if _area(poly) > 0 else list(reversed(poly))


def _cw(poly):
    return list(poly) if _area(poly) < 0 else list(reversed(poly))


_EPS = 1e-9


def _same(p, q) -> bool:
    return abs(p[0] - q[0]) <= 1e-7 and abs(p[1] - q[1]) <= 1e-7


def _point_in_tri(p, a, b, c) -> bool:
    """
    Strictly inside. Not on an edge, not on a corner.

    The tolerant version of this test - the one that counts a point lying ON
    an edge as inside - cannot be used here, because bridging a hole into the
    outer contour deliberately creates COINCIDENT vertices: the bridge is a
    zero-width channel, so the same point appears twice in the polygon. With
    an inclusive test every candidate ear touching a bridge contains "another"
    vertex (its own duplicate), no ear is ever accepted, and the clipper
    stops after a handful of triangles. That is why a plate with two bolt
    holes came out as 136 triangles with 136 open edges - a cap with a bite
    missing, and walls with nothing to close against.
    """
    if _same(p, a) or _same(p, b) or _same(p, c):
        return False

    def sign(p1, p2, p3):
        return ((p1[0] - p3[0]) * (p2[1] - p3[1])
                - (p2[0] - p3[0]) * (p1[1] - p3[1]))

    d1, d2, d3 = sign(p, a, b), sign(p, b, c), sign(p, c, a)
    neg = (d1 < -_EPS) or (d2 < -_EPS) or (d3 < -_EPS)
    pos = (d1 > _EPS) or (d2 > _EPS) or (d3 > _EPS)
    return not (neg and pos)


def _seg_cross(p1, p2, p3, p4) -> bool:
    """Do segments p1p2 and p3p4 properly cross? Shared endpoints do not count."""
    def o(a, b, c):
        v = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        return 0 if abs(v) <= 1e-9 else (1 if v > 0 else -1)
    if _same(p1, p3) or _same(p1, p4) or _same(p2, p3) or _same(p2, p4):
        return False
    d1, d2, d3, d4 = o(p3, p4, p1), o(p3, p4, p2), o(p1, p2, p3), o(p1, p2, p4)
    return d1 != d2 and d3 != d4 and 0 not in (d1, d2, d3, d4)


def _overlaps(p1, p2, p3, p4) -> bool:
    """
    Are the two segments collinear and overlapping in more than a point?

    _seg_cross deliberately ignores shared endpoints and touching, which is
    right for a proper crossing and blind to the case that actually breaks a
    merged contour: a new bridge running ALONG an existing zero-width channel.
    Nothing crosses, and the polygon still stops being simple.
    """
    def cr(a, b, c):
        return ((b[0] - a[0]) * (c[1] - a[1])
                - (b[1] - a[1]) * (c[0] - a[0]))
    if abs(cr(p1, p2, p3)) > 1e-7 or abs(cr(p1, p2, p4)) > 1e-7:
        return False                      # not collinear
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = dx * dx + dy * dy
    if L <= 1e-18:
        return False

    def t_of(q):
        return ((q[0] - p1[0]) * dx + (q[1] - p1[1]) * dy) / L

    t3, t4 = sorted((t_of(p3), t_of(p4)))
    lo, hi = max(0.0, t3), min(1.0, t4)
    return (hi - lo) > 1e-6


def _is_simple(poly) -> bool:
    """No two non-adjacent edges cross. The property ear clipping needs."""
    n = len(poly)
    if n > 900:                      # O(n^2); above this trust the construction
        return True
    for i in range(n):
        a1, a2 = poly[i], poly[(i + 1) % n]
        for j in range(i + 1, n):
            if j == i or (j + 1) % n == i or (i + 1) % n == j:
                continue
            if _seg_cross(a1, a2, poly[j], poly[(j + 1) % n]):
                return False
    return True


def _bridge_holes(outer, holes):
    """
    Fold every hole into the outer contour, without any bridge crossing
    anything.

    TWO EARLIER VERSIONS, TWO DIFFERENT FAILURES.

    The first bridged each hole to the nearest outer vertex on its right and
    checked nothing. Bridges crossed each other, the polygon stopped being
    simple, ear clipping stalled with sixty vertices left, and a rounded
    plate with four bolt holes came out with eighty open edges - right area,
    unprintable file.

    The second added proper crossing rejection but only ever targeted the
    ORIGINAL outer ring, one distinct vertex per hole. That is correct and
    too strict: in a grid of sixteen holes, an inner hole has no line to the
    outside that does not cross a hole in front of it, so it simply failed.

    This one merges incrementally and lets a hole bridge to whatever is
    nearest in the contour built so far - including a previously merged
    hole's ring, which is exactly how an inner hole in a grid reaches the
    outside: through its neighbour. Every candidate bridge is tested against
    the current contour and against the holes not yet merged, and the first
    that crosses nothing wins. Nearest-first ordering means that is normally
    the first or second candidate tried.
    """
    contour = _ccw(list(outer))
    holes = [_cw(list(h)) for h in holes if len(h) >= 3]
    if not holes:
        return contour
    # Rightmost first. Each hole then reaches out through open space or
    # through a neighbour that has already been merged.
    holes.sort(key=lambda h: -max(pt[0] for pt in h))

    for hidx, hole in enumerate(holes):
        hi = max(range(len(hole)), key=lambda i: hole[i][0])
        M = hole[hi]
        m = len(contour)
        contour_edges = [(contour[i], contour[(i + 1) % m]) for i in range(m)]
        hole_edges = [(hole[i], hole[(i + 1) % len(hole)])
                      for i in range(len(hole))]
        pending = []
        for other in holes[hidx + 1:]:
            k = len(other)
            pending.extend((other[i], other[(i + 1) % k]) for i in range(k))

        order = sorted(range(m), key=lambda i: (
            (contour[i][0] - M[0]) ** 2 + (contour[i][1] - M[1]) ** 2))

        chosen = None
        for i in order:
            P = contour[i]
            if _same(P, M):
                continue
            if any(_seg_cross(M, P, a, b) for a, b in contour_edges):
                continue
            if any(_seg_cross(M, P, a, b) for a, b in hole_edges):
                continue
            if any(_seg_cross(M, P, a, b) for a, b in pending):
                continue
            if any(_overlaps(M, P, a, b) for a, b in contour_edges):
                continue
            # The bridge must run through material, not across the void
            # outside the part or across the inside of a hole. Its midpoint
            # decides.
            mid = ((M[0] + P[0]) / 2.0, (M[1] + P[1]) / 2.0)
            if not _inside(mid, contour):
                continue
            if _inside(mid, hole):
                continue
            chosen = i
            break

        if chosen is None:
            raise ValueError(
                "could not cut one of these holes without the bridge "
                "crossing another edge - move it away from the outline or "
                "from its neighbours")

        rotated = hole[hi:] + hole[:hi]
        contour = (contour[:chosen + 1] + rotated + [rotated[0]]
                   + contour[chosen:])

    # A last check rather than a hope. Ear clipping needs a simple polygon,
    # and when it does not get one it does not crash - it stalls and returns
    # a cap with gaps, which reaches the user as an STL a slicer rejects.
    # Better to say so here, where the reason is still known.
    if not _is_simple(contour):
        raise ValueError(
            "the holes could not be cut cleanly into this outline - the "
            "bridges between them overlap. Try fewer holes, or move them "
            "apart, or cut them as separate parts.")
    return contour


def _inside(pt, ring) -> bool:
    """Even-odd crossing test. Used to keep a bridge inside the material."""
    x, y = pt[0], pt[1]
    inside = False
    n = len(ring)
    for i in range(n):
        x1, y1 = ring[i]
        x2, y2 = ring[(i + 1) % n]
        if (y1 > y) != (y2 > y):
            t = (y - y1) / (y2 - y1)
            if x < x1 + t * (x2 - x1):
                inside = not inside
    return inside


def _point_in_tri_incl(p, a, b, c) -> bool:
    """Inside or on the boundary. Used only for the visibility test above,
    where a blocker sitting exactly on an edge still blocks."""
    def sign(p1, p2, p3):
        return ((p1[0] - p3[0]) * (p2[1] - p3[1])
                - (p2[0] - p3[0]) * (p1[1] - p3[1]))
    d1, d2, d3 = sign(p, a, b), sign(p, b, c), sign(p, c, a)
    neg = (d1 < -_EPS) or (d2 < -_EPS) or (d3 < -_EPS)
    pos = (d1 > _EPS) or (d2 > _EPS) or (d3 > _EPS)
    return not (neg and pos)


def _dedup(poly):
    """Drop consecutive coincident points. They make zero-area ears that the
    clipper can neither accept nor get past, which is how it deadlocks."""
    out = []
    for pt in poly:
        if not out or not _same(pt, out[-1]):
            out.append(pt)
    while len(out) > 1 and _same(out[0], out[-1]):
        out.pop()
    return out


def triangulate(outer, holes=()) -> list:
    """
    Ear clipping, in two passes.

    The single-pass version deadlocked. A bridged polygon is not a friendly
    input: it has coincident vertices by construction, near-collinear runs
    from rounded corners, and a channel per hole. Whenever no ear passed the
    strict test the clipper stopped, the cap came back partial, and the part
    had open edges - 40 of them on a rounded plate with four bolt holes, 104
    on a C-channel with six.

    So: sweep looking for a strictly valid ear. If a whole sweep finds none,
    do one relaxed sweep that takes any convex corner, which always exists in
    a polygon with more than three vertices and always makes progress. The
    relaxed triangle can overlap the channel of a bridge; it cannot leave a
    gap, and closing the solid matters more here than an ideal triangulation.

    Progress is guaranteed, so the whole polygon is always consumed and the
    cap boundary always matches the walls.
    """
    # NOT deduplicated when there are holes. A bridge is a zero-width
    # channel, so its endpoints appear twice on purpose; collapsing them
    # removes the channel and reopens the hole into the cap.
    poly = (_bridge_holes(outer, holes) if holes else _dedup(_ccw(list(outer))))
    n = len(poly)
    if n < 3:
        return []
    idx = list(range(n))
    out = []

    def corner(k):
        i0, i1, i2 = idx[(k - 1) % len(idx)], idx[k], idx[(k + 1) % len(idx)]
        a, b, c = poly[i0], poly[i1], poly[i2]
        cross = ((b[0] - a[0]) * (c[1] - a[1])
                 - (b[1] - a[1]) * (c[0] - a[0]))
        return i0, i1, i2, a, b, c, cross

    guard = 0
    while len(idx) > 3 and guard < 200000:
        guard += 1
        found = -1
        for k in range(len(idx)):
            i0, i1, i2, a, b, c, cross = corner(k)
            if cross <= _EPS:
                continue
            if any(_point_in_tri(poly[j], a, b, c)
                   for j in idx if j not in (i0, i1, i2)):
                continue
            found = k
            break
        if found < 0:
            # Relaxed sweep: the best convex corner available, ignoring
            # containment. Always exists, always shrinks the ring.
            best, best_cross = -1, 0.0
            for k in range(len(idx)):
                _, _, _, _, _, _, cross = corner(k)
                if cross > best_cross:
                    best, best_cross = k, cross
            if best < 0:
                break                       # degenerate ring, nothing to add
            found = best
        _, _, _, a, b, c, cross = corner(found)
        if cross > _EPS:
            out.append((a, b, c))
        idx.pop(found)

    if len(idx) == 3:
        a, b, c = poly[idx[0]], poly[idx[1]], poly[idx[2]]
        cross = ((b[0] - a[0]) * (c[1] - a[1])
                 - (b[1] - a[1]) * (c[0] - a[0]))
        if abs(cross) > _EPS:
            out.append((a, b, c) if cross > 0 else (a, c, b))
    return out


def is_closed(tris) -> int:
    """
    How many edges are NOT shared by exactly two triangles.

    Zero means the solid is watertight, which is the only thing a slicer
    cares about. Cheap enough to run on every part, which is the point: this
    is the check, not a hope.
    """
    from collections import Counter
    seen = Counter()
    for t in tris:
        for i in range(3):
            a = tuple(round(v, 4) for v in t[i])
            b = tuple(round(v, 4) for v in t[(i + 1) % 3])
            seen[tuple(sorted((a, b)))] += 1
    return sum(1 for c in seen.values() if c != 2)


def _extrude_once(outer, holes, thickness, z0) -> list:
    tris = []
    z1 = z0 + float(thickness)
    for a, b, c in triangulate(outer, holes):
        tris.append(((a[0], a[1], z0), (c[0], c[1], z0), (b[0], b[1], z0)))
        tris.append(((a[0], a[1], z1), (b[0], b[1], z1), (c[0], c[1], z1)))

    def wall(ring, outward: bool):
        m = len(ring)
        for i in range(m):
            x1, y1 = ring[i]
            x2, y2 = ring[(i + 1) % m]
            p1, p2 = (x1, y1, z0), (x2, y2, z0)
            p3, p4 = (x2, y2, z1), (x1, y1, z1)
            if outward:
                tris.append((p1, p2, p3))
                tris.append((p1, p3, p4))
            else:
                tris.append((p1, p3, p2))
                tris.append((p1, p4, p3))

    wall(_ccw(list(outer)), True)
    for h in holes:
        wall(_cw(list(h)), False)
    return tris


def extrude(outer, holes=(), thickness: float = 4.0, z0: float = 0.0) -> list:
    """
    A closed solid: a triangulated cap at each end plus the side walls.

    BUILT, THEN CHECKED, THEN REBUILT IF NEEDED.

    Cutting several holes into one outline is the one genuinely hard piece of
    geometry here. The holes have to be folded into the outline along bridges,
    and whether that produces a polygon an ear clipper can finish depends on
    where the bridges land - which depends on where the holes happen to be.
    Most layouts work first time. Some do not, and the failure is quiet: the
    cap comes back with a gap in it, the walls have nothing to close against,
    and the STL looks fine in a viewer and is rejected by a slicer.

    Chasing that with ever-cleverer bridge selection was the wrong instinct.
    The right one is that closure is CHEAP TO VERIFY - count the edges, every
    one must be used exactly twice - so build it, check it, and if it is not
    closed, rebuild with the rings rotated so different bridges get chosen.
    A rotation changes nothing about the shape and everything about where the
    bridging starts.

    If no attempt closes, this raises. A part that cannot be built is a
    sentence the user can act on; a part that is silently open is a wasted
    print.
    """
    outer = list(outer)
    holes = [list(h) for h in (holes or [])]
    attempts = []
    n = len(outer)

    # Three things vary, because three different things can go wrong:
    #  - where the outer ring starts, which moves every bridge target;
    #  - where each hole ring starts, which moves each bridge origin;
    #  - the ORDER holes are merged in. That last one matters most on a part
    #    like a C-channel, where holes sit in two narrow uprights: merging
    #    strictly right-to-left interleaves the two groups and a later bridge
    #    has to reach across a channel already cut in the other upright.
    #    Grouping them differently gives every bridge a short path through
    #    its own upright.
    orders = [holes]
    if len(holes) > 1:
        orders.append(list(reversed(holes)))
        orders.append(sorted(holes, key=lambda h: min(pt[0] for pt in h)))
        orders.append(sorted(holes, key=lambda h: (
            round(sum(pt[0] for pt in h) / len(h), 3),
            round(sum(pt[1] for pt in h) / len(h), 3))))

    for shift in (0, n // 3, 2 * n // 3, n // 6, 1):
        rot_outer = outer[shift:] + outer[:shift] if shift else outer
        for order in orders:
            for hshift in (0, 1):
                rot_holes = ([h[len(h) // 2:] + h[:len(h) // 2] for h in order]
                             if hshift else order)
                attempts.append((rot_outer, rot_holes))
        if not holes:
            break

    last_err = None
    best, best_open = None, None
    for rot_outer, rot_holes in attempts:
        try:
            tris = _extrude_once(rot_outer, rot_holes, thickness, z0)
        except Exception as e:
            last_err = e
            continue
        open_edges = is_closed(tris)
        if open_edges == 0:
            return tris
        if best_open is None or open_edges < best_open:
            best, best_open = tris, open_edges

    if last_err is not None and best is None:
        raise last_err
    raise ValueError(
        f"could not cut these holes into this outline cleanly - the best "
        f"attempt left {best_open} open edge(s), which will not slice. Move "
        f"the holes apart, keep them away from the outline, or cut them as "
        f"separate parts.")


# ═══════════════════════════════════════════════════════════════════════════
# §2  PROFILES AND PRIMITIVES
# ═══════════════════════════════════════════════════════════════════════════

def circle(cx, cy, r, segments: int = 48):
    return [(cx + r * math.cos(2 * math.pi * i / segments),
             cy + r * math.sin(2 * math.pi * i / segments))
            for i in range(segments)]


def rect(x, y, w, h, radius: float = 0.0, segments: int = 8):
    if radius <= 0:
        return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
    r = min(radius, w / 2, h / 2)
    pts = []
    for cx, cy, a0 in ((x + w - r, y + r, -math.pi / 2),
                       (x + w - r, y + h - r, 0.0),
                       (x + r, y + h - r, math.pi / 2),
                       (x + r, y + r, math.pi)):
        for i in range(segments + 1):
            a = a0 + (math.pi / 2) * i / segments
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def polygon(sides: int, cx, cy, r):
    return [(cx + r * math.cos(2 * math.pi * i / sides + math.pi / 2),
             cy + r * math.sin(2 * math.pi * i / sides + math.pi / 2))
            for i in range(max(3, int(sides)))]


def sphere(cx, cy, cz, r, segments: int = 32) -> list:
    tris, rings = [], max(6, segments // 2)
    def P(i, j):
        phi = math.pi * i / rings
        th = 2 * math.pi * j / segments
        return (cx + r * math.sin(phi) * math.cos(th),
                cy + r * math.sin(phi) * math.sin(th),
                cz + r * math.cos(phi))
    for i in range(rings):
        for j in range(segments):
            a, b, c, d = P(i, j), P(i, j + 1), P(i + 1, j + 1), P(i + 1, j)
            if i != 0:
                tris.append((a, b, c))
            if i != rings - 1:
                tris.append((a, c, d))
    return tris


def torus(cx, cy, cz, r_major, r_minor, seg_major=48, seg_minor=24) -> list:
    tris = []
    def P(i, j):
        u = 2 * math.pi * i / seg_major
        v = 2 * math.pi * j / seg_minor
        rr = r_major + r_minor * math.cos(v)
        return (cx + rr * math.cos(u), cy + rr * math.sin(u),
                cz + r_minor * math.sin(v))
    for i in range(seg_major):
        for j in range(seg_minor):
            a, b, c, d = P(i, j), P(i + 1, j), P(i + 1, j + 1), P(i, j + 1)
            tris.append((a, b, c))
            tris.append((a, c, d))
    return tris


def cone(cx, cy, z0, r_bottom, r_top, height, segments: int = 48) -> list:
    """Covers cones, cylinders (r_top == r_bottom) and points (r_top == 0)."""
    tris = []
    z1 = z0 + height
    for i in range(segments):
        a0 = 2 * math.pi * i / segments
        a1 = 2 * math.pi * (i + 1) / segments
        b0 = (cx + r_bottom * math.cos(a0), cy + r_bottom * math.sin(a0), z0)
        b1 = (cx + r_bottom * math.cos(a1), cy + r_bottom * math.sin(a1), z0)
        t0 = (cx + r_top * math.cos(a0), cy + r_top * math.sin(a0), z1)
        t1 = (cx + r_top * math.cos(a1), cy + r_top * math.sin(a1), z1)
        if r_bottom > 0:
            tris.append(((cx, cy, z0), b1, b0))
        if r_top > 0:
            tris.append(((cx, cy, z1), t0, t1))
        if r_bottom > 0 and r_top > 0:
            tris.append((b0, b1, t1))
            tris.append((b0, t1, t0))
        elif r_bottom > 0:
            tris.append((b0, b1, t0))
        elif r_top > 0:
            tris.append((t0, t1, b0))
    return tris


def revolve(profile, segments: int = 48) -> list:
    """
    Spin a 2D profile (x = radius, y = height) around the Z axis.

    Vases, knobs, bottles, pulleys, anything turned on a lathe.
    """
    tris = []
    pts = [(max(0.0, float(x)), float(y)) for x, y in profile]
    for i in range(segments):
        a0 = 2 * math.pi * i / segments
        a1 = 2 * math.pi * (i + 1) / segments
        for k in range(len(pts) - 1):
            r0, z0 = pts[k]
            r1, z1 = pts[k + 1]
            p00 = (r0 * math.cos(a0), r0 * math.sin(a0), z0)
            p01 = (r0 * math.cos(a1), r0 * math.sin(a1), z0)
            p10 = (r1 * math.cos(a0), r1 * math.sin(a0), z1)
            p11 = (r1 * math.cos(a1), r1 * math.sin(a1), z1)
            if r0 > 0:
                tris.append((p00, p01, p11))
            if r1 > 0:
                tris.append((p00, p11, p10))
    return tris


# ═══════════════════════════════════════════════════════════════════════════
# §3  THE SPEC
#
# What Nova writes. A list of parts, each a primitive with dimensions and a
# position. Deliberately small: every field is a number or a short word, so a
# language model can fill it in reliably, and nothing in it can describe an
# invalid solid.
# ═══════════════════════════════════════════════════════════════════════════

# WHAT A SPEC CAN AND CANNOT BE.
#
# THE BLOCK WITH TWO HOLES IN IT.
#
# Asked for "a statue of Goku and Frieza fighting", the model passed a spec.
# This module did exactly what a spec says: it built a rectangular prism with
# two cylindrical holes, saved it, measured it, called it watertight, and
# reported SUCCESS. Everything downstream agreed. The user got a block.
#
# The spec route builds EXACT PRIMITIVES - boxes, plates, cylinders, tubes,
# cones, spheres, tori, revolves. That is the whole vocabulary. It is the
# right answer for a bracket, a spacer, a stand, a vase, an enclosure: things
# defined by dimensions. It has no way to express a face, a limb, a pose or
# two figures in contact, and it cannot fail at those - it will happily
# approximate a person as a box, because a box is a shape and the spec asked
# for shapes.
#
# So the check has to happen BEFORE the build, on the subject, not after, on
# the geometry. A mesh cannot be inspected for "does this look like Goku";
# a request can be read for "is this a character".
#
# Biased deliberately toward saying no. Sending a bracket down the slower
# neural path costs a few minutes; sending a character down the spec path
# costs the user their afternoon and hands them a block labelled SUCCESS.
_ORGANIC = re.compile(
    r"\b("
    # people and parts of them
    r"person|people|human|man|woman|men|women|boy|girl|child|kid|baby"
    r"|face|head|hand|hands|arm|arms|leg|legs|body|bodies|torso|hair"
    r"|figure|figurine|statue|bust|portrait|character|characters"
    # creatures
    r"|animal|dog|cat|horse|bird|dragon|monster|creature|beast|fish"
    r"|tree|flower|plant|leaf"
    # things only bodies do
    r"|fighting|fight|posing|pose|dancing|running|standing|sitting|kneeling"
    r"|punching|kicking|clashing|battle|battling|wielding|holding"
    # named-character signals
    r"|goku|frieza|freiza|anime|superhero|warrior|knight|soldier|god|angel"
    r"|realistic|lifelike|organic|sculpt|sculpted|sculpture"
    r")\b", re.I)


def shape_note(tris) -> str:
    """
    What this mesh geometrically IS, in one sentence, from counting alone.

    THE SIX VIEWS WERE ATTACHED AND IT DID NOT HELP.

    The block was rendered from six angles and put in front of the model,
    which then described it as "battle-ready with golden hair, glowing aura,
    and purple dragon eyes". A 2B model looked at a grey rectangle and
    reported the prompt back. The character sheet forbids exactly that, and
    an instruction is no match for a small model's pull toward the words it
    was given.

    A picture is an interpretation. A triangle count is not. Two figures in
    combat is tens of thousands of triangles across hundreds of surface
    directions; the block was 244 triangles across 6 flat faces, and that
    difference is arithmetic anybody can check.

    So the mesh reports its own shape as measured fact, alongside the
    render. Not a verdict on whether the result is good - a description of
    what is actually there, which is the thing the model kept skipping.
    """
    n = len(tris or ())
    if not n:
        return "empty - no triangles at all"
    import math

    # COUNTING NORMALS IS NOT ENOUGH, AND THE BLOCK PROVED IT.
    #
    # The Goku slab had 62 distinct normals, which sounds like curvature and
    # is not: 56 of them are the facets of three cylindrical holes, carrying
    # almost none of the surface. What separates a box from a body is not how
    # many directions exist but how much AREA is on how few of them. A slab
    # puts nearly all its surface on six planes. A figure cannot.
    area_by_dir = {}
    area_by_plane = {}
    total = 0.0
    for t in tris:
        (ax, ay, az), (bx, by, bz), (cx, cy, cz) = t[:3]
        ux, uy, uz = bx - ax, by - ay, bz - az
        vx, vy, vz = cx - ax, cy - ay, cz - az
        nx = uy * vz - uz * vy
        ny = uz * vx - ux * vz
        nz = ux * vy - uy * vx
        ln = math.sqrt(nx * nx + ny * ny + nz * nz)
        if ln <= 1e-9:
            continue
        area = ln / 2.0
        total += area
        ux_, uy_, uz_ = nx / ln, ny / ln, nz / ln
        key = (round(ux_, 2), round(uy_, 2), round(uz_, 2))
        area_by_dir[key] = area_by_dir.get(key, 0.0) + area
        # AND THE SAME AREA GROUPED BY ACTUAL PLANE, not just direction.
        # Two parallel faces at opposite ends of an object share a direction
        # but are not the same surface; the offset separates them. This is
        # what finds a flat back.
        off = round(ux_ * ax + uy_ * ay + uz_ * az, 1)
        area_by_plane[(key, off)] = area_by_plane.get((key, off), 0.0) + area

    faces = len(area_by_dir)
    top6 = sum(sorted(area_by_dir.values(), reverse=True)[:6])
    flat = (top6 / total) if total > 0 else 1.0
    biggest_plane = max(area_by_plane.values()) if area_by_plane else 0.0

    # A BOX IS JUDGED FIRST, so a primitive slab is called a slab and not
    # mistaken for a relief - the flat-back test below would match a plain
    # box too, and "plaque" would be the wrong word for it.
    if flat >= 0.85:
        return (f"{n} triangles across {faces} surface directions; "
                f"{round(100 * flat)}% of its surface lies on just six flat "
                f"planes. This is a BOX OR SLAB, whatever else was asked "
                f"for - it is not a figure, a character or a scene.")

    # AND A PLAQUE IS NOT A BOX, WHICH IS HOW IT GOT THROUGH.
    #
    # The relief fallback produced 102,396 triangles across 20,154 surface
    # directions on an 80 x 80 x 8 mm plate. Every test above passed it - the
    # picture pressed into the face really is finely modelled, so the area is
    # genuinely spread across thousands of directions - and this function
    # called it "a detailed, organic-scale form".
    xs = [v[0] for t in tris for v in t[:3]]
    ys = [v[1] for t in tris for v in t[:3]]
    zs = [v[2] for t in tris for v in t[:3]]
    dims = sorted([max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs)])
    thin = dims[0] / dims[2] if dims[2] > 0 else 1.0

    # THE RATIO ALONE IS NOT THE TEST, AND CHASING IT UPWARD BROKE IT.
    #
    # The 8 mm plate was 10% as thick as it was wide, so a "under 22%" rule
    # caught it. Then the relief depth was raised to 18 mm and the next one
    # measured 20.9 mm on 80 - 26% - and walked straight past that rule and
    # out to the user, described by this very function as "a detailed,
    # organic-scale form".
    #
    # The temptation was to move 22% to 35%. That is wrong, and it is worth
    # writing down why: A STANDING FIGURE IS ALSO THIN. A person 80 mm tall
    # is about 30 wide and 20 deep, which is 25% - the same number as the
    # plaque. A threshold high enough to catch the plate would start calling
    # real statues plates, which is a worse failure than the one being fixed.
    #
    # What actually separates them is not slenderness. It is THE FLAT BACK.
    # A heightmap plate has one single plane, at the far side of its thinnest
    # axis, whose area is the ENTIRE footprint of the bounding box: measured
    # on the 20.9 mm relief, 6402 mm(2) of back on an 80 x 80 = 6400 mm(2)
    # face - 100% of it, and 18% of the model's whole surface, on one plane.
    # A statue has no such plane. Its base is a fraction of its silhouette,
    # and everything else curves.
    #
    # So the test is geometric, not proportional, and it does not care how
    # deep the relief is made: a slab is a slab at 8 mm and at 21 mm and at
    # 40 mm, and pressing a picture harder into it never makes a figure.
    face = dims[1] * dims[2]          # the largest bounding-box face
    covered = (biggest_plane / face) if face > 0 else 0.0
    if n > 400 and covered >= 0.5 and thin < 0.5:
        pct = round(100 * thin)
        return (f"{n} triangles, but one single flat plane covers "
                f"{round(100 * covered)}% of the {dims[2]:.0f} x "
                f"{dims[1]:.0f} mm footprint - the whole back is one face, "
                f"and the object is {dims[0]:.0f} mm deep ({pct}% as thick "
                f"as it is wide). This is a PLAQUE OR RELIEF: a flat plate "
                f"with detail pressed into one side. It is not a figure and "
                f"it has no back, no sides and no depth to walk around.")

    if thin < 0.22 and n > 400:
        pct = round(100 * thin)
        return (f"{n} triangles, but the whole thing is "
                f"{dims[0]:.0f} mm deep on a {dims[2]:.0f} mm footprint - "
                f"{pct}% as thick as it is wide. This is a PLAQUE OR RELIEF: "
                f"a flat plate with detail pressed into one face. It is not a "
                f"figure and it has no back, no sides and no depth to walk "
                f"around.")

    if flat >= 0.6:
        kind = ("mostly flat panels with some detail on them - a plate, an "
                "enclosure or a bracket rather than a sculpted form")
    elif n < 4000:
        kind = "a rounded but low-detail shape"
    elif n < 30000:
        kind = "a moderately detailed form"
    else:
        kind = "a detailed, organic-scale form"
    return (f"{n} triangles across {faces} surface directions; {kind}.")


def is_figure(tris) -> bool:
    """
    Could this mesh plausibly be a person, creature or scene? Counting only.

    A deliberately generous floor. Anything under it is definitely not a
    figure; passing it does not make something a good statue, only that the
    geometry is not obviously a primitive.
    """
    n = len(tris or ())
    if n < 2000:
        return False
    note = shape_note(tris)
    return "BOX OR SLAB" not in note and "PLAQUE OR RELIEF" not in note


def spec_suits(subject: str) -> str:
    """
    "" if a spec can represent this, otherwise why it cannot.

    Read the words the user actually used. A spec is a list of primitives;
    if the subject is a body, a creature or an action only a body performs,
    no arrangement of boxes and cylinders is going to be it.
    """
    text = str(subject or "")
    if not text.strip():
        return ""
    m = _ORGANIC.search(text)
    if not m:
        return ""
    return (f"the request mentions {m.group(0)!r}, and a spec can only build "
            f"exact primitives - boxes, plates, cylinders, tubes, cones, "
            f"spheres, tori and revolves. There is no arrangement of those "
            f"that is a character, a body or a pose. A spec would produce a "
            f"block with holes in it and call it a success")


SPEC_HELP = """A 3D spec is JSON: {"units": "mm", "parts": [ ... ]}

Every part has "shape" and its own dimensions, plus optional "at": [x, y, z].

  {"shape": "box",      "size": [60, 40, 4], "radius": 3,
   "holes": [{"at": [10, 10], "d": 5}, {"at": [50, 30], "d": 5}]}
  {"shape": "cylinder", "d": 20, "h": 30, "hole_d": 8}
  {"shape": "cone",     "d": 30, "d_top": 0, "h": 40}
  {"shape": "sphere",   "d": 25}
  {"shape": "torus",    "d": 40, "thickness": 6}
  {"shape": "tube",     "d": 20, "wall": 2, "h": 40}
  {"shape": "plate",    "outline": [[0,0],[80,0],[80,20],[20,20],[20,60],[0,60]],
   "thickness": 4, "holes": [{"at": [10, 10], "d": 5}]}
  {"shape": "revolve",  "profile": [[0,0],[20,0],[18,40],[8,60],[10,70],[0,72]]}

"holes" are through-holes; "d" is a diameter, "h" a height, "wall" a wall
thickness. Sizes are millimetres unless "units" says otherwise. Parts are
combined into one object; use "at" to place them relative to each other."""


def _hole_rings(holes, segments=48):
    out = []
    for h in holes or []:
        at = h.get("at") or [0, 0]
        d = float(h.get("d", h.get("diameter", 0)) or 0)
        if d <= 0:
            continue
        r = d / 2.0
        # Segments proportional to size. 48 sides on a 4 mm hole is invisible
        # detail and it makes the bridging search - which is quadratic in
        # vertex count - far slower than it needs to be.
        seg = max(12, min(int(segments), int(r * 8) // 2 * 2 + 12))
        out.append(circle(float(at[0]), float(at[1]), r, seg))
    return out


def _translate(tris, dx, dy, dz):
    if not (dx or dy or dz):
        return tris
    return [tuple((p[0] + dx, p[1] + dy, p[2] + dz) for p in t) for t in tris]


def _part(p: dict) -> list:
    shape = str(p.get("shape", "box")).strip().lower()
    at = p.get("at") or [0, 0, 0]
    ax, ay, az = (list(at) + [0, 0, 0])[:3]

    def num(*keys, default=0.0):
        for k in keys:
            if p.get(k) is not None:
                try:
                    return float(p[k])
                except (TypeError, ValueError):
                    pass
        return float(default)

    if shape in ("box", "cube", "plate", "block"):
        if p.get("outline"):
            outline = [(float(x), float(y)) for x, y in p["outline"]]
            th = num("thickness", "h", "height", default=4.0)
        else:
            size = p.get("size") or [num("w", "width", default=40),
                                     num("d", "depth", default=40),
                                     num("thickness", "h", "height", default=4)]
            w, dd, th = (list(size) + [40, 40, 4])[:3]
            outline = rect(0, 0, float(w), float(dd),
                           radius=num("radius", "fillet", default=0.0))
        tris = extrude(outline, _hole_rings(p.get("holes")), th)

    elif shape in ("cylinder", "rod", "disc", "disk"):
        r = num("d", "diameter", default=20) / 2.0 or num("r", "radius",
                                                          default=10)
        h = num("h", "height", default=20)
        hd = num("hole_d", "bore", default=0.0)
        if hd > 0:
            tris = extrude(circle(0, 0, r), [circle(0, 0, hd / 2.0)], h)
        else:
            tris = cone(0, 0, 0, r, r, h)

    elif shape in ("tube", "pipe", "ring"):
        r = num("d", "diameter", default=20) / 2.0
        wall = num("wall", "thickness", default=2.0)
        h = num("h", "height", default=20)
        tris = extrude(circle(0, 0, r), [circle(0, 0, max(0.1, r - wall))], h)

    elif shape in ("cone", "taper", "frustum"):
        tris = cone(0, 0, 0, num("d", "diameter", default=30) / 2.0,
                    num("d_top", "top_d", default=0.0) / 2.0,
                    num("h", "height", default=30))

    elif shape in ("sphere", "ball", "dome"):
        r = num("d", "diameter", default=30) / 2.0 or num("r", "radius",
                                                          default=15)
        tris = sphere(0, 0, r, r)

    elif shape in ("torus", "donut", "doughnut"):
        rj = num("d", "diameter", default=40) / 2.0
        rn = num("thickness", "tube_d", "minor_d", default=8) / 2.0
        tris = torus(0, 0, rn, max(rn, rj - rn), rn)

    elif shape in ("revolve", "lathe", "vase"):
        prof = p.get("profile") or [[0, 0], [20, 0], [16, 40], [22, 70],
                                    [18, 74], [0, 74]]
        tris = revolve([(float(a), float(b)) for a, b in prof])

    elif shape in ("prism", "hex", "hexagon", "polygon"):
        sides = int(num("sides", default=6))
        r = num("d", "diameter", "across", default=20) / 2.0
        tris = extrude(polygon(sides, 0, 0, r), _hole_rings(p.get("holes")),
                       num("h", "height", "thickness", default=10))
    else:
        raise ValueError(
            f"unknown shape {shape!r}. Known shapes: box/plate, cylinder, "
            f"tube, cone, sphere, torus, revolve, prism.")

    return _translate(tris, ax, ay, az)


def build(spec) -> list:
    """A spec (dict or JSON string) to a triangle list."""
    if isinstance(spec, str):
        spec = json.loads(spec)
    if not isinstance(spec, dict):
        raise ValueError("a spec must be a JSON object")
    parts = spec.get("parts") or ([spec] if spec.get("shape") else [])
    if not parts:
        raise ValueError("the spec has no parts. " + SPEC_HELP)
    tris = []
    for p in parts[:64]:
        tris.extend(_part(p if isinstance(p, dict) else {}))
    if not tris:
        raise ValueError("the spec produced no geometry")
    return tris


# ═══════════════════════════════════════════════════════════════════════════
# §4  AN IMAGE, IN RELIEF
#
# Brightness becomes height. This is how a generated picture - or a photo, or
# a logo - becomes something with a shape, on any machine, with no model.
# A lithophane is the same operation with the height inverted and a thin
# base, which is why both live in one function.
# ═══════════════════════════════════════════════════════════════════════════

def read_png(path: Path):
    """
    Decode a PNG to (pixels, width, height) with nothing but zlib.

    Pillow is not installed on a real install - the shipped Python is
    embedded, with no pip - so "read the image" cannot mean "import PIL".
    Without this, turning a generated picture into a relief worked on the
    developer's machine and raised on the user's, which is the same shape of
    bug as the camera frame that was written with no file extension.

    Handles the colour types stable-diffusion.cpp and the browser actually
    produce: 8-bit greyscale, greyscale+alpha, RGB and RGBA, non-interlaced.
    Anything else returns None and the caller says so.
    """
    import struct
    import zlib

    data = Path(path).read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    pos, idat, width, height, depth, colour, interlace = 8, [], 0, 0, 8, 0, 0
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        tag = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if tag == b"IHDR":
            width, height, depth, colour, _, _, interlace = struct.unpack(
                ">IIBBBBB", body[:13])
        elif tag == b"IDAT":
            idat.append(body)
        elif tag == b"IEND":
            break
    if not idat or depth != 8 or interlace != 0:
        return None
    channels = {0: 1, 2: 3, 4: 2, 6: 4}.get(colour)
    if channels is None:
        return None

    raw = zlib.decompress(b"".join(idat))
    stride = width * channels
    out = bytearray(stride * height)
    prev = bytearray(stride)
    i = 0
    for y in range(height):
        ftype = raw[i]
        i += 1
        line = bytearray(raw[i:i + stride])
        i += stride
        if ftype == 1:
            for x in range(channels, stride):
                line[x] = (line[x] + line[x - channels]) & 0xFF
        elif ftype == 2:
            for x in range(stride):
                line[x] = (line[x] + prev[x]) & 0xFF
        elif ftype == 3:
            for x in range(stride):
                a = line[x - channels] if x >= channels else 0
                line[x] = (line[x] + ((a + prev[x]) >> 1)) & 0xFF
        elif ftype == 4:
            for x in range(stride):
                a = line[x - channels] if x >= channels else 0
                b = prev[x]
                c = prev[x - channels] if x >= channels else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                line[x] = (line[x] + pr) & 0xFF
        out[y * stride:(y + 1) * stride] = line
        prev = line

    px = []
    for k in range(0, len(out), channels):
        if channels >= 3:
            px.append((out[k], out[k + 1], out[k + 2]))
        else:
            v = out[k]
            px.append((v, v, v))
    return px, width, height


def _luma_grid(image: Path, cols: int, rows: int):
    """A cols x rows grid of 0..1 brightness. Pillow if present, else PNG."""
    try:
        from PIL import Image
        with Image.open(image) as im:
            im = im.convert("L").resize((cols, rows), Image.LANCZOS)
            px = list(im.getdata())
        return [[px[y * cols + x] / 255.0 for x in range(cols)]
                for y in range(rows)]
    except Exception:
        pass
    got = read_png(Path(image))
    if got is None:
        raise RuntimeError(
            f"could not read {Path(image).name} for a relief. PNG is read "
            f"directly; any other format needs Pillow, which is not part of "
            f"this install. Convert it to PNG first - convert_file does that.")
    src, sw, sh = got
    out = []
    for y in range(rows):
        line = []
        sy = min(sh - 1, int(y * sh / rows))
        for x in range(cols):
            sx = min(sw - 1, int(x * sw / cols))
            r, g, b = src[sy * sw + sx]
            line.append((0.299 * r + 0.587 * g + 0.114 * b) / 255.0)
        out.append(line)
    return out


def relief(image: Path, *, width: float = 80.0, depth: float = 4.0,
           base: float = 1.5, resolution: int = 160,
           invert: bool = False) -> list:
    """
    An image as a displaced surface with a solid base and closed sides.

    Watertight on purpose: a heightfield with open edges is a surface, not a
    solid, and a slicer will refuse it or fill it wrongly.
    """
    image = Path(image)
    cols = max(16, min(400, int(resolution)))
    grid = _luma_grid(image, cols, cols)
    rows = len(grid)
    cols = len(grid[0])
    sx = float(width) / (cols - 1)
    sy = float(width) / (rows - 1)

    def h(x, y):
        v = grid[y][x]
        if invert:
            v = 1.0 - v
        return float(base) + v * float(depth)

    tris = []
    for y in range(rows - 1):
        for x in range(cols - 1):
            p00 = (x * sx, y * sy, h(x, y))
            p10 = ((x + 1) * sx, y * sy, h(x + 1, y))
            p11 = ((x + 1) * sx, (y + 1) * sy, h(x + 1, y + 1))
            p01 = (x * sx, (y + 1) * sy, h(x, y + 1))
            tris.append((p00, p10, p11))
            tris.append((p00, p11, p01))

    W = (cols - 1) * sx
    D = (rows - 1) * sy

    # THE BASE IS TESSELLATED LIKE THE TOP, NOT LEFT AS TWO BIG TRIANGLES.
    #
    # Two triangles across the whole underside gives the base ONE long edge
    # per side, while the skirt above it has one short edge per grid column.
    # The two never meet, and every one of those short edges is left open:
    # 192 of them at 48x48. It renders perfectly and no slicer will take it.
    # Matching the grid costs triangles and closes the solid.
    for y in range(rows - 1):
        for x in range(cols - 1):
            q00 = (x * sx, y * sy, 0.0)
            q10 = ((x + 1) * sx, y * sy, 0.0)
            q11 = ((x + 1) * sx, (y + 1) * sy, 0.0)
            q01 = (x * sx, (y + 1) * sy, 0.0)
            tris.append((q00, q11, q10))
            tris.append((q00, q01, q11))

    for x in range(cols - 1):
        tris.append(((x * sx, 0, 0), ((x + 1) * sx, 0, 0),
                     ((x + 1) * sx, 0, h(x + 1, 0))))
        tris.append(((x * sx, 0, 0), ((x + 1) * sx, 0, h(x + 1, 0)),
                     (x * sx, 0, h(x, 0))))
        tris.append(((x * sx, D, 0), (x * sx, D, h(x, rows - 1)),
                     ((x + 1) * sx, D, h(x + 1, rows - 1))))
        tris.append(((x * sx, D, 0), ((x + 1) * sx, D, h(x + 1, rows - 1)),
                     ((x + 1) * sx, D, 0)))
    for y in range(rows - 1):
        tris.append(((0, y * sy, 0), (0, y * sy, h(0, y)),
                     (0, (y + 1) * sy, h(0, y + 1))))
        tris.append(((0, y * sy, 0), (0, (y + 1) * sy, h(0, y + 1)),
                     (0, (y + 1) * sy, 0)))
        tris.append(((W, y * sy, 0), (W, (y + 1) * sy, 0),
                     (W, (y + 1) * sy, h(cols - 1, y + 1))))
        tris.append(((W, y * sy, 0), (W, (y + 1) * sy, h(cols - 1, y + 1)),
                     (W, y * sy, h(cols - 1, y))))
    return tris


# ═══════════════════════════════════════════════════════════════════════════
# §5  WRITING IT OUT
# ═══════════════════════════════════════════════════════════════════════════

def save(tris: list, dest: Path) -> Path:
    """Write triangles using model3d's own writers, so one reader reads them."""
    dest = Path(dest)
    ext = dest.suffix.lower()
    if ext == ".stl":
        ok = model3d._write_ascii_stl(tris, dest, name="HubMesh")
    elif ext == ".obj":
        ok = model3d._write_obj(tris, dest)
    elif ext == ".ply":
        ok = model3d._write_ply(tris, dest)
    else:
        dest = dest.with_suffix(".stl")
        ok = model3d._write_ascii_stl(tris, dest, name="HubMesh")
    if not ok:
        raise RuntimeError(f"could not write {dest.name}")
    return dest


def measure(tris: list) -> dict:
    lo = [min(p[i] for t in tris for p in t) for i in range(3)]
    hi = [max(p[i] for t in tris for p in t) for i in range(3)]
    return {"triangles": len(tris),
            "size": [round(hi[i] - lo[i], 2) for i in range(3)],
            "min": [round(v, 2) for v in lo],
            "max": [round(v, 2) for v in hi]}
