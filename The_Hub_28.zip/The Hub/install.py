"""
install.py - one-click setup for The Hub on Windows 11.

Everything it writes lands inside this folder. No registry keys, no system
directories, no PATH changes, nothing elsewhere in your user profile. Delete
the folder and The Hub is gone without a trace.

  1  check prerequisites
  2  measure the machine and choose the matching build
  3  install llama.cpp        thinking
  4  install whisper.cpp      hearing        (CPU only, fully local)
  5  download models          starter set
  6  write configuration      from what was measured, not from a guess
  7  verify                   every subsystem, loudly

Safe to re-run. Anything already present is skipped.

NO ANCESTOR REQUIRED
--------------------
The Hub does not need Cairn, LuminovaZero or VeraZero to be installed,
and does not read anything they own. It downloads its runtime from GitHub
and its models from HuggingFace, exactly as if this were the first AI thing
this machine had ever seen. That is the test of independence, and it is the
reason this file exists rather than a migration script.

If you DO already have models on this machine and want them, that is an
explicit copy you ask for, not something the installer goes looking for:

    python get_model.py --import "C:\\path\\to\\model.gguf"

SMALL MODELS ON PURPOSE
-----------------------
The default set is about about 3.5 GB for the Gemma starter plus local runtime assets. A 16 GB laptop with 4 GB of VRAM runs
a 2.6B comfortably and leaves room for memory work to run beside it, which
is the whole point of having a background memory model. Bigger models can be
added afterwards and switched to from the dropdown; starting there means the
first run either works or fails for reasons that have nothing to do with The
The Hub.

This is the only part of The Hub that uses the internet by design. After
it finishes, everything except web search runs with the network unplugged.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# The installer imports The Hub's own modules (core, vision) to report what it
# just installed. sys.path was only being extended inside verify(), several
# steps later, so every earlier `import core` / `import vision` raised - and
# because those reads sat inside a broad `except Exception`, the failure came
# out as a vague one-line vision notice instead of an error. Put the folder on
# the path once, at the top, where every step can rely on it.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

MODELS = ROOT / "llm" / "models"
RUNTIME = ROOT / "llm" / "llama.cpp"
WHISPER = ROOT / "llm" / "whisper.cpp"
DL = ROOT / "llm" / "_dl"

# Pinned, not "latest". Reproducible: if something breaks later we know it
# was not the upstream release shifting underneath us.
LLAMA_BUILD = "b10456"
LLAMA_BASE = f"https://github.com/ggml-org/llama.cpp/releases/download/{LLAMA_BUILD}"
WHISPER_TAG = "v1.9.2"
WHISPER_BASE = f"https://github.com/ggml-org/whisper.cpp/releases/download/{WHISPER_TAG}"

LLAMA_ASSETS = {
    "cuda": [f"llama-{LLAMA_BUILD}-bin-win-cuda-12.4-x64.zip",
             "cudart-llama-bin-win-cuda-12.4-x64.zip"],
    "cpu":  [f"llama-{LLAMA_BUILD}-bin-win-cpu-x64.zip"],
}
WHISPER_ASSET = "whisper-bin-x64.zip"

# Preferred starter model only. The Hub still discovers and loads any GGUF
# the user adds to llm\models; this list controls what a fresh install
# downloads, not what the model selector permits.
#
# WHY A CATALOGUE AND NOT ONE MODEL
#
# The requirement has not moved: uncensored, with vision, tool calling and
# thinking, on a 4 GB card. What moved is the evidence. Two models were
# chosen on paper and rejected in use, and both times the paper was right
# about capability and silent about the thing that actually mattered.
#
# Qwen3-VL-4B-Thinking was all three by construction. It is REMOVED - not
# skipped, removed - for two measured reasons:
#
#   slow      a 4B that reasons before every answer, on a card with 4 GB, is
#             minutes per reply. "Not worth running if it is going to be
#             like this."
#   repeats   worse than slow. It re-read its own context in a loop -
#             "Wait, maybe there's a mix-up. Let me check the user's message
#             again." over and over - and spent a whole reply deciding what
#             the request was without ever doing it.
#
# A model that loops is not a slow model, it is a model that does not
# finish. It is gone from this list rather than left in it, because leaving
# it selectable is leaving the loop selectable.
#
#   Qwen3.5-2B abliterated      1.7 GB   DEFAULT. The Qwen3.5 small series
#                                        is multimodal with hybrid reasoning
#                                        and tool calling, so all three are
#                                        present at 2B - and 2B is several
#                                        times faster than any 4B here. The
#                                        ~1 GB it saves goes into the
#                                        context window, which is what stops
#                                        Nova's own instructions being cut
#                                        to fit (ADR-71). Measured 32768 on
#                                        this card against 15360 for a 4B.
#   Qwen3.5-4B abliterated      2.8 GB   The same three with more behind
#                                        them. Slower, smaller window.
#   Gemma 4 E2B abliterated     3.6 GB   Explicitly asked for. Fast, and
#                                        coherent where the 4B thinking
#                                        models were not. Vision and tools,
#                                        no reasoning mode - so the
#                                        enable_thinking flag does nothing
#                                        and it is two of three. Uncensored,
#                                        which the plain ggml-org build is
#                                        not.
#
# Not installed, and worth knowing about:
#
#   MiniCPM-o 4.5 is the omni-modal answer - vision, video, speech IN and
#   speech OUT in one model, with instruct and thinking modes. It is 9B and
#   5.0 GB at Q4_K_M, so it does not fit beside a KV cache on this card, and
#   its speech path needs more than llama-server provides. It is the right
#   model for a machine with 12 GB or more, and the wrong one for this.
#
# Anything already in llm\models stays selectable whether it came from here
# or not. This list is only what a fresh install downloads.
MODEL_CATALOGUE = [
    {"name": "Gemma 4 E2B abliterated",
     "repo": "mradermacher/Huihui-gemma-4-E2B-it-abliterated-GGUF",
     "model": "Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf",
     "model_mb": 3200,
     "projector": "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf",
     "projector_mb": 520,
     "install": True,
     "why": "DEFAULT. Coherent and fast in use, uncensored, vision and "
            "tools. No reasoning mode, so two of three - and two that work "
            "beat three where one arrives as a loop"},
    {"name": "Qwen3.5-4B abliterated",
     "repo": "mradermacher/Huihui-Qwen3.5-4B-abliterated-GGUF",
     "model": "Huihui-Qwen3.5-4B-abliterated.Q4_K_M.gguf",
     "model_mb": 2500,
     "projector": "Huihui-Qwen3.5-4B-abliterated.mmproj-Q8_0.gguf",
     "projector_mb": 330,
     "install": False,
     "why": "all three capabilities, kept selectable but no longer fetched "
            "- slower, and the family hallucinated in use here"},
]

MODEL_SET = [(e["repo"], e["model"], e["model_mb"], "main")
             for e in MODEL_CATALOGUE if e["install"]]
PROJECTOR_SET = [(e["repo"], e["projector"], e["projector_mb"],
                  "vision-projector")
                 for e in MODEL_CATALOGUE if e["install"] and e.get("projector")]

# Every downloadable asset is pinned by content hash, taken from the Git LFS
# pointer the repository publishes. A model that arrives with a different
# hash is not the model this was tested against, so it is deleted rather than
# loaded. install_models() reports any file it fetched WITHOUT a hash here,
# because an unverified download that says nothing is worse than one that
# says so.
ASSET_SHA256 = {
    "Huihui-Qwen3.5-4B-abliterated.Q4_K_M.gguf":
        "423f10b6ec2d99c3378143d7cd3b80eb4887b3ed92103103ac59173b404f4f7c",
    "Huihui-Qwen3.5-4B-abliterated.mmproj-Q8_0.gguf":
        "650e2af8754b8b10e21debdbaf352cab43cd2435ec8ed56b893b9b581ae4a95c",
    "Huihui-gemma-4-E2B-it-abliterated.Q4_K_M.gguf":
        "55044454df35c2e3b9f4ca7a52b27cc7b057b3b3547cd114183196c31f5062a8",
    "Huihui-gemma-4-E2B-it-abliterated.mmproj-Q8_0.gguf":
        "030b1a496787c3ca9240552a3d5488db0ba50c6d6cdc878793513340d736765c",
    # Kept so that an existing Gemma install still verifies rather than
    # being re-downloaded or reported as unknown.
    "gemma-4-E2B-it-Q4_K_M.gguf":
        "71e6e8cb64a76da1a734fb8f6ba389d2784950d9902f5e87244fca0a15190c94",
    "mmproj-gemma-4-E2B-it-BF16.gguf":
        "04125f8e2a1135824e48064c32157356704e6681a9f3af669af321a3c70c39d7",
}

def verify_sha(path: Path, expected: str) -> bool:
    h = hashlib.sha256()
    try:
        with path.open("rb") as f:
            for blk in iter(lambda: f.read(1 << 20), b""):
                h.update(blk)
    except Exception:
        return False
    got = h.hexdigest().lower()
    if got != expected.lower():
        p(f"  ERROR: SHA256 mismatch for {path.name}", "r")
        p(f"         got  {got}", "r")
        p(f"         want {expected.lower()}", "r")
        return False
    p(f"  sha256  {path.name} verified", "g")
    return True
WHISPER_MODEL = ("ggerganov/whisper.cpp", "ggml-base.en.bin", 100)

# ---------------------------------------------------------------- generators
#
# Image, video and 3D generation ship WITH The Hub rather than requiring the
# user to install ComfyUI or Automatic1111 first. Both projects below are
# ggml - the same family as llama.cpp, the same GGUF weights, the same kind of
# pinned Windows binary - so this is the pattern already in use, not a new one.
#
# Pinned to an exact release for the same reason llama.cpp is: when something
# breaks later, it was not the upstream shifting underneath us.
GEN = ROOT / "llm" / "gen"
SD_DIR = GEN / "sd"
TRELLIS_DIR = GEN / "trellis"
GEN_MODELS = GEN / "models"
TRELLIS_MODELS = GEN / "trellis-models"

# THE TAG AND THE FILENAME ARE NOT THE SAME STRING.
#
# The release is tagged `master-709-92a3b73` - build number and short hash -
# but the files inside it are named `sd-master-92a3b73-...`, with the build
# number left out. Building the filename out of the tag produced
#
#     sd-master-709-92a3b73-bin-win-cuda12-x64.zip     ->  404
#
# and the installer dutifully reported "sd-cli did not install", which is a
# true sentence about a URL that never existed. The 537 MB CUDA runtime beside
# it downloaded fine, which made it look like a network problem rather than a
# typo. Two constants, because they are two different things.
SD_BUILD = "master-709-92a3b73"        # the release tag, used in the URL path
SD_REV = "92a3b73"                     # the short hash, used in filenames
SD_BASE = ("https://github.com/leejet/stable-diffusion.cpp/releases/download/"
           + SD_BUILD)
SD_ASSETS = {
    "cuda": [f"sd-master-{SD_REV}-bin-win-cuda12-x64.zip",
             "cudart-sd-bin-win-cu12-x64.zip"],
    # No CUDA card: Vulkan works on almost anything and is far faster than
    # the plain CPU build, which is the last resort.
    "cpu":  [f"sd-master-{SD_REV}-bin-win-vulkan-x64.zip",
             f"sd-master-{SD_REV}-bin-win-avx2-x64.zip"],
}

TRELLIS_TAG = "v0.4.3"
TRELLIS_BASE = ("https://github.com/pwilkin/trellis.cpp/releases/download/"
                + TRELLIS_TAG)
TRELLIS_ASSETS = {"cuda": ["trellis-cuda-windows-x64.zip"],
                  "cpu": ["trellis-vulkan-windows-x64.zip"]}

# Image.
#
# TWO CHECKPOINTS, AND THE ORDER MATTERS.
#
# The first build shipped only stable-diffusion-v1-5-pruned-emaonly, which is
# the raw 2022 base weights. It is the reference model, not a good one: faces
# come out melted at 512px and it needs a lot of prompt work to produce
# anything usable. The user's report was blunt and correct - "the images
# aren't good... faces don't work... we should not send ten image prompts
# through to get one good image".
#
# DreamShaper XL Turbo is the better default by a wide margin:
#   - SDXL, so it renders natively at 1024 and a face gets four times the
#     pixels it had at 512, which is most of the face problem on its own;
#   - a fine-tune rather than base weights, so anatomy and composition are
#     far better without a paragraph of prompt engineering;
#   - turbo-distilled, so 6-8 steps instead of 28 - it is 2.8 GB and it is
#     FASTER on this card than the 1.7 GB model it replaces.
#
# SD1.5 stays as the fallback: if 2.8 GB will not fit alongside a 1024px
# latent on a particular card, there has to be something that does.
# forge._preferred_image_model() prefers the fine-tune; forge.model_preset()
# gives each one the step count and CFG it actually needs.
IMAGE_SET = [
    ("offgrid-ai/dreamshaper-xl-v2-turbo-GGUF",
     "dreamshaper-xl-v2-turbo-Q4_K.gguf", 2500, "image"),
    ("second-state/stable-diffusion-v1-5-GGUF",
     "stable-diffusion-v1-5-pruned-emaonly-Q8_0.gguf", 1500, "image-fallback"),
]

# Video. Wan 2.1 T2V at 1.3B is the small one on purpose; the 14B does not
# fit here at any quantisation. It needs three separate files, and sd-cli
# takes them as three separate flags.
VIDEO_SET = [
    ("samuelchristlie/Wan2.1-T2V-1.3B-GGUF",
     "Wan2.1-T2V-1.3B-Q5_K_M.gguf", 900, "video"),
    ("Comfy-Org/Wan_2.1_ComfyUI_repackaged",
     "split_files/vae/wan_2.1_vae.safetensors", 200, "video-vae"),
    # Q3_K_M of the text encoder, not Q8: the encoder is the largest single
    # piece of a Wan run and this is the difference between fitting and not.
    ("city96/umt5-xxl-encoder-gguf",
     "umt5-xxl-encoder-Q3_K_M.gguf", 2500, "video-text-encoder"),
]

# 3D. The 512 path of TRELLIS.2 - eight files. The 1024 variants are left
# out deliberately: they are another 5 GB and they will not run on a 4 GB
# card, so downloading them would only buy disk usage.
TRELLIS_SET = [
    ("ilintar/trellis2-gguf", n, mb, "trellis") for n, mb in (
        ("birefnet.gguf", 800), ("dinov3.gguf", 550),
        ("ss_flow.gguf", 2400), ("ss_dec.gguf", 130),
        ("shape_flow_512.gguf", 2400), ("shape_dec.gguf", 880),
        ("tex_flow_512.gguf", 2400), ("tex_dec.gguf", 880))
]

GEN_SHA256 = {
    "dreamshaper-xl-v2-turbo-Q4_K.gguf":
        "3864355a401eb48f7909f6ee8ab14ef2a7e1e259e27ee85fc4a234f333d588c8",
    "stable-diffusion-v1-5-pruned-emaonly-Q8_0.gguf":
        "d0555243938c62faeefb4ac93f6c7a053ad373a4290c5256bce229aeb193bf94",
    "Wan2.1-T2V-1.3B-Q5_K_M.gguf":
        "6b4f8cd71200e9ffb6da45d9cc01e97c6a330929e9b0d186a85da3a961b76e75",
    "wan_2.1_vae.safetensors":
        "2fc39d31359a4b0a64f55876d8ff7fa8d780956ae2cb13463b0223e15148976b",
}

ASSET_MANIFEST = {
    "model": ("mradermacher/Huihui-Qwen3-VL-4B-Thinking-abliterated-GGUF/"
              "Huihui-Qwen3-VL-4B-Thinking-abliterated.Q4_K_M.gguf"),
    "whisper": "ggerganov/whisper.cpp/ggml-base.en.bin",
    "llama_build": LLAMA_BUILD,
    "whisper_tag": WHISPER_TAG,
}

C = {"i": "\033[96m", "g": "\033[92m", "y": "\033[93m",
     "r": "\033[91m", "d": "\033[90m", "b": "\033[1m", "x": "\033[0m"}


def p(msg, c="x"):
    print(f"{C.get(c, '')}{msg}{C['x']}")


def head(n, total, msg):
    print()
    p(f"[{n}/{total}] {msg}", "i")
    p("-" * 58, "d")


# ---------------------------------------------------------------- 1 checks

def check_tools() -> bool:
    ok = True
    p(f"  python   {sys.version.split()[0]}", "g")
    if sys.version_info < (3, 9):
        p("  ERROR: Python 3.9 or newer is required.", "r")
        ok = False
    for exe in ("curl.exe", "tar.exe"):
        if shutil.which(exe):
            p(f"  {exe}   found", "g")
        else:
            p(f"  ERROR: {exe} MISSING - needs Windows 10 1803 or newer", "r")
            ok = False
    try:
        free = shutil.disk_usage(ROOT).free / 2**30
        p(f"  disk     {free:.1f} GB free", "g" if free > 6 else "y")
        if free < 10:
            p("  Under 10 GB free. Setup needs the ~3.43 GB Gemma starter plus runtime/model headroom.", "y")
    except Exception:
        pass
    if "onedrive" in str(ROOT).lower():
        p("  WARNING: this folder is inside OneDrive.", "y")
        p("  Syncing corrupts multi-gigabyte model files. Move it first.", "y")
    return ok


# ---------------------------------------------------------------- 2 machine

def measure() -> dict:
    """
    Look at the actual machine. Everything written into config comes from
    here rather than from an assumption about what a laptop is like.
    """
    m = {"kind": "cpu", "threads": 6, "budget_mb": 9000,
         "total_mb": 0, "avail_mb": 0, "vram_mb": 0, "cores": 0}

    cores = os.cpu_count() or 8
    m["cores"] = cores
    # Half the logical cores, floor 2, ceiling 8. llama.cpp scales badly past
    # the physical core count, and leaving headroom is what keeps the machine
    # usable while a long generation runs.
    m["threads"] = max(2, min(8, cores // 2))
    p(f"  CPU      {cores} logical cores  ->  {m['threads']} threads", "g")

    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong),
                        ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong),
                        ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong),
                        ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        st = MS()
        st.dwLength = ctypes.sizeof(MS)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
            m["total_mb"] = int(st.ullTotalPhys / 1048576)
            m["avail_mb"] = int(st.ullAvailPhys / 1048576)
    except Exception:
        pass

    if m["total_mb"]:
        p(f"  RAM      {m['total_mb']/1024:.1f} GB total, "
          f"{m['avail_mb']/1024:.1f} GB available now", "g")
        # Recorded, not enforced. An earlier version wrote
        # (available - 1500) into config as a hard ceiling, which on a
        # machine measured mid-session produced 7.5 GB and then permanently
        # blocked an 11 GB model that demonstrably runs on it. Free memory is
        # measured at load time now; this is only ever shown to the user.
        m["budget_mb"] = 0
        if m["total_mb"] < 8000:
            p("  Under 8 GB of RAM. It will run, but keep n_ctx low.", "y")
    else:
        p("  RAM      could not be measured - using a conservative budget", "y")

    return m


def detect_gpu(m: dict) -> str:
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,driver_version",
             "--format=csv,noheader"],
            capture_output=True, text=True, timeout=20, shell=False)
        if r.returncode != 0 or not r.stdout.strip():
            raise RuntimeError
        name, vram, drv = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")]
        p(f"  GPU      {name}", "g")
        p(f"  VRAM     {vram}", "g")
        p(f"  driver   {drv}", "g")
        try:
            m["vram_mb"] = int("".join(ch for ch in vram if ch.isdigit()))
        except Exception:
            pass
        major = int(str(drv).split(".")[0])
        # CUDA 12.4 needs a 551+ Windows driver; CUDA 13.x needs 580+.
        # Choosing wrong costs a 370 MB download and a cryptic failure.
        if major >= 551:
            p("  -> CUDA 12.4 build", "i")
            return "cuda"
        p(f"  Driver {drv} predates 551, so CUDA 12.4 will not load.", "y")
        p("  -> CPU build. Update the driver and re-run for GPU speed.", "y")
        return "cpu"
    except Exception:
        p("  No NVIDIA GPU found (or nvidia-smi unavailable).", "y")
        p("  -> CPU build. Slower, but everything works.", "y")
        return "cpu"


# ---------------------------------------------------------------- fetch

def fetch(url: str, dest: Path, min_mb: float = 0.5) -> bool:
    if dest.exists() and dest.stat().st_size > min_mb * 1048576:
        p(f"  have    {dest.name}", "d")
        return True
    dest.parent.mkdir(parents=True, exist_ok=True)
    p(f"  get     {dest.name}", "d")
    r = subprocess.run(["curl.exe", "-L", "--fail", "--retry", "3",
                        "--continue-at", "-", "-o", str(dest), url], shell=False)
    if r.returncode != 0:
        p(f"  FAILED  {dest.name}", "r")
        dest.unlink(missing_ok=True)
        return False
    mb = dest.stat().st_size / 1048576
    if mb < min_mb:
        p(f"  Only {mb:.1f} MB - that was an error page, not a file.", "r")
        dest.unlink(missing_ok=True)
        return False
    p(f"  ok      {dest.name}  {mb:.1f} MB", "g")
    return True


def unzip_into(z: Path, target: Path, want: str) -> bool:
    target.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(z) as f:
            f.extractall(target)
    except Exception as e:
        p(f"  extract failed: {e}", "r")
        return False
    exe = target / want
    if not exe.is_file():
        # Some builds nest one folder deep. Flatten.
        found = next(target.rglob(want), None)
        if found:
            for item in found.parent.iterdir():
                dst = target / item.name
                if not dst.exists():
                    shutil.move(str(item), str(dst))
    return (target / want).is_file()


# ---------------------------------------------------------------- 3 llama

def install_llama(kind: str) -> bool:
    if (RUNTIME / "llama-server.exe").is_file():
        p("  llama-server.exe already present - skipping", "d")
        return True
    for asset in LLAMA_ASSETS[kind]:
        z = DL / asset
        if not fetch(f"{LLAMA_BASE}/{asset}", z, 5):
            return False
        if not unzip_into(z, RUNTIME, "llama-server.exe") and asset == LLAMA_ASSETS[kind][0]:
            p("  ERROR: llama-server.exe not found after extraction.", "r")
            return False
    if not (RUNTIME / "llama-server.exe").is_file():
        p("  ERROR: llama-server.exe missing.", "r")
        return False
    p(f"  ok      llama-server.exe + {len(list(RUNTIME.glob('*.dll')))} DLLs", "g")
    return True


# ---------------------------------------------------------------- 4 whisper

def install_whisper() -> bool:
    """
    Hearing, on the CPU on purpose.

    A 4 GB card already holds about 2 GB of language model. Putting the
    speech model on the GPU as well would contend for VRAM - the exact
    failure that can hang Windows. On a handful of CPU threads, base.en
    transcribes a spoken sentence in well under a second, which is all a
    turn needs.
    """
    if (WHISPER / "whisper-server.exe").is_file():
        p("  whisper-server.exe already present - skipping", "d")
        return True
    z = DL / WHISPER_ASSET
    if not fetch(f"{WHISPER_BASE}/{WHISPER_ASSET}", z, 1):
        p("  OPTIONAL: hearing could not be installed. The Hub still runs;", "y")
        p("  the mic button will say the speech model is unavailable.", "y")
        return False
    if not unzip_into(z, WHISPER, "whisper-server.exe"):
        p("  OPTIONAL: whisper-server.exe not found after extraction.", "y")
        return False
    p("  ok      whisper-server.exe (CPU, fully local)", "g")
    return True


# ------------------------------------------------------- 4b generators

def _fetch_set(items, dest_dir, label) -> list:
    """Download a pinned set into a folder. Returns what actually landed."""
    dest_dir.mkdir(parents=True, exist_ok=True)
    got = []
    for repo, fname, min_mb, role in items:
        leaf = fname.split("/")[-1]
        url = f"https://huggingface.co/{repo}/resolve/main/{fname}?download=true"
        if fetch(url, dest_dir / leaf, min_mb):
            target = dest_dir / leaf
            want = GEN_SHA256.get(leaf)
            if want and not verify_sha(target, want):
                try:
                    target.unlink()
                except Exception:
                    pass
                continue
            got.append(leaf)
        else:
            p(f"  WARNING: could not fetch {leaf} for {label}.", "y")
    return got


# The names each project might give its executable. A LIST, because these are
# third-party archives whose internal layout is not ours to pin, and the
# alternative is what happened with trellis: a 693 MB download that arrived
# perfectly, extracted perfectly, and was declared "did not install" because
# the file inside was not called exactly `trellis-cli.exe`. The binary was
# sitting on disk the whole time.
SD_NAMES = ("sd-cli", "sd", "stable-diffusion")
# CLI names first, then the server - and the server is the one that will
# actually be found, because it is the only executable in the release.
#
# Order matters and so does the distinction between asking and guessing.
# A NAMED match returns the server happily: it is a real program with a real
# interface and the application knows how to speak to it. The inspection
# fallback still refuses anything called *server*, because a GUESS that
# hands back a long-running service in place of a one-shot tool is how this
# whole class of bug started.
TRELLIS_NAMES = ("trellis-cli", "trellis2-cli", "trellis-cpp", "trellis2",
                 "trellis-server")


def _find_binary(folder: Path, names) -> Path | None:
    """
    The executable in this folder, by preferred name and then by inspection.

    Named candidates first. If none of them are there, look for what IS
    there: on Windows the runtime ships DLLs and one or two executables, so
    an .exe whose name relates to the folder is a far better guess than
    giving up - and it is reported by name, so the log says exactly what was
    found rather than implying nothing arrived.
    """
    if not folder.is_dir():
        return None
    try:
        files = [q for q in folder.rglob("*") if q.is_file()]
    except OSError:
        return None
    # IN THE ORDER GIVEN, not in the order the filesystem happens to list.
    #
    # This built one set of acceptable names and returned the first FILE that
    # matched any of them, so with both trellis-cli.exe and
    # trellis-server.exe on disk the winner was whichever rglob reached
    # first. The tuple is a preference list; honour it.
    by_name = {q.name.lower(): q for q in files}
    for n in names:
        for cand in (n.lower(), n.lower() + ".exe"):
            if cand in by_name:
                return by_name[cand]
    # Nothing matched by name. Any executable that shares a word with one of
    # the expected names, longest match first.
    # AND NEVER A SERVER.
    #
    # The stem of "trellis-cli" is "trellis", which also matches
    # trellis-server.exe - a long-running HTTP service that does not
    # understand a single command-line flag. This fallback picked it, the
    # installer called 3D ready and skipped the download, and every 3D
    # request for weeks fell back to a flat relief. A guess is allowed to be
    # wrong about the NAME; it is not allowed to hand back a program of the
    # wrong SHAPE.
    stems = {n.lower().split("-")[0] for n in names}
    cands = [q for q in files
             if q.suffix.lower() in (".exe", "")
             and q.stat().st_size > 100_000
             and any(s in q.name.lower() for s in stems)
             and "server" not in q.name.lower()
             and "daemon" not in q.name.lower()]
    if cands:
        return max(cands, key=lambda q: q.stat().st_size)
    return None


def _install_binary(folder: Path, base: str, assets, names,
                    label: str, cost: str) -> bool:
    """Download and extract a generator runtime, then find what it produced."""
    found = _find_binary(folder, names)
    if found:
        p(f"  {found.name} already present - skipping", "d")
        return True
    for asset in assets:
        z = DL / asset
        if not fetch(f"{base}/{asset}", z, 15):
            continue
        folder.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(z) as f:
                f.extractall(folder)
        except Exception as e:
            p(f"  extract failed for {asset}: {e}", "r")
            continue
        found = _find_binary(folder, names)
        if found:
            break
    if found:
        p(f"  ok      {label}  ->  {found.name}", "g")
        # Write down what was found, so forge.py and a person reading the
        # folder both know which file is the entry point.
        try:
            (folder / "BINARY.txt").write_text(found.name, encoding="utf-8")
        except Exception:
            pass
        return True

    # Say what IS in the folder. "did not install" with nothing else is the
    # least useful thing an installer can print about a 693 MB download that
    # clearly arrived.
    p(f"  WARNING: {label} did not install - {cost}.", "y")
    try:
        present = sorted(q.name for q in folder.rglob("*")
                         if q.is_file() and q.suffix.lower() == ".exe")[:8]
        if present:
            p(f"           the folder does contain: {', '.join(present)}", "d")
            p(f"           if one of those is the right program, rename it to "
              f"{names[0]}.exe", "d")
        elif folder.is_dir() and any(folder.iterdir()):
            p(f"           {folder.name}\\ has files but no .exe - the "
              f"download may be for another platform", "d")
    except Exception:
        pass
    return False


def install_generators(kind: str) -> dict:
    """
    Image, video and 3D generation - binaries and weights.

    Everything here is OPTIONAL to the application running. A failed download
    costs that one capability and nothing else, which is why every step warns
    rather than returning False: nobody should lose a working assistant
    because a 2 GB video model timed out.
    """
    out = {"image": False, "video": False, "model3d": False}
    GEN.mkdir(parents=True, exist_ok=True)

    # --- stable-diffusion.cpp: images AND video, one binary ---------------
    _install_binary(SD_DIR, SD_BASE, SD_ASSETS[kind], SD_NAMES,
                    "sd-cli (images and video)",
                    "image and video generation will be unavailable")

    # --- trellis.cpp: image to 3D -----------------------------------------
    _install_binary(TRELLIS_DIR, TRELLIS_BASE, TRELLIS_ASSETS[kind],
                    TRELLIS_NAMES, "trellis (image to 3D)",
                    "3D falls back to the built-in geometry builder, "
                    "which always works")

    # --- weights ----------------------------------------------------------
    imgs = _fetch_set(IMAGE_SET, GEN_MODELS, "image generation")
    vids = _fetch_set(VIDEO_SET, GEN_MODELS, "video generation")
    tris = _fetch_set(TRELLIS_SET, TRELLIS_MODELS, "3D generation")

    sd = _find_binary(SD_DIR, SD_NAMES)
    # ASK THE RUNTIME, DO NOT GUESS ALONGSIDE IT.
    #
    # AND THE SERVER COUNTS, because the server is what ships.
    #
    # The previous version of this asked for a CLI and warned when it found
    # only trellis-server.exe. It always finds only trellis-server.exe: the
    # 693 MB CUDA archive for v0.4.3 contains exactly one executable and it
    # is the server. Asking for a binary the release does not contain turned
    # a silent wrong-program bug into a loud missing-program bug and fixed
    # nothing.
    #
    # forge.trellis_backend() accepts either shape and is the single
    # definition both sides use.
    kind = ""
    try:
        import forge as _forge
        kind, tr = _forge.trellis_backend()
    except Exception:
        tr = _find_binary(TRELLIS_DIR, TRELLIS_NAMES)
    out["image"] = bool(sd and imgs)
    out["video"] = bool(sd and len(vids) >= 3)
    out["model3d"] = bool(tr and len(tris) >= 6)
    if tr is not None and kind == "server":
        p(f"  3D runs through {Path(tr).name} on port {_trellis_port()} - "
          f"started for one mesh and stopped again.", "d")
    return out


def _trellis_port() -> int:
    try:
        import core as _c
        return int(_c.TRELLIS_PORT)
    except Exception:
        return 8103


# ---------------------------------------------------------------- 5 models

def install_models(with_ears: bool) -> list:
    MODELS.mkdir(parents=True, exist_ok=True)
    got = []

    # Say what is coming and what is not, before any of it starts. Several
    # gigabytes arriving with no account of what they are, and a catalogue
    # entry that was deliberately skipped looking identical to one that was
    # forgotten, is how "why do I have this model" happens.
    total = sum(e["model_mb"] + e.get("projector_mb", 0)
                for e in MODEL_CATALOGUE if e["install"])
    p(f"  models: {total/1024:.1f} GB to fetch", "i")
    for e in MODEL_CATALOGUE:
        mark = "get " if e["install"] else "skip"
        size = (e["model_mb"] + e.get("projector_mb", 0)) / 1024
        p(f"    {mark}  {e['name']:<34} {size:>4.1f} GB  {e['why']}",
          "g" if e["install"] else "d")

    unpinned = [f for _, f, _, _ in MODEL_SET + PROJECTOR_SET
                if f not in ASSET_SHA256]
    if unpinned:
        p(f"  WARNING: no content hash recorded for {', '.join(unpinned)} - "
          f"they will be downloaded but not verified.", "y")

    for repo, fname, min_mb, role in MODEL_SET:
        url = f"https://huggingface.co/{repo}/resolve/main/{fname}?download=true"
        if fetch(url, MODELS / fname, min_mb):
            dest = MODELS / fname
            if fname in ASSET_SHA256 and not verify_sha(dest, ASSET_SHA256[fname]):
                try: dest.unlink()
                except Exception: pass
            else:
                got.append((fname, role))
        else:
            p(f"  ERROR: could not fetch the {role} model. Check {repo}.", "r")
    for repo, fname, min_mb, role in PROJECTOR_SET:
        url = f"https://huggingface.co/{repo}/resolve/main/{fname}?download=true"
        if fetch(url, MODELS / fname, min_mb):
            dest = MODELS / fname
            if fname in ASSET_SHA256 and not verify_sha(dest, ASSET_SHA256[fname]):
                try: dest.unlink()
                except Exception: pass
            else:
                got.append((fname, role))
        else:
            p(f"  WARNING: could not fetch the {role}. Vision may be unavailable until it is added.", "y")
    if with_ears:
        repo, fname, min_mb = WHISPER_MODEL
        url = f"https://huggingface.co/{repo}/resolve/main/{fname}?download=true"
        if fetch(url, MODELS / fname, min_mb):
            got.append((fname, "hearing"))
        else:
            p("  OPTIONAL: speech model unavailable; hearing will stay off.", "y")
    return got


# ---------------------------------------------------------------- 6 config

def _pick_main(ggufs: list) -> str:
    """
    The model a fresh install should start on.

    Size alone is the wrong ordering. The starter model is chosen because it
    can see, and a bigger text-only model that happens to be sitting in the
    same folder is not an upgrade for a first run - it is the difference
    between an application that opens an image and one that apologises for
    not being able to. So: the largest model that has a projector paired with
    it; only if none does, the largest model.
    """
    try:
        import core
        import vision
    except Exception:
        core = vision = None

    def size(n):
        try:
            return (MODELS / n).stat().st_size
        except OSError:
            return 0

    seeing = ([n for n in ggufs if vision.find_projector(MODELS / n)]
              if vision is not None else [])

    # THE PREFERRED MODEL WINS AMONG THOSE THAT CAN SEE.
    #
    # This checked PREFERRED_MODEL only after size, which was fine while the
    # preferred model was also the biggest one. It is not any more: the
    # starter is now Qwen3-VL-4B-Thinking at 2.33 GB, and a machine that
    # already has the old 3.19 GB Gemma sitting beside it would have had the
    # installer pick Gemma every time - silently keeping the model without a
    # thinking mode, on the grounds that it was larger.
    #
    # Bigger is not better. Bigger is bigger.
    if core is not None and core.PREFERRED_MODEL in (seeing or ggufs):
        return core.PREFERRED_MODEL
    if seeing:
        return max(seeing, key=size)
    if core is not None and core.PREFERRED_MODEL in ggufs:
        return core.PREFERRED_MODEL
    return max(ggufs, key=size)


def report_limits() -> None:
    """
    Say what this machine's limits actually are, out loud, at setup.

    THREE THINGS SCALE TO THE DEVICE AND NONE OF THEM IS WRITTEN DOWN:

        the context window   runtime.plan(), recomputed on every load
        the graphics card    runtime.plan(), likewise
        the memory store     store.ceiling_gb(), measured from the disk

    Nothing here decides anything - it reads what the running code would
    decide and prints it. A setup that printed its own separate opinion would
    be a second definition of the same thing, which is the fault shape that
    has cost this project more sessions than any other.

    It is printed because a limit nobody can see is indistinguishable from one
    that is not working. That is the whole lesson of ADR-142.
    """
    try:
        import core, store, runtime
    except Exception as e:
        p(f"  could not read this machine's limits: {e}", "y")
        return
    mach = store.machine()
    p(f"  disk     {mach['disk_free_gb']:.0f} GB free of "
      f"{mach['disk_total_gb']:.0f} GB", "g")
    p(f"  store    up to {store.ceiling_gb():.0f} GB for memories, pictures "
      f"and transcripts", "g")
    p(f"           ({store.os_reserve_gb():.0f} GB held back so Windows can "
      f"still page and update)", "d")
    p("           0 in Settings means 'this computer's limit' and is the "
      "default;", "d")
    p("           it is measured again on every machine this folder is "
      "copied to.", "d")
    cfg = core.load()
    model = cfg.get("model") or ""
    if model:
        try:
            rt, advisory = runtime.plan(model, dict(cfg.get("runtime") or {},
                                                    n_ctx="auto"))
            ngl = rt.get("n_gpu_layers")
            if isinstance(ngl, int):
                p(f"  card     {ngl} of this model's layers fit, so that is "
                  f"what will be sent", "g")
            else:
                p("  card     no card measurable here; llama.cpp keeps its "
                  "own default", "d")
            if advisory:
                p(f"           {advisory[:150]}", "d")
        except Exception:
            pass
    p("  window   auto - worked out from the model and this machine on every "
      "load,", "g")
    p("           never frozen here. Set a number in Settings to override.",
      "d")


def write_config(got: list, ears_ok: bool, m: dict) -> None:
    cfg_path = ROOT / "config.json"
    cfg = {}
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        except Exception:
            cfg = {}

    # A PROJECTOR IS NOT A MODEL.
    #
    # This globbed *.gguf raw and then took max()/min() by file size. A
    # multimodal projector is also a .gguf, so it sat in that list as if it
    # were selectable, and the two selectors picked wrongly in opposite
    # directions:
    #
    #   min() by size chose mmproj-gemma-4-E2B-it-BF16.gguf (0.94 GB) over
    #   the model it belongs to (3.19 GB), every single time;
    #
    #   max() by size chose the biggest file in the folder, which on a
    #   machine that already holds other GGUFs is some unrelated 11 GB model
    #   with no projector beside it - and the summary below then honestly
    #   reported no vision, because the model it had just selected genuinely
    #   has none. That is the "no vision module" report: not a missing
    #   projector, a mis-selected model.
    #
    # core.is_projector() already existed and core.models() already used it.
    # The installer was the one place that did not. It does now.
    import core
    ggufs = sorted(f.name for f in MODELS.glob("*.gguf")
                   if f.is_file() and not core.is_projector(f.name))
    if not ggufs:
        p("  ERROR: no language models present - config left alone.", "r")
        return

    main = next((n for n, r in got if r == "main"), None)
    if not main or main not in ggufs:
        main = _pick_main(ggufs)

    cfg["model"] = main
    # No curator_model key any more - core._prune() strips it from any
    # config written by an earlier build.
    cfg.setdefault("assistant_name", "Nova")

    rt = cfg.setdefault("runtime", {})
    rt["threads"] = m["threads"]
    rt["ram_budget_mb"] = 0          # measured live, never frozen here
    rt.setdefault("fit_policy", "adapt")
    rt.setdefault("n_gpu_layers", "auto")
    rt.setdefault("kv_type", "f16")
    rt.setdefault("n_ubatch", 512)
    rt.setdefault("n_batch", 2048)

    # THE WINDOW IS NOT DECIDED HERE ANY MORE.
    #
    # This used to freeze n_ctx at 4096 or 8192 from the VRAM reading taken
    # during setup - and it OVERWROTE a number the user had chosen, every
    # re-install, because the small-card branch assigned instead of
    # defaulting. A measurement taken once, on one busy afternoon, is not a
    # property of the machine; it is a property of that afternoon.
    #
    # runtime.plan() now budgets the card and the host together on every
    # single load, so "auto" is not a deferral - it is the answer, recomputed
    # whenever the machine changes underneath it. A number typed in Settings
    # is still honoured, and still survives an install.
    rt.setdefault("n_ctx", "auto")

    # THE MEMORY STORE FOLLOWS THE MACHINE, for the same reason.
    # 0 = whatever this computer can give, measured from the disk every time.
    # Copy the folder to a bigger drive and the ceiling rises by itself.
    cfg.setdefault("storage", {}).setdefault("limit_gb", 0)

    hear = cfg.setdefault("hearing", {})
    speech = next((n for n, r in got if r == "hearing"), None)
    if speech:
        hear["model"] = speech
    hear["threads"] = max(2, min(6, m["threads"]))
    hear["enabled"] = False   # opt in from the interface

    cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

    p(f"  thinking {main}", "g")
    p("  memory   external active frontier + Tree of Life; maintained locally", "g")
    p(f"  threads  {rt['threads']}   n_ctx {rt['n_ctx']}   "
      f"fit policy {rt['fit_policy']}", "g")
    if m["avail_mb"]:
        p(f"  {m['avail_mb']/1024:.1f} GB free right now - measured again at "
          f"every model load, never frozen", "d")
    if speech and ears_ok:
        p(f"  hearing  {speech}  (CPU, local)", "g")
    else:
        p("  hearing  OPTIONAL: not installed", "y")
    # SIGHT, REPORTED HONESTLY.
    #
    # This block referenced `core` without importing it, so it raised
    # NameError on every run, was swallowed by the except, and printed a
    # vague line that read as "no vision module" whether or not a projector
    # was sitting correctly paired on disk. That is the same class of bug
    # verify.py had already been fixed for - look at the disk, not at a
    # config field - and this copy of the check never got the fix.
    #
    # There are three distinct outcomes and the user is told which one:
    #   paired      -> the selected model can see, and with what
    #   unpaired    -> a projector exists but does not belong to this model
    #   none        -> no projector at all, plus the command that gets one
    try:
        import core as _core
        import vision as _vis
        _sel = str(cfg.get("model") or "")
        _pair = _vis.find_projector(MODELS / _sel) if _sel else None
        _projs = [q for q in MODELS.glob("*.gguf")
                  if q.is_file() and _core.is_projector(q.name)]
        if _pair:
            p(f"  vision   ON  - {_sel} sees through {_pair.name}", "g")
        elif _projs:
            p(f"  vision   OFF - {len(_projs)} projector(s) on disk, none "
              f"belongs to {_sel or 'the selected model'}", "y")
            p("           A projector is architecture-specific. Select a "
              "model that has one,", "d")
            p(f"           or rename the right file to "
              f"{(_sel[:-5] if _sel.endswith('.gguf') else 'model')}"
              f".mmproj.gguf", "d")
        else:
            p("  vision   OFF - no projector in llm\\models", "y")
            p("           python get_model.py vision      lists what is "
              "available", "d")
    except Exception as e:
        # An actual fault here is a fault, not a footnote.
        p(f"  ERROR: could not determine vision support: "
          f"{type(e).__name__}: {str(e)[:80]}", "r")


# ---------------------------------------------------------------- 7 verify

def verify() -> bool:
    """
    Say what is missing, in the words the project uses everywhere else:
    ERROR for a required part, OPTIONAL for one that is not, EXCLUDED for
    one left out on purpose. Never a silent skip.
    """
    ok = True
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import core
    for mod in ("core", "events", "grove", "classify", "memory", "knowledge",
                "research", "policy", "tools", "runtime", "server"):
        try:
            __import__(mod)
            p(f"  {mod}.py imports cleanly", "g")
        except Exception as e:
            p(f"  ERROR: {mod}.py FAILED: {e}", "r")
            ok = False

    if not (RUNTIME / "llama-server.exe").is_file():
        p("  ERROR: llama-server.exe missing", "r")
        ok = False
    if not list(MODELS.glob("*.gguf")):
        p("  ERROR: no language model present", "r")
        ok = False
    main_cfg = {}
    try:
        main_cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8")) if (ROOT / "config.json").is_file() else {}
    except Exception:
        main_cfg = {}
    # Two hand-written checks used to live here, both comparing literal
    # filenames: `selected == "gemma-4-E2B-it-Q4_K_M.gguf"` and
    # `main_name.startswith("gemma-4-")`. They tested the starter download
    # and nothing else, so they passed silently for every other model and
    # went stale the moment the starter changed. One check, derived from the
    # same pairing function the running application uses.
    selected = str(main_cfg.get("model") or "")
    if selected:
        try:
            import vision as _v
            if _v.find_projector(MODELS / selected):
                p(f"  vision paired for {selected}", "g")
            elif selected == core.PREFERRED_MODEL:
                # The starter model is chosen for its sight. Shipping it
                # blind is an install that did not finish.
                p(f"  ERROR: {selected} is the multimodal starter model but "
                  f"its projector is missing", "r")
                ok = False
            else:
                p(f"  OPTIONAL: {selected} has no projector - text only", "y")
        except Exception as e:
            p(f"  ERROR: vision pairing check failed: {e}", "r")
            ok = False
    if (WHISPER / "whisper-server.exe").is_file() and list(MODELS.glob("ggml-*.bin")):
        p("  hearing ready", "g")
    else:
        p("  OPTIONAL: hearing not available", "y")

    try:
        import verify as v
        ok = v.run(quiet=True) and ok
    except Exception as e:
        p(f"  ERROR: subsystem verification failed to run: {e}", "r")
        ok = False
    return ok


# ---------------------------------------------------------------- main

def generators_only() -> int:
    """
    `python install.py --generators` - retry just the generation install.

    The generators are ~19 GB. A download that dies two thirds of the way in
    should not mean redoing llama.cpp, the model and whisper as well.
    """
    m = measure()
    kind = detect_gpu(m)
    head(1, 1, "Installing on-device generation  -  images, video, 3D")
    got = install_generators(kind)
    print()
    for key, name in (("image", "images"), ("video", "video"),
                      ("model3d", "3D (TRELLIS)")):
        p(f"  {name}: {'ready' if got.get(key) else 'NOT installed'}",
          "g" if got.get(key) else "y")
    return 0 if any(got.values()) else 1


def main() -> int:
    try:
        os.system("")   # enable ANSI colour in cmd.exe
    except Exception:
        pass

    print()
    p("=" * 58, "i")
    # Spaced out, which is why two rename passes looking for "HUB-ZERO" walked
    # straight past it and the installer greeted the user by the old name.
    # verify.py now checks for letter-spaced branding as well as plain.
    p("   T H E   H U B   -   local AI, assembled in one pass", "b")
    p("   Everything installs inside this folder. Nothing else is touched.", "d")
    p("=" * 58, "i")

    TOTAL = 8
    head(1, TOTAL, "Checking prerequisites")
    if not check_tools():
        p("\nFix the red items above, then run INSTALL.bat again.", "r")
        return 1

    head(2, TOTAL, "Measuring this machine")
    m = measure()
    kind = detect_gpu(m)

    head(3, TOTAL, f"Installing llama.cpp {LLAMA_BUILD} ({kind})  -  thinking")
    if not install_llama(kind):
        p("\nRuntime install failed. Check your internet connection.", "r")
        return 1

    head(4, TOTAL, f"Installing whisper.cpp {WHISPER_TAG}  -  hearing")
    ears_ok = install_whisper()

    head(5, TOTAL, "Downloading starter model, vision projector, and local speech assets")
    got = install_models(ears_ok)

    head(6, TOTAL, "Installing on-device generation  -  images, video, 3D")
    p("  This is the large part of the install: roughly 19 GB of runtimes", "d")
    p("  and weights. Everything after it works with the network unplugged.", "d")
    gen_ok = install_generators(kind)

    head(7, TOTAL, "Writing configuration from what was measured")
    write_config(got, ears_ok, m)
    report_limits()
    for d in ("data/tree/yesod", "data/knowledge", "data/ash", "data/events",
              "data/sessions/archive", "data/logs"):
        (ROOT / d).mkdir(parents=True, exist_ok=True)
    p("  data folders ready", "g")

    head(8, TOTAL, "Verifying every subsystem")
    ok = verify()

    # Say plainly which generators arrived. A capability that half-installed
    # is worse than one that did not, because nobody finds out until they
    # ask for it.
    label = {"image": "images", "video": "video", "model3d": "3D (TRELLIS)"}
    for key, name in label.items():
        if gen_ok.get(key):
            p(f"  generation: {name} ready", "g")
        else:
            p(f"  generation: {name} NOT installed - "
              f"`python install.py --generators` retries just this part", "y")
    p("  generation: 3D (built-in geometry) always available", "g")

    if DL.exists():
        try:
            shutil.rmtree(DL)
            p("  cleared download cache", "d")
        except Exception:
            pass

    print()
    if ok:
        p("=" * 58, "g")
        p("   Ready. Double-click HUB.bat to start.", "g")
        p("   Your browser opens at 127.0.0.1:8440", "d")
        p("", "d")
        p("   From here on, only web search touches the internet.", "d")
        p("   Everything else works with the network unplugged.", "d")
        p("", "d")
        p("   Already have models elsewhere on this machine?", "d")
        p('   python get_model.py --import "C:\\path\\to\\model.gguf"', "d")
        p("=" * 58, "g")
    else:
        p("Setup finished with problems - see the red lines above.", "y")
    return 0 if ok else 1


if __name__ == "__main__":
    if "--generators" in sys.argv:
        sys.path.insert(0, str(ROOT))
        raise SystemExit(generators_only())
    raise SystemExit(main())
