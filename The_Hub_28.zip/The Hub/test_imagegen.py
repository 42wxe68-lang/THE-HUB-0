from pathlib import Path
from unittest.mock import patch
import tempfile
import json
import sys
sys.path.insert(0, str(Path(__file__).parent))

import imagegen
import playground
import tools, policy

old_root = playground.ROOT

assert 'generate_image' in tools.REGISTRY
assert 'generate_image' in tools.ALWAYS
assert 'generate_image' in policy.TIERS
assert 'generate_image' in policy.ARGS
try:
    with tempfile.TemporaryDirectory() as td:
        playground.ROOT = Path(td)
        with patch.object(imagegen, 'discover', return_value=[{
            'provider': 'automatic1111', 'host': '127.0.0.1', 'port': 7860, 'model': 'test-checkpoint'
        }]), patch.object(imagegen, '_a1111', return_value=(b'PNGDATA', {
            'provider': 'automatic1111', 'prompt': 'a red cube', 'seed': 7
        })), patch.object(imagegen.runtime, 'state', return_value={'status':'ready','model':'gemma-test'}), patch.object(imagegen.runtime, 'stop') as stop, patch.object(imagegen.runtime, 'start') as start:
            r = imagegen.generate(prompt='a red cube', filename='cube.png', seed=7)
            assert r['ok'] and r['name'] == 'cube.png'
            assert (Path(td) / 'cube.png').read_bytes() == b'PNGDATA'
            manifest = json.loads((Path(td) / 'cube.generation.json').read_text())
            assert manifest['prompt'] == 'a red cube'
            stop.assert_called_once()
            start.assert_called_once()
    print('ok   image generation writes to Playground and restores the selected model')

    with patch.object(imagegen, 'discover', return_value=[]):
        try:
            imagegen.generate(prompt='anything')
        except RuntimeError as e:
            assert 'no supported local image generator' in str(e)
        else:
            raise AssertionError('missing provider should fail clearly')
    print('ok   missing generator is reported without fabricating capability')
finally:
    playground.ROOT = old_root

print('2 passed, 0 failed')
