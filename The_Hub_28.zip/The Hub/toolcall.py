"""
toolcall.py - recover a tool call the chat template failed to parse.

WHY THIS EXISTS

The Hub relies on llama-server's own `--jinja` tool parsing to turn a model's
output into `message.tool_calls`. When that parsing works, this module is
never used.

When it does not, the call text lands in `message.content` instead, and the
answer phase streams it straight to the user. Observed in a real session:

    <|tool_call>call:open_file{path:<|"|>Chat/chat-mti6v7ff/IMG_1110.JPG<|"|>}<tool_call|>

That is a tool call with mangled special-token markers - `<|"|>` where a
quote belongs, an unbalanced closing tag - produced by a GGUF whose template
does not round-trip its own control tokens. The model did the right thing;
the plumbing dropped it and the user got token soup in the middle of a
sentence.

WHAT THIS IS AND IS NOT

It is a last-resort reader of text that has already failed the normal path.
It is NOT a second source of authority. Every call it recovers goes through
policy.Gate exactly like a properly parsed one, so a recovered call has no
more power than a normal one.

The safety rule that makes this acceptable: a recovered call is only
returned when its name is one of the tools ALREADY OFFERED on this turn.
Text that merely looks like a function call - a code sample, a quoted log
line, a user pasting an example - names something that is not in that list
and is left completely alone.
"""
from __future__ import annotations

import json
import os
import re
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Control-token debris. Templates leak these in several shapes; all of them
# mean "a quote was here" or "a tag was here".
_JUNK_QUOTE = re.compile(r"<\|\s*[\"']\s*\|>")
_TAG = re.compile(r"<\|?/?\s*tool_calls?\s*\|?>", re.I)
_CHANNEL = re.compile(r"<\|(?:start|end|channel|message|constrain|return)\|>",
                      re.I)


def _strip_markers(text: str) -> str:
    text = _JUNK_QUOTE.sub('"', text or "")
    text = _TAG.sub(" ", text)
    text = _CHANNEL.sub(" ", text)
    return text


def _coerce_args(blob: str) -> dict:
    """Turn a loose key/value body into a dict, JSON first."""
    blob = (blob or "").strip()
    if not blob:
        return {}
    try:
        v = json.loads(blob)
        return v if isinstance(v, dict) else {}
    except Exception:
        pass
    # {path:"x", size:3} and {path: x} - unquoted keys, single quotes, or
    # nothing quoted at all. Values are taken as strings unless numeric.
    out = {}
    for m in re.finditer(
            r"""["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*[:=]\s*"""
            r"""(?:"([^"]*)"|'([^']*)'|([^,}\n]+))""", blob):
        key = m.group(1)
        val = next((g for g in m.groups()[1:] if g is not None), "")
        val = val.strip().strip('"').strip("'")
        if re.fullmatch(r"-?\d+", val):
            out[key] = int(val)
        elif re.fullmatch(r"-?\d*\.\d+", val):
            out[key] = float(val)
        elif val.lower() in ("true", "false"):
            out[key] = val.lower() == "true"
        else:
            out[key] = val
    return out


def recover(content: str, offered: set) -> tuple:
    """
    (name, args, cleaned_text) for a tool call hiding in `content`.

    `offered` is the set of tool names available on this turn. A name outside
    it is not a tool call, whatever the text looks like.
    Returns (None, None, content) when there is nothing to recover.

    TWO CONDITIONS, BOTH REQUIRED. The name must be a tool that is actually
    offered, AND the text must look like a failed call rather than a
    sentence that mentions one - either it carries control-token debris, or
    the call is essentially the whole message. Without the second condition
    "here is how you would call open_file({...})" becomes a file read, which
    is a worse bug than the one being fixed.
    """
    if not content or not offered:
        return None, None, content
    leaked = looks_like_leaked_markup(content)
    text = _strip_markers(content)
    body = text.strip()
    if not body:
        return None, None, content

    def _accept(span: str) -> bool:
        # Debris means the template failed and this is not prose.
        # Otherwise the call has to BE the message, not sit inside it.
        return leaked or len(span.strip()) >= 0.8 * len(body)

    # 1. the OpenAI-ish object: {"name": "x", "arguments": {...}}
    for m in re.finditer(r"\{[^{}]*\"name\"\s*:\s*\"([A-Za-z0-9_]+)\"[^{}]*"
                         r"(?:\"(?:arguments|parameters)\"\s*:\s*)?"
                         r"(\{.*?\})?[^{}]*\}", text, re.S):
        if m.group(1) in offered and _accept(m.group(0)):
            return m.group(1), _coerce_args(m.group(2) or "{}"), ""

    # 2. call:name{...} / name({...}) / name{...}
    for m in re.finditer(r"(?:call\s*[:=]\s*)?\b([A-Za-z_][A-Za-z0-9_]*)\s*"
                         r"(?:\(\s*)?(\{.*?\})\s*\)?", text, re.S):
        if m.group(1) in offered and _accept(m.group(0)):
            return m.group(1), _coerce_args(m.group(2)), ""

    # 2b. KEYWORD ARGUMENTS, NO BRACES ANYWHERE.
    #
    #     Calling tool: generate_video(prompt="A short video based on the
    #     provided image.", input_image="cosmic forge.png")
    #
    # Written exactly like that, twice in a row, as ordinary prose - because
    # every pattern above needs a `{`, and there is not one in it. The
    # promise check fired ("said it would - asking it to actually do it"),
    # the model was asked to actually do it, and it wrote the same sentence
    # again. Nothing ran either time.
    #
    # A small model that has learned Python signatures will write this form,
    # and it is a call in every respect except punctuation. The same two
    # conditions still apply: the name must be a tool that is offered, and
    # the call must BE the message rather than be mentioned inside it.
    for m in re.finditer(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(([^()]*)\)", text):
        inner = m.group(2)
        if m.group(1) not in offered:
            continue
        if inner.strip() and "=" not in inner and ":" not in inner:
            continue          # name(something) with no arguments named
        if _accept(m.group(0)):
            return m.group(1), _coerce_args(inner), ""

    # 3. a bare name on its own with nothing else of substance around it
    if body in offered:
        return body, {}, ""

    return None, None, content


def looks_like_leaked_markup(content: str) -> bool:
    """
    True when the text carries control-token debris the user must not see.

    Used when no call could be recovered: the text is still not an answer,
    and showing it is worse than saying nothing.
    """
    if not content:
        return False
    return bool(_JUNK_QUOTE.search(content) or _TAG.search(content)
                or _CHANNEL.search(content))


# A short fragment repeated this many times in a row is not writing.
RUNAWAY_REPEATS = 8
RUNAWAY_TAIL = 900


def runaway(content: str) -> str:
    """
    "" if this is text, otherwise the fragment it is stuck on.

    THE HUNDRED CLOSING TAGS.

    A real session streamed this to the user's screen:

        <tool_call> <function=pass_off> <parameter=topic> body_nudity_focus
        </parameter> </parameter> </parameter> </parameter> ...

    and kept going until they pressed stop. Two separate failures met: a
    malformed tool call landed in the answer channel, and then the model got
    stuck emitting one closing tag forever.

    The existing scrub runs AFTER the answer completes, so it cleaned the
    stored copy of something the user had already watched arrive token by
    token. There is no un-sending a token; the only fix is to stop early.

    Looks only at the tail, so it is cheap enough to run while streaming. A
    fragment under 40 characters repeated eight times back to back is a
    degenerate loop in every case that matters - real prose does not do it,
    and a list that did would still be worth cutting.
    """
    tail = (content or "")[-RUNAWAY_TAIL:]
    squashed = re.sub(r"\s+", " ", tail).strip()
    if len(squashed) < 40:
        return ""
    for size in range(2, 41):
        frag = squashed[-size:]
        if not frag.strip():
            continue
        run = 1
        pos = len(squashed) - size
        while pos - size >= 0 and squashed[pos - size:pos] == frag:
            run += 1
            pos -= size
            if run >= RUNAWAY_REPEATS:
                return frag.strip()
    return ""


# Saying you are about to do a thing, in every phrasing a small model
# reaches for. The verb tense is the whole signal: these are all statements
# about a future action, and a future action is not an action.
_PROMISE = re.compile(
    r"\b("
    r"i (?:will|'ll|am going to|shall|am about to)\b"
    r"|i am (?:now )?(?:attempting|generating|creating|building|making|"
    r"rendering|searching|starting|running|working on)\b"
    r"|i'?m (?:now )?(?:attempting|generating|creating|building|making|"
    r"rendering|searching|starting|running)\b"
    r"|(?:attempting|generating|creating|building|starting) (?:the|a|now)\b"
    r"|let me (?:generate|create|build|make|render|search|try|run|look)\b"
    r"|please wait while\b"
    r"|(?:generation|process) (?:is )?(?:now )?(?:running|starting|underway)\b"
    r")", re.I)

# What the promise is about. Only capabilities that need a tool - promising
# to explain or summarise is just writing, and writing is what an answer is.
# ORDER MATTERS AND SO DOES WHOSE WORDS THESE ARE READ FROM.
#
# Most specific first. "a 3D model of the image" is a 3D request that
# happens to mention an image, and with image tested first it was read as a
# picture request - the system then ORDERED generate_image for it.
_PROMISED_TOOL = (
    ("generate_3d",    r"\b(3d|mesh|stl|glb|statue|figurine|sculpt|"
                       r"3-?d model|three.dimensional)\b"),
    ("generate_video", r"\b(video|clip|animation|footage)\b"),
    ("generate_image", r"\b(image|picture|photo|render|artwork|illustration)\b"),
    ("web_search",     r"\b(search|look up|google|find online|on the web)\b"),
    ("open_file",      r"\b(open|read|look at) (?:the )?(?:file|image|document)\b"),
    ("search_memory",  r"\b(check|search) (?:my |the )?(memory|memories|notes)\b"),
)

# "that was a video attempt, NOT a 3D model" names video while saying video
# is the wrong thing. A word inside a negation is not a request for it.
_NEGATED = re.compile(
    r"(?i)\b(?:not|isn'?t|wasn'?t|instead of|rather than|no longer|"
    # A COMMA ENDS THE NEGATION. "no more video, do the 3D one" negates
    # video and asks for 3D; without the comma in this class the negation
    # reached across the clause and suppressed both.
    r"no more|stop|don'?t|never)\b[^.,;!?]{0,40}$")


# "That was a video generation attempt, NOT a 3D model."
#
# A correction names BOTH things: what happened, and what was wanted. The
# wanted one is the one after "not", and reading left to right gets it
# exactly backwards - which is how a correction became an instruction to do
# the same thing again.
# Only the form that describes WHAT HAPPENED. "That was a video, not a 3D
# model" means do the 3D one. "I wanted a picture, not a video" is the
# opposite shape - the first thing named is the wanted one - and a rule that
# reads both the same way gets one of them backwards every time.
_CORRECTION = re.compile(
    r"(?i)\b(?:that|this|it)\s+(?:was|is|were)\b[^,.;!?]{0,60}?,?\s*"
    r"\bnot\s+(?:a|an|the)?\s*([^.,;!?]{2,40})")


def _names_tool(text: str, have: set) -> str:
    """
    Which tool this sentence asks for.

    Corrections first, because they are the sentences that matter most and
    the ones a left-to-right reading gets wrong.
    """
    text = text or ""
    for m in _CORRECTION.finditer(text):
        wanted = _plain(m.group(1), have)
        if wanted:
            return wanted
    for name, subject in _PROMISED_TOOL:
        if name not in have:
            continue
        for m in re.finditer(subject, text, re.I):
            if _NEGATED.search(text[:m.start()]):
                continue          # named only to say it is NOT that
            return name
    return ""


def _plain(phrase: str, have: set) -> str:
    """The tool a bare phrase names, with no negation handling."""
    for name, subject in _PROMISED_TOOL:
        if name in have and re.search(subject, phrase or "", re.I):
            return name
    return ""


def promised_action(content: str, offered, asked_for: str = "") -> str:
    """
    The tool this reply SAYS it is about to use, if it never used one.

    THE GAP BETWEEN SAYING AND DOING.

        "I am attempting the generation now."
        "I will try again. I have faith in the process of iteration."
        "I am rebuilding the request now, focusing entirely on creating a
         realistic, dynamic 3D model of Goku and Frieza fighting."

    Three replies, no file. To every layer below the model these are ordinary
    answers - the tool phase saw no tool_calls, shrugged, and shipped the
    text. Nothing anywhere checked whether a reply that PROMISES an action
    contains one, and stating the intention costs a small model far fewer
    tokens than formatting a correct call, so it is the cheaper path and it
    gets taken.

    It reads as fear and it is not. It is a missing check.

    Returns the tool name when the text promises an action that needs one and
    that tool is actually offered this turn; "" otherwise. Promising to
    explain, summarise or answer returns "" - that is just writing.
    """
    text = " ".join((content or "").split())
    if not text or not _PROMISE.search(text):
        return ""
    have = set(offered or ())

    # ═══════════════════════════════════════════════════════════════════
    #  WHOSE SENTENCE DECIDES WHAT SHE IS ABOUT TO DO
    #
    # This read the tool out of NOVA'S OWN REPLY, and her reply is about
    # whatever she was last doing. That turned a correction into a loop:
    #
    #   user:  "now try a 3D model."
    #   user:  "you choose for all features like this on this go around."
    #   Nova:  "I will build a video using any PNG file I can access."
    #   THE SYSTEM: "STOP. ... The tool is generate_video. Call it NOW."
    #   -> she calls generate_video
    #
    #   user:  "That was a video generation attempt, not a 3D model."
    #   Nova:  "...that was a video generation attempt..."
    #   THE SYSTEM: "The tool is generate_video."   <- the word she was
    #   -> she calls generate_video AGAIN               NEGATING
    #
    # Three times, while the user corrected her each time. The model was
    # obeying; the correction machinery was pointing at the last thing
    # instead of the asked thing, and every round reinforced it.
    #
    # THE REPLY ESTABLISHES *THAT* SHE PROMISED. THE USER'S MESSAGE
    # ESTABLISHES *WHAT*. When they disagree, the user wins - always, and
    # without needing to be repeated.
    # `asked_for` may be one message or the recent user turns, NEWEST
    # FIRST. Walking back matters as much as reading the latest: "Choose
    # one to test with" names nothing, and the standing subject is whatever
    # the user last named - which was the 3D model, two turns earlier.
    # Falling back to her reply at that point is what re-selected video.
    recent = ([asked_for] if isinstance(asked_for, str)
              else list(asked_for or []))
    for said in recent:
        wanted = _names_tool(said, have)
        if wanted:
            return wanted
    named = _names_tool(text, have)
    if named:
        return named
    # "I am attempting the generation now" names no subject at all, and it
    # is the exact sentence that started this. A bare promise to generate,
    # run or build something is still a promise of an action; the caller
    # knows what was asked for even when this text does not.
    if re.search(r"\b(generation|generate|generating|the build|"
                 r"the process|the attempt|it now)\b", text, re.I):
        return "?"
    return ""


def scrub(content: str) -> str:
    """Remove control-token debris from text that will be shown to a person."""
    text = _strip_markers(content or "")
    return re.sub(r"[ \t]{2,}", " ", text).strip()
