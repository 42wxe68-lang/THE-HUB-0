"""
classify.py - where a memory goes. Decided in Python, never by the model.

THE PROBLEM THIS SOLVES
-----------------------
Cairn asked its 350M curator to emit a JSON object keyed by sephira:

    {"keter":[...], "chesed":[...], "gevurah":[...], ...}

That is asking a 350-million-parameter model to understand Kabbalah, in
JSON, reliably, on a CPU. It does not. The observable failure was that
everything drifted into keter, because keter came first in the schema and a
small model under structural load takes the first branch it recognises. A
tree whose crown holds "coconuts are tropical fruits" is not a memory
system, it is a bucket with ten labels on it.

So the model's job shrank to the thing it is actually good at: reading a
conversation and saying what was said. This module decides where each
statement belongs, deterministically, with rules that can be read, tested
and argued with.

    curator model  ->  "a flat list of things the user said"
                          |
                          v
                    classify.place()          <- this file
                          |
                          v
                    sephira + confidence + why

WHAT IT RETURNS, AND WHY IT IS NOT A STRING
-------------------------------------------
A Placement carries a distribution, not a winner. "I'm building The Hub
this week" is genuinely both a current focus and a goal, and collapsing that
to one label throws away the thing that made it ambiguous. The distribution
is kept so that a placement can later be reviewed - and so the classifier
can be told it was wrong in a way that is measurable rather than anecdotal.

UNSORTED IS A LEGITIMATE ANSWER
-------------------------------
If nothing matches, place() says so instead of guessing. A memory parked as
unsorted can be looked at later. A memory confidently filed in the wrong
sephira is invisible forever, because nobody goes looking in the crown for
a fact about a graphics card.

SCOPE COMES FIRST
-----------------
"I am a nurse" and "a nurse is a licensed clinician" share almost every
word and belong in completely different places. Scope - is this about the
user, about the world, about the machine, about someone else - is decided
before the sephira, because it changes what the same sentence means.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------- scopes

SELF = "self"        # about the person using The Hub
OTHER = "other"      # about a specific other person
WORLD = "world"      # about the world, independent of anyone here
SYSTEM = "system"    # about Nova, The Hub, this machine's own setup

FIRST_PERSON = re.compile(r"\b(i|i'?m|i'?ve|i'?ll|i'?d|me|my|mine|myself|we|our|us)\b", re.I)
USER_REF = re.compile(r"\b(the user|they said|user's|zero'?s?)\b", re.I)
SYSTEM_REF = re.compile(
    r"\b(nova|the hub|hub|this (app|application|system|machine|laptop)|"
    r"the (model|curator|runtime|server|installer)|llama\.cpp|whisper)\b", re.I)
OTHER_PERSON = re.compile(
    r"\b(his|her|their|he|she|they)\b(?!\s+(said|are|were)\b)|"
    r"\b(my|their)\s+(wife|husband|partner|son|daughter|mother|father|mum|mom|"
    r"dad|brother|sister|friend|colleague|boss|manager|client|teacher)\b", re.I)


# An instruction has no subject. "Never send anything to the cloud" contains
# no "I", so a pronoun-based scope test reads it as a statement about the
# world - and a statement about the world cannot be a boundary the user set,
# so the rule that mattered most was the one most reliably thrown away.
IMPERATIVE = re.compile(
    r"^\s*(never|always|don'?t|do not|avoid|only ever|make sure|ensure|"
    r"keep|use|prefer|stick to|remember to|please)\b", re.I)

MODAL_CONSTRAINT = re.compile(
    r"\b(must|must not|has to|have to|cannot|can'?t|should never|"
    r"is not allowed|is forbidden|required to|may only|only ever)\b", re.I)

REQUIREMENT = re.compile(
    r"\b(hard )?(requirement|constraint|rule|policy|limit)\b\s*(is|:)|"
    r"\b(budget|deadline|capped at|no more than|at most|limited to)\b", re.I)

# Descriptive "never" is not prescriptive "never". "Whisper never uses the
# GPU" reports behaviour; "never put whisper on the GPU" sets a rule. The
# difference is whether a subject precedes the verb.
DESCRIPTIVE_NEVER = re.compile(r"\b\w+\s+(never|always)\s+\w+s\b", re.I)


def is_directive(text: str) -> bool:
    t = (text or "").strip()
    if DESCRIPTIVE_NEVER.search(t) and not IMPERATIVE.match(t):
        return False
    return bool(IMPERATIVE.match(t) or MODAL_CONSTRAINT.search(t)
                or REQUIREMENT.search(t))


def scope(text: str) -> str:
    """
    Who is this about? Decided before anything else.

    Order matters. A sentence can mention the machine and the person; a
    statement about a named other person that also says "my" is about that
    person, not about the speaker.
    """
    t = (text or "").strip()
    if OTHER_PERSON.search(t):
        return OTHER
    if SYSTEM_REF.search(t) and not FIRST_PERSON.search(t):
        return SYSTEM
    if FIRST_PERSON.search(t) or USER_REF.search(t):
        return SELF
    if SYSTEM_REF.search(t):
        return SYSTEM
    return WORLD


# ---------------------------------------------------------------- signals
#
# Each rule is (weight, pattern). Weights are small integers on purpose:
# they are a ranking, not a probability, and pretending otherwise would
# invite tuning them to three decimal places against forty examples.

# Gaps found in use. "I go by Zero and I build local AI systems" matched no
# rule at all and fell through to Hod - a name landing in "plain fact". Nor
# did "my daughter Ada is learning piano" reach Netzach. The 68-case suite
# passed throughout, because neither shape was in it.
#
# Weights are deliberately low for the kinship and time rules. Raising them
# flipped three cases the suite had already settled: "My sister lives in
# Seattle" is a plain FACT that happens to mention a person, and the suite
# was right about that.
EXTRA_RULES: dict[str, list] = {
    "keter": [
        (5, re.compile(r"\b(i go by|call me|my name'?s?|my name is|"
                       r"people call me|you can call me)\b", re.I)),
        (4, re.compile(r"\bi(?:'m| am)? (?:build|make|design|develop)"
                       r"(?:ing)?\b.{0,40}\b(system|app|tool|model|assistant|"
                       r"software|hardware|robot)", re.I)),
        (3, re.compile(r"\bi (?:work|specialis|specializ)(?:e|ed|ing)?\s+"
                       r"(?:on|with|in)\b", re.I)),
    ],
    "netzach": [
        (1, re.compile(r"\bmy (wife|husband|partner|son|daughter|kid|child|"
                       r"children|sister|brother|mother|father|mum|mom|dad|"
                       r"parents|nephew|niece|cousin|friend|colleague|"
                       r"co-?worker|boss|neighbou?r|teacher|student)\b", re.I)),
    ],
    "binah": [
        (2, re.compile(r"\b(yesterday|last (week|month|year)|since|until|"
                       r"after|before|next (week|month|year))\b", re.I)),
    ],
}

RULES: dict[str, list] = {

    # WHO THEY ARE. Deliberately narrow. Everything that is merely true
    # about the person, rather than constitutive of them, belongs in hod.
    "keter": [
        # "I'm a developer" is identity. "I'm trying to ship this" is not, and
        # the first version of this rule caught both, so every sentence that
        # began with a contraction landed in the crown.
        (5, re.compile(r"\b(i am|i'?m)\s+(a|an)\s+"
                       r"(?!bit|little|lot|few|second|moment|good|bad|sure)\w+", re.I)),
        (5, re.compile(r"\bmy name is\b|\bcall me\b|\bgoes by\b", re.I)),
        (4, re.compile(r"\b(i am|i'?m)\s+\w+(er|or|ist|ian|eer|ant|ent|wright)\b", re.I)),
        (5, re.compile(r"\b(user'?s? name is|the user is (a|an|called))\b", re.I)),
        (4, re.compile(r"\bi (work|works) as\b|\bi'?m an? \w+ (by trade|by training)\b", re.I)),
        (4, re.compile(r"\b(i am|i'?m) (a|an) (developer|engineer|builder|designer|"
                       r"nurse|teacher|student|writer|artist|founder|scientist|"
                       r"doctor|lawyer|analyst|architect|researcher)\b", re.I)),
        (3, re.compile(r"\bidentifies as\b|\bwho (i|they) (am|are)\b", re.I)),
    ],

    # WHAT MUST NOT BE CROSSED. Rules the user set, and hard constraints
    # reality set for them. Both are things that constrain action.
    "gevurah": [
        (5, re.compile(r"\b(never|must not|do not|don'?t) (ever )?\w+", re.I)),
        (5, re.compile(r"\b(always (has to|must)|has to|must) (be|stay|remain|run)\b", re.I)),
        (4, re.compile(r"\b(hard )?(requirement|constraint|rule|limit|boundary)\b", re.I)),
        (4, re.compile(r"\b(only|strictly)\b.{0,24}?\b(use|allow|run|touch|read|write|reach)\b", re.I)),
        (3, re.compile(r"\b(offline|air.?gapped|private|no internet|nothing leaves)\b", re.I)),
        (5, re.compile(r"\b(budget|deadline|cap(ped)? at|no more than|at most|"
                       r"limited to)\b", re.I)),
        (3, re.compile(r"\bi (can'?t|cannot|won'?t) (stand|allow|have)\b", re.I)),
    ],

    # WHAT THEY LIKE. Taste, not rule. "I prefer X" constrains nothing.
    "chesed": [
        (5, re.compile(r"\bi (like|love|enjoy|prefer|favour|favor|appreciate)\b", re.I)),
        (5, re.compile(r"\b(favou?rite|preference is|prefers?)\b", re.I)),
        (5, re.compile(r"\bi'?d (rather|like|prefer)\b|\bwould rather\b", re.I)),
        (4, re.compile(r"\bi (hate|dislike|can'?t stand|don'?t like)\b", re.I)),
        (3, re.compile(r"\b(likes|enjoys) (to |the )?\w+", re.I)),
    ],

    # WHERE THEY ARE HEADED. Intent with a future in it.
    "netzach": [
        (5, re.compile(r"\bi (want|plan|intend|hope|aim|mean) to\b", re.I)),
        # "I want to build X" and "I want X" are the same wish. The first
        # version required the infinitive, so dropping two words moved the
        # statement from a goal to a fact about the world.
        (4, re.compile(r"\bi (want|need|would like)\s+(a|an|the|some|it)\b", re.I)),
        (5, re.compile(r"\b(the )?goal is\b|\bgoals?\b|\bambition\b", re.I)),
        (4, re.compile(r"\b(wants?|plans?|hopes?|intends?) to\b", re.I)),
        (4, re.compile(r"\b(eventually|one day|long.?term|down the line|someday)\b", re.I)),
        (4, re.compile(r"\bbuilding towards\b|\bworking towards\b|\btrying to (build|make|get)\b", re.I)),
        (3, re.compile(r"\bi'?m going to (build|make|write|learn|start)\b", re.I)),
    ],

    # WHAT IS HAPPENING NOW. Volatile by definition; this sephira decays fast.
    "tiferet": [
        (5, re.compile(r"\b(currently|right now|at the moment|these days|this (week|month|sprint))\b", re.I)),
        (5, re.compile(r"\bi'?m (currently )?(working on|building|writing|fixing|debugging|reading)\b", re.I)),
        (4, re.compile(r"\b(today|tonight|this morning|this afternoon)\b", re.I)),
        (3, re.compile(r"\bin the middle of\b|\bpartway through\b|\bhalf.?finished\b", re.I)),
    ],

    # WHAT THEY WORKED OUT. A generalisation that outlives its example.
    "chokmah": [
        (5, re.compile(r"\bi (realised|realized|learned|worked out|figured out|discovered)\b", re.I)),
        (5, re.compile(r"\b(the (trick|key|point|lesson|principle) is|turns out|it turns out)\b", re.I)),
        (4, re.compile(r"\b(always|never) (better|worse|works|fails) (than|when|if)\b", re.I)),
        (4, re.compile(r"\b(is|are) (worse|better|cheaper|faster|safer|harder|"
                       r"easier|simpler|slower) than\b", re.I)),
        (4, re.compile(r"\b(beats|outperforms|wins over)\b", re.I)),
        (3, re.compile(r"\b(every time|always|never)\b\s*[\.\,]?\s*$", re.I)),
        (4, re.compile(r"\bthe (whole )?(reason|problem|answer) is\b", re.I)),
        (3, re.compile(r"\b(rule of thumb|in general|as a rule|the way to)\b", re.I)),
    ],

    # HOW THE PARTS FIT. Structure and relation, not a single fact.
    "binah": [
        (5, re.compile(r"\b(consists of|is made up of|is composed of|breaks down into)\b", re.I)),
        (5, re.compile(r"\b(architecture|topology|structure|layout|pipeline|layer)\b", re.I)),
        (4, re.compile(r"\b(depends on|sits (on|under|between)|feeds into|wraps|is part of|"
                       r"is built (on|from)|talks to)\b", re.I)),
        (4, re.compile(r"\b(the way|how) .{0,30}\b(fits|works together|connects|relates)\b", re.I)),
        (2, re.compile(r"\b(module|component|subsystem|interface|boundary)\b", re.I)),
    ],

    # EVERYTHING CONCRETE. The default home for a true statement, and the
    # reason keter stays clean.
    "hod": [
        (4, re.compile(r"\b\d+(\.\d+)?\s?(gb|mb|kb|tb|ghz|mhz|ms|hz|tok|tokens|"
                       r"cores?|threads?|watts?|volts?|inches|cm|kg|lbs?)\b", re.I)),
        (3, re.compile(r"\b(version|build|model|driver|release)\s+[\w\.\-]*\d", re.I)),
        (3, re.compile(r"\b(is|are|was|were|has|have)\b.{0,60}\b(called|named|located|"
                       r"made of|found in|used for)\b", re.I)),
        (2, re.compile(r"\b(lives in|based in|located in|works at|studied at)\b", re.I)),
    ],
}

# A concrete-looking statement with no rule hit still belongs somewhere.
CONCRETE = re.compile(
    r"\d|\b[A-Z][a-z]+[A-Z]\w*\b|\b\w+\.\w{2,4}\b|\b[A-Z]{2,}\b|"
    r"\b(is|are|was|were|has|have|contains|holds|weighs|costs|runs)\b", re.I)

# Statements that are not memories at all. Filed by nobody, on purpose.
NOT_A_MEMORY = re.compile(
    r"^\s*(ok(ay)?|sure|thanks?|thank you|yes|no|yeah|nope|hi|hello|hey|"
    r"maybe|perhaps|right|fine|alright|good (morning|evening|night)|"
    r"got it|nice|cool|lol|hmm+|i see|understood)\b"
    r"[\s,\.!-]*(that|this|it)?\s*(works|sounds good|makes sense|is fine|"
    r"good|great|cool|fine)?[\s\.!]*$", re.I)

MIN_CONFIDENCE = 0.28


@dataclass
class Placement:
    sephira: str | None = None
    confidence: float = 0.0
    scope: str = WORLD
    distribution: dict = field(default_factory=dict)
    reason: str = ""
    unsorted: bool = True

    def as_dict(self) -> dict:
        return {"sephira": self.sephira, "confidence": round(self.confidence, 3),
                "scope": self.scope, "unsorted": self.unsorted,
                "reason": self.reason,
                "distribution": {k: round(v, 3) for k, v in
                                 sorted(self.distribution.items(),
                                        key=lambda kv: -kv[1])[:4]}}


def _merge_extra() -> None:
    """Fold EXTRA_RULES into RULES once, at import."""
    for name, extra in EXTRA_RULES.items():
        RULES.setdefault(name, [])
        have = {pat.pattern for _, pat in RULES[name]}
        for w, pat in extra:
            if pat.pattern not in have:
                RULES[name].append((w, pat))


_merge_extra()


def place(text: str) -> Placement:
    """
    Decide where one statement belongs.

    The scope adjustments below are the part that does the real work:
    the same rule fires on "I never use the cloud" and "banks never use the
    cloud", and only one of those is a boundary the user set.
    """
    t = (text or "").strip()
    if len(t) < 3 or NOT_A_MEMORY.match(t):
        return Placement(reason="not a durable statement", unsorted=True)

    sc = scope(t)
    scores: dict[str, float] = {}
    hits: dict[str, list] = {}

    for sephira, rules in RULES.items():
        total = 0.0
        why = []
        for weight, pat in rules:
            m = pat.search(t)
            if m:
                total += weight
                why.append(m.group(0)[:28].strip().lower())
        if total:
            scores[sephira] = total
            hits[sephira] = why

    # ---- scope adjustments ------------------------------------------
    # These are not tie-breakers. They are the difference between a memory
    # that can be found again and one that poisons the crown of the tree.
    directive = is_directive(t)
    wants_future = "netzach" in scores or "tiferet" in scores

    # An instruction is the user speaking, whatever its grammar says, and so
    # is a statement of what they are doing or aiming at. Both look like
    # statements about the world to a pronoun test, and both are about the
    # person sitting in front of the machine.
    if sc in (WORLD, SYSTEM) and (directive or wants_future):
        sc = SELF

    if sc in (WORLD, SYSTEM):
        # Nothing about the world describes who the user is or what they like.
        for k in ("keter", "chesed", "netzach", "tiferet"):
            scores.pop(k, None)
        # And a description of how something behaves is not a rule the user
        # set, however many times it says "never".
        if not directive:
            scores.pop("gevurah", None)
        scores["hod"] = scores.get("hod", 0.0) + 2.0

    if sc == OTHER:
        # A fact about someone else is a fact, not the user's identity.
        scores.pop("keter", None)
        scores["hod"] = scores.get("hod", 0.0) + 1.5

    if not scores:
        # A concrete statement with no rule hit still belongs somewhere, but
        # "sure, that works" contains the word "works" and would otherwise be
        # filed as a fact about the world.
        if len(t) >= 18 and CONCRETE.search(t) and sc in (WORLD, SYSTEM, OTHER, SELF):
            return Placement(sephira="hod", confidence=0.30, scope=sc,
                             distribution={"hod": 1.0},
                             reason="concrete statement, no stronger signal",
                             unsorted=False)
        return Placement(scope=sc, reason="no placement signal", unsorted=True)

    total = sum(scores.values()) or 1.0
    dist = {k: v / total for k, v in scores.items()}
    best = max(dist.items(), key=lambda kv: kv[1])

    p = Placement(sephira=best[0], confidence=best[1], scope=sc,
                  distribution=dist,
                  reason=", ".join(hits.get(best[0], []))[:80] or "scope default",
                  unsorted=best[1] < MIN_CONFIDENCE)
    if p.unsorted:
        p.reason = f"ambiguous ({p.reason})"
        p.sephira = None
    return p


def place_many(lines) -> list:
    """Classify a batch. Returns [(text, Placement)] in the order given."""
    return [(t, place(t)) for t in (lines or []) if isinstance(t, str)]


# ---------------------------------------------------------------- self-test

if __name__ == "__main__":
    import json
    import pathlib
    import sys

    bench = pathlib.Path(__file__).resolve().parent / "tests" / "placement.jsonl"
    if not bench.exists():
        print(f"ERROR: benchmark missing at {bench}")
        raise SystemExit(2)

    hard = soft = unsorted_n = total = 0
    rows = []
    for line in bench.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        case = json.loads(line)
        total += 1
        p = place(case["text"])
        want = case["sephira"]
        got = p.sephira

        if got is None:
            unsorted_n += 1
            status = "unsorted"
            if want is None:
                status = "ok"
        elif want is None:
            status = "soft"          # placed something we expected to park
            soft += 1
        elif got == want:
            status = "ok"
        elif got in case.get("acceptable", []):
            status = "soft"
            soft += 1
        else:
            status = "HARD"
            hard += 1

        if status in ("HARD", "soft"):
            rows.append(f"  {status:8} want={str(want):8} got={str(got):8} "
                        f"conf={p.confidence:.2f} scope={p.scope:6} "
                        f"{case['text'][:56]!r}")

    for r in rows:
        print(r)
    print(f"\n  {total} cases   hard failures: {hard}   soft: {soft}   "
          f"unsorted: {unsorted_n} ({unsorted_n * 100 // max(total,1)}%)")
    sys.exit(1 if hard else 0)
