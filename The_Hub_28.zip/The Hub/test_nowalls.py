"""
test_nowalls.py - nothing may stop a generation for taking time.

    "none of these should ever return because it took too long, only if it
     never ran in the first place or if it ran but had errors or something
     stopping it - don't become the reason it stops, let go and see if it
     runs"

THIS IS A RULE TEST, NOT A LIST OF CASES.

Three separate limiters of mine have now killed the exact thing they were
protecting: a subprocess deadline, a size refusal, and a RAM floor. Each time
the fix removed that one number and each time a different number was already
waiting. Zero's ledger settles the argument with evidence:

    video killed  x4   at 17.7, 18.3, 17.7, 18.5 minutes
    video worked  x3   at 43.3, 43.5, 46.6 minutes
    model3d       x2   killed at exactly 3.00 hours, one of them at flow
                       step 10 of 12 with ~34 minutes left

Upstream (pwilkin/trellis.cpp) reports 3-12 minutes end-to-end on a 16 GB
RTX 5060 Ti, and describes the CPU fallback this machine runs on as "very
slow, RAM-hungry". Thirty to sixty times slower is the EXPECTED behaviour of
the configuration, not a fault - so any fixed deadline was going to lose.

So these tests assert the property over the whole generation path rather
than three specific numbers, and they fail on a fourth limiter nobody has
invented yet.
"""
from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

import testkit

# The generation path, plus the three files that decide what the model is
# told. server.py and runtime.py are covered by their own tests below
# rather than here, because they legitimately hold small timeouts - a 2s
# health poll is how you find out something is dead, which is the opposite
# of a deadline.
#
# carryover, timeline and growth are on this list for the reason the
# handoff gave for widening it: they read the user's own history off a
# disk, and reading a transcript has no business having a deadline. A
# limiter here would fail the way every other one did - quietly, and by
# removing the thing it was meant to protect.
GEN = ("forge.py", "tools.py", "model3d.py", "meshgen.py", "imagegen.py",
       "carryover.py", "timeline.py", "growth.py")

# Anything that could plausibly be a wall-clock ceiling. Small numbers are
# not deadlines - a 2s health poll and a 20s terminate-then-kill are how you
# find out something is dead, which is the opposite of a deadline.
_BIG = 90


def _numbers_near(src: str, pattern: str) -> list[tuple[int, str, int]]:
    out = []
    for i, line in enumerate(src.splitlines(), 1):
        if line.lstrip().startswith("#"):
            continue
        if not re.search(pattern, line):
            continue
        for m in re.finditer(r"(?<![\w.])(\d{2,7})(?:\.\d+)?(?![\w.])", line):
            out.append((i, line.strip(), int(m.group(1))))
    return out


def test_no_generator_runs_under_a_wall_clock_deadline():
    """No large timeout= anywhere a generator can reach."""
    bad = []
    for name in GEN:
        src = Path(name).read_text(encoding="utf-8")
        for ln, text, n in _numbers_near(src, r"timeout\s*="):
            if n >= _BIG and "timeout" in text:
                bad.append(f"{name}:{ln}  {text[:90]}")
    assert not bad, (
        "a wall-clock deadline is back in the generation path:\n  "
        + "\n  ".join(bad))


def test_no_generator_is_killed_by_subprocess_run():
    """
    subprocess.run(..., timeout=) kills the child. Popen + drain does not,
    and is the only shape that can report progress while it waits.

    ONE KIND IS ALLOWED and it has to say so. Asking a binary to print its
    own --help is not a generation: something that cannot answer that in
    thirty seconds is broken, not slow, and finding out a thing is dead is
    the opposite of a deadline. Such a call must carry a `# PROBE:` comment
    above it and a timeout under 90 seconds - which means a real deadline
    can never slip back in wearing a probe's clothes without somebody
    typing the word PROBE and being wrong on purpose.
    """
    for name in GEN:
        src = Path(name).read_text(encoding="utf-8")
        lines = src.splitlines()
        for node in ast.walk(ast.parse(src)):
            if not isinstance(node, ast.Call):
                continue
            f = node.func
            if not (isinstance(f, ast.Attribute) and f.attr == "run"
                    and isinstance(f.value, ast.Name)
                    and f.value.id == "subprocess"):
                continue
            for kw in node.keywords:
                if kw.arg != "timeout":
                    continue
                above = "\n".join(lines[max(0, node.lineno - 7):node.lineno])
                secs = getattr(kw.value, "value", None)
                assert "# PROBE:" in above and isinstance(secs, (int, float)) \
                    and secs < _BIG, (
                    f"{name} line {node.lineno}: subprocess.run with a "
                    f"timeout kills the process it is waiting for. If it is "
                    f"genuinely a liveness probe, mark it `# PROBE:` and "
                    f"keep it under {_BIG}s.")


def test_the_trellis_request_waits_indefinitely():
    """
    The 3D mesh POST is synchronous and there is no progress endpoint
    upstream, so the socket must simply wait. 10,800 seconds looked generous
    and still killed a run at flow step 10 of 12.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    gen = src[src.index("    def generate(self, image: Path"):
              src.index("    def stop(self)")]
    assert "urlopen(req, timeout=timeout)" in gen
    sig = src[src.index("    def generate(self, image: Path"):
              src.index('"""', src.index("    def generate(self, image: Path"))]
    assert "timeout: int | None = None" in sig, (
        "the mesh request has a default deadline again")


def test_the_server_start_has_no_deadline_by_default():
    src = Path("forge.py").read_text(encoding="utf-8")
    assert "def start(self, deadline: float = 0.0)" in src, (
        "bringing the 3D runtime up is on a clock again")


def test_the_ram_floor_is_off_unless_the_user_turns_it_on():
    """
    The floor killed four finished videos ~25 minutes short of the end. It
    stays available and stays OFF, and the default is asserted here rather
    than trusted to a comment.
    """
    import forge
    assert forge.RAM_FLOOR_MB == 0.0, "the RAM floor is armed again by default"
    guard = forge._RamGuard(proc=None, floor_mb=0.0)
    assert guard.start()._t is None, "a zero floor still started a watcher"


def test_nothing_refuses_a_tool_for_being_slow():
    """
    policy.py may refuse for what a call IS. It may never refuse for how
    long anything took.
    """
    src = Path("policy.py").read_text(encoding="utf-8")
    for m in re.finditer(r"_no\(d,\s*\"([a-z0-9-]+)\"", src):
        reason = m.group(1)
        assert not re.search(r"slow|timeout|too-long|duration|deadline",
                             reason), f"policy refuses on {reason!r}"


def test_the_progress_bar_never_invents_a_time_remaining():
    """
    "this should never be timed for 'how long it should take' only for how
     long it has taken in the past"

    At step 1 of 12 the old extrapolation announced "~186 min left". The
    board carries measured history now, and nothing computes a countdown.
    """
    import forge
    forge._progress_start("video", "test")
    board = forge.progress()
    forge._progress_clear()
    assert "eta" not in board, "the extrapolated ETA is back on the board"
    for k in ("typical", "fastest", "slowest", "runs"):
        assert k in board, f"measured history is missing {k!r}"
    ui = Path("ui.html").read_text(encoding="utf-8")
    assert "pr.eta" not in ui, "the UI is showing an invented countdown again"
    assert "past runs" in ui, "the UI stopped showing measured history"


def test_the_tool_loop_has_one_ceiling_and_it_explains_itself():
    """
    There used to be two: policy said 120 calls and said so in words, and
    the loop said 7 and fell through in silence.
    """
    src = Path("server.py").read_text(encoding="utf-8")
    assert "for _ in range(7)" not in src, "the silent 7-round ceiling is back"
    assert 'rounds = int(policy.LIMITS.get("calls_per_turn")' in src, (
        "the loop has its own ceiling again instead of the declared one")
    assert "hit_the_ceiling" in src and "tool_ceiling" in src, (
        "reaching the ceiling is silent again")


def test_a_progress_bar_can_never_become_a_failure_reason():
    """
    Four rows of the real ledger carry a picture of a loading bar as their
    reason. Both bar shapes are checked: sd.cpp's and trellis.cpp's.
    """
    import forge
    for bar in (
        "|##################################################| 108/108 - 626.91MB/s\n"
        "model_loader.cpp:1229 - loading tensors completed, taking 0.22s",
        "[flow] [###########.........] 7/12 7139.7s ~5100s left\n"
        "[flow] [################....] 10/12 10211.0s ~2042s left",
    ):
        why = forge._explain(bar)
        assert "|" not in why and "#" not in why, f"bar became a reason: {why}"
        assert "%" not in why, f"bar became a reason: {why}"
    real = forge._explain("[flow] [###...] 3/12 900.0s\n"
                          "error: failed to allocate 4096 MB")
    assert "failed to allocate" in real, real


def test_the_memory_path_cannot_stop_a_turn():
    """
    THE FILES THAT DECIDE WHAT SHE IS TOLD.

    Nothing that reads memory may fail a turn or truncate itself because
    something took a moment. These read JSON off a local disk; the only
    reason a deadline would ever appear here is defensiveness, and every
    defensive number in this project so far has killed what it guarded.
    """
    for name in ("carryover.py", "timeline.py", "memory.py", "focus.py"):
        src = Path(name).read_text(encoding="utf-8")
        for lineno, line, n in _numbers_near(src, r"\btimeout\s*="):
            assert n < _BIG, f"{name}:{lineno} has a {n}s deadline: {line}"
        assert "signal.alarm" not in src, f"{name} arms an alarm"


def test_reading_the_past_is_never_capped_by_a_clock():
    """
    A transcript is trimmed by SIZE, in whole rounds, from the oldest end.
    It is never trimmed by how long reading it took, and it is never given
    up on. The difference matters because one of them is reproducible.
    """
    src = Path("carryover.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            fn = node.func
            name = (fn.attr if isinstance(fn, ast.Attribute)
                    else getattr(fn, "id", ""))
            assert name not in ("alarm", "settimeout", "wait_for"), \
                f"carryover.py:{node.lineno} waits on a clock"
    assert "time.time()" not in src, "carryover.py measures elapsed time"


def test_the_standing_block_is_bounded_by_room_not_by_time():
    src = Path("timeline.py").read_text(encoding="utf-8")
    body = src[src.index("def standing("):src.index("def about(")]
    assert "limit_chars" in body, "the standing block must be bounded"
    assert "time" not in body.replace("timeline", "").replace("sometimes", ""), \
        "the standing block is bounded by a clock"


# ══════════════════════════════════════════════════════════════════════
# §  THE ONE THING THAT IS ALLOWED TO SAY NO
#
#     "none of these should ever return because it took too long, only if
#      it never ran in the first place or if it ran but had errors"
#
# "It never ran in the first place" is in the rule, and it is the only
# permitted no. A generator crashed the machine twice, for the same reason
# both times, and the two things that could have caught it were both off:
# room_for() logged "starting anyway", and the RAM floor that would have
# fired was disarmed because it had killed four good video runs.
#
# The floor stays off. These tests draw the line between the two.
# ══════════════════════════════════════════════════════════════════════

def test_the_start_check_is_arithmetic_not_a_prediction():
    import forge
    src = Path("forge.py").read_text(encoding="utf-8")
    body = src[src.index("def enough_room_to_start("):src.index("def room_for(")]
    for banned in ("margin", "estimate", "peak", "expect"):
        assert f"{banned}_mb" not in body and f"{banned} =" not in body, \
            f"the start check acquired a {banned} - that is a guess, not a measurement"
    assert "free_mb()" in body and "weights_in(" in body
    for clock in ("time.time(", "time.sleep(", "timeout", "deadline",
                  "elapsed"):
        assert clock not in body, \
            f"the start check must not know about {clock} - it is not a clock"


def test_it_refuses_only_when_the_weights_cannot_fit(tmp_path):
    import forge
    big = tmp_path / "weights.bin"
    big.write_bytes(b"0" * (3 * 1024 * 1024))          # 3 MB
    argv = ["sd.exe", "--model", str(big), "-p", "a lighthouse"]

    saved = forge.free_mb
    try:
        forge.free_mb = lambda: 2.0                     # 2 MB free, 3 MB needed
        ok, why = forge.enough_room_to_start(argv)
        assert not ok
        assert "cannot start" in why and "3 MB" in why
        assert "nothing was lost" in why.lower()

        forge.free_mb = lambda: 3.5                     # it fits
        assert forge.enough_room_to_start(argv)[0] is True

        forge.free_mb = lambda: -1.0                    # unmeasurable
        assert forge.enough_room_to_start(argv)[0] is True, \
            "no reading means no opinion"

        forge.free_mb = lambda: 0.5
        assert forge.enough_room_to_start(["sd.exe", "-p", "no files here"])[0] \
            is True, "nothing to load, nothing to refuse"
    finally:
        forge.free_mb = saved


def test_it_can_be_switched_off(tmp_path):
    import forge
    import core as _core
    big = tmp_path / "w.bin"
    big.write_bytes(b"0" * (2 * 1024 * 1024))
    saved_free, saved_cfg = forge.free_mb, _core.CONFIG
    try:
        forge.free_mb = lambda: 1.0
        _core.CONFIG = tmp_path / "config.json"
        cfg = _core.load()
        cfg.setdefault("generation", {})["start_check"] = False
        _core.save(cfg)
        assert forge.enough_room_to_start(["x", str(big)])[0] is True
    finally:
        forge.free_mb, _core.CONFIG = saved_free, saved_cfg


def test_it_is_asked_once_before_the_process_exists():
    """
    THE WHOLE DIFFERENCE FROM THE RAM FLOOR.

    The floor sampled every four seconds for the length of the run and
    killed four videos at 17-18 minutes against successes at 43-47. This
    is asked once, before Popen, and cannot reach a process that exists.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    run = src[src.index("    def _run(self, backend"):]
    run = run[:run.index("\n    def ", 10)] if "\n    def " in run[10:] else run
    check_at = run.index("enough_room_to_start(")
    popen_at = run.index("subprocess.Popen(")
    assert check_at < popen_at, "the check must happen before the process"
    after = run[popen_at:]
    assert "enough_room_to_start" not in after, \
        "the start check is being asked again while something is running"
    assert "free_mb" not in after.split("while True:")[-1], \
        "free memory is being sampled inside the read loop"


def test_every_backend_goes_through_it():
    """
    One chokepoint, so a backend added later cannot be the one that was
    forgotten - which is how TRELLIS spent weeks being 'ready'.
    """
    src = Path("forge.py").read_text(encoding="utf-8")
    assert src.count("enough_room_to_start(") == 2, \
        "defined once and called once, in _run"
    for backend in ('self._run("image"', 'self._run("video"',
                    'self._run("model3d"'):
        assert backend in src, backend


def test_the_ram_floor_is_still_off():
    import forge
    assert forge.RAM_FLOOR_MB == 0.0
    assert forge._ram_floor() == 0.0, \
        "the floor that killed four good videos must stay off"


def test_memory_work_stands_down_while_a_generator_runs():
    """
    "Idle" meant the USER was idle, and during a 45-minute generation the
    user is idle by definition - so the heaviest background work in the
    application ran on every pass at the exact moment the machine had
    least to give.
    """
    src = Path("memory.py").read_text(encoding="utf-8")
    loop = src[src.index("def loop(stop_evt"):src.index("# What the last growth pass")]
    assert "import forge" in loop and "busy()" in loop, \
        "the memory loop does not know when a generator is running"
    gate = loop.index("busy()")
    # run_curator() is named in the docstring above the code, so match the
    # call, not the word.
    assert loop.index("run_curator(cfg") > gate
    assert loop.index("growth.tend(") > gate
    assert "continue" in loop[gate:gate + 260], \
        "it must skip the pass, not press on"


if __name__ == "__main__":
    sys.exit(testkit.run(dict(globals()), "NOTHING STOPS IT FOR BEING SLOW"))
