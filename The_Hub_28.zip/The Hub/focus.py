"""
focus.py - what the user is doing NOW, and what Nova is given because of it.

RULE 5: CURRENT FOCUS OUTRANKS BACKGROUND.

Retrieval on its own answers "what in memory resembles this sentence". That
is not the same question as "what does this person need in front of them
right now". A user three turns into designing a greenhouse asks "what about
the frame" - lexical retrieval returns picture frames, window frames and a
note about a framing library, because the sentence contains the word frame
and nothing else.

Focus is the missing term. It is derived, not asked for: the subject that has
persisted across recent turns, weighted toward the newest, decaying when the
conversation moves on.

RULE 3: MEMORY IS LARGER THAN CONTEXT.

Nova never receives the Tree. She receives an ACTIVE PERCEPTION - a small
assembled slice built for this turn:

    ANCHOR      identity and boundaries. Small, permanent, never ranked away.
    FOCUS       what the current task is, and what is known about it.
    RELEVANT    retrieval against the question AND the focus, not the
                question alone.
    RECENT      a thin tail, so yesterday is not forgotten just because it
                did not match.

Every part is bounded in tokens before assembly. The store can grow to a
library; this stays the same size.

DRIFT

Focus also makes drift measurable. If the user is designing a greenhouse and
Nova is three tool calls deep into CNC machines, that is visible as a number -
the overlap between the current activity and the established focus - and the
control layer can act on it. This file MEASURES drift. It does not decide what
to do about it, because that is a policy question and this is not the policy
layer.
"""
from __future__ import annotations

import math
import re
import threading
from datetime import datetime, timezone

import core

# How many recent user turns contribute to focus.
WINDOW = 6
# Newer turns count for more. This is the half-life in turns.
HALF_LIFE = 1.8
# Below this overlap, the current activity is not what the user was doing.
# Where the measured data actually separates: clearly-related activity scored
# 0.38-0.58, a materials tangent 0.14, and genuinely unrelated work 0.00. The
# line goes below the tangent, because drift detection is ADVISORY and a false
# "you have wandered off" costs more than a missed one.
DRIFT_AT = 0.12

STOP = {
    "the", "a", "an", "and", "or", "but", "is", "are", "was", "were", "be",
    "been", "being", "to", "of", "in", "on", "at", "for", "with", "it", "its",
    "this", "that", "these", "those", "i", "you", "my", "your", "we", "our",
    "me", "us", "as", "if", "so", "do", "does", "did", "have", "has", "had",
    "not", "no", "can", "will", "would", "should", "could", "there", "here",
    "what", "when", "where", "who", "how", "why", "just", "very", "really",
    "some", "any", "more", "most", "much", "many", "then", "than", "them",
    "they", "their", "about", "into", "from", "out", "up", "down", "over",
    "also", "get", "got", "make", "made", "one", "two", "now", "like",
    "want", "need", "know", "think", "say", "said", "tell", "let", "going",
    "continue", "please", "thanks", "okay", "yes",
}

_lock = threading.RLock()
_state = {"terms": {}, "task": "", "since": "", "turns": 0}


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _terms(text: str) -> list:
    return [w for w in re.findall(r"[a-z0-9][a-z0-9'\-]{2,}", (text or "").lower())
            if w not in STOP]


# ═══════════════════════════════════════════════════════════════════════════
# §1  DERIVING FOCUS
# ═══════════════════════════════════════════════════════════════════════════

def _subject_cues(text: str) -> set[str]:
    """Strong cues that identify the concrete object of the current turn.

    File names/extensions are much stronger than generic words like "see",
    "look", or "image".  Those generic words are exactly what caused old
    visual conversations to bleed into an STL question.
    """
    text = text or ""
    cues = set()
    for m in re.findall(r"(?i)([a-z0-9][a-z0-9 _.-]{0,80}\.(?:stl|obj|glb|gltf|ply|3mf|fbx|step|stp|jpg|jpeg|png|webp|gif|bmp|svg|avif|txt|pdf|mp4|mov|webm))", text):
        whole = m.strip().lower().strip(' .')
        if whole:
            cues.add(whole)
            stem = re.sub(r"\.[a-z0-9]+$", "", whole).strip()
            cues.update(_terms(stem))
    low = text.lower()
    for marker in (".stl", " stl", " stl's", "3d model", "3d models", "mesh", "obj file",
                   "glb", "gltf", "ply", "3mf", "image", "photo", "photograph"):
        if marker in low:
            cues.add(marker.strip())
    # Normalize possessives such as STL's without altering ordinary stems.
    cues = {((c[:-2]) if c.endswith("'s") else c) for c in cues}
    # Named things - characters, people, places, titles - are subjects too,
    # and are the ones this function used to be completely blind to.
    cues |= named_subjects(text)
    # Model- and object-class words are useful; broad visual verbs are not.
    for t in _terms(text):
        norm = t.rstrip("'s") if t.endswith("'s") else t
        if norm in {"stl", "obj", "glb", "gltf", "ply", "mesh", "model",
                 "models", "3d", "file", "files", "projector", "vision",
                 "vlm", "camera", "webcam", "photo", "image", "images"}:
            cues.add(norm)
    return cues


# Words that open a sentence or stand in for a subject, so a capital letter
# on them means nothing.
_NOT_A_NAME = {
    "i", "the", "this", "that", "these", "those", "you", "we", "it", "he",
    "she", "they", "but", "and", "so", "no", "yes", "now", "try", "can",
    "do", "does", "did", "please", "make", "find", "research", "look",
    "what", "when", "where", "who", "how", "why", "since", "if", "there",
    "here", "again", "ok", "okay", "also", "just", "still", "nice", "close",
    "wait", "first", "next", "then", "your", "my", "our", "their", "a", "an",
}

# HOW A NAME ANNOUNCES ITSELF WHEN IT IS NOT CAPITALISED.
#
# "Research the terrible tornado, the character, you cannot forget it."
#
# Not one capital letter in the name, no file extension, nothing in any
# vocabulary this file ships with. And yet a person reads that sentence and
# knows instantly what the subject is, from two things that are structural
# rather than lexical: a LOOKUP VERB in front of it, and an APPOSITIVE
# ("the character") behind it. Neither needs to know what a Tatsumaki is.
_LOOKUP_RE = re.compile(
    r"(?i)\b(?:research(?:\s+on)?|look\s+up|looks?\s+like|search\s+for|"
    r"find(?:\s+out)?(?:\s+about)?|tell\s+me\s+about|information\s+on|"
    r"who\s+is|what\s+is|an?\s+image\s+of|images?\s+of|picture\s+of|"
    r"a\s+separate\s+image\s+of)\s+(?:the\s+|a\s+|an\s+)?"
    r"([a-z0-9][a-z0-9 '\-]{2,48})")
_APPOSITIVE_RE = re.compile(
    r"(?i)([a-z0-9][a-z0-9 '\-]{2,48}?)\s*,\s*(?:the|a|an)\s+"
    r"(?:character|person|people|hero|heroine|villain|figure|place|city|"
    r"country|company|band|game|film|movie|show|series|book|anime|manga|"
    r"song|artist|author|actor|player|team|animal|creature|species|"
    r"product|model|tool|language|framework)\b")
_QUOTED_RE = re.compile(r"[\"\u201c']([^\"\u201d']{2,60})[\"\u201d']")
_CAPS_RE = re.compile(r"\b([A-Z][a-z]{1,}(?:[ -][A-Z][a-z]{1,}){0,3})\b")


# Where a name stops. `_terms` has already dropped most of these as stop
# words, but "and", "in", "of" and friends survive as sentence joints and a
# capture that walks through one has stopped being a name.
_BOUNDARY = {"and", "or", "in", "of", "with", "for", "on", "at", "from",
             "into", "plus", "versus", "vs", "fighting", "separate",
             "image", "images", "picture", "photo", "model", "statue",
             "create", "make", "generate", "please", "using", "based"}


def named_subjects(text: str) -> set[str]:
    """
    The named things this sentence is about - people, characters, places,
    titles - without a list of them existing anywhere.

    THE HOLE THIS FILLS. _subject_cues() knew about file extensions and
    eighteen technical nouns, so a turn about a named character carried NO
    cue at all and was judged to have no subject. The user asked for
    "terrible tornado, the character" and the focus layer, finding nothing
    it recognised, reached back and declared the subject was still a Goku
    statue from four turns earlier - then said so, every turn, while the
    user tried to move on.

    "The ability to find characters, items, famous or known people places or
     things in history or the current time is limited ... it seems to forget
     this goal."

    It was not forgetting. It was never able to see the goal in the first
    place, because a name is not a file extension.
    """
    out = set()
    t = text or ""
    for rx in (_LOOKUP_RE, _APPOSITIVE_RE, _QUOTED_RE):
        for m in rx.finditer(t):
            phrase = m.group(1).strip(" ,.'-").lower()
            # A name ends where the sentence turns. Without this the capture
            # runs on - "create an image of Goku in ultra instinct and a
            # separate image of terrible tornado" came back as one 6-word
            # "name" that matches nothing and is nobody.
            words = []
            for w in _terms(phrase):
                if w in _BOUNDARY:
                    break
                words.append(w)
            words = [w for w in words if w not in _NOT_A_NAME][:4]
            if 1 <= len(words) <= 4:
                out.add(" ".join(words))
                out.update(words)
    for m in _CAPS_RE.finditer(t):
        phrase = m.group(1).strip()
        words = [w for w in phrase.lower().split() if w not in _NOT_A_NAME]
        if words:
            out.add(" ".join(words))
            out.update(w for w in words if len(w) > 2)
    return {w for w in out if len(w) > 2}


def subject_kind(text: str) -> str:
    """
    The CATEGORY the user named, when they named one: "character", "place",
    "band". Empty when they did not.

    This is the word that decides a search. "terrible tornado" alone returns
    a weather system, a video-game skin and an S-Class hero with equal
    confidence; "terrible tornado character" returns the hero. The user said
    "the character" out loud and it was thrown away before the query was
    built - then the three unrelated buckets came back and were reported as
    though all three were answers.
    """
    m = _APPOSITIVE_RE.search(text or "")
    if m:
        tail = (text or "")[m.end(1):m.end()]
        words = [w for w in re.findall(r"[a-z]+", tail.lower())
                 if w not in {"the", "a", "an"}]
        if words:
            return words[-1]
    return ""


# A turn that says "not that" is a turn that has changed the subject, and
# nothing earlier may be carried forward over the top of it.
_MOVED_ON_RE = re.compile(
    r"(?i)\b(?:i(?:'m| am)? not (?:asking|talking|referring)|"
    r"we are not talking|not what i asked|that is not what|"
    r"i did ?n[o']?t ask|forget (?:that|the)|instead of|"
    r"no,? (?:the|i|that)|at the moment|right now,? (?:i|we)|"
    r"different (?:thing|subject|topic))\b")


def changed_subject(text: str) -> bool:
    """Did the user just say the previous subject is not this one?"""
    return bool(_MOVED_ON_RE.search(text or ""))


def _current_anchor(history: list) -> str:
    """Return the closest substantive user statement that defines the subject."""
    users = [m.get("content", "") for m in (history or [])
             if m.get("role") == "user" and isinstance(m.get("content"), str)]
    if not users:
        return ""
    latest = users[-1].strip()

    # THE ASYMMETRY THAT MADE AN OLD TASK OUTRANK THE CURRENT ONE.
    #
    # This used to require the LATEST turn to carry a subject cue - a
    # filename or one of eighteen technical nouns - while an EARLIER turn
    # qualified on cues OR on merely being substantive. The newest message
    # was held to the stricter test, so whenever the user changed to a
    # subject this file had no vocabulary for, the old one won.
    #
    # This file's own first line says "CURRENT FOCUS OUTRANKS BACKGROUND"
    # and update() says "the newest concrete subject wins". The code said
    # the opposite, in one `and`.
    #
    # Same test both ways now: a turn is a subject if it names something or
    # if it has enough of its own content to stand up.
    if (_subject_cues(latest) or named_subjects(latest)
            or len(_terms(latest)) >= 3):
        return latest[:240]

    # And a turn that says "not that" ends the old subject outright, rather
    # than inheriting it. "I am NOT asking for a 3D model at the moment" is
    # not a short follow-up about 3D models.
    if changed_subject(latest):
        return latest[:240]

    # A short follow-up inherits the nearest earlier subject.
    #
    # This required _subject_cues() to fire on the earlier turn, and those
    # cues are filenames, model names, extensions - concrete nouns the
    # matcher knows. A perfectly clear sentence like "Code for me a program
    # to build things in scratch on a pi" contains none of them, so nothing
    # was inherited and the function fell through to returning the latest
    # turn instead: "the second one". Which anchors on nothing at all.
    #
    # Substance is the better test. A turn with several distinctive terms IS
    # the subject, whether or not it happens to name a file.
    for text in reversed(users[:-1]):
        if _subject_cues(text) or len(_terms(text)) >= 3:
            return text.strip()[:240]
    return latest[:240]


def update(history: list) -> dict:
    """Derive a short-lived focus from the user's own recent turns.

    The newest concrete subject wins.  Generic assistant vocabulary never
    contributes, and old subjects decay faster so a new file/model/task can
    take over without dragging the previous topic along.
    """
    users = [m.get("content", "") for m in (history or [])
             if m.get("role") == "user" and isinstance(m.get("content"), str)]
    users = users[-WINDOW:]
    if not users:
        return snapshot()

    weighted: dict = {}
    n = len(users)
    for i, text in enumerate(users):
        age = (n - 1) - i
        w = math.pow(0.5, age / HALF_LIFE)
        # Concrete file/model/subject cues get a strong multiplier.
        cues = _subject_cues(text)
        for t in set(_terms(text)):
            norm = t[:-2] if t.endswith("'s") else t
            key = norm if norm in {"stl", "obj", "glb", "gltf", "ply", "mesh", "model",
                                   "models", "3d", "file", "files", "projector",
                                   "vision", "vlm", "camera", "webcam", "photo",
                                   "image", "images"} else t
            weighted[key] = weighted.get(key, 0.0) + w * (2.2 if norm in cues else 1.0)

    top = sorted(weighted.items(), key=lambda kv: -kv[1])
    keep = {t: round(v, 3) for t, v in top[:14] if v >= 0.30}

    with _lock:
        prior = set(_state["terms"])
        _state["terms"] = keep
        _state["turns"] = n
        anchor = _current_anchor(history)
        if anchor:
            _state["task"] = anchor
        if not prior or not (prior & set(keep)):
            _state["since"] = now()
    return snapshot()

def snapshot() -> dict:
    with _lock:
        return {"terms": dict(_state["terms"]), "task": _state["task"],
                "since": _state["since"], "turns": _state["turns"]}


def terms() -> set:
    with _lock:
        return set(_state["terms"])


def overlap(text: str) -> float:
    """
    0..1 — how much this belongs to what the user is currently doing.

    Weighted by how central each term is to the focus, so matching the main
    subject counts for more than matching a word mentioned once in passing.
    """
    with _lock:
        f = dict(_state["terms"])
    if not f:
        return 1.0            # no established focus yet: nothing is off-task
    got = set(_terms(text))
    if not got:
        return 0.0
    hit = sum(w for t, w in f.items() if t in got)

    # Normalised against the CENTRAL terms, not all of them.
    #
    # Dividing by the total weight of fourteen terms meant matching one
    # central subject scored 0.07 and read as drift - "aluminium extrusion
    # for garden structures" while designing a garden greenhouse. Touching
    # the main subject at all is strong evidence of being on task; matching
    # every peripheral word is not required and never happens.
    core_w = sum(sorted(f.values(), reverse=True)[:5]) or 1e-6
    return round(min(1.0, hit / core_w), 3)


def drifting(text: str) -> dict:
    """
    Is this activity still what the user asked for?

    MEASURES, decides nothing. What to do about drift is a policy question
    and belongs to the layer that owns policy.
    """
    o = overlap(text)
    s = snapshot()
    return {"overlap": o, "drifting": bool(s["terms"]) and o < DRIFT_AT,
            "task": s["task"], "focus": sorted(s["terms"])[:8]}


# ═══════════════════════════════════════════════════════════════════════════
# §2  ACTIVE PERCEPTION
# ═══════════════════════════════════════════════════════════════════════════

def perception(question: str, tokens: int, history: list = None) -> str:
    """Assemble a bounded, subject-aware memory slice for this turn.

    Conversation history is the source of continuity; memory is background.
    Therefore memory retrieval is conservative and recent unsorted leaves are
    not dumped into the prompt. Explicit file/object cues outrank generic
    visual vocabulary, and superseded conversational fragments stay out unless
    the user asks for history or corrections.
    """
    import memory

    if history:
        update(history)
    f = snapshot()
    cues = _subject_cues(question)
    lowq = (question or "").lower()
    history_users = [m.get("content", "") for m in (history or [])
                     if m.get("role") == "user" and isinstance(m.get("content"), str)]

    budget_chars = max(240, int(tokens * 3.1))
    out, used = [], 0

    def add(line: str) -> bool:
        nonlocal used
        if used + len(line) + 1 > budget_chars:
            return False
        out.append(line)
        used += len(line) + 1
        return True

    # Identity/boundaries are stable background. Do not inject preferences,
    # goals, or an old visual focus into a concrete file question.
    anchor = memory.frame(limit_chars=min(850, budget_chars // 4))
    if anchor:
        # Keep only the first two stable frame sections.
        stable = []
        for block in anchor.split("\n\n"):
            if block.startswith(("Who they are:", "Boundaries:")):
                stable.append(block)
        if stable:
            add("\n\n".join(stable))

    # State the concrete subject explicitly - but ONLY when it was carried in
    # from an earlier turn.
    #
    # THE BUG THIS FIXES. _current_anchor() returns the LATEST user turn when
    # that turn is substantive, and this block is handed to the model under
    # the heading "[what you remember]". So on the very first message of an
    # empty session, with zero leaves and zero events, Nova received:
    #
    #     [what you remember]
    #     Working on: Code for me a program to build things in scratch on a pi.
    #
    #     Code for me a program to build things in scratch on a pi.
    #
    # The same sentence twice - once labelled as a memory. Nova read the
    # label, believed it, and answered "I remember that we were working on a
    # program to build things in Scratch on a Raspberry Pi. What would you
    # like to do next?" to a message that had just been typed. The user said
    # "I just said that..." and they were right.
    #
    # The model was not confused; the prompt was false. The current message
    # is already in the turn, verbatim, immediately below this block - it
    # never needed restating, and restating it as recollection is how an
    # assistant with no memory at all still sounds like it is remembering.
    task = _current_anchor(history or [])
    latest = ""
    for m in reversed(history or []):
        if m.get("role") == "user" and isinstance(m.get("content"), str):
            latest = m["content"].strip()
            break
    if task and task[:240] != latest[:240]:
        add("")
        add(f"Earlier in this conversation (background, not the current "
            f"request): {task}")

    # Retrieval: use the concrete subject when present. For short follow-ups,
    # inherit the nearest subject-bearing user turn rather than all prior focus
    # vocabulary.
    query = (question or "").strip()
    if cues:
        query = query + " " + " ".join(sorted(cues))
    elif f["terms"]:
        query = query + " " + " ".join(sorted(f["terms"])[:5])
    # Add one nearest user anchor only, not six turns of vocabulary.
    for text in reversed(history_users[:-1]):
        if _subject_cues(text) and len(_terms(text)) >= 2:
            query += " " + text[:180]
            break

    room = budget_chars - used
    if room > 180:
        hits = memory.recall(query, 8)

        # A CUE RANKS. IT DOES NOT GATE.
        #
        # THIS IS THE AMNESIA, AND IT IS ONE BRANCH.
        #
        # The block below used to end `else: hits = []` - if nothing
        # recalled contained the cue as a literal lowercase substring, the
        # entire memory section was thrown away. That was written when
        # _subject_cues() could only return a filename, an extension or one
        # of about thirty technical nouns, so on an ordinary sentence `cues`
        # was empty, `if cues:` was False, and the branch never ran. It was
        # dead code that read like a safety rail.
        #
        # Then named_subjects() was added and cues started matching ANY
        # capitalised word. The dead branch woke up on nearly every turn.
        # From that release onward, memory returned a couple of literal
        # substring matches or nothing at all, unpredictably, which is
        # exactly what it looks like from the outside:
        #
        #     "very broken fragments of tiny chunks of memory scattered
        #      about pretty randomly"
        #
        # Nothing had been deleted. One filter had been switched on.
        #
        #     "Stop severing limbs and correct this, stitch it back on and
        #      allow it to do the things it is built for."
        #
        # So the cue now does what a cue is for: it puts the memories that
        # share the subject FIRST. The rest follow, in relevance order,
        # and the section can no longer become empty because a word did not
        # appear verbatim.
        concrete = {c for c in cues
                    if c not in {"image", "images", "photo", "photograph"}}
        if concrete and hits:
            def _shares(h) -> bool:
                txt = str(h.get("line", "")).lower()
                return any(c in txt for c in concrete)
            hits = ([h for h in hits if _shares(h)]
                    + [h for h in hits if not _shares(h)])

        wants_history = any(k in lowq for k in ("previous", "earlier", "corrected", "correction",
                                                "history", "what did i say", "what changed", "remember"))
        if not wants_history:
            # Superseded is not deleted. It is kept, and it is kept OUT of
            # an ordinary answer - but the timeline still knows it was once
            # true, which is what "was, until" is made of.
            hits = [h for h in hits if h.get("truth") not in {"superseded", "contradicted", "disproven"}]
        if hits:
            add("")
            add(memory.RECALL_HEADING)
            for h in hits[:4]:
                if not add("  - " + memory.remembered_line(h)):
                    break

    # The moving external frontier carries recently ACTIVE memories by weight,
    # without dumping an undifferentiated "learned recently" list.
    try:
        active = memory.active_context(question, max(120, tokens // 3))
        if active:
            add("")
            add(active)
    except Exception:
        pass

    # Do not inject a global "Learned recently" list here. Raw recent
    # conversation is already in the message history and is authoritative for
    # continuity; unrelated durable memories belong in recall, not the tail.
    return "\n".join(out).strip()

def stats() -> dict:
    s = snapshot()
    return {"task": s["task"][:80], "terms": len(s["terms"]),
            "top": sorted(s["terms"], key=lambda t: -s["terms"][t])[:6],
            "since": s["since"]}
