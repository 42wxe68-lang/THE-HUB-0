"""
Starter assets: the catalogue, the installer and core must agree.

These used to read install.py with a regular expression over its source text,
which broke the moment MODEL_SET stopped being a literal - and broke by
raising AttributeError on a None match, which is a test failing for the wrong
reason. They now read the catalogue itself, and check EVERY entry rather than
whichever one happened to be written first.
"""
import ast
import tempfile
from pathlib import Path

import core


def _catalogue() -> dict:
    """
    The asset declarations out of install.py, without running the installer.

    Executing install.py would try to find Windows binaries and a network.
    Only the plain assignments are evaluated, which is all this needs.
    """
    src = Path("install.py").read_text(encoding="utf-8")
    want = {"MODEL_CATALOGUE", "MODEL_SET", "PROJECTOR_SET", "ASSET_SHA256"}
    ns: dict = {}
    for node in ast.parse(src).body:
        if (isinstance(node, ast.Assign) and node.targets
                and getattr(node.targets[0], "id", "") in want):
            exec(compile(ast.Module([node], []), "<install>", "exec"), ns)
    missing = want - set(ns)
    assert not missing, f"install.py no longer declares: {sorted(missing)}"
    return ns


def test_starter_asset_manifest():
    """ASSETS.md documents every model a fresh install downloads."""
    ns = _catalogue()
    text = Path("ASSETS.md").read_text(encoding="utf-8")
    for entry in ns["MODEL_CATALOGUE"]:
        if not entry["install"]:
            continue
        assert entry["repo"] in text, f"{entry['repo']} is undocumented"
        assert entry["model"] in text, f"{entry['model']} is undocumented"
        assert ns["ASSET_SHA256"][entry["model"]] in text, (
            f"the hash for {entry['model']} is not in ASSETS.md")


def test_every_downloaded_asset_is_pinned_by_hash():
    """
    An unverified multi-gigabyte download is a supply chain with no lock on
    it. Anything the installer fetches must have a content hash recorded.
    """
    ns = _catalogue()
    unpinned = [f for _, f, _, _ in ns["MODEL_SET"] + ns["PROJECTOR_SET"]
                if f not in ns["ASSET_SHA256"]]
    assert not unpinned, f"no SHA256 recorded for: {', '.join(unpinned)}"


def test_the_starter_model_is_one_the_installer_actually_fetches():
    """core and install must not disagree about what a fresh install starts on."""
    ns = _catalogue()
    fetched = [f for _, f, _, _ in ns["MODEL_SET"]]
    assert core.PREFERRED_MODEL in fetched, (
        f"core.PREFERRED_MODEL is {core.PREFERRED_MODEL!r} but a fresh "
        f"install downloads {fetched} - it would fetch one model and then "
        f"prefer a different one")


def test_every_model_ships_its_own_projector():
    """
    A vision model whose projector comes from a different repository is a
    pairing waiting to break, and the symptom is 'no vision module' on a
    correct install. Checked for every entry, not just the first.
    """
    import vision
    ns = _catalogue()
    for entry in ns["MODEL_CATALOGUE"]:
        proj = entry.get("projector")
        assert proj, f"{entry['name']} has no projector - it cannot see"
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            (d / entry["model"]).write_bytes(b"0")
            (d / proj).write_bytes(b"0")
            paired = vision.find_projector(d / entry["model"])
            assert paired is not None and paired.name == proj, (
                f"{proj} does not pair with {entry['model']} by name - "
                f"The Hub would report no vision on a correct install")


def test_a_projector_is_never_offered_as_a_language_model():
    ns = _catalogue()
    for entry in ns["MODEL_CATALOGUE"]:
        assert not core.is_projector(entry["model"]), (
            f"{entry['model']} is being treated as a projector")
        assert core.is_projector(entry["projector"]), (
            f"{entry['projector']} would be offered as a language model")


def test_the_catalogue_says_why_each_model_is_there():
    """
    A skipped entry and a forgotten entry look identical without a reason
    written down. Qwen3-VL-4B-Thinking is in this list ON PURPOSE and is not
    downloaded ON PURPOSE, and six months from now that has to still be
    legible.
    """
    ns = _catalogue()
    assert len(ns["MODEL_CATALOGUE"]) >= 2, "a catalogue of one is a choice"
    for entry in ns["MODEL_CATALOGUE"]:
        assert entry.get("why", "").strip(), f"{entry['name']} has no reason"
        assert isinstance(entry["install"], bool)


def test_the_model_that_looped_is_gone():
    """
    Qwen3-VL-4B-Thinking re-read its own context instead of answering:
    "Wait, maybe there's a mix-up. Let me check the user's message again."
    A model that loops does not finish, so it is REMOVED rather than left in
    the list unfetched - leaving it selectable leaves the loop selectable.
    """
    ns = _catalogue()
    for entry in ns["MODEL_CATALOGUE"]:
        assert "Qwen3-VL" not in entry["model"], (
            f"{entry['model']} is still in the catalogue")
    src = Path("install.py").read_text(encoding="utf-8")
    assert "Huihui-Qwen3-VL-4B-Thinking-abliterated.Q4_K_M.gguf" not in [
        f for _, f, _, _ in ns["MODEL_SET"] + ns["PROJECTOR_SET"]]
    assert "repeats" in src, "the reason it was removed is not written down"


def test_the_default_fits_the_card_and_its_cost_is_written_down():
    """
    4 GB of VRAM holds the weights, the projector AND the KV cache, and those
    three compete. This asserted 2600 MB, which the Qwen 2B met and Gemma 4
    E2B does not - Gemma is 3.7 GB with its projector.

    That is a trade the user made deliberately: the smaller model was faster
    and had a bigger window, and it hallucinated. Coherence won. So the
    invariant is no longer a number the choice contradicts - it is that the
    default FITS AT ALL, and that the window it costs is recorded rather than
    discovered later (ADR-71 is what happens when it is not).
    """
    ns = _catalogue()
    entry = next(e for e in ns["MODEL_CATALOGUE"]
                 if e["model"] == core.PREFERRED_MODEL)
    total = entry["model_mb"] + entry.get("projector_mb", 0)
    assert total <= 3900, (
        f"the starter is {total} MB and will not load on a 4096 MB card")
    text = Path("ASSETS.md").read_text(encoding="utf-8")
    assert "context window" in text.lower(), (
        "nothing records what the default costs in context")

    # And whatever the window turns out to be, the two rules that must never
    # be cut are in the part of the sheet that is never cut.
    import budget
    sheet = core.character()
    plan = budget.Plan(4096, 1365, budget.count(sheet))
    kept, _ = budget.fit_character(sheet, plan.character)
    assert "try again" in kept.lower()
    assert "call the tool" in kept.lower()


if __name__ == "__main__":
    import sys, testkit
    sys.exit(testkit.run(dict(globals()),
                         "STARTER ASSETS - catalogue, installer and core agree"))
