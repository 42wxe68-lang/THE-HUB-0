"""
test_naming.py - generated files are named so they can be found again.

WHY THIS MATTERS MORE THAN IT SOUNDS

Everything used to be called generated.png, generated_3d.glb or
source_for_3d.png, so a Playground with a dozen results in it read:

    generated.png
    generated (2).png
    generated (3).png

The user cannot tell those apart. Neither can the model - which is worse,
because it means Nova cannot refer back to one of them without opening every
one, and cannot answer "make the swing picture bigger" at all.

A timestamp orders them and makes them unique. A few content words from the
prompt say which is which.
"""
from __future__ import annotations

import os
import re
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import forge
import tools


STAMP = re.compile(r"^\d{4}-\d{2}-\d{2} \d{4} ")


def test_a_name_carries_the_subject():
    n = forge._describe(
        "a girl sitting on a swing set eating an ice-cream cone in a sunset "
        "on a tropical beach in Hawaii", ".png")
    assert STAMP.match(n), n
    assert n.endswith(".png")
    low = n.lower()
    assert "girl" in low and "swing" in low, n


def test_filler_words_are_dropped():
    n = forge._describe(
        "please generate me an image of a red vintage motorcycle in the rain",
        ".png").lower()
    for junk in ("please", "generate", "image", " of ", " the ", " me "):
        assert junk not in n, f"{junk!r} survived into {n!r}"
    assert "motorcycle" in n and "vintage" in n


def test_two_different_prompts_get_different_names():
    a = forge._describe("Goku in super saiyan form 2", ".png")
    b = forge._describe("a girl on a swing at sunset", ".png")
    assert a != b, "two subjects must not collide"


def test_a_name_is_short_enough_to_read_in_a_list():
    n = forge._describe("a " * 200 + "extremely long rambling prompt", ".png")
    assert len(n) <= 80, f"{len(n)} chars: {n}"


def test_an_empty_prompt_still_produces_a_usable_name():
    n = forge._describe("", ".png")
    assert STAMP.match(n) and n.endswith(".png")
    assert "untitled" in n


def test_the_extension_is_kept():
    for suffix in (".png", ".mp4", ".glb", ".stl"):
        assert forge._describe("a red cube", suffix).endswith(suffix)


def test_a_shape_spec_gets_a_readable_name_too():
    summary = tools._spec_summary(
        {"parts": [{"shape": "box", "holes": [{"at": [1, 1], "d": 5},
                                              {"at": [2, 2], "d": 5}]},
                   {"shape": "cylinder"}]})
    assert "box" in summary and "cylinder" in summary and "2 hole" in summary
    n = forge._describe(summary, ".stl")
    assert "box" in n and n.endswith(".stl"), n


def test_no_generated_placeholder_names_remain_in_the_tools():
    """The whole point is that nothing is called "generated" any more."""
    src = open(os.path.join(_ROOT, "tools.py"), encoding="utf-8").read()
    for dead in ('"generated.png"', '"generated_3d.glb"',
                 '"generated_video.mp4"', '"source_for_3d.png"'):
        assert dead not in src, f"{dead} is still hardcoded in tools.py"


def test_the_preferred_checkpoint_is_not_the_2022_base_weights():
    """A fine-tune beats raw base weights at everything a person asks for."""
    models = [{"name": "stable-diffusion-v1-5-pruned-emaonly-Q8_0.gguf",
               "size_mb": 1682},
              {"name": "dreamshaper-xl-v2-turbo-Q4_K.gguf", "size_mb": 2668}]
    best = forge._preferred_image_model(models)
    assert "dreamshaper" in best["name"].lower(), best["name"]
    # ...but with only the base present it is still used rather than nothing.
    only = forge._preferred_image_model(models[:1])
    assert only is not None and "v1-5" in only["name"]


def test_each_model_family_gets_settings_that_suit_it():
    """
    Running a turbo model at 28 steps and CFG 7 burns the image; running an
    SD1.5 model at 6 steps and CFG 1.5 produces fog. One fixed setting cannot
    serve both, which is what the first build tried to do.
    """
    turbo = forge.model_preset("dreamshaper-xl-v2-turbo-Q4_K.gguf")
    assert turbo["family"] == "sdxl-turbo"
    assert turbo["steps"] <= 10 and turbo["cfg"] <= 3.0
    # 768, NOT 1024, AND NOT 512 EITHER.
    #
    # This asserted 1024 because SDXL is trained there and rendering an SDXL
    # model at SD1.5's 512 is a real mistake. Then 1024 was measured on the
    # target card: 716 seconds for one 8-step render, because 1024 is what
    # forces the VAE decode onto the CPU. 768 is inside SDXL's usable range
    # and is the difference between waiting a minute and waiting twelve.
    #
    # The invariant is "bigger than SD1.5, small enough to finish", not a
    # specific number.
    assert 640 <= turbo["width"] <= 1024, (
        f"{turbo['width']}px: an SDXL model at SD1.5 sizes is soft, and 1024 "
        f"costs twelve minutes on this card")

    sd15 = forge.model_preset("stable-diffusion-v1-5-pruned-emaonly-Q8_0.gguf")
    assert sd15["family"] == "sd15"
    assert sd15["steps"] >= 24, "20 steps was part of why output was poor"
    assert sd15["cfg"] >= 6.0
    assert sd15["width"] == 512, "SD1.5 was trained at 512"
    assert sd15["clip_skip"] == 2

    lcm = forge.model_preset("dreamshaper_8LCM-iq4_nl.gguf")
    assert lcm["sampler"] == "lcm", "an LCM model needs the LCM sampler"


def test_every_preset_carries_a_negative_prompt():
    """
    The single cheapest quality fix there is. The first build sent an EMPTY
    negative prompt, so "bad anatomy, extra fingers, deformed" were all
    perfectly likely completions with nothing pushing against them.
    """
    for name in ("stable-diffusion-v1-5-pruned-emaonly-Q8_0.gguf",
                 "dreamshaper-xl-v2-turbo-Q4_K.gguf",
                 "realisticVision_v6.gguf"):
        neg = forge.model_preset(name)["negative"]
        assert neg and len(neg) > 20, f"{name} has no negative prompt"
        assert "anatomy" in neg or "deformed" in neg, neg


if __name__ == "__main__":
    import testkit
    sys.exit(testkit.run(dict(globals()),
                         "NAMING AND PRESETS - findable files, usable settings"))
