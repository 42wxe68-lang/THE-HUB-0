"""
verify.py - does every subsystem actually work? Answered out loud.

    python verify.py

THE RULE THIS ENFORCES
----------------------
Three words, used consistently everywhere in this project:

    ERROR      a required component is missing or broken
    OPTIONAL   a component that is not installed, and that is fine
    EXCLUDED   a component deliberately left out, with a reason

There is no fourth category, and in particular there is no silent skip. The
recurring failure in this project's history has been a check that quietly
passed over something - a regex flag, a missing fixture, a wrong port, a
fail-open grammar - so that the system looked healthy while a whole
subsystem was doing nothing. A knowledge tree that fails to import and gets
swallowed by a bare `except` is indistinguishable, from the outside, from a
knowledge tree that is working and simply has nothing to say yet.

WHAT IS CHECKED THAT ORDINARY IMPORT TESTS DO NOT
-------------------------------------------------
The two shape mismatches Vera found the hard way, because they are the exact
class of bug that hides:

  * context_for() returns a TUPLE. Anything that treats it as a string puts
    the literal "[None, '']" into the prompt and nothing crashes.
  * grow() takes `domain` as a REQUIRED positional. Calling it with two
    arguments raises TypeError, which a caller's bare except swallows,
    leaving the tree permanently empty while looking connected.

And the claim that makes the event log worth having: that the whole tree can
be rebuilt from history. That is run against a scratch copy every time, so
if it ever stops being true, it is caught here rather than discovered on the
day it is needed.
"""
from __future__ import annotations

import warnings
import shutil
import json
import pathlib
import re
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

C = {"g": "\033[92m", "y": "\033[93m", "r": "\033[91m",
     "d": "\033[90m", "i": "\033[96m", "x": "\033[0m"}

_state = {"errors": 0, "optional": 0, "excluded": 0, "ok": 0, "quiet": False}


def _say(tag: str, colour: str, msg: str) -> None:
    if _state["quiet"] and tag == "ok":
        return
    print(f"  {C[colour]}{tag:9}{C['x']} {msg}")


def ok(msg: str) -> None:
    _state["ok"] += 1
    _say("ok", "g", msg)


def error(msg: str) -> None:
    _state["errors"] += 1
    _say("ERROR", "r", msg)


def optional(msg: str) -> None:
    _state["optional"] += 1
    _say("OPTIONAL", "y", msg)


def excluded(msg: str) -> None:
    _state["excluded"] += 1
    _say("EXCLUDED", "d", msg)


def section(name: str) -> None:
    if not _state["quiet"]:
        print(f"\n{C['i']}{name}{C['x']}")


# ---------------------------------------------------------------- checks

def check_imports() -> None:
    section("Modules")
    required = ["core", "events", "grove", "classify", "memory", "research",
                "policy", "tools", "runtime", "server", "knowledge", "budget",
                "index", "vault", "consolidate", "gguf", "vision"]
    for mod in required:
        try:
            __import__(mod)
            ok(f"{mod}.py imports cleanly")
        except Exception as e:
            error(f"{mod}.py failed to import: {e}")


def check_files() -> None:
    section("Files")
    for name in ("core.py", "server.py", "memory.py", "grove.py", "knowledge.py",
                 "classify.py", "research.py", "policy.py", "tools.py",
                 "runtime.py", "events.py", "budget.py", "index.py",
                 "vault.py", "consolidate.py", "gguf.py", "vision.py", "ui.html",
                 "character.md", "config.json"):
        if (ROOT / name).is_file():
            ok(f"{name}")
        else:
            error(f"{name} is missing")

    import core
    if core.LLAMA_EXE.is_file():
        ok(f"llama-server.exe present ({core.RUNTIME})")
    else:
        error("llama-server.exe missing - run INSTALL.bat")

    models = core.models()
    if models:
        ok(f"{len(models)} model(s): " + ", ".join(m["name"] for m in models[:3]))
    else:
        error("no .gguf model present - run INSTALL.bat")

    if core.WHISPER_EXE.is_file():
        ok("whisper.cpp present (hearing)")
    else:
        optional("whisper.cpp not installed - the mic button will say so")

    # LOOK ON DISK, not in config.
    #
    # This read cfg["runtime"]["mmproj"] - a field that is now "auto" and no
    # longer needs setting. It reported "no multimodal projector" whether or
    # not one was sitting correctly paired in llm/models, and told the user to
    # set a value that does nothing.
    cfg = core.load()
    try:
        import vision
        sel = cfg.get("model") or ""
        projs = list(core.MODELS.glob("*.gguf")) if core.MODELS.is_dir() else []
        projs = [q for q in projs if "mmproj" in q.name.lower()
                 or "proj" in q.name.lower()]
        paired = vision.find_projector(core.MODELS / sel) if sel else None
        if paired:
            ok(f"vision: {sel} pairs with {paired.name}")
        elif projs:
            excluded(f"vision - {len(projs)} projector(s) present but none "
                     f"matches {sel or 'the selected model'}. A projector is "
                     f"architecture-specific; rename it "
                     f"{(sel or 'model')[:-5]}.mmproj.gguf if it does belong "
                     f"to this model.")
        else:
            excluded("vision - no projector in llm/models. Run "
                     "`python get_model.py vision` to see the options, or "
                     "`vision qwen35-9b-vision` to add sight to a Qwen3.5 "
                     "you already have.")
    except Exception as e:
        excluded(f"vision - could not check: {str(e)[:70]}")


def check_isolation() -> None:
    """The Hub must not need, read, or collide with any ancestor."""
    section("Independence")
    import core

    for port, what in ((core.UI_PORT, "interface"), (core.MAIN_PORT, "main model"),
                       (core.CURATOR_PORT, "curator"), (core.EAR_PORT, "ears")):
        owner = core.ANCESTOR_PORTS.get(port)
        if owner:
            error(f"{what} is on port {port}, which {owner} owns - "
                  f"whichever application starts second will fail to bind, "
                  f"and STOP.bat will kill the wrong model")
        else:
            ok(f"{what} on port {port} - The Hub's own")

    # Parse the code rather than grepping it. The first version of this
    # check matched a wrapped line of prose that happened to begin "from
    # Cairn, so a limb is..." and reported a dependency that did not exist.
    # Comments about lineage are the point of this project; imports are the
    # thing that would actually break it.
    import ast
    ANCESTORS = ("cairn", "luminova", "verazero", "vera_core", "lumin")

    # TWO THINGS WERE WRONG WITH THIS CHECK.
    #
    # 1. It collected findings into `bad` and then called ok() unconditionally,
    #    outside any test of `bad`. So it printed "no import or path
    #    references any ancestor application" once per module, forty-four
    #    times, whether or not it had found something - and it had. The check
    #    had never been able to fail.
    #
    # 2. Once it could fail, it failed on the wrong thing. It flagged any
    #    string containing an ancestor name and a slash, which is a fair
    #    description of every module docstring in this project: lineage is
    #    what these files are ABOUT. `memory.py` opens with "the Tree of
    #    Life. Cairn's topology, Luminova's biology" and that sentence is the
    #    documentation working, not a dependency.
    #
    # An import is what would actually break. A path literal only matters if
    # it is shaped like a path: on one line, short, and with the ancestor
    # name sitting directly against a separator - "C:\\CAIRN\\data",
    # "../luminova/tree.json". Docstrings are skipped by identity, not by
    # guesswork.
    def _docstrings(tree):
        found = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                                 ast.AsyncFunctionDef)):
                body = getattr(node, "body", None)
                if (body and isinstance(body[0], ast.Expr)
                        and isinstance(body[0].value, ast.Constant)
                        and isinstance(body[0].value.value, str)):
                    found.add(id(body[0].value))
        return found

    # A separator must actually be present on one side or the other. Anchors
    # alone matched the bare word, so core.py's ANCESTOR_PORTS map - which
    # exists precisely to name the ports Cairn and The Hearth own - reported
    # itself, and so did this function's own ANCESTORS tuple.
    _names = "|".join(ANCESTORS)
    PATHISH = re.compile(rf"[\\/](?:{_names})(?:[\\/]|$)"
                         rf"|(?:^|[\\/])(?:{_names})[\\/]", re.I)

    bad = []
    for f in sorted(ROOT.glob("*.py")):
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            error(f"{f.name} will not parse: {e}")
            continue
        docs = _docstrings(tree)
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for n in node.names:
                    if any(a in n.name.lower() for a in ANCESTORS):
                        bad.append(f"{f.name}: import {n.name}")
            elif isinstance(node, ast.ImportFrom):
                mod = (node.module or "").lower()
                if any(a in mod for a in ANCESTORS):
                    bad.append(f"{f.name}: from {node.module} import ...")
            elif (isinstance(node, ast.Constant)
                  and isinstance(node.value, str)
                  and id(node) not in docs):
                v = node.value
                if ("\n" in v or len(v) > 160) or not PATHISH.search(v):
                    continue
                bad.append(f"{f.name}: path literal {v[:48]!r}")

    if bad:
        for b in bad[:10]:
            error(f"references an ancestor application - {b}")
    else:
        n_files = len(list(ROOT.glob("*.py")))
        ok(f"{n_files} modules: no import or path references Cairn, "
           f"The Hearth, Luminova or Vera")


def check_knowledge() -> None:
    """
    Vera's routing vocabulary, now feeding ONE tree.

    The two shapes that broke silently in Vera are gone as failure modes,
    because nothing calls context_for() or grow() any more - knowledge is a
    limb of the Tree of Life and goes in through memory.learn(). What is
    checked instead is that the routing still works, since that is the part
    that was worth carrying over.
    """
    section("Knowledge routing")
    try:
        import knowledge
        cases = [("explain how gravity works", "science"),
                 ("how do I quantise a gguf for a 4 GB card", "craft"),
                 ("prove the square root of two is irrational", "math"),
                 ("what key is this song in", "art"),
                 ("what did I have for lunch", None)]
        bad = 0
        for q, want in cases:
            got, conf = knowledge.route(q)
            if got == want:
                ok(f"{q[:34]!r} -> {got}")
            else:
                bad += 1
                error(f"{q[:34]!r} routed to {got!r}, expected {want!r}")
        if not bad:
            ok("all four domains route, and unrelated text routes nowhere")
    except Exception as e:
        error(f"knowledge routing failed: {e}")


def check_budget() -> None:
    """The 400. A prompt must never be able to exceed the context window."""
    section("Context budget")
    try:
        import budget
        p = budget.Plan(n_ctx=8192, max_tokens=1024, character_tokens=900)
        total = (p.character + p.frame + p.knowledge + p.recall
                 + p.evidence + p.history + p.reply)
        if total <= 8192 - budget.SAFETY + 1:
            ok(f"allowances sum to {total} inside an 8192 window")
        else:
            error(f"allowances sum to {total}, over an 8192 window")

        small = budget.Plan(n_ctx=2048, max_tokens=4096, character_tokens=900)
        if small.reply <= 2048 // 3 + 1:
            ok("a reply never takes more than a third of the window")
        else:
            error(f"reply allowance {small.reply} in a 2048 window")

        long_text = "\n".join(f"line {i} with some words in it" for i in range(400))
        cut = budget.fit_text(long_text, 100)
        if cut and budget.count(cut) <= 100 and cut.endswith("in it"):
            ok("blocks are trimmed on line boundaries, never mid-sentence")
        else:
            error("fit_text cut mid-line or returned nothing")

        hist = [{"role": "user" if i % 2 == 0 else "assistant",
                 "content": "a fairly long message " * 40} for i in range(40)]
        kept = budget.fit_history(hist, 500)
        if kept and budget.measure(kept) <= 560 and kept[-1] is hist[-1]:
            ok(f"history keeps the newest {len(kept)} turns that fit")
        else:
            error("fit_history kept the wrong turns")
    except Exception as e:
        error(f"budget check failed: {e}")


def check_memory() -> None:
    section("Memory")
    tmp = Path(tempfile.mkdtemp(prefix="hub-verify-"))
    try:
        import core
        saved = (core.DATA, core.TREE, core.ASH, core.EVENTS, core.SESSIONS,
                 core.LOGS, core.WRITABLE)
        core.DATA = tmp / "data"
        core.TREE = core.DATA / "tree"
        core.ASH = core.DATA / "ash"
        core.EVENTS = core.DATA / "events"
        core.SESSIONS = core.DATA / "sessions"
        core.LOGS = core.DATA / "logs"
        core.WRITABLE = (core.DATA, core.TREE, core.ASH, core.EVENTS,
                         core.SESSIONS, core.LOGS)
        core.ensure_dirs()

        import events
        import grove
        import memory
        events.LOG = core.EVENTS / "events.jsonl"
        grove.ASH_FILE = core.ASH / "ash.jsonl"
        memory.YESOD_DIR = core.TREE / "yesod"
        memory.UNSORTED = core.TREE / "unsorted.jsonl"
        memory._loaded = False
        memory._limbs = {}

        memory.graft("keter", "Goes by Zero and builds local AI systems",
                     origin="user", truth="confirmed")
        memory.graft("gevurah", "Everything must run offline", origin="user")
        memory.graft("hod", "The card has 4 GB of VRAM", origin="user")
        if memory.status()["leaves"] == 3:
            ok("memories plant into the living tree")
        else:
            error(f"expected 3 leaves, found {memory.status()['leaves']}")

        if memory.frame():
            ok("the reality frame renders")
        else:
            error("the reality frame came back empty with memories present")

        hits = memory.recall("how much VRAM does the card have", 3)
        if hits and "VRAM" in hits[0]["line"]:
            ok("recall finds the right memory first")
        else:
            error(f"recall returned {[h['line'][:30] for h in hits]}")

        noise = memory.recall("bananas", 3)
        if not noise:
            ok("recall returns nothing when nothing matches")
        else:
            error(f"recall invented {len(noise)} hit(s) for an unrelated query")

        lb = memory.limbs()["hod"]
        lb.age(days=60)
        if grove.ash_count() >= 1:
            ok("faded leaves fall to ash rather than being deleted")
        else:
            error("a faded leaf was lost instead of ashed")

        shutil.rmtree(core.TREE, ignore_errors=True)
        memory._loaded = False
        memory._limbs = {}
        r = memory.rebuild()
        if memory.status()["counts"]["keter"] == 1:
            ok(f"the tree rebuilds from the event log alone ({r['events']} events)")
        else:
            error("rebuild lost identity - the event log is not authoritative")

        (core.DATA, core.TREE, core.ASH, core.EVENTS, core.SESSIONS,
         core.LOGS, core.WRITABLE) = saved
        memory._loaded = False
        memory._limbs = {}
    except Exception as e:
        error(f"memory check failed: {e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def check_sight() -> None:
    """Sight works without any model, and says so when there is none."""
    section("Sight")
    try:
        import vision, tempfile
        from pathlib import Path as _P
        d = _P(tempfile.mkdtemp())
        img = d / "t.png"
        img.write_bytes(vision._solid_png(120, 60, (200, 40, 40)))
        f = vision.image_facts(img)
        if f.get("width") == 120 and f.get("height") == 60:
            ok(f"images are measured with no model ({f.get('reader')})")
        else:
            error("image measurement failed")
        c = (f.get("dominant_colours") or [{}])[0].get("colour")
        if c in ("red", "dark red"):
            ok(f"colour is measured, not described - got {c}")
        else:
            error(f"colour measurement wrong: {c}")
        # Checks the PROPERTY, not the phrasing: measurements present, and
        # a plain statement that nothing looked. The sentence now also names
        # the command that would fix it, which is more use than the wording
        # this used to match on.
        r = vision.look(img, "", "")
        txt = r["text"]
        measured = "120x60" in txt and "red" in txt.lower()
        honest = r["via"] == "measured" and (
            "could look at this image" in txt or "vision model" in txt)
        if measured and honest:
            ok("with nothing able to see, it measures and says so")
        else:
            error(f"a blind model could pass off a description as a look "
                  f"(via={r['via']})")
        cap = vision.capability()
        if "sees" in cap:
            ok(f"capability is probed, not configured (now: {cap['sees']})")
    except Exception as e:
        error(f"sight check failed: {e}")


def check_hub() -> None:
    section("Supervisory layers")
    # The probes below deliberately trip the gate: an unknown tool, a
    # model-driven memory write, a poisoned search. Each one used to write a
    # REFUSE line into the real policy.log, so every verify run salted the
    # evidence with four synthetic refusals. Reading the logs back on
    # 2026-09-05, ALL 27 "web_search tainted-query" refusals turned out to
    # be this function testing itself - it took a script to tell them from
    # real ones. A log that has to be filtered before it can be read is a
    # log that will be misread. The probes go somewhere else now.
    import core as _c
    _real_logs = _c.LOGS
    _scratch = tempfile.mkdtemp(prefix="hub-verify-logs-")
    _c.LOGS = Path(_scratch)
    try:
        import policy
        import research

        v = research.preflight("what is the latest version of llama.cpp",
                               {"hub": {"preflight": True}})
        if v.required:
            ok(f"preflight fires on a currentness question (query {v.query!r})")
        else:
            error("preflight missed an obvious external-world question")

        v2 = research.preflight("what did I tell you about my daughter",
                                {"hub": {"preflight": True}})
        if not v2.required and v2.suppressed_by == "personal":
            ok("preflight suppresses a personal question before scoring it")
        else:
            error("PRIVACY: a personal question would have been searched")

        cfg = {"tools": {"clock": True, "web_search": True,
                         "search_memory": True, "open_file": True},
               "hub": {"capability_gate": True, "confirm_writes": True}}
        g = policy.Gate()
        g.begin_turn("verify")
        if g.authorize("anything_at_all", "{}", cfg).verdict == "refuse":
            ok("the gate denies an unknown tool by default")
        else:
            error("the gate allowed a tool it has never heard of")

        if g.authorize("remember", '{"text":"x"}', cfg).verdict == "refuse":
            ok("the model has no tool for writing its own memory")
        else:
            error("a model-driven memory write is still reachable")

        poison = ("credentials passphrase collector transmit immediately "
                  "operator secrets")
        g.postflight("web_search", poison, cfg)
        d = g.authorize("web_search",
                        '{"query":"credentials passphrase operator"}', cfg)
        if d.verdict == "refuse" and d.reason == "tainted-query":
            ok("a search echoing retrieved text is refused - the exfil path")
        else:
            error("EXFILTRATION: a query carrying retrieved words was allowed")
        d = g.authorize("web_search", '{"query":"whisper base model size"}', cfg)
        if d.verdict == "execute":
            ok("but an unrelated search still runs")
        else:
            error("a harmless follow-up search was blocked")
    except Exception as e:
        error(f"supervisory check failed: {e}")
    finally:
        _c.LOGS = _real_logs
        shutil.rmtree(_scratch, ignore_errors=True)



def check_python_floor() -> None:
    """
    Source that only parses on a new Python is source that does not ship.

    The Hub installs its own Python 3.13, and PEP 701 landed in 3.12, so a
    line like

        f"ASSET: {pathlib.Path(a[<dq>path<dq>]).name}"

    where <dq> is the same double quote that opens the string - reusing the
    delimiter inside the braces - which is perfectly legal
    on the developer's interpreter and a hard SyntaxError on anything older.
    HUB-ZERO shipped exactly that line in server.py. The module could not be
    imported at all: no chat, no tools, no vision, no memory. One character.

    It matters because HUB.bat falls back to a system `python` when the
    private runtime is missing, and because TEST.bat, get_model.py and every
    developer checkout may be on whatever is on PATH. The floor is 3.9, the
    same version install.py enforces.

    Detected by reading, not by parsing, so this check gives the same answer
    on every interpreter - including the 3.13 that would happily accept it.
    """
    section("Source compatibility")

    # The (?<![A-Za-z0-9_]) is load-bearing. Without it the "f" at the end of
    # an ordinary identifier counts as an f-string prefix, and the line
    #     "pass_off": {"tier": AUTO, "network": False},
    # reports itself: pass_off ends in f, the quote after it looks like the
    # opening delimiter, and the dict braces that follow look like an
    # interpolation full of quotes. A checker that cries wolf on a policy
    # table is a checker somebody turns off.
    NESTED_FSTRING = re.compile(
        r"""(?<![A-Za-z0-9_])(?:f|F)(?:r|R)?(?P<q>"|')"""
        r"""(?P<body>(?:[^\\{}]|\\.|\{\{|\}\})*?)"""
        r"""\{(?P<expr>[^{}]*?)\}""", re.S)

    floor = (3, 9)
    bad = []
    for f in sorted(ROOT.glob("*.py")):
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if "f\"" not in line and "f'" not in line:
                continue
            for m in NESTED_FSTRING.finditer(line):
                if m.group("q") in m.group("expr"):
                    bad.append((f.name, i, m.group("q"), line.strip()[:90]))

    if bad:
        for name, line_no, q, snippet in bad[:8]:
            error(f"{name}:{line_no} reuses {q} inside an f-string expression - "
                  f"PEP 701, needs Python 3.12+, floor is "
                  f"{floor[0]}.{floor[1]}")
            _say("", "d", f"    {snippet}")
    else:
        n = len(list(ROOT.glob("*.py")))
        ok(f"{n} modules use no syntax newer than Python "
           f"{floor[0]}.{floor[1]}")

    if sys.version_info < floor:
        error(f"this interpreter is {sys.version.split()[0]}; "
              f"the floor is {floor[0]}.{floor[1]}")
    else:
        ok(f"running on Python {sys.version.split()[0]}")


def check_name_resolution() -> None:
    """
    Every module a function reaches for is actually in scope where it runs.

    THIS HAS NOW COST TWO RELEASES.

    install.py used `core` in a block that never imported it, inside a broad
    `except Exception`, so it raised on every run and came out as a vague
    one-line vision notice (ADR-42). Then tools.py used `playground` in four
    functions and imported it at the top of none of them:

        3D GENERATION FAILED: name 'playground' is not defined

    which the model reported to the user as a capability limit and then
    repeated for the rest of the session. A missing import became "I do not
    have the resources for that".

    Python cannot catch this at import time - the name is only looked up when
    the line executes, and these lines execute rarely, usually inside an
    except that swallows the result. So it is checked here, statically,
    before it ships.

    Only first-party modules are checked. A missing standard-library import
    is caught the first time anything runs; a missing sibling module is the
    one that hides.
    """
    section("Name resolution")
    import ast

    ours = {f.stem for f in ROOT.glob("*.py")}
    problems = []
    for f in sorted(ROOT.glob("*.py")):
        # AND ANY WARNING PARSING RAISES.
        #
        # A Windows path typed into a docstring - data\sessions\s2026... -
        # makes \s an invalid escape sequence. Python still runs it, but
        # every ast.parse of that file prints
        #
        #     <unknown>:424: SyntaxWarning: invalid escape sequence '\s'
        #
        # and these checks parse every file, so two of those appeared in the
        # middle of the user's install log with no filename attached. A
        # warning nobody can trace is worse than no warning; caught here,
        # with the file named.
        import warnings as _w
        try:
            with _w.catch_warnings(record=True) as caught:
                _w.simplefilter("always")
                tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
            for item in caught:
                if "escape sequence" in str(item.message):
                    problems.append(f"{f.name} {item.message} - use a raw "
                                    f"string (r\"...\") or forward slashes")
        except Exception:
            continue

        module_level = set()
        for n in tree.body:
            if isinstance(n, ast.Import):
                for a in n.names:
                    module_level.add(a.asname or a.name.split(".")[0])
            elif isinstance(n, ast.ImportFrom):
                for a in n.names:
                    module_level.add(a.asname or a.name)
            elif isinstance(n, (ast.Assign, ast.AugAssign, ast.AnnAssign)):
                for t in ast.walk(n):
                    if isinstance(t, ast.Name) and isinstance(t.ctx, ast.Store):
                        module_level.add(t.id)

        # ENCLOSING SCOPES COUNT, because closures are not a bug.
        #
        # This treated every function as if it stood alone, so a nested
        # helper reading a name its parent imported was reported as a
        # NameError waiting to happen. It is not - Python resolves it as a
        # free variable, and it works. A checker that cries wolf is a checker
        # somebody switches off, which would have cost more than the bug it
        # was written to catch.
        parent = {}
        for node in ast.walk(tree):
            for child in ast.iter_child_nodes(node):
                parent[child] = node

        def _bound_in(fn_node):
            """Names this function binds: arguments, imports, assignments."""
            names = {a.arg for a in fn_node.args.args + fn_node.args.kwonlyargs}
            if fn_node.args.vararg:
                names.add(fn_node.args.vararg.arg)
            if fn_node.args.kwarg:
                names.add(fn_node.args.kwarg.arg)
            for n in ast.walk(fn_node):
                if isinstance(n, ast.Import):
                    for a in n.names:
                        names.add(a.asname or a.name.split(".")[0])
                elif isinstance(n, ast.ImportFrom):
                    for a in n.names:
                        names.add(a.asname or a.name)
                elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                    names.add(n.id)
            return names

        for fn in [n for n in ast.walk(tree)
                   if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
            in_scope = set(module_level)
            up = parent.get(fn)
            while up is not None:
                if isinstance(up, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    in_scope |= _bound_in(up)
                up = parent.get(up)
            for a in fn.args.args + fn.args.kwonlyargs:
                in_scope.add(a.arg)
            for n in ast.walk(fn):
                if isinstance(n, ast.Import):
                    for a in n.names:
                        in_scope.add(a.asname or a.name.split(".")[0])
                elif isinstance(n, ast.ImportFrom):
                    for a in n.names:
                        in_scope.add(a.asname or a.name)
                elif isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
                    in_scope.add(n.id)

            reached = {n.value.id for n in ast.walk(fn)
                       if isinstance(n, ast.Attribute)
                       and isinstance(n.value, ast.Name)}
            for name in sorted((reached & ours) - in_scope):
                problems.append(f"{f.name}:{fn.lineno} {fn.name}() uses "
                                f"{name}.* with no import in scope")

    if problems:
        for line in problems[:10]:
            error(f"NameError waiting to happen - {line}")
        if len(problems) > 10:
            error(f"...and {len(problems) - 10} more")
    else:
        n = len(list(ROOT.glob("*.py")))
        ok(f"{n} modules: every first-party name a function reaches for is "
           f"in scope")


def _always_leaves(stmts) -> bool:
    """
    True if this block can never fall off its end - it always raises,
    returns, breaks or continues.

    Deliberately conservative. Anything it is not sure about is False, so
    the check below only ever reports code that is provably unreachable.
    """
    import ast
    if not stmts:
        return False
    last = stmts[-1]
    if isinstance(last, (ast.Raise, ast.Return, ast.Break, ast.Continue)):
        return True
    if isinstance(last, ast.If):
        return (bool(last.orelse)
                and _always_leaves(last.body)
                and _always_leaves(last.orelse))
    if isinstance(last, ast.With):
        # A `with` whose body always leaves, leaves - unless __exit__
        # swallows the exception, which nothing here does.
        return _always_leaves(last.body)
    if isinstance(last, ast.Try):
        if last.handlers or last.orelse:
            return False
        return _always_leaves(last.body) or _always_leaves(last.finalbody)
    if isinstance(last, ast.Match):
        return bool(last.cases) and all(
            _always_leaves(c.body) for c in last.cases)
    return False


def check_dead_code() -> None:
    """
    Nothing sits after a block that can never fall through to it.

    THE TAIL THE FALLBACK LEFT BEHIND.

    Removing the relief fallback from _generate_3d meant replacing it with a
    `raise` at the end of a `with` block. The code that used to run after
    that `with` - four lines that save `tris` to a file - stayed exactly
    where it was, now unreachable, still referring to a variable that no
    longer exists on any path that reaches it.

    Nothing complained. It parses. It imports. The name-resolution check
    passes it too, and that near miss is the interesting part: `tris` IS
    bound in this function, in the shape-spec branch two hundred lines
    above, so a check that asks "is this name bound anywhere in the
    function" says yes. It would have shipped, and the first person to
    delete the spec route would have found it.

    Unreachable code is not merely untidy. It is the residue of a removal
    that was not finished, and it is the shape a half-reverted decision
    takes. Python has no warning for it, so it is checked here.
    """
    section("Dead code")
    import ast

    problems = []
    for f in sorted(ROOT.glob("*.py")):
        if f.name.startswith("test_") or f.name == "verify.py":
            continue
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                tree = ast.parse(f.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            for field in ("body", "orelse", "finalbody"):
                block = getattr(node, field, None)
                if not isinstance(block, list):
                    continue
                for i, st in enumerate(block[:-1]):
                    if _always_leaves([st]):
                        nxt = block[i + 1]
                        where = getattr(node, "name", type(node).__name__)
                        problems.append(
                            f"{f.name}:{nxt.lineno} in {where} - "
                            f"unreachable, the {type(st).__name__.lower()} "
                            f"above it always leaves")
    if problems:
        for p in problems[:12]:
            error(p)
        if len(problems) > 12:
            error(f"...and {len(problems) - 12} more")
    else:
        ok("no unreachable statements in any module")


def check_tool_surface() -> None:
    """
    Every argument the model can see, the gate has been told about.

    The gate refuses any argument that is not in its own declared shape for
    that tool. So the schema the model reads and the shape the gate enforces
    are two halves of one contract, kept in two files, with nothing joining
    them. They drifted, and the drift was invisible: both files were valid,
    every test passed, and the only symptom was Nova saying she could not do
    things she was built to do.

        generate_3d  {"spec": {...}}   ->  Refused: unexpected argument: spec
        generate_video {"width": 512}  ->  Refused: unexpected argument: width
        generate_image {"input_image"} ->  Refused: unexpected argument
        web_search_more {"query": ...} ->  Refused: unexpected argument

    The spec route for 3D needs no download and cannot fail; it was the
    always-works path, and it was unreachable. Video was never once
    attempted. Image-to-image never ran. Nova reported all of it as her own
    limitation, because from where she stands that is exactly what it looks
    like.

    A missing declaration is a capability the user paid for and never got.
    So this compares them directly, both ways: an argument in the schema and
    not in the gate is refused in the field; one in the gate and not in the
    schema is dead weight nobody will ever send.
    """
    section("Tool surface")
    try:
        sys.path.insert(0, str(ROOT))
        import tools, policy
    except Exception as e:
        error(f"could not load the tool surface: {e}")
        return

    missing, dead, unshaped = [], [], []
    for name, spec in sorted(tools.REGISTRY.items()):
        params = (((spec.get("schema") or {}).get("function") or {})
                  .get("parameters") or {})
        shown = set((params.get("properties") or {}).keys())
        gate = policy.ARGS.get(name)
        if gate is None:
            unshaped.append(name)
            continue
        for key in sorted(shown - set(gate)):
            missing.append(f"{name}({key})")
        for key in sorted(set(gate) - shown):
            dead.append(f"{name}({key})")

        # A required argument the gate does not insist on is a weaker check
        # than advertised, not a failure. A gate requirement the schema never
        # mentions IS a failure: the model cannot know to send it.
        for key, rule in gate.items():
            if rule.get("required") and key not in shown:
                missing.append(f"{name}({key}, required by the gate and "
                               f"never shown to the model)")

    if unshaped:
        error("no argument shape declared, so every call is refused: "
              + ", ".join(unshaped[:6]))
    if missing:
        error("the model is shown arguments the gate will refuse: "
              + ", ".join(missing[:8]))
        if len(missing) > 8:
            error(f"...and {len(missing) - 8} more")
    if dead:
        error("the gate allows arguments no tool advertises: "
              + ", ".join(dead[:8]))
    if not (missing or dead or unshaped):
        n = len(tools.REGISTRY)
        ok(f"{n} tools: what the model is shown and what the gate accepts "
           f"are the same list")


def check_clean_tree() -> None:
    """
    Is this an INSTALLED Hub, or a release candidate about to be zipped?

    The two want opposite things from the same directory, and the first
    version of this check did not ask which it was looking at.

    On a release candidate, files in data/ are somebody else's work that
    would ship to a stranger - a build once went out with twenty-nine copies
    of `script (N).py` in the Vault and a used event log, which means a fresh
    install would have opened already remembering a machine that was not
    theirs.

    On an INSTALLED Hub, those same files are the entire point of the
    application. Sessions, memories, generated pictures - that is the user's
    history, and it is supposed to survive every update and reinstall.

    The first version treated the second case as the first. It ran as part of
    INSTALL.bat, found the user's own conversations and generated images
    exactly where they belong, called them "state that is not the user's",
    and failed the install of a perfectly healthy machine. That is the worst
    kind of check: one that is loudest when everything is right.

    So it asks first. A tree with models in llm/models is installed and in
    use, and its data is reported as an asset, never as a fault. Only a tree
    with no install at all can be a release candidate, and only there does
    leftover content matter.
    """
    section("Data")

    # Imported here, like every other check in this file does it - and NOT
    # wrapped in a bare `except Exception`. The last time a missing `core`
    # sat inside one of those it produced the "no vision module" report that
    # took three sessions to find (ADR-42). check_name_resolution() caught
    # this one statically before it ran, which is what it is for.
    import core
    models = core.MODELS
    installed = models.is_dir() and any(models.glob("*.gguf"))

    data = ROOT / "data"

    def _count(name: str) -> int:
        d = data / name
        if not d.is_dir():
            return 0
        return sum(1 for f in d.rglob("*") if f.is_file() and f.name != ".keep")

    counts = {n: _count(n) for n in
              ("sessions", "tree", "knowledge", "ash", "playground", "events")}

    # ---------------------------------------------------------- installed
    if installed:
        # NOTHING HERE IS EVER AN ERROR. This is the user's history and the
        # reason the application exists; an update that treats it as debris
        # is an update that deletes the thing it was meant to carry forward.
        kept = ", ".join(f"{v} {k}" for k, v in counts.items() if v)
        if kept:
            ok(f"your history is here and untouched by this update: {kept}")
        else:
            ok("installed, with nothing remembered yet - that is a first run, "
               "not a fault")
        try:
            import playground
            mb = playground.size_mb()
            if mb > playground.CAP_MB:
                excluded(f"the Playground holds {mb:.0f} MB. Nothing is "
                         f"deleted automatically. Keep what you want with "
                         f"Nova's offer, then Settings -> Erase Memory -> "
                         f"Playground files clears the rest.")
        except Exception:
            pass
        return

    # ------------------------------------------------------ release tree
    #
    # AN EMPTY SCAFFOLD IS NOT SOMEBODY'S CONTENT.
    #
    # data/tree/hod.json exists the moment anything touches memory, because
    # the permanent limbs - observations, people known, environment, studies
    # - are created up front and are supposed to be there. Every one of them
    # then reads `"leaves": []`. Counting the FILE reported six errors and
    # "it is carrying somebody's content" on a tree carrying nothing, which
    # is the ADR-96 fault exactly: a check that is loudest when everything is
    # right, wired into INSTALL.bat.
    #
    # So this asks what is INSIDE, the same way the branch above asks what
    # the tree IS. A leaf is something a person said. No leaves, no content.
    def _holds_anything(f: pathlib.Path) -> bool:
        if f.suffix.lower() != ".json":
            return True                      # not ours to interpret - flag it
        try:
            blob = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            return True                      # unreadable: err towards flagging
        found = []

        def walk(node):
            if isinstance(node, dict):
                for k, v in node.items():
                    if k in ("leaves", "entries", "facts", "items") \
                            and isinstance(v, list):
                        found.extend(v)
                    else:
                        walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)
        walk(blob)
        return bool(found)

    dirty = [str(f.relative_to(ROOT))
             for n in ("ash", "knowledge", "playground", "sessions", "tree")
             for f in (data / n).rglob("*")
             if (data / n).is_dir() and f.is_file() and f.name != ".keep"
             and (n not in ("tree", "knowledge") or _holds_anything(f))]

    made = ROOT / "vault" / "Made"
    if made.is_dir():
        dirty += [str(f.relative_to(ROOT)) for f in made.rglob("*")
                  if f.is_file() and f.name.lower() != "read me.txt"]

    vault_dir = ROOT / "vault"
    if vault_dir.is_dir():
        import re as _re
        dupes = [f.name for f in vault_dir.glob("*")
                 if f.is_file() and _re.search(r" \(\d+\)\.[A-Za-z0-9]+$", f.name)]
        if len(dupes) > 2:
            dirty.append(f"{len(dupes)} numbered duplicates in vault/ "
                         f"(e.g. {dupes[0]})")

    noted = [str(f.relative_to(ROOT))
             for n in ("logs", "events")
             for f in (data / n).rglob("*")
             if (data / n).is_dir() and f.is_file() and f.name != ".keep"]

    if dirty:
        for line in dirty[:8]:
            error(f"no model is installed, so this looks like a release tree "
                  f"- and it is carrying somebody's content: {line}")
        if len(dirty) > 8:
            error(f"...and {len(dirty) - 8} more")
    else:
        ok("no install present and no leftover content - safe to package")
    if noted:
        excluded(f"{len(noted)} log/event file(s) in data/ - clear them before "
                 f"packaging; the event log is what a fresh install would "
                 f"rebuild memory from")


def check_branding() -> None:
    """
    No ancestor's name is presented to the user as this application's own.

    Plain "HUB-ZERO" was renamed twice and the installer still greeted people
    with it, because the banner was letter-spaced:

        H U B - Z E R O   -   local AI, assembled in one pass

    A substitution pass looking for "HUB-ZERO" walks straight past that, and
    so does a grep. verify.py's own banner had the identical bug with
    "T H E   H E A R T H". So this strips spacing before comparing - the same
    text a person reads, not the text as it happens to be typed.

    Comments and documentation are exempt: lineage is what half of this
    project's documentation is ABOUT, and ADR-43 exists precisely to explain
    where the ports came from. Only strings shown to a user count.
    """
    section("Branding")
    import ast

    OLD = ("hubzero", "thehearth", "hearth", "cairn", "luminova", "verazero")

    # Two deliberate exceptions, both of which NAME an ancestor in order to
    # avoid it rather than to impersonate it:
    #   core.ANCESTOR_PORTS  - the map of ports Cairn and The Hearth own, which
    #                          is how verify reports a collision by name.
    #   the suites and this file - their labels quote the old names on purpose.
    EXEMPT_FILES = {"verify.py"}
    bad = []
    for f in sorted(ROOT.glob("*.py")):
        if f.name in EXEMPT_FILES or f.name.startswith("test"):
            continue
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue

        exempt = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(
                    getattr(t, "id", "") == "ANCESTOR_PORTS" for t in node.targets):
                for sub in ast.walk(node):
                    if isinstance(sub, ast.Constant):
                        exempt.add(id(sub))

        docs = set()
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                                 ast.AsyncFunctionDef)):
                body = getattr(node, "body", None)
                if (body and isinstance(body[0], ast.Expr)
                        and isinstance(body[0].value, ast.Constant)
                        and isinstance(body[0].value.value, str)):
                    docs.add(id(body[0].value))
        for node in ast.walk(tree):
            if (isinstance(node, ast.Constant)
                    and isinstance(node.value, str)
                    and id(node) not in docs
                    and id(node) not in exempt):
                flat = re.sub(r"[\s\-_]", "", node.value).lower()
                for old in OLD:
                    if old in flat:
                        bad.append(f"{f.name}:{getattr(node, 'lineno', '?')} "
                                   f"{node.value.strip()[:56]!r}")
                        break

    # ui.html is markup, not code: compare its visible text the same way.
    ui = ROOT / "ui.html"
    if ui.is_file():
        text = re.sub(r"<!--.*?-->", "", ui.read_text(encoding="utf-8",
                                                      errors="replace"), flags=re.S)
        text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
        flat = re.sub(r"[\s\-_]", "", text).lower()
        for old in ("hubzero",):
            if old in flat:
                bad.append(f"ui.html contains {old!r} in visible text")

    if bad:
        for b in bad[:8]:
            error(f"an ancestor's name is shown to the user - {b}")
    else:
        ok(f"nothing shown to the user names HUB-ZERO, The Hearth or Cairn "
           f"(spacing ignored)")


def check_suites() -> None:
    section("Test suites")
    import subprocess
    # EVERY test_*.py IN THE FOLDER, NOT A HAND-KEPT LIST.
    #
    # This list named five scripts. The folder held twelve. test_model3d,
    # test_generators, test_imagegen, test_assets, test_theme,
    # test_active_memory, test_playground and test_workspace_shared were
    # never run by verify.py and only two of them by TEST.bat - so
    # test_model3d had been failing on a missing library, and three others
    # had been exiting 0 without executing a single assertion, and nothing
    # on the machine was in a position to say so.
    #
    # A suite that is not discovered is a suite that does not exist. The
    # named entries below set the reporting order for the ones people look
    # at first; everything else on disk is picked up automatically.
    named = (("placement", "classify.py"),
             ("research", "test_research.py"),
             ("hub scenarios", "test_hub.py"),
             ("live wiring", "test_live.py"),
             ("interface", "test_ui.py"))
    seen = {script for _, script in named}
    discovered = tuple(
        (f.stem.replace("test_", "").replace("_", " "), f.name)
        for f in sorted(ROOT.glob("test_*.py")) if f.name not in seen)

    # NO SUITE MAY WRITE INTO THE USER'S VAULT.
    #
    # test_playground.py redirected core.DATA and forgot vault.VAULT, so
    # every run left note.txt, script.py and another numbered copy in the
    # release tree - a build shipped with twenty-nine of them. On a real
    # install that is a test writing into the one directory the entire
    # application is built never to touch.
    #
    # Snapshotted around the whole run rather than trusted to review.
    # The Playground is the same fault one directory over: test_model3d.py
    # exercised model3d.convert(), whose real contract is to write into the
    # Playground, and left box.obj / box.ply / box.stl in the release tree
    # every run. Both are watched.
    # A TEST DEFINED AFTER THE RUNNER NEVER RUNS.
    #
    # `if __name__ == "__main__": sys.exit(testkit.run(dict(globals())))`
    # executes at that point in the file. Three tests appended below it were
    # defined afterwards, so globals() had never seen them: the suite
    # reported 29 passed and quietly skipped them. This is the same family
    # as the pytest files that exited 0 having executed nothing (ADR-45) -
    # a test that does not run is a test that does not exist.
    import ast as _ast
    for f in sorted(ROOT.glob("test_*.py")):
        try:
            tree = _ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        guard = next((n.lineno for n in tree.body
                      if isinstance(n, _ast.If)
                      and "__main__" in _ast.dump(n.test)), None)
        if guard is None:
            continue
        after = [n.name for n in tree.body
                 if isinstance(n, (_ast.FunctionDef, _ast.AsyncFunctionDef))
                 and n.name.startswith("test_") and n.lineno > guard]
        if after:
            error(f"{f.name}: {len(after)} test(s) defined AFTER the runner "
                  f"and never executed (first: {after[0]})")

    # THE TREE IS WATCHED TOO NOW.
    #
    # A suite redirected memory.YESOD_DIR and not core.TREE, so a fixture
    # leaf - "the GTX 1650 card has 4 GB of VRAM" - was written into the
    # shipped data/tree/hod.json and would have installed on a stranger's
    # machine as one of their own memories. The Vault and the Playground
    # were watched because that had happened there before; the tree was not,
    # because it had not happened yet. That is the wrong reason to choose
    # what to watch.
    # data/active is watched for the same reason the tree is, and it was
    # added for the same reason: a suite redirected core.DATA and not
    # memory.ACTIVE_DIR, which is bound to core.DATA at import, so a
    # fixture's turns were written into the shipped build's active memory
    # while every watched directory stayed clean. "It has not happened
    # here yet" is the wrong reason to choose what to watch.
    watched = [ROOT / "vault", ROOT / "data" / "playground",
               ROOT / "data" / "tree", ROOT / "data" / "knowledge",
               ROOT / "data" / "ash", ROOT / "data" / "sessions",
               ROOT / "data" / "active"]

    def _snapshot():
        out = {}
        for d in watched:
            out[d] = ({str(f.relative_to(d)) for f in d.rglob("*")}
                      if d.is_dir() else set())
        return out

    before = _snapshot()

    for name, script in named + discovered:
        path = ROOT / script
        if not path.is_file():
            error(f"{name} suite missing ({script})")
            continue
        r = subprocess.run([sys.executable, str(path)], capture_output=True,
                           text=True, cwd=str(ROOT), timeout=240)
        tail = [l for l in (r.stdout or "").strip().splitlines() if l.strip()]
        summary = next((l for l in reversed(tail)
                        if "passed" in l or "cases" in l or "PASS" in l),
                       tail[-1] if tail else "")
        if r.returncode == 0:
            ok(f"{name}: {summary.strip()}")
        else:
            error(f"{name} FAILED: {summary.strip()}")

    after = _snapshot()
    left = [(d.name, f) for d in watched
            for f in sorted(after[d] - before[d])]
    if left:
        for where, f in left[:6]:
            error(f"a test suite wrote into the shipped {where}: {f}")
        if len(left) > 6:
            error(f"...and {len(left) - 6} more")
    else:
        ok("no suite wrote into the Vault, the Playground or the tree")


# ---------------------------------------------------------------- run

def run(quiet: bool = False) -> bool:
    _state.update({"errors": 0, "optional": 0, "excluded": 0, "ok": 0,
                   "quiet": quiet})
    check_files()
    check_imports()
    check_isolation()
    check_python_floor()
    check_branding()
    check_name_resolution()
    check_dead_code()
    check_tool_surface()
    check_clean_tree()
    check_memory()
    check_knowledge()
    check_budget()
    check_sight()
    check_hub()
    if not quiet:
        check_suites()

    print()
    e, o, x, k = (_state["errors"], _state["optional"], _state["excluded"],
                  _state["ok"])
    if e:
        print(f"  {C['r']}{e} ERROR(S){C['x']}   {k} ok   {o} optional   {x} excluded")
        print(f"  {C['r']}The Hub is not ready. Fix the errors above.{C['x']}")
    else:
        print(f"  {C['g']}{k} checks passed{C['x']}   "
              f"{o} optional   {x} excluded   {C['g']}0 errors{C['x']}")
    return e == 0


if __name__ == "__main__":
    try:
        import os
        os.system("")
    except Exception:
        pass
    print()
    print("  T H E   H U B   -   verification")
    raise SystemExit(0 if run() else 1)
