"""
get_model.py - add a model to The Hub.

    Download one from Hugging Face:
        python get_model.py <repo> <file> [--as NAME] [--sha256 HASH]

    Copy one you already have on this machine:
        python get_model.py --import "C:\\path\\to\\model.gguf" [--as NAME]
        python get_model.py --import "C:\\path\\to\\folder" --all

Example:
    python get_model.py LiquidAI/LFM2.5-1.2B-Instruct-GGUF LFM2.5-1.2B-Instruct-Q4_K_M.gguf

Find exact filenames at  https://huggingface.co/<repo>/tree/main
Use --as to give a cryptic upload a readable name in the model dropdown.

WHY IMPORT IS A COPY AND NOT A LINK
-----------------------------------
The Hub's rule is that everything it needs lives in its own folder, so
that copying the folder copies the application and its mind together. A
junction or a symlink into another application's model directory breaks
that: The Hub would start failing the day the other folder moved, and
the failure would look like a Hub bug.

So --import copies. It costs disk and buys independence, and if you would
rather not spend the disk, --move is there and says exactly what it does.

The destination goes through core.under(), so a filename containing
separators or traversal cannot write outside llm/models.
"""
from __future__ import annotations

# ---------------------------------------------------------------------------
# The Hub ships with a private embedded Python (.runtime\python). An embedded
# distribution carries a ._pth file, which puts the interpreter in isolated
# mode - and in isolated mode the script's own directory is NOT placed on
# sys.path. Every `import core` in this file would then fail on a machine that
# has no system Python, one step after a successful install.
#
# One line, at the top, before any first-party import.
# ---------------------------------------------------------------------------
import os as _os
import sys as _sys
_ROOT = _os.path.dirname(_os.path.abspath(__file__))
if _ROOT not in _sys.path:
    _sys.path.insert(0, _ROOT)

import argparse
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path

import core


def _dest_for(name: str):
    if not name.lower().endswith((".gguf", ".bin")):
        print(f"Refusing: {name!r} is not a .gguf or ggml .bin file.")
        return None
    try:
        return core.under(core.MODELS, name)
    except core.Denied as e:
        print(f"Refusing: {e}")
        return None


def import_local(src: Path, rename: str | None, move: bool, take_all: bool) -> int:
    core.MODELS.mkdir(parents=True, exist_ok=True)

    if src.is_dir():
        if not take_all:
            print(f"{src} is a folder. Add --all to bring in every model in it,")
            print("or name a single file.")
            return 1
        files = sorted(list(src.glob("*.gguf")) + list(src.glob("ggml-*.bin")))
        if not files:
            print(f"No .gguf or ggml-*.bin files in {src}")
            return 1
        total = sum(f.stat().st_size for f in files) / 2**30
        print(f"{len(files)} model(s), {total:.1f} GB total")
        free = shutil.disk_usage(core.ROOT).free / 2**30
        if not move and free < total + 2:
            print(f"Refusing: only {free:.1f} GB free, this needs {total + 2:.1f} GB.")
            print("Use --move to relocate them instead of copying.")
            return 1
        n = 0
        for f in files:
            n += 0 if import_local(f, None, move, False) else 1
        print(f"\n{n} of {len(files)} brought in.")
        return 0 if n else 1

    if not src.is_file():
        print(f"Not found: {src}")
        return 1

    dest = _dest_for(rename or src.name)
    if dest is None:
        return 1
    if dest.exists():
        print(f"Already present: {dest.name}")
        return 1

    gb = src.stat().st_size / 2**30
    free = shutil.disk_usage(core.ROOT).free / 2**30
    if not move and free < gb + 1:
        print(f"Refusing: {gb:.1f} GB model, only {free:.1f} GB free.")
        print("Use --move to relocate it instead of copying.")
        return 1

    print(f"{'move' if move else 'copy'}  {src.name}  {gb:.2f} GB")
    try:
        if move:
            shutil.move(str(src), str(dest))
        else:
            shutil.copy2(str(src), str(dest))
    except Exception as e:
        print(f"Failed: {e}")
        return 1
    print(f"ok    {dest.name}")
    print("Restart The Hub - it will appear in the model dropdown.")
    return 0


def download(repo: str, fname: str, rename: str | None, sha: str | None) -> int:
    dest = _dest_for(rename or fname)
    if dest is None:
        return 1
    if dest.exists():
        print(f"Already present: {dest.name}")
        return 1

    url = f"https://huggingface.co/{repo}/resolve/main/{fname}?download=true"
    print(f"repo : {repo}\nfile : {fname}\nsave : {dest.name}\n")

    r = subprocess.run(["curl.exe", "-L", "--fail", "--retry", "3",
                        "--continue-at", "-", "-o", str(dest), url], shell=False)
    if r.returncode != 0:
        print(f"\nDownload failed. Check https://huggingface.co/{repo}/tree/main")
        if dest.exists() and dest.stat().st_size < 50_000_000:
            dest.unlink()
        return 1

    mb = dest.stat().st_size / 1048576
    if mb < 20:
        dest.unlink()
        print(f"\nOnly {mb:.1f} MB - that was an error page, not a model.")
        return 1
    print(f"\nOK  {dest.name}  {mb:.1f} MB")

    if sha:
        h = hashlib.sha256()
        with dest.open("rb") as f:
            for blk in iter(lambda: f.read(1 << 20), b""):
                h.update(blk)
        got = h.hexdigest()
        print("SHA256 verified." if got.lower() == sha.lower()
              else f"SHA256 MISMATCH\n  got  {got}\n  want {sha.lower()}")

    print("Restart The Hub - it will appear in the model dropdown.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("repo", nargs="?", help="e.g. LiquidAI/LFM2.5-2.6B-GGUF")
    ap.add_argument("file", nargs="?", help="e.g. LFM2.5-2.6B-Q4_K_M.gguf")
    ap.add_argument("--import", dest="src", default=None,
                    help="copy a .gguf already on this machine")
    ap.add_argument("--all", action="store_true",
                    help="with --import on a folder, take every model in it")
    ap.add_argument("--move", action="store_true",
                    help="with --import, move instead of copy")
    ap.add_argument("--as", dest="rename", default=None,
                    help="save under a clearer name")
    ap.add_argument("--sha256", default=None, help="verify the download")
    a = ap.parse_args()

    if a.src:
        return import_local(Path(a.src).expanduser(), a.rename, a.move, a.all)
    if a.repo and a.file:
        return download(a.repo, a.file, a.rename, a.sha256)
    ap.print_help()
    print("\nCurrently installed:")
    for m in core.models() or []:
        print(f"  {m['name']}  {m['size_mb']} MB")
    if not core.models():
        print("  (none yet - run INSTALL.bat)")
    return 0




# ═══════════════════════════════════════════════════════════════════════════
# §  VISION PAIRS
#
# A vision model is TWO files and both must be downloaded. The Hub pairs
# them automatically once they are in llm/models, but nothing can pair a file
# that was never fetched - which is exactly how a model library ends up with
# seven GGUFs and no sight.
#
# These are the ggml-org prebuilt pairs, small enough to run as a HELPER
# beside a main model on a 16 GB machine with a 4 GB card. The main model
# keeps the GPU; the helper runs on the CPU.
# ═══════════════════════════════════════════════════════════════════════════

VISION_PAIRS = {
    # ── PROJECTOR ONLY ────────────────────────────────────────────────────
    # For a model you ALREADY have that is natively multimodal but arrived
    # without its vision encoder. Qwen3.5 is the common case: the whole
    # family - 0.8B, 2B, 4B, 9B - is natively vision-language with thinking
    # and tool calling, and the GGUF repos ship the projector as a SEPARATE
    # file that is easy to miss. A Qwen3.5 GGUF with no mmproj beside it is
    # not a text-only model; it is a vision model missing one file.
    #
    # The projector is saved as <your-model>.mmproj.gguf so The Hub pairs
    # it without any renaming. unsloth's own filename is a bare
    # "mmproj-F16.gguf", which says nothing about which model it belongs to.
    "qwen35-9b-vision": {
        "repo": "unsloth/Qwen3.5-9B-GGUF",
        "model": None,                      # projector only
        "mmproj": "mmproj-F16.gguf",
        "pair_with": "Qwen3.5-9B",
        "mb": 918,
        "note": "vision for any Qwen3.5-9B you already have, incl. uncensored",
    },
    "qwen35-4b-vision": {
        "repo": "unsloth/Qwen3.5-4B-GGUF",
        "model": None,
        "mmproj": "mmproj-F16.gguf",
        "pair_with": "Qwen3.5-4B",
        "mb": 700,
        "note": "vision for any Qwen3.5-4B you already have",
    },

    # ── COMPLETE PAIRS ────────────────────────────────────────────────────
    "smolvlm": {
        "repo": "ggml-org/SmolVLM2-500M-Video-Instruct-GGUF",
        "model": "SmolVLM2-500M-Video-Instruct-Q8_0.gguf",
        "mmproj": "mmproj-SmolVLM2-500M-Video-Instruct-Q8_0.gguf",
        "mb": 600,
        "note": "backup helper only - smallest thing that can look at a picture",
    },
    "moondream": {
        "repo": "ggml-org/moondream2-20250414-GGUF",
        "model": "moondream2-text-model-f16_ct-vicuna.gguf",
        "mmproj": "moondream2-mmproj-f16-20250414.gguf",
        "mb": 1900,
        "note": "backup helper - better at reading text in images",
    },
    "qwen3vl-4b": {
        "repo": "Qwen/Qwen3-VL-4B-Thinking-GGUF",
        "model": "Qwen3VL-4B-Thinking-Q4_K_M.gguf",
        "mmproj": "mmproj-Qwen3VL-4B-Thinking-F16.gguf",
        "mb": 3600,
        "note": "full model: vision + thinking + tools, ~2.5 GB + projector",
    },
}


def list_vision() -> None:
    print("\n  A vision model is TWO files: the model and its projector.\n")
    print("  ADD SIGHT TO A MODEL YOU ALREADY HAVE")
    for key, v in VISION_PAIRS.items():
        if v["model"] is None:
            print(f"    {key:18} ~{v['mb']/1000:.1f} GB   {v['note']}")
    print("\n  COMPLETE MODELS")
    for key, v in VISION_PAIRS.items():
        if v["model"] is not None:
            print(f"    {key:18} ~{v['mb']/1000:.1f} GB   {v['note']}")
    print("\n  get_model.py vision smolvlm      downloads the pair\n")
    print("  Once both files are in llm/models, The Hub finds them by")
    print("  itself. A model that has no projector of its own uses this one")
    print("  to look at pictures; a model that CAN see is never sent through")
    print("  it, because looking beats reading someone else's description.\n")


def _models_on_disk() -> list:
    try:
        from core import MODELS
        return [p for p in sorted(MODELS.glob("*.gguf"))
                if "mmproj" not in p.name.lower()]
    except Exception:
        return []


def get_vision(key: str) -> int:
    v = VISION_PAIRS.get(key)
    if v is None:
        print(f"Unknown: {key!r}")
        list_vision()
        return 1

    # PROJECTOR ONLY: find the model it belongs to and save the projector
    # under a name The Hub will pair automatically. The repo filename is
    # a bare "mmproj-F16.gguf" and would sit unmatched forever.
    if v["model"] is None:
        want = v["pair_with"].lower()
        hits = [p for p in _models_on_disk() if want in p.stem.lower()]
        if not hits:
            print(f"\nNo {v['pair_with']} model found in llm/models.")
            print("This download is the vision encoder for a model you "
                  "already have, not a model on its own.")
            for p in _models_on_disk():
                print(f"   present: {p.name}")
            return 1
        if len(hits) > 1:
            print(f"\nSeveral {v['pair_with']} models are present:")
            for p in hits:
                print(f"   {p.name}")
            print("The projector is saved for the first one; copy it "
                  "alongside the others under the same <model>.mmproj.gguf "
                  "name if you want them all to see.")
        target = hits[0]
        rename = target.stem + ".mmproj.gguf"
        print(f"\n{key} - vision encoder for {target.name}")
        print(f"about {v['mb']} MB, saved as {rename}\n")
        rc = download(v["repo"], v["mmproj"], rename, None)
        if rc in (0, 1):
            print(f"\n{target.name} can now see. Restart The Hub - the "
                  f"sight line in Settings will confirm it.")
        return 0

    print(f"\n{key} - two files, about {v['mb']/1000:.1f} GB total\n")
    rc = download(v["repo"], v["model"], None, None)
    if rc not in (0, 1):
        return rc
    rc2 = download(v["repo"], v["mmproj"], None, None)
    print("\nBoth files are in llm/models." if rc2 in (0, 1)
          else "\nThe projector did not download - without it the model "
               "cannot see.")
    return 0


# ── entry point, at the END so everything above it exists ─────────────────
#
# It was above the vision section, so `get_model.py vision smolvlm` reached
# an argparse that had never heard of it. A module runs top to bottom; the
# dispatcher has to be last.

if __name__ == "__main__":
    import sys as _sys
    if _sys.argv[1:2] == ["vision"]:
        raise SystemExit(list_vision() or 0 if len(_sys.argv) < 3
                         else get_vision(_sys.argv[2]))
    raise SystemExit(main())
