"""Shared offline generator helpers for The Hub.

The main Nova model is never the generator. Local generator backends are
optional capabilities discovered at runtime. Generated assets are written to
Playground first and can be inspected by Nova before an explicit Vault save.
"""
from __future__ import annotations

import base64
import json
import os
import subprocess
import time
import urllib.parse
import urllib.request
from pathlib import Path

import core
import playground
import runtime

COMFY_PORT = int(os.environ.get("HUB_COMFYUI_PORT", "8188"))


def comfy_available() -> dict | None:
    url = f"http://127.0.0.1:{COMFY_PORT}/system_stats"
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            if r.status == 200:
                return {"provider": "comfyui", "host": "127.0.0.1", "port": COMFY_PORT}
    except Exception:
        return None
    return None


def _request(provider: dict, path: str, *, data=None, headers=None, timeout=30, method=None):
    url = f"http://{provider['host']}:{provider['port']}{path}"
    req = urllib.request.Request(url, data=data, headers=headers or {}, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def upload_image(provider: dict, path: Path) -> str:
    raw = path.read_bytes()
    boundary = f"----thehub{os.urandom(8).hex()}"
    body = bytearray()
    body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"image\"; filename=\"{path.name}\"\r\nContent-Type: application/octet-stream\r\n\r\n".encode()
    body += raw
    body += f"\r\n--{boundary}\r\nContent-Disposition: form-data; name=\"overwrite\"\r\n\r\ntrue\r\n--{boundary}--\r\n".encode()
    _, out = _request(provider, "/upload/image", data=bytes(body),
                      headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
                      timeout=60, method="POST")
    obj = json.loads(out.decode("utf-8", "replace"))
    name = obj.get("name")
    if not name:
        raise RuntimeError("ComfyUI did not return an uploaded image name")
    return str(name)


def _replace_tokens(obj, *, prompt: str, negative_prompt: str = "", input_image: str | None = None):
    if isinstance(obj, dict):
        return {k: _replace_tokens(v, prompt=prompt, negative_prompt=negative_prompt, input_image=input_image) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_replace_tokens(v, prompt=prompt, negative_prompt=negative_prompt, input_image=input_image) for v in obj]
    if isinstance(obj, str):
        return (obj.replace("{{PROMPT}}", prompt)
                   .replace("{{NEGATIVE_PROMPT}}", negative_prompt)
                   .replace("{{INPUT_IMAGE}}", input_image or ""))
    return obj


def run_comfy(*, prompt: str, workflow: dict, input_image: Path | None = None,
              output_exts: set[str], timeout: int = 3600) -> tuple[bytes, str, dict]:
    provider = comfy_available()
    if not provider:
        raise RuntimeError("no local ComfyUI generator is reachable on 127.0.0.1:8188")
    img_name = None
    if input_image is not None:
        img_name = upload_image(provider, input_image)
    graph = _replace_tokens(workflow, prompt=prompt, input_image=img_name)
    cid = f"hub-{int(time.time()*1000)}"
    payload = json.dumps({"prompt": graph, "client_id": cid}).encode()
    _, queued = _request(provider, "/prompt", data=payload,
                         headers={"Content-Type": "application/json"}, timeout=30, method="POST")
    q = json.loads(queued.decode("utf-8", "replace"))
    pid = q.get("prompt_id")
    if not pid:
        raise RuntimeError("ComfyUI did not return a prompt id")

    deadline = time.time() + timeout
    history = None
    while time.time() < deadline:
        try:
            _, body = _request(provider, f"/history/{urllib.parse.quote(pid)}", timeout=10)
            history = json.loads(body.decode("utf-8", "replace"))
            if pid in history:
                break
        except Exception:
            pass
        time.sleep(1.0)

    if not history or pid not in history:
        raise RuntimeError("local generator timed out before completion")
    record = history[pid]
    outputs = record.get("outputs") or {}
    candidates = []
    for node in outputs.values():
        for key in ("images", "gifs", "videos", "files", "meshes"):
            for item in node.get(key) or []:
                if isinstance(item, dict) and item.get("filename"):
                    candidates.append(item)
    for item in candidates:
        ext = Path(item["filename"]).suffix.lower()
        if ext in output_exts:
            qs = (f"?filename={urllib.parse.quote(item['filename'])}"
                  f"&subfolder={urllib.parse.quote(item.get('subfolder',''))}"
                  f"&type={urllib.parse.quote(item.get('type','output'))}")
            _, raw = _request(provider, "/view" + qs, timeout=120)
            return raw, item["filename"], {"provider": "comfyui", "prompt": prompt, "prompt_id": pid}
    raise RuntimeError(f"generator completed but returned no supported output ({sorted(output_exts)})")


def run_exclusive(fn):
    """Run a large local generator while preserving the selected Nova model."""
    state = runtime.state()
    was_running = state.get("status") not in ("stopped", "error")
    selected_model = state.get("model")
    if was_running:
        runtime.stop()
    try:
        return fn()
    finally:
        if was_running and selected_model:
            cfg = core.load().get("runtime", {})
            runtime.start(selected_model, cfg)


def _safe_filename(filename: str) -> str:
    name = Path(str(filename).replace("\\", "/")).name
    name = "".join(c if (c.isalnum() or c in "._-() ") else "_" for c in name)
    return name.strip(" .") or "generated"


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(2, 10000):
        candidate = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not candidate.exists():
            return candidate
    raise RuntimeError("too many generated files with that name")


def save_unique_playground(filename: str, data: bytes) -> Path:
    safe = _safe_filename(filename)
    if not Path(safe).suffix:
        raise ValueError("generated output needs a file extension")
    target = _unique_path(playground.ROOT / safe)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return target


def run_local_ai_command(program: str, args: list[str], timeout: int = 3600) -> subprocess.CompletedProcess:
    """Explicitly named local generator execution path for installed offline AI tools."""
    return subprocess.run([program, *args], cwd=str(playground.ROOT), capture_output=True, timeout=timeout, text=True)
