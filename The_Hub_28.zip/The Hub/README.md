# The Hub

**The Hub is The Hearth, carried forward.** Not a rival to it and not a
rewrite of it - the next version, built from the files that were already
working, keeping what they got right and fixing what they got wrong. It
installs on its own and needs no ancestor present, the same way Vera is
Luminova and still installs from nothing.

The line runs: **Emergence → Cairn → The Hearth → The Hub.**

There was one more step between the last two that is not in that line.
HUB-ZERO was an attempt at this same jump that did not survive testing; what
it got right has been kept, what it broke has been fixed, and the whole of
it is written down in `DECISIONS.md` under ADR-16 to ADR-24 so the same
ground is not lost twice.

What changed since Cairn, in one list:

| | Cairn | The Hub |
|---|---|---|
| memory | ten sephirot holding flat lists | ten sephirot, each one a **living tree** - weight, decay, pins, branches |
| knowledge | none | **Da'at**, the sephira at the centre, holding what was worked out |
| forgetting | dropped on the floor | falls to **ash**, kept forever, still searchable |
| organising | a second 350M model on its own port | **the model already loaded**, in idle gaps |
| what the model writes | `remember(where, text)` - it chose the branch | nothing; the system records, the model **searches** |
| search | web only | a **search engine over everything ever recorded** |
| prompt size | unbounded - this is what caused `error: 400` | **budgeted against n_ctx** every turn |
| files | none | a **vault** you drop things into |
| sight | none | **probed at load**; images, PDFs, 3D models and video measured offline |
| settings | tool checkboxes | **one switch** - web search. The rest is automatic. |
| research | a line in the system prompt | a **deterministic preflight** the model cannot skip |
| tools | a registry that ran what it recognised | a **default-deny gate** |
| repair | none | **rebuild from the event log** |
| shutdown | `taskkill /IM llama-server.exe` - killed every model on the machine | **port-scoped**, touches nothing else |


A local AI that runs entirely on your own machine. Nothing you say leaves
this computer unless you turn on web search, and you are told when that
happens.

    INSTALL.bat        set it up      (~24 GB, the generators are most of it)
    HUB.bat            start it       browser opens at 127.0.0.1:8440
    STOP.bat           stop it
    TEST.bat           check every subsystem

### The model it thinks with

`Huihui-Qwen3-VL-4B-Thinking-abliterated` — Q4_K_M, 2.33 GB, with its own
433 MB projector. Chosen because it is all four at once on a 4 GB card:

- **sees** — Qwen3-VL, projector ships in the same repo
- **thinks** — it *is* the reasoning edition, not a flag on a model that lacks one
- **uses tools** — "invokes tools, completes tasks" is a headline feature
- **uncensored** — huihui-ai abliterated; nothing in The Hub filters anything

It replaced Gemma 4 E2B, which has vision and tools and good abliterated
builds but no reasoning mode — so the thinking flag The Hub sends every turn
did nothing. Two out of three.

It is also **1.4 GB smaller** than what it replaced, which on a 4 GB card is
a real difference — though not the one this line used to claim. The spilling
was never the KV cache. It was the weights: `-ngl` was not being sent, so
llama.cpp put every layer on the card whatever the card could hold, and the
NVIDIA driver quietly paged the excess back over PCIe instead of failing.
The Hub now works out the offload and sends it, so a model that is too big
for the card runs partly on the CPU rather than thrashing. See §2.1 of
`HANDOFF.md` and ADR-142.

Any GGUF already in `llm\models` stays in the dropdown. This is what a fresh
install downloads, not what the application permits.

### Erasing memory

Settings has five red buttons. Every one of them opens a second screen first,
which counts what would actually go — *412 memories, 38 conversations, 1,204
events* — and asks. Esc, clicking outside, and No all close it; only Yes
deletes, and the server refuses a confirmation it did not issue, one already
used, one older than two minutes, or one staged for a different scope. A
stray click cannot reach the delete.

| | goes | survives |
|---|---|---|
| Conversations | transcripts | everything Nova learned from them |
| Ash | what already faded | nothing live |
| Recent working memory | the moving frontier | trees and event log |
| All memories | the trees | **the event log — Rebuild restores it** |
| Erase everything | all of it, and the log | nothing |

Config, models, the Vault and the Playground are never touched.

### Making things

Images, video and 3D models are generated **on this machine**, with no ComfyUI
and no Automatic1111 required — both are supported as optional upgrades if you
already run one.

| | how |
|---|---|
| images | stable-diffusion.cpp. DreamShaper XL Turbo by default (SDXL, native 1024, 8 steps), SD1.5 as fallback. Text→image and image→image. |
| video | stable-diffusion.cpp, Wan 2.1 T2V 1.3B. Short clips, slowly. |
| 3D, neural | trellis.cpp, image → textured GLB. Wants more card than 4 GB has; it is installed and tried, and falls back cleanly when it cannot run. |
| 3D, always | built in. Exact watertight geometry from a shape description, or a relief from any image. No download, no VRAM, instant. |

**One at a time, and Nova stops while one runs.** The card holds one large
model. A generation request pauses the conversation and resumes it afterwards;
a whole pipeline (text → image → mesh) stops Nova once, not once per step.

For anything with dimensions — a bracket, a plate, a spacer, a stand — the
built-in path is the better answer, not the fallback: Nova writes the numbers,
The Hub builds the solid, and what comes out is measured, watertight and
printable rather than approximately shaped.

Generated files land in the Playground **and appear in the conversation** —
an image as an image, a video with a player, a 3D model as its six rendered
views. They are named `<date> <time> <subject>`, so
`2026-09-01 1432 girl swing sunset beach.png` rather than `generated (3).png`,
which is what lets you and Nova refer back to one of them.

Settings are chosen per checkpoint: an SDXL turbo model gets 8 steps at CFG 2,
an SD1.5 model gets 28 at CFG 7 with a real negative prompt and a second
high-res pass for faces. Running either at the other's numbers produces
garbage, which is why there is no single default.

Any Stable Diffusion or Flux checkpoint dropped into `llm\gen\models` is
picked up automatically, the same way `llm\models` works for language models.
Nothing is whitelisted and no filter is applied to what a generator produces.

Windows 11. **No system Python needed** - INSTALL.bat downloads a private
Python 3.13 into `.runtime\python` and every launcher uses it. An NVIDIA card
is used if present and is not required.

The Hub runs on ports **8440 / 8100 / 8101 / 8102 / 8103**, so it can sit beside
Cairn (8420 / 808x) and The Hearth (8430 / 809x) on one machine without any
of them noticing each other. `STOP.bat` only ever touches The Hub's four.

---

## What it is

The assistant is called **Nova**. The Hub is the application around her:
the interface, the memory, the senses, the runtime that loads her — and the
layer that checks her work.

That last part is the reason this exists. A local model is small, and a
small model forgets to check things, mis-files what it remembers, and can be
talked into doing what a web page tells it. The usual fix is to write "please
remember to check" into the system prompt, which is asking the model to
notice its own blind spot.

The Hub does it structurally instead:

```
        you
         |
         v
  HUB PREFLIGHT      does this depend on the outside world?
         |              decided here, before Nova runs, and
         |              Nova cannot opt out by not asking
         v
       NOVA             the model. Answers, and proposes tools.
         |
         v
  HUB GATE           default deny. execute / confirm / refuse
         |
         v
       TOOL
         |
         v
  HUB POSTFLIGHT     the only way a result gets back into context
         |
         v
      answer
```

Nova is the agent. The Hub is what makes the agent accountable.

---

## Memory

Memory is **one** Tree of Life. Ten sephirot, each a different **kind** of
memory. That much is inherited from Cairn.

What is new is that each sephira is **alive**. A memory is a leaf with a
weight. Time takes weight away; being recalled gives it back. Branches grow
inside a sephira as its subject matter grows. Identity and boundaries are
pinned and never fade.

```
  KETER     who you are            pinned, never decays
  CHOKMAH   things you worked out  slow
  BINAH     how your work fits     slow
  CHESED    what you like          slow
  GEVURAH   your rules and limits  pinned, never decays
  TIFERET   what you are on now    fast - focus is meant to move
  NETZACH   where you are headed   slow
  DA'AT     what was worked out    slow  - the hidden one, in the middle
  HOD       concrete facts         normal
  YESOD     conversation digests   flowing
  MALKUTH   live sessions          10 days, then digested
```

**Nothing is ever deleted.** A leaf that fades is written to
`data/ash/ash.jsonl` — the Tree of Death — and that file is never rewritten.
Decay changes what is in mind. It does not change what happened. Something
found to be wrong keeps its place and gains a `disproven` mark, because
knowing you were wrong is worth more than never having heard it.

**Where a memory goes is decided in Python**, not by the model. Asking a
350M model to sort statements into Hebrew category names does not work; it
takes the first option every time, and the crown of the tree fills up with
facts about graphics cards. So Nova says what is worth keeping and
`classify.py` decides where it belongs — and when it cannot tell, it parks
the statement rather than guessing.

**All of it can be rebuilt.** Every change is appended to
`data/events/events.jsonl`. Delete the entire `data/tree` directory and press
*Rebuild memory from events* in the HUB tab. It comes back.

### What reaches Nova, and when

Three blocks, and the difference between them matters.

**[earlier conversations]** — the last ten rounds of each of the last two
conversations, in full, every turn. Not a summary: the words that were
actually said. This is what answers "the last prompt", "before that" and
"what did we say". Every conversation was always saved to `data/sessions`;
until this release nothing ever read one back, so Nova could be asked to
remember something she had never been given.

**[what is current]** — one line per subject, the newest thing known about
it, with anything already marked superseded shown underneath as "was". This
is where "the latest", "the newest version" and "what changed" are answered.
Ranking cannot answer those: relevance has no opinion about which of two
matching memories came second.

**[what you remember]** — retrieval for this particular question. Every line
arrives with its date, how it was learned and how well it is known:

```
- (2026-09-06, 3 days ago, they told you, known well) the card has 4 GB
- (2026-08-14, 3 weeks ago, you worked this out, said once, NOT confirmed)
  the turbo preset renders at 768
```

A model told "you worked this out once, not confirmed" can hedge. Told the
same sentence bare, it cannot — it has nothing to hedge with. That is the
difference between memory and confident invention.

### Ending a conversation

A conversation ends itself after a set number of rounds — *rounds per
conversation* in Settings, 20 by default, 0 to never. The transcript is
**kept**, not deleted: it becomes one of the earlier conversations Nova reads
from tomorrow, and the next one starts with the window empty again.
Refreshing the page no longer loses your place; the server hands the
conversation back.

### The Failure button

One button in the header, and it is not "new chat". Press it when a
conversation has gone too far wrong to be worth fixing in place — the subject
is mangled, she has the wrong end of it, starting again is cheaper than
digging out. It ends the conversation the same way, keeps the transcript, and
**marks** it. The next conversation is told plainly that you stopped that one,
and its last rounds are the clearest thing she will ever be told about what
going wrong looks like. It takes two presses, so a stray click cannot mark a
conversation that was going fine.

Everything you do not mark stays grey. Not good, not bad — unjudged. She is
told that in those words, because almost every conversation is unmarked and a
model that reads silence as praise makes the mark worth nothing. The count of
failures is yours to see, not hers: it is a judgement about her rather than
about one piece of work.

---

## Knowledge lives in the middle of the tree

Da'at is the hidden sephira at the centre of a Tree of Life, and its name
means knowledge. That is where what-was-worked-out goes - branches for
mathematics, science, art and craft, routed by subject.

Earlier drafts of this kept knowledge in a **second, separate tree**, copied
from Vera. That was right for Vera and wrong here: her camera planted 15,224
observations into the same pool as thirty conversations and drowned
knowledge completely, and a separate tree was the cheapest fix. But the real
fix for drowning is a limb with its own weighting, and this tree already has
a place for knowledge in the middle where the paths cross.

So there is one tree. Everything ages by the same rules, is found by the same
search, and rebuilds from the same event log.

## Nova does not write her own memory

Cairn gave the model a `remember` tool and asked it to pick which sephira.
That put the model in charge of its own memory, which is wrong twice: it
writes down what it happened to notice rather than what was said, and it can
write something false into durable storage.

The Hub records everything by itself. What Nova gets instead is
`search_memory` - phrases, sentences and words, across living memory, faded
memory, past conversations and your files. She asks; the engine ranks. The
model consumes search results, it does not curate them.

## Your files

There is a `vault\` folder beside the application. Drop anything in it -
through the interface or straight into the folder in Explorer, both work -
and it is catalogued, searchable, and displayable: images and video render
inline, 3D models and documents open, text files can be read on request.

Nothing there is uploaded anywhere, and nothing there is ever deleted or
rewritten by the application. It is the one folder that is yours rather than
derived.

## The three checks

**Preflight** decides whether your question depends on something that
changes. Suppressors run first: anything about you, anything about what Nova
remembers, anything the clock or calculator answers exactly, and anything
creative is never searched. If research is needed, The Hub performs it and
hands Nova the evidence. Every decision is logged to `data/logs/research.log`.

**The gate** authorises every tool call. Unknown tools are refused by
default. Searches are rate-limited. Repeated identical calls are stopped.
Arguments that read like instructions are refused, because arguments carry
data, not directions. Anything that writes to memory is **staged** — you get
a Keep / Discard button, and the reply keeps streaming while you decide.

**Postflight** is the only route a tool result takes back into Nova's
context. It labels provenance, and once untrusted web content has entered a
turn, no further searches run in that turn. A poisoned page that can induce a
second search controls what gets sent to a third party, and that is a channel
out of a machine whose whole promise is that nothing leaves it.

---

## Files

```
  core.py        paths, config, the sandbox, the ports
  events.py      append-only history; everything else derives from it
  grove.py       Leaf / Branch / Limb / ActiveTree - how a memory lives
  hold.py        how firmly a memory is held, and how it fades
  memory.py      the ten sephirot, the curator, recall, the reality frame
  growth.py      when a branch should become a limb, or two become one
  carryover.py   the last rounds of the last two conversations
  timeline.py    what is current, by subject, in time order
  focus.py       what this turn is about; the per-question memory slice
  classify.py    where a memory goes. Deterministic.
  knowledge.py   the Knowledge Tree - four domains
  research.py    the preflight - outward, and inward
  policy.py      the capability gate
  tools.py       clock, calculator, remember, web search
  runtime.py     owns every llama.cpp and whisper.cpp process
  server.py      the controller. Assembles the prompt, wires the layers.
  ui.html        the interface
  verify.py      does every subsystem actually work
```

Standard library only. No `pip install`. It runs with the network unplugged.

---

## Adding models

The default install is small on purpose: a 2.6B for Nova and a 350M for
background memory work. That fits comfortably on 16 GB with 4 GB of VRAM and
leaves room for both to run at once.

```
  python get_model.py mradermacher/Huihui-Qwen3-VL-4B-Thinking-abliterated-GGUF \
                      Huihui-Qwen3-VL-4B-Thinking-abliterated.Q4_K_M.gguf
  python get_model.py --import "C:\path\to\a-model.gguf"
  python get_model.py --import "C:\path\to\models" --all
```

Imported models are **copied**, not linked. Everything The Hub needs lives
in its own folder, so moving or copying the folder takes the application and
its memory together.

New models appear in the dropdown after a restart. The Hub refuses to
start a model that will not fit rather than letting Windows swap, because on
a 16 GB laptop that is not an error message, it is a hard reset.

---

## If something is wrong

Run `TEST.bat`. It reports in three words and never skips silently:

```
  ERROR      a required component is missing or broken
  OPTIONAL   not installed, and that is fine
  EXCLUDED   deliberately left out, with a reason
```

Logs are in `data/logs/`: `llama.log`, `curator.log`, `whisper.log`,
`research.log`, `policy.log`, `memory.log`, `knowledge.log`.

---

## Relationship to Cairn

The Hub is a **separate application**. It uses Cairn's architecture,
because that architecture is tested and works, and none of Cairn's state.
Its own folder, its own ports, its own `data/`, its own models. It does not
read anything Cairn owns, does not import from it, and does not need it
installed.

`STOP.bat` kills only the four ports The Hub declares, after checking the
image name. Cairn's shutdown kills every `llama-server.exe` on the machine;
copying that here would have taken Cairn's model down mid-sentence.

Read `ARCHAEOLOGY.md` for what was taken from where, `INVENTORY.md` for every
component classified KEEP / ADAPT / MERGE / REPLACE / REMOVE / NOT YET, and
`DECISIONS.md` for why each architectural choice was made and what would make
it worth changing.
## Sight

A vision model in llama.cpp is **two files**, not one:

```
llm/models/SmolVLM2-500M-Video-Instruct-Q8_0.gguf
llm/models/mmproj-SmolVLM2-500M-Video-Instruct-Q8_0.gguf
```

The second is the **projector**. It encodes an image into something the
language model can read, and it is trained against ONE architecture. A
projector from another model does not degrade gracefully - it is rejected,
or it produces embeddings the model cannot interpret.

**So a model can see if and only if a matching projector sits beside it.**
No setting changes that. `Qwen3.5-9B-Uncensored` is not `Qwen3-VL`; it has no
projector and never will.

### What The Hub does about it

```
    model has a matching projector ->  the image goes straight to that model
    model has no projector       ->  the model remains text-only; the image
                                     may be measured, but is never described
                                     by a second model
```

There is **no vision helper/side-car**. The selected model is the only model
process running. If you want vision, select a model marked **VISION** in the
model dropdown; its matching projector is loaded automatically.

### Your model may already be able to see

**Qwen3.5 is natively multimodal.** The whole family - 0.8B, 2B, 4B, 9B -
has vision, thinking and tool calling built in. So does Qwen3-VL, Gemma 3,
and a growing number of others. The GGUF repositories ship the vision
encoder as a **separate file**, and it is easy to download the model without
it.

A Qwen3.5 GGUF sitting alone is not a text-only model. It is a vision model
missing one file.

```
get_model.py vision qwen35-9b-vision
```

That fetches the ~918 MB projector and saves it as
`<your-model>.mmproj.gguf`, which The Hub pairs automatically. The
repository's own filename is a bare `mmproj-F16.gguf` - it says nothing about
which model it belongs to, so left as-is it would sit there unmatched.

**Naming.** Three conventions all work:

```
mmproj-gemma-3-4b-it-Q8_0.gguf        descriptive - matched by name
Qwen3.5-9B-Uncensored-Q4_K_M.mmproj.gguf   the twin convention
mmproj-F16.gguf                       generic - only paired when it is
                                      alone with one model, because
                                      otherwise pairing it is a guess
```

Quantisation tags are never treated as evidence. `Qwen3.5-9B-Uncensored-Q4_K_M`
and `Llama-3.1-8B-Uncensored-Q4_K_M` share "uncensored" and "q4"; pairing on
that produced a projector attached to the wrong architecture.

### Thinking

Qwen3.5's small models ship with **reasoning disabled by default**. The
The Hub sends `chat_template_kwargs.enable_thinking` on every request, so a
model that can reason does. Templates that do not mention it ignore it.
Turn it off with `sampling.thinking` if you want faster, shorter answers.

### Getting sight

```
get_model.py vision              lists the pairs
get_model.py vision smolvlm      downloads both files, about 0.6 GB
```

These downloads provide complete selectable VLMs and their matching projector
files. They are not helper models. Select the VLM as Nova's main model and
The Hub runs that model directly.

### How capability is decided

Probed at load, never assumed, using only fields llama.cpp documents:
`GET /props` for `modalities.vision`, then `GET /v1/models` for
`input_modalities` - which is what the llama.cpp server README tells clients
to check. Then a flat red square settles it, because a model whose projector
is loaded but broken does not error; it describes an image it never saw.

**The camera.** The eye button captures from any video device. Permission is
requested with an unconstrained call first, because a device id cannot be
known until permission exists - asking for a specific camera before that is
what produced `OverconstrainedError`. Failures name the cause: permission
denied, no camera, held by another app, or not a secure context. Open The
The Hub at `http://127.0.0.1:8440`; the machine's network address is not a
secure context and the browser will not hand over a camera there.


## The Hub current control layer

`KEY_LEGEND.md` is the indexed local guide for nonstandard tools. Nova retrieves only the relevant entry with `read_key`; the entire key is not embedded in every prompt. `pass_off` is an internal next-round tool for self-review, correction, and continuation. Web research stores complete result sets locally and exposes later pages through `web_search_more`, so evidence is not silently discarded at the first page boundary. Nova theme control is user-gated in Appearance & RGB.
