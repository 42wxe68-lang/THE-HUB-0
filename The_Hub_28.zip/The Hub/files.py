"""
files.py - one namespace. Name a file, get the file.

WHY THIS EXISTS.

    "What if we only divide the difference by files able to be edited by the
     model ... marked only by naming the file instead of leaving the
     playground and the vault in different spaces?"

Because the split was never about safety. It was about WHERE THINGS SIT, and
that is a fact about the disk, not about permission - which is why an entire
release went on failures of the form

    "the required input image, Cosmic_Forge_Base.png, was not found in the
     Playground workspace"

three times in a row, about a file that existed, while the user said so. It
was in vault/Made, because they had kept it. Nothing was unsafe. Nothing was
missing. A name failed to resolve because the model had guessed the wrong
folder, and the answer was an error instead of the file.

So the two spaces stop being two questions. There is one namespace and one
question per file:

    CAN SHE WRITE TO IT?

    hers, writable     the Playground, and vault/AI - her own working space
    the user's, read   everything else in the Vault: originals, chat
                       attachments, and anything they chose to KEEP

The permission is a property of the file, not of the folder it happens to be
in, and it travels with the name wherever it is used. "Read the user's, write
your own" is the whole rule, and it is now impossible to state it wrong by
naming the wrong space.

WORKING ON SOMETHING OF THEIRS. She never edits it in place. `bring()` copies
it into the Playground and hands back the copy - which is what the user asked
for in the same breath:

    "you can take files to copy them from the vault and paste them into the
     playground for you to use, this is for you to be able to use both file
     spaces without changing the users files, that's me."

The original is never touched. What she changes is always hers.
"""
from __future__ import annotations

import re
from pathlib import Path

import core

# Suffixes a file picks up when a name is already taken. The user's uploaded
# copy of "cosmic forge.png" landed as "cosmic forge (3).png", so the name
# the model knew and the name on disk were never going to match on a
# character-by-character test - and did not.
_COPY_N = re.compile(r"\s*\((\d+)\)$")

# Notes ABOUT a file. Never the file.
SIDECARS = (".generation.json", ".source.json", ".preview.png")

MEDIA = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif",
         ".mp4", ".webm", ".mov", ".mkv",
         ".stl", ".obj", ".glb", ".gltf", ".ply", ".3mf"}


def _bare(name: str) -> str:
    """A name with its sidecar tail and any " (2)" removed."""
    n = (name or "").strip()
    for tail in SIDECARS:
        if n.lower().endswith(tail):
            n = n[: -len(tail)]
            break
    p = Path(n)
    stem = _COPY_N.sub("", p.stem)
    return (stem + p.suffix) if p.suffix else stem


def _writable_roots() -> list:
    import playground
    import vault
    return [playground.ROOT, vault.AI_VAULT]


def writable(path) -> bool:
    """Hers to change, or the user's to leave alone."""
    try:
        p = Path(path).resolve()
    except Exception:
        return False
    for root in _writable_roots():
        try:
            if p.is_relative_to(Path(root).resolve()):
                return True
        except Exception:
            pass
    return False


def where(path) -> str:
    """A short, honest description of which part of the namespace this is."""
    import playground
    import vault
    p = Path(path)
    try:
        if p.is_relative_to(Path(playground.ROOT).resolve()):
            return "your workspace"
        if p.is_relative_to(Path(vault.AI_VAULT).resolve()):
            return "your box in the vault"
        if p.is_relative_to(Path(vault.MADE_VAULT).resolve()):
            return "kept by the user"
        if p.is_relative_to(Path(vault.CHAT_VAULT).resolve()):
            return "sent to you in chat"
        if p.is_relative_to(Path(vault.VAULT).resolve()):
            return "the user's own file"
    except Exception:
        pass
    return "elsewhere"


def find(name: str):
    """
    The file this name means, wherever it lives, or None.

    Order is deliberate: her own workspace first, because a file she is
    working on should win over one with the same name that the user kept
    last week. Then the vault, nearest match first.
    """
    import playground
    import vault
    name = str(name or "").strip()
    if not name:
        return None

    # A SIDECAR IS NEVER THE ANSWER while the thing it describes exists.
    # Naming "X.generation.json" means "the thing X" - a note about a
    # picture is not something a generator can read, and the note is right
    # there in the listing, which is exactly why it gets named.
    asked_for_note = any(name.lower().endswith(t) for t in SIDECARS)
    if not asked_for_note:
        exact = playground.resolve(name)
        if exact is not None and Path(exact).is_file():
            return Path(exact)
        direct = vault.resolve(name)
        if direct is not None and Path(direct).is_file():
            return Path(direct)

    want = _bare(name).lower()
    if not want:
        return None
    stem = Path(want).stem

    pool = []
    try:
        playground.ensure()
        pool += [f for f in Path(playground.ROOT).rglob("*") if f.is_file()]
    except Exception:
        pass
    try:
        vault.ensure()
        pool += [f for f in Path(vault.VAULT).rglob("*") if f.is_file()]
    except Exception:
        pass

    def rank(f: Path) -> tuple:
        # A real file beats a note about one; a media file beats a stray
        # text file that happens to share a name.
        note = any(f.name.lower().endswith(t) for t in SIDECARS)
        return (note, f.suffix.lower() not in MEDIA, len(f.name))

    same, stemmed = [], []
    for f in pool:
        low = f.name.lower()
        if _bare(low) == want:
            same.append(f)
        elif Path(_bare(low)).stem == stem and f.suffix.lower() in MEDIA:
            stemmed.append(f)
    for group in (same, stemmed):
        real = [f for f in group
                if not any(f.name.lower().endswith(t) for t in SIDECARS)]
        if real:
            return sorted(real, key=rank)[0]
    # Only a note exists under that name. Hand it back rather than claiming
    # nothing is there - reading it is still useful, and open_file can.
    for group in (same, stemmed):
        if group:
            return sorted(group, key=rank)[0]
    return None


def bring(name: str):
    """
    The file, ready to work on: hers already, or a copy of theirs.

    Returns (path, note). `note` is "" when nothing had to be moved, and
    otherwise says what was copied and from where, because a file appearing
    in her workspace that she did not put there deserves a sentence.
    """
    import playground
    found = find(name)
    if found is None:
        return None, ""
    if writable(found):
        return found, ""

    playground.ensure()
    dest = Path(playground.ROOT) / found.name
    if dest.is_file():
        return dest, ""
    try:
        got = playground.copy_in(found, found.name)
        made = playground.resolve(got["name"])
        core.log_line("files",
                      f"copied {found.name} ({where(found)}) into the "
                      f"workspace")
        return Path(made), (f"copied {found.name} into your workspace from "
                            f"{where(found)} - the original is untouched")
    except FileExistsError:
        return dest, ""
    except Exception as e:
        core.log_line("files", f"could not copy {found.name} in: {e}")
        # Readable where it is. Reading the user's file was never the
        # problem; only writing to it is.
        return found, ""


def listing(limit: int = 60) -> list:
    """
    Everything she can reach, in one list, each marked with what she may do.

    One list because there is one namespace. The mark is the whole point -
    it is the only thing that was ever really different between the two
    folders, and now it is said out loud beside every name instead of being
    implied by a path.
    """
    import playground
    import vault
    rows = []
    seen = set()

    def add(f: Path):
        key = str(f.resolve()).lower()
        if key in seen or not f.is_file():
            return
        if f.name.startswith(".") or f.name.lower() == "thumbs.db":
            return                      # placeholders are not files
        seen.add(key)
        try:
            mb = round(f.stat().st_size / 1048576.0, 3)
        except Exception:
            mb = 0.0
        rows.append({"name": f.name, "size_mb": mb,
                     "can_edit": writable(f), "where": where(f),
                     "is_note": any(f.name.lower().endswith(t)
                                    for t in SIDECARS)})

    for root in (playground.ROOT, vault.AI_VAULT, vault.MADE_VAULT,
                 vault.CHAT_VAULT, vault.VAULT):
        try:
            for f in sorted(Path(root).rglob("*"),
                            key=lambda p: -p.stat().st_mtime
                            if p.is_file() else 0):
                add(f)
                if len(rows) >= limit:
                    return rows
        except Exception:
            continue
    return rows
