"""
gguf.py - read a model's own metadata instead of guessing at it.

WHY THIS EXISTS
---------------
The first version of the fit check did this:

    kv_mb = n_ctx * 0.14        # "~140 KB per 1k ctx per GB class"

That number is invented. It is not per-model, it does not know how many
layers the model has, it does not know how many KV heads, and it is wrong by
a factor of several either way depending on the architecture. A check built
on an invented constant will refuse models that run and accept models that
hang the machine, and it will do both with total confidence.

Every GGUF file states these things about itself in its header. Reading them
takes about a millisecond and removes the guess entirely:

    block_count            how many layers
    attention.head_count_kv    how many KV heads (GQA models have few)
    attention.key_length       head dimension
    embedding_length       fallback when key_length is absent

KV cache size is then exact arithmetic rather than a fudge factor:

    bytes_per_token = 2 (K and V) * layers * kv_heads * head_dim * element_size

THE FORMAT
----------
    magic     4 bytes, "GGUF"
    version   uint32
    n_tensors uint64
    n_kv      uint64
    then n_kv pairs of:  key string, value type uint32, value

Only the metadata block is read. Tensor data is never touched, so this costs
one small read regardless of whether the file is 400 MB or 40 GB.

Large arrays - a tokenizer's vocabulary is often 150,000 strings - are
skipped by seeking past them rather than materialising them, because nothing
here needs them and reading them would turn a millisecond into a second.
"""
from __future__ import annotations

import struct
from pathlib import Path

# GGUF value types
U8, I8, U16, I16, U32, I32, F32, BOOL, STR, ARR, U64, I64, F64 = range(13)

_FIXED = {U8: ("<B", 1), I8: ("<b", 1), U16: ("<H", 2), I16: ("<h", 2),
          U32: ("<I", 4), I32: ("<i", 4), F32: ("<f", 4), BOOL: ("<?", 1),
          U64: ("<Q", 8), I64: ("<q", 8), F64: ("<d", 8)}

# Bytes per element in the KV cache, including quantisation block overhead.
# q8_0 stores 32 values plus one f16 scale, so 34 bytes per 32 values.
KV_ELEMENT_BYTES = {
    "f32": 4.0, "f16": 2.0, "bf16": 2.0,
    "q8_0": 34 / 32, "q5_1": 24 / 32, "q5_0": 22 / 32, "q4_1": 20 / 32,
    "q4_0": 18 / 32,
}

# Keys worth keeping. Anything else is skipped without being decoded.
WANTED_SUFFIXES = (
    "block_count", "context_length", "embedding_length",
    "attention.head_count", "attention.head_count_kv",
    "attention.key_length", "attention.value_length",
    "expert_count", "expert_used_count", "rope.dimension_count",
    # SLIDING WINDOW. Without these the cache arithmetic below charges every
    # layer a full-length cache, which for a Gemma overstates it by about 5x.
    # See kv_mb() for what llama.cpp actually allocates.
    "attention.sliding_window", "attention.sliding_window_pattern",
    "attention.key_length_swa", "attention.value_length_swa",
    "attention.shared_kv_layers",
)

# The largest fixed-type array worth materialising. A per-layer flag or head
# count is tens of entries; a tokenizer vocabulary is 150,000 and is still
# seeked past. Anything between is small enough that reading it costs nothing.
MAX_ARRAY = 4096

# llama.cpp pads a KV cache up to a multiple of this many cells
# (GGML_PAD(..., 256) in llama-kv-cache-iswa.cpp).
CELL_PAD = 256


def _pad(n: int, to: int = CELL_PAD) -> int:
    return ((int(n) + to - 1) // to) * to


class Meta:
    """What a model says about itself, plus the arithmetic that follows."""

    def __init__(self, path: Path, kv: dict, size_mb: float):
        self.path = path
        self.raw = kv
        self.size_mb = size_mb
        self.arch = str(kv.get("general.architecture", "") or "")
        self.name = str(kv.get("general.name", "") or path.stem)
        # Filled in by read() from the tensor table. Empty when the table
        # could not be walked, and every caller must cope with that.
        self.blocks = {}          # {block index: MB of weights}
        self.outside_mb = 0.0     # token embedding, output norm, output head

    def weights_mb_on_card(self, n_gpu_layers: int):
        """
        MB of weights that `-ngl n` really puts on the card. None if unknown.

        llama.cpp offloads from the END - `i_gpu_start = n_layer_all + 1 -
        n_gpu_layers` - and counts one slot beyond the blocks for the output
        head, which is why -ngl is usually quoted as 33 for a 32-layer model.
        The last slot is `outside_mb`, so it is the FIRST thing offloaded and
        for a large-vocabulary model it is also the biggest.
        """
        if not self.blocks:
            return None
        slots = self.layers + 1
        n = max(0, min(int(n_gpu_layers), slots))
        if n == 0:
            return 0.0
        start = slots - n
        mb = sum(v for k, v in self.blocks.items() if k >= start)
        if start <= self.layers:
            mb += self.outside_mb
        return round(mb, 2)

    def _n(self, suffix: str, default=0) -> int:
        v = self.raw.get(f"{self.arch}.{suffix}", self.raw.get(suffix, default))
        try:
            return int(v)
        except (TypeError, ValueError):
            return int(default)

    @property
    def layers(self) -> int:
        return self._n("block_count")

    @property
    def heads(self) -> int:
        return self._n("attention.head_count")

    @property
    def kv_heads(self) -> int:
        # Multi-query and grouped-query models have far fewer KV heads than
        # attention heads, and that ratio IS the KV cache size. Assuming
        # kv_heads == heads overestimates a modern model's cache by 4-8x.
        return self._n("attention.head_count_kv") or self.heads

    @property
    def head_dim(self) -> int:
        k = self._n("attention.key_length")
        if k:
            return k
        emb, h = self._n("embedding_length"), self.heads
        return (emb // h) if (emb and h) else 128

    @property
    def train_ctx(self) -> int:
        return self._n("context_length")

    # ------------------------------------------------------ sliding window

    @property
    def swa_window(self) -> int:
        """Attention window in tokens, or 0 for a model that attends to all."""
        return self._n("attention.sliding_window")

    @property
    def head_dim_swa(self) -> int:
        """Sliding-window layers may carry a smaller head than full ones."""
        return self._n("attention.key_length_swa") or self.head_dim

    @property
    def kv_layers(self) -> int:
        """
        How many layers own a KV cache. Gemma 3n and Gemma 4 let later layers
        REUSE an earlier layer's cache rather than allocate one, which is
        `n_layer_kv_from_start = n_layer_all - shared_kv_layers` in
        llama-model.cpp. Absent the key, every layer owns one.
        """
        shared = self._n("attention.shared_kv_layers")
        return max(0, self.layers - shared) if shared else self.layers

    def is_swa(self, il: int) -> bool:
        """
        Is layer `il` a sliding-window layer?

        Two shapes appear in the wild and llama.cpp reads both through
        `get_key_or_arr`: a per-layer array of flags, or one number.

        A LIST is used as written. A NUMBER is read as Gemma 3's repeating
        period - `il % n < n - 1`, five of every six - which is what
        `set_swa_pattern` builds. That reading can only ever overstate the
        cache relative to "every layer is windowed", and overstating is the
        safe direction for something that decides what to put on a 4 GB card.
        """
        pat = self.raw.get(f"{self.arch}.attention.sliding_window_pattern",
                           self.raw.get("attention.sliding_window_pattern"))
        if not self.swa_window or pat is None:
            return False
        if isinstance(pat, (list, tuple)):
            return bool(pat[il]) if il < len(pat) else False
        try:
            n = int(pat)
        except (TypeError, ValueError):
            return False
        return n == 0 or (il % n) < (n - 1) if n else False

    def kv_heads_at(self, il: int) -> int:
        """head_count_kv, which is itself per-layer on some architectures."""
        v = self.raw.get(f"{self.arch}.attention.head_count_kv",
                         self.raw.get("attention.head_count_kv"))
        if isinstance(v, (list, tuple)) and il < len(v):
            try:
                return int(v[il]) or self.kv_heads
            except (TypeError, ValueError):
                return self.kv_heads
        return self.kv_heads

    # ------------------------------------------------------------ the cache

    def kv_bytes_per_token(self, kv_type: str = "f16") -> float:
        """
        K and V for every layer at full length - the WORST case, kept because
        it is the honest headline figure for a model with no sliding window
        and the right thing to print in a summary. It is NOT what a Gemma
        allocates; kv_mb() is. Budget with kv_mb().
        """
        if not (self.layers and self.kv_heads and self.head_dim):
            return 0.0
        elem = KV_ELEMENT_BYTES.get(str(kv_type).lower(), 2.0)
        return 2.0 * self.layers * self.kv_heads * self.head_dim * elem

    def kv_mb(self, n_ctx: int, kv_type: str = "f16",
              n_ubatch: int = 512) -> float:
        """
        What llama.cpp will really allocate for the cache, layer by layer.

        `llama_kv_cache_iswa` builds TWO caches and the difference is large:

            size_base = n_ctx                                  full layers
            size_swa  = PAD(min(n_ctx, n_swa + n_ubatch), 256)  windowed ones

        A windowed layer's cache stops growing once the window is covered, so
        at 32k a Gemma layer holds ~1,536 cells rather than 32,768 - and five
        layers in six are windowed. Charging all of them full length is how a
        budget decides a window is unaffordable when it is nowhere near.

        Layers that reuse another layer's cache are not charged at all, and a
        windowed layer is charged its own head size when it has one.
        """
        return self.kv_mb_layers(0, self.layers, n_ctx, kv_type, n_ubatch)

    def kv_mb_layers(self, lo: int, hi: int, n_ctx: int,
                     kv_type: str = "f16", n_ubatch: int = 512) -> float:
        """
        The cache for layers [lo, hi) only.

        llama.cpp offloads from the END - `i_gpu_start = n_layer_all + 1 -
        n_gpu_layers` - and a layer's cache lives wherever the layer lives.
        So "how much of the cache lands on the card" is a question about a
        SLICE of the layers, and with a sliding window the slice is not a
        fraction of the whole: which layers are windowed decides it.
        """
        n_ctx = max(0, int(n_ctx))
        if not self.usable or n_ctx <= 0:
            return 0.0
        elem = KV_ELEMENT_BYTES.get(str(kv_type).lower(), 2.0)
        full_cells = _pad(n_ctx)
        swa_cells = (_pad(min(n_ctx, self.swa_window + max(0, int(n_ubatch))))
                     if self.swa_window else full_cells)
        stop = max(0, min(int(hi), self.layers, self.kv_layers))
        total = 0.0
        for il in range(max(0, int(lo)), stop):
            windowed = self.is_swa(il)
            cells = swa_cells if windowed else full_cells
            head = self.head_dim_swa if windowed else self.head_dim
            total += 2.0 * cells * head * self.kv_heads_at(il) * elem
        return total / 1048576.0

    def ctx_for_budget(self, mb: float, kv_type: str = "f16",
                       n_ubatch: int = 512) -> int:
        """
        The largest context that fits in `mb` of cache. Rounded down to 512.

        Bisected against kv_mb() rather than divided by a per-token rate,
        because with a sliding window there IS no single per-token rate - the
        windowed layers stop growing and the full ones do not.
        """
        if mb <= 0 or not self.usable:
            return 0
        # lo always fits; hi is always an upper bound. Both stay multiples of
        # 512 so the midpoint can never land back on lo and stall.
        lo = 0
        hi = max(512, (self.train_ctx or 131072)) // 512 * 512
        if self.kv_mb(hi, kv_type, n_ubatch) <= mb:
            return hi
        while lo < hi:
            mid = ((lo + hi + 512) // 2) // 512 * 512
            if mid <= lo:
                break
            if self.kv_mb(mid, kv_type, n_ubatch) <= mb:
                lo = mid
            else:
                hi = mid - 512
        return max(0, lo)

    @property
    def usable(self) -> bool:
        """Did we learn enough to do real arithmetic, or should we fall back?"""
        return bool(self.layers and self.kv_heads and self.head_dim)

    def summary(self) -> str:
        if not self.usable:
            return f"{self.path.name}: metadata unreadable"
        return (f"{self.path.name}: {self.arch or '?'}, {self.layers} layers, "
                f"{self.kv_heads} kv heads x {self.head_dim}, "
                f"{self.kv_bytes_per_token()/1024:.0f} KB/token f16")


def read(path) -> Meta | None:
    """
    Read a GGUF header. Returns None if the file is not GGUF or is damaged.

    Never raises. A model whose header cannot be read is a model the caller
    falls back to estimating, not a crash on startup.
    """
    path = Path(path)
    try:
        size_mb = path.stat().st_size / 1048576.0
        with path.open("rb") as f:
            if f.read(4) != b"GGUF":
                return None
            struct.unpack("<I", f.read(4))[0]          # version
            n_tensors = struct.unpack("<Q", f.read(8))[0]
            n_kv = struct.unpack("<Q", f.read(8))[0]
            if n_kv > 100_000:
                return None                            # not a sane header

            kv = {}
            complete = True
            for _ in range(n_kv):
                key = _string(f)
                if key is None:
                    complete = False
                    break
                vt = struct.unpack("<I", f.read(4))[0]
                keep = key in ("general.architecture", "general.name",
                               "general.alignment") or \
                    any(key.endswith(s) for s in WANTED_SUFFIXES)
                val = _value(f, vt, keep)
                if keep and val is not None:
                    kv[key] = val
            meta = Meta(path, kv, size_mb)
            if complete:
                meta.blocks, meta.outside_mb = _tensors(f, n_tensors, kv,
                                                       path.stat().st_size)
            return meta
    except Exception:
        return None


def _tensors(f, n_tensors: int, kv: dict, file_bytes: int) -> tuple:
    """
    Per-layer weight sizes, in MB, taken from the tensor table.

    WHY BOTHER, WHEN THE FILE SIZE IS RIGHT THERE

    Because "the file divided by the layer count" is not what one offloaded
    layer costs. A GGUF also holds the token embedding, which for a Gemma's
    262,144-token vocabulary is enormous and is not a layer at all. Prorating
    charges every layer a share of it and gets the per-layer figure wrong in
    the direction that matters: too small, so too many layers are offered to
    the card.

    No ggml type table is needed to size a tensor. Every tensor states its
    OFFSET into the data blob, and the blob is contiguous, so one tensor's
    size is the next one's offset minus its own - and the last one runs to the
    end of the file. Exact, and it costs one sequential read of the names.

    Returns ({block index: MB}, MB of everything that is not in a block).
    """
    infos = []
    for _ in range(min(n_tensors, 1 << 20)):
        name = _string(f)
        if name is None:
            return {}, 0.0
        nd = struct.unpack("<I", f.read(4))[0]
        if nd > 8:
            return {}, 0.0
        f.seek(8 * nd, 1)                       # dimensions
        f.read(4)                               # ggml type
        off = struct.unpack("<Q", f.read(8))[0]
        infos.append((off, name))
    if not infos:
        return {}, 0.0
    align = int(kv.get("general.alignment", 32) or 32)
    here = f.tell()
    data_start = ((here + align - 1) // align) * align
    infos.sort()
    blocks, outside = {}, 0.0
    for i, (off, name) in enumerate(infos):
        end = infos[i + 1][0] if i + 1 < len(infos) \
            else max(off, file_bytes - data_start)
        mb = max(0, end - off) / 1048576.0
        # "blk.17.attn_q.weight" -> 17. Everything else - the token embedding,
        # the output norm, the output head - belongs to the one extra layer
        # llama.cpp counts on top of block_count.
        part = name.split(".")
        if len(part) > 2 and part[0] == "blk" and part[1].isdigit():
            blocks[int(part[1])] = blocks.get(int(part[1]), 0.0) + mb
        else:
            outside += mb
    return blocks, round(outside, 2)


def _string(f):
    raw = f.read(8)
    if len(raw) < 8:
        return None
    n = struct.unpack("<Q", raw)[0]
    if n > 1 << 20:
        return None
    return f.read(n).decode("utf-8", "replace")


def _value(f, vt: int, keep: bool):
    if vt in _FIXED:
        fmt, size = _FIXED[vt]
        return struct.unpack(fmt, f.read(size))[0]
    if vt == STR:
        return _string(f)
    if vt == ARR:
        et = struct.unpack("<I", f.read(4))[0]
        n = struct.unpack("<Q", f.read(8))[0]
        if et in _FIXED:
            fmt, size = _FIXED[et]
            # A per-layer array - sliding-window flags, per-layer KV head
            # counts - is tens of entries and is the difference between real
            # cache arithmetic and a guess. A tokenizer vocabulary is 150,000
            # and is still seeked past: decoding it to discard it turns a
            # millisecond into a second.
            if keep and n <= MAX_ARRAY:
                raw = f.read(size * n)
                if len(raw) < size * n:
                    return None
                return list(struct.unpack("<" + fmt[1] * n, raw))
            f.seek(size * n, 1)
            return None
        for _ in range(n):                             # strings: no fixed size
            _value(f, et, False)
        return None
    return None                                        # unknown type, give up


def scan(models_dir) -> list:
    """Read every .gguf in a directory. Used by the runtime to plan a fit."""
    out = []
    try:
        for p in sorted(Path(models_dir).glob("*.gguf")):
            m = read(p)
            if m:
                out.append(m)
    except Exception:
        pass
    return out


if __name__ == "__main__":
    import sys
    for arg in sys.argv[1:] or ["."]:
        p = Path(arg)
        for f in ([p] if p.is_file() else sorted(p.glob("*.gguf"))):
            m = read(f)
            if not m:
                print(f"  {f.name}: not a readable GGUF")
                continue
            print(f"  {m.summary()}")
            for ctx in (4096, 8192, 16384, 32768):
                print(f"      {ctx:>6} ctx -> {m.kv_mb(ctx):7.0f} MB KV (f16), "
                      f"{m.kv_mb(ctx, 'q8_0'):7.0f} MB (q8_0)")
